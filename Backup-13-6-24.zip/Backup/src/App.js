import { useEffect } from "react"
import "./App.css"
import {
  Routes,
  Route,
  Navigate,
  useLocation,
  BrowserRouter,
} from "react-router-dom"
import { Helmet } from "react-helmet"
import SignUp from "./modules/SignUp/SignUp"
import Login from "./modules/Login/Login"
import Home from "./modules/Home/Home"
import Otp from "./components/OTP/OTP"
import { Link } from "react-router-dom"
import PrivateRoute from "./components/Layouts/PrivateRoute"
import EvQuallogo from "./assets/images/EvQuallogo.svg"
import ErrorBoundary from "./components/ErrorHandling/ErrorBoundary.js"
import Dashboard from "./modules/Dashboard/Dashboard"
import ForgotPassword from "./modules/ForgotPassword/ForgotPassword"
import DeviceView from "./modules/DeviceView/DeviceView"
import DeviceFilter from "./modules/Devices/DevicesFilter/DevicesFilter.jsx"
import ViewProfile from "./components/UserProfile/ViewProfile/ViewProfile1.jsx"
import About from "./modules/About/About"
import BigCalendar from "./modules/BigCalendar/BigCalendar.jsx"
import Calendar from "./components/Calendar/Calendar.jsx"
import DisableShortcuts from "./components/DisableShortcuts/DisableShortcuts.jsx"
import { useState } from "react"
import TestManager from "./modules/Automation/TestManager/TestManager"
import ChangePassword from "./components/UserProfile/EditProfile/ChangePassword"
import EditProfile from "./components/UserProfile/EditProfile/EditUserProfile"
import AdminHomePage from "./modules/AdminFunctionality/AdminHomePage/AdminHomePage"
import EditUser from "./modules/AdminFunctionality/ManageUsers/EditUser/EditUser"
import AddUser from "./modules/AdminFunctionality/ManageUsers/AddUser/AddUser"
import AddDevice from "./modules/AdminFunctionality/ManageDevices/AddDevice/AddDevice"
import ManageDevices from "./modules/AdminFunctionality/ManageDevices/ManageDevices"
import Platform from "./modules/Platform/Platform"
import ImageState from "./context/ImageState"
import BuyLicense from "./components/License/BuyLicense/BuyLicense"
import ActivateLicense from "./components/License/ActivateLicense/ActivateLicense"
import AboutLicense from "./components/License/AboutLicense/AboutLicense"
import SupportLicense from "./components/License/SupportLicense/SupportLicense"
import Remotetesting from "./modules/RemoteTesting/Remotetesting"
import IDEEditor from "./modules/IDE/IDEEditor"
import ConnectToJira from "./modules/Automation/TestManager/JiraIntegration/ConnectToJira"
import SelectJiraProject from "./modules/Automation/TestManager/JiraIntegration/SelectJiraProject"
import SelectJiraFunction from "./modules/Automation/TestManager/JiraIntegration/SelectJiraFunction"
import CreateJiraIssue from "./modules/Automation/TestManager/JiraIntegration/CreateJiraIssue"
import UpdateJiraIssue from "./modules/Automation/TestManager/JiraIntegration/UpdateJiraIssue"
import AttachFileJira from "./modules/Automation/TestManager/JiraIntegration/AttachFileJira"
import Integration5G from "./modules/Home/Integration5G"
import AV from "./components/VideoQuality/AV.jsx"
// import AV from "./components/VideoQuality/AV.jsx";
//import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"
import { ThemeProvider } from "./components/ThemeToggle/ThemeContext"
import { EditUserContext } from "./context/EditUserContext"
import { useTheme } from "../src/components/ThemeToggle/ThemeContext.jsx"
import AiTest from "./components/AiTest/AiTest.jsx"
import AutoGeneration from "./components/AiTest/AutoScript/AutoGeneration.jsx"
// import { DeviceProvider } from "./context/DeviceContext/DeviceContext"

function App() {
  document.addEventListener("contextmenu", (e) => e.preventDefault());

  function ctrlShiftKey(e, keyCode) {
    return e.ctrlKey && e.shiftKey && e.keyCode === keyCode.charCodeAt(0);
  }

  document.onkeydown = (e) => {
    // Disable F12, Ctrl + Shift + I, Ctrl + Shift + J, Ctrl + U
    if (
      e.keyCode === 123 ||
      ctrlShiftKey(e, "I") ||
      ctrlShiftKey(e, "J") ||
      ctrlShiftKey(e, "C") ||
      (e.ctrlKey && e.keyCode === "U".charCodeAt(0))
    )
      return false;
  };
   const URLNotFound = () => {
      const { theme } = useTheme()
    return (
    <div className={`PageNotFound ${theme === "dark" ? "dark" : "light"}`}>
        <div className="Logo">
          <Link to="/login" className="Logo">
            <img
              src={EvQuallogo}
              style={{ paddingTop: "5px" }}
              alt="Evqual Logo"
            />
          </Link>
        </div>
        <div className="Message">
          <h3>Page Not Found</h3>
        </div>
        <div className="Login">
          <Link to="/login">Login</Link>
        </div>
      </div>
    )
  }
  // const theme = useTheme();

  return (
    <>
      <ThemeProvider>
        <Helmet>
          <meta
            http-equiv="Content-Security-Policy"
            content="frame-ancestors 'none'"
          />
          <meta http-equiv="X-Frame-Options" content="deny" />
        </Helmet>
        <ImageState>
          <BrowserRouter>
            <Routes>
             <Route
                path="/*"
                element={
                  <ErrorBoundary>
                    {" "}
                    <URLNotFound />{" "}
                  </ErrorBoundary>
                }
              />
              <Route path="/" element={<ErrorBoundary><Login />   </ErrorBoundary>} />
              <Route path="/Register" element={   <ErrorBoundary><SignUp />   </ErrorBoundary>} />
              <Route path="/Login" element={   <ErrorBoundary><Login />   </ErrorBoundary>} />
              <Route
                path="/ide"
                element={
                  <PrivateRoute>
                     <ErrorBoundary>
                    <IDEEditor />
                       </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/null/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/ConnectToJira"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ConnectToJira />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/SelectJiraProject"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SelectJiraProject />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/AV"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AV />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/SelectJiraFunction"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SelectJiraFunction />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/CreateJiraIssue"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <CreateJiraIssue />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/UpdateJiraIssue"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <UpdateJiraIssue />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/AttachFileJira"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AttachFileJira />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/aiTest"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AiTest />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/aiTest/autoGeneration"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AutoGeneration />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Telecom/aiTest"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AiTest />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Telecom/aiTest/autoGeneration"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AutoGeneration />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Healthcare/aiTest"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AiTest />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Healthcare/aiTest/autoGeneration"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AutoGeneration />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Transportation/aiTest"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AiTest />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Transportation/aiTest/autoGeneration"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AutoGeneration />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TELECOM/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TRANSPORTATION/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Desktop/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Web/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/M&E/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/M&E/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Desktop/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Desktop/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Web/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Web/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TELECOM/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TELECOM/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="platform/M&E/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TRANSPORTATION/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TRANSPORTATION/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/aboutlicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/home"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/homeTRANSPORTATION"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/M&E/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/Web/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/TELECOM/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/about"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <About />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Platform />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/dashboardTRANSPORTATION"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/remotetesting"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Remotetesting />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/remotetesting"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Remotetesting />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/remotetesting"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Remotetesting />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/remotetesting"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Remotetesting />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/remotetesting"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Remotetesting />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/Web/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/TRANSPORTATION/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/calendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Calendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/adminHomePage/manageDevices"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ManageDevices />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route path="/forgotpassword" element={ <ErrorBoundary><ForgotPassword /> </ErrorBoundary>} />

              <Route
                path="/platform/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TELECOM/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/M&E/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Desktop/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/Web/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                    <BuyLicense />
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile/aboutLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/HMI/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HMI/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/HEALTHCARE"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile/aboutLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/HEALTHCARE/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/HEALTHCARE/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              {/* TRANSPORTATION */}
              <Route
                path="/platform/TRANSPORTATION"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />

                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/aboutLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/TRANSPORTATION/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/TRANSPORTATION/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              {/* API Testing */}

              <Route
                path="/platform/API Testing"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Home />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/dashboard"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <Dashboard />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/automation"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <TestManager />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/DeviceFilter"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceFilter />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/DeviceFilter/deviceView"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <DeviceView />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/DeviceFilter/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ViewProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile/buyLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BuyLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile/aboutLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AboutLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile/activateLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ActivateLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile/supportLicense"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <SupportLicense />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/viewprofile/changepassword"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <ChangePassword />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />

              <Route
                path="/platform/API Testing/viewprofile/edituserprofile"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditProfile />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/adminHomePage"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AdminHomePage />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/adminHomePage/addUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/adminHomePage/editUser"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <EditUser />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/adminHomePage/addDevice"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="/platform/API Testing/adminHomePage/editDevice/:id"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <AddDevice />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/M&E/automation/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Transportation/automation/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Healthcare/automation/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
              <Route
                path="platform/Telecom/automation/bigCalendar"
                element={
                  <PrivateRoute>
                   <ErrorBoundary>
                    <BigCalendar />
                     </ErrorBoundary>
                  </PrivateRoute>
                }
              />
            </Routes>
          </BrowserRouter>
        </ImageState>
        {/* </EditUserContext> */}
        {/* </DeviceProvider> */}
      </ThemeProvider>
    </>
  )
}

export default App
