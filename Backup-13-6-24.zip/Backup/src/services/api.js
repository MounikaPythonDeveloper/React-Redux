// export const db_ipaddress = "https://db-api.evqual.com/";
// export const msl_ipaddress = "https://msl-signapi.evqual.com/";
// export const msl_ipaddress_trigger = "https://msl-tmapi.evqual.com/";
// export const profile_ipaddress = "https://msl-signapi.evqual.com/";
// export const LIVEKITROOM_API = "https://msl-tmapi.evqual.com/";

// export const db_ipaddress = "https://test-db-api.evqual.com/"
// export const msl_ipaddress = "https://test-msl-signapi.evqual.com/"
// export const msl_ipaddress_trigger = "https://test-msl-tmapi.evqual.com/"
// export const profile_ipaddress = "https://msl-signapi.evqual.com/"
// export const LIVEKITROOM_API = "https://test-msl-tmapi.evqual.com/"
// export const LIVEKIT_STREAM_API = "wss://avstreaming1.evqual.com/"
// export const VIDEO_METRICS_DEVICE = "https://demo-video-prop1.evqual.com/"
// export const VIDEO_METRICS_ETISILAT =
//   "https://demo-etisalat-tch-linux-jade.evqual.com/"
// export const THROTTLING_ABR = "https://demo-abr1.evqual.com/"
// export const VIDEO_INSIGHTS_START_STOP =
//   "https://demo-etisalat-tch-android.evqual.com/"
// export const NETWORK_THOTTLE_ABR = "https://demo-abr1.evqual.com/"

export const db_ipaddress = "https://demo-db-api.evqual.com/"
export const msl_ipaddress = "https://demo-msl-signapi.evqual.com/"
export const msl_ipaddress_trigger = "https://demo-msl-tmapi.evqual.com/"
export const profile_ipaddress = "https://msl-signapi.evqual.com/"
export const LIVEKITROOM_API = "https://demo-msl-tmapi.evqual.com/"
export const LIVEKIT_STREAM_API = "wss://avstreaming1.evqual.com/"
export const VIDEO_METRICS_DEVICE = "https://demo-video-prop1.evqual.com/"
export const VIDEO_METRICS_ETISILAT =
  "https://demo-etisalat-tch-linux-jade.evqual.com/"
export const THROTTLING_ABR = "https://demo-abr1.evqual.com/"
export const VIDEO_INSIGHTS_START_STOP =
  "https://demo-etisalat-tch-android.evqual.com/"
export const NETWORK_THOTTLE_ABR = "https://demo-abr1.evqual.com/"
export const ABR_TUNNELING = "https://tunneling1.evqualsolutions.com/"
export const AUTO_SCRIPT_GENERATION =
  // "http://52.66.144.40:5002/autoscript_execution_test"
  "https://demo-as1.evqual.com/autoscript_execution_test"

// export const db_ipaddress = "http://192.168.0.107:5000/";
// export const msl_ipaddress = "http://192.168.0.57:5001/";
// export const msl_ipaddress_trigger = "http://192.168.0.57:5002/";
// export const profile_ipaddress = "https://msl-signapi.evqual.com/";
// export const LIVEKITROOM_API = "https://demo-msl-tmapi.evqual.com/";
// export const LIVEKIT_STREAM_API = "wss://avstreaming1.evqual.com/";

// export const db_ipaddress = "http://15.206.148.7:5000/"
// export const msl_ipaddress = "http://15.206.148.7:5001/"
// export const msl_ipaddress_trigger = "http://15.206.148.7:5002/"
// export const profile_ipaddress = "http://3.7.28.3:5001/"
// export const LIVEKITROOM_API = "https://test-msl-tmapi.evqual.com/"
// export const db_ipaddress = "http://192.168.0.107:5000/";
// export const msl_ipaddress = "http://192.168.0.107:5001/";
// export const msl_ipaddress_trigger = "http://192.168.0.107:5002/";
// export const profile_ipaddress = "http://192.168.0.107:5000/";
// export const LIVEKITROOM_API = "https://test-msl-tmapi.evqual.com/";
// export const LIVEKIT_STREAM_API = "wss://avstreaming1.evqual.com/";

//Profile Picture API's
export const FETCH_PROFILE_API =
  profile_ipaddress + "fetch_profile_picture?image="

export const UPLOAD_PROFILE_API = profile_ipaddress + "update_profile_picture"

//Data Base API's

export const DELETE_VIEW_RESERVATION_API =
  db_ipaddress + "remove_reservation_on_device?details="

export const VIEW_RESERVATION_API = db_ipaddress + "fetch_reservation_details?"
export const DEVICES_TYPE_API = db_ipaddress + "fetch_device_type_category_name"

export const DEVICES_API =
  db_ipaddress + "fetch_devices_from_devices_under_test"

export const DEVICE_CATEGORY_API =
  db_ipaddress + "fetch_device_category" + "?device_type="

export const FETCH_DEVICEs_API =
  db_ipaddress + "fetch_device_category" + "?device_category='Android_Mobile'"

export const TESTCASES_API = db_ipaddress + "fetch_testcases_testrepository"

export const TESTSUITES_API = db_ipaddress + "fetch_testsuites_testrepository"
export const TESTSUITES_DEVICES_API =
  db_ipaddress + "fetch_test_suite_for_devices?data="

export const ONGOINGTEST_API =
  db_ipaddress + "fetch_ongoingtest_dashboard?details="
//fetch_ongoingtest_dashboard

export const TESTHISTORY_API = db_ipaddress + "fetch_rows_dashboard?details="

export const VIDEO_QUALITY_HISTORY_API =
  db_ipaddress + "fetch_rows_video_quality_dashboard?details="

export const DEVICE_STATUS_API1 =
  db_ipaddress + "fetch_device_status_for_devices"

export const DEVICE_STATUS_API =
  db_ipaddress + "fetch_device_type_category_name_status_state"

export const TESTMANAGER_API =
  db_ipaddress + "/fetch_all_details_test_manager_page?condition="

export const TESTMANAGER_SEARCH_API =
  db_ipaddress + "/fetch_all_details_user_search_for_test?"

export const REMOTE_API =
  db_ipaddress + "/fetch_all_details_remote_testing_page?condition="

export const REMOTE_API_PLATFORM =
  db_ipaddress + "/fetch_all_details_remote_testing_page?details="

export const FETCH_ATTRIBUTE_API =
  db_ipaddress + "fetch_details_for_attribute?attribute="

export const FETCH_DEVICE_CATEGORY_ATTRIBUTE_API =
  db_ipaddress + "fetch_device_category_for_adding_device?data="

export const FETCH_AGENT_ATTRIBUTE_API =
  db_ipaddress + "fetch_agent_id_for_jenkins_master?master_id="

export const FETCH_CITY_ATTRIBUTE_API =
  db_ipaddress + "fetch_city_for_device_page?data="

export const FETCH_LAB_ATTRIBUTE_API =
  db_ipaddress + "fetch_lab_name_for_adding_device?data="

export const FETCH_MASTER_ATTRIBUTE_API = db_ipaddress + "fetch_master_id?data="

export const FETCH_LOCATION_ID__ATTRIBUTE_API =
  db_ipaddress + "fetch_location_id?data="

export const CHECK_RESERVE_API =
  db_ipaddress + "check_if_reservation_exists?details"

  export const DEVICE_VIEW_MINI_DASHBOARD_API =
  db_ipaddress + "/fetch_all_details_mini_dashboard?details=";

export const CANCEL_ALL_RESERVATIONS_API =
  db_ipaddress + "remove_reservation_on_device?cancelAll=true&user="

export const FETCH_RESERVATION_API =
  db_ipaddress + 'fetch_reservation_details?condition={"reserved_by":'

export const CANCEL_SINGLE_RESERVATION_API =
  db_ipaddress + "remove_reservation_on_device?reservation_number="

export const VALIDATE_DEVICE_API = db_ipaddress + "check_data_pk?details="

export const ADD_DEVICE_API = db_ipaddress + "insertdata_admin_page?details="

export const DELETE_DEVICE_API =
  db_ipaddress + "delete_device_in_database?attribute="

//Fetching all the data from user_accounts along with platform:
export const VIEW_USERS_API = db_ipaddress + "fetch_all_details_user_accounts?"

// export const DELETE_USER_API = db_ipaddress + "delete_data_account?attribute=";

export const USER_ROLE_API = db_ipaddress + "update_data_user_privilege?key="

export const DEVICE_LOCK_UNLCOK_API =
  db_ipaddress + "update_devices_under_test_status?dev_details="

export const UPDATE_USERS_API = db_ipaddress + "update_data_account?key="

export const VALIDATE_USERNAME_API =
  db_ipaddress + "fetch_exist_status_of_username?data="

export const VALIDATE_EMAIL_API =
  db_ipaddress + "fetch_exist_status_of_email_id?data="

export const VALIDATE_USERNAME_PASSWORD_API =
  db_ipaddress + "fetch_exist_status_of_username_and_password?data="

export const EDIT_USERDATA_API = db_ipaddress + "update_username_email_id?data="

export const DEVICE_TRACKING_API =
  db_ipaddress + "insertdata_user_device_trace?details="


export const VIDEO_DASHBOARD_SEARCH_API =
  db_ipaddress + "/fetch_all_details_user_search_for_video_quality_dashboard?"

export const MANAGE_RESERVATION_API =
  db_ipaddress + "fetch_device_reservation_details?condition={}"

export const FETCH_RESERVATION_DETAILS_CALENDAR_API =
  db_ipaddress + "fetch_reservation_details?data="

export const SEARCH_USER_API =
  db_ipaddress + "fetch_all_details_user_search_for_user_accounts?search="

export const SEARCH_USER_REGISTRATION_API =
  db_ipaddress + "fetch_all_details_user_search_for_user_registration?search="

export const SEARCH_RESERVATION_API =
  db_ipaddress + "fetch_all_details_user_search_for_reservation?search="

export const DELETE_MANAGE_RESERVATION_API =
  db_ipaddress + "remove_reservation_on_device?details="
export const EDIT_USER_API = db_ipaddress + "update_data_account?key="

export const FETCH_LOGIN_ATTEMPTS_API =
  db_ipaddress + "fetch_account_data?condition="

export const FETCH_DEVICES_BY_DEVICE_STATUS_API =
  db_ipaddress + "fetch_device_name_by_device_status?data="

export const FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API =
  db_ipaddress + "/fetch_details_adding_device?data="

export const DEVICES_FILTER_SEARCH_API =
  db_ipaddress + "/fetch_all_details_user_search?"

export const MANAGE_DEVICES_API =
  db_ipaddress + "fetch_add_device_page_details?"

export const MANAGE_DEVICES_SEARCH_API =
  db_ipaddress + "/fetch_user_search_add_device_page_details?search="

export const DELETE_MANAGE_DEVICES_API =
  db_ipaddress + "/delete_device_admin_page?attribute="

export const CHECK_ADD_DEVICE_ATTRIBUTES_API =
  db_ipaddress + "/check_data_pk?details="

export const FETCH_ADD_DEVICE_ATTRIBUTES_API =
  db_ipaddress + "/fetch_details_for_attribute?attribute"

export const DELETE_DATA_CURRENT_LOGIN =
  db_ipaddress + "delete_data_current_login?attribute="

export const BUILD_DATA_API = msl_ipaddress_trigger + "build_loading?data="
export const BUILD_STATUS_API =
  db_ipaddress + "fetch_device_build_table_data?condition="

export const VALIDATE_USERNAME_SIGNIN_API =
  db_ipaddress + "fetch_exist_status_of_username?data="

export const FETCH_SESSION_API =
  db_ipaddress + "fetch_session_id_and_email_id_for_user?data="

export const VIEW_USERS_REGISTRATION_API =
  db_ipaddress + "fetch_account_data?condition="

export const USER_PRIVILAGE = db_ipaddress + "fetch_account_data?condition="

export const SUPPORT_API_DEVICES =
  db_ipaddress + "fetch_devices_under_test_data_filter_one_column?condition="
export const VERIFY_USER_API =
  db_ipaddress + "fetch_exist_status_of_unverified_user?data="
export const MANAGE_SCHEDULING_SEARCH_API =
  db_ipaddress +
  "/fetch_all_details_user_search_for_trigger_test_schedular?search="

export const MANAGE_SCHEDULING_API =
  db_ipaddress + "/fetch_trigger_test_schedular_data?condition={}"
export const MANAGE_SCHEDULING_DELETE_API =
  db_ipaddress + "/delete_data_trigger_test_schedular?attribute="

export const VERIFY_LICENSE_API =
  db_ipaddress + "fetch_exist_status_of_license_key?data="

export const VALIDATE_BUYLICENSE_STATUS =
  db_ipaddress + "fetch_licenses_data?condition="

export const ABOUT_DB_API = db_ipaddress + "fetch_licenses_data?condition="

export const NETWORK_THROTTLING_STATUS_API =
  db_ipaddress + "fetch_devices_under_test_data_filter_one_column?condition="

export const GET_PLATFORMS_API =
  db_ipaddress + "fetch_platforms_data?attributes="

export const Drag_and_Drop_Availability_API =
  db_ipaddress + "fetch_exist_status_of_testcase?data="

export const CONNECT_JIRA_API = db_ipaddress + "update_account_id?data="

export const FETCH_JIRA_ACCOUNT_ID =
  db_ipaddress + "fetch_account_data?condition="

export const JIRA_SPRINTS_API =
  db_ipaddress + "fetch_sprint_name_based_on_sprint_status?data="

export const FETCH_DEVICE_NAMES_VIDEO_METRICS_API =
  db_ipaddress +
  "fetch_device_name_by_device_status_and_video_quality_analysis?data="

export const FETCH_REPORT_API =
  db_ipaddress + "fetch_report_based_on_trigger_id?data="
export const AUTOMATION_DASHBOARD_SEARCH_API =
  db_ipaddress + "/fetch_all_details_user_search_for_dashboard?"

//%7B%22username%22:%22abinaya%22,%22platform%22:%22Media%20And%20Entertainment%22,%22device_category%22:[%22STB%22,%22Smart%20TV%22,%22OTT%22,%22iOS%22,%22Android%22,%22Gaming%22],%22current_date%22:%222023-06-28%22,%22current_time%22:%2223:00:00%22,%20%22video_metrics%22:%22True%22%7D

//Not used DB API's
// export const AGENTS_API = db_ipaddress + "fetch_agent_name_dut"

// export const DEVICES_TYPES_API = db_ipaddress + "fetch_device_type_for_devices"
// export const DEVICE_CATEGORY_API =
//   db_ipaddress + "fetch_device_category" + "device_type='Android'";
// export const VIEW_ALL_DEVICES_API =
//   db_ipaddress + "fetch_add_device_page_details?";

// export const DELETE_DEVICE_API =
//   db_ipaddress + "remove_device_admin_page?attribute="
// export const DEVICE_LOCK_API =
//   db_ipaddress + "reserve_device?reservation_details="

// export const DEVICE_UNLOCK_API =
//   db_ipaddress + "update_data_device_reservation?"

// export const DEVICE_UNLOCK_DELETE_API =
//   db_ipaddress + "remove_reservation_on_device?device_name="

//MSL API's
// https://test-ss1.evqual.com/screenshot
export const SCREEN_SHOT_IMAGE_API = "https://test-ss1.evqual.com/screenshot"

export const SCREEN_SHOT_IMAGE_ETISILAT =
  "https://mh1-demo.evqual.com/screenshot"

export const RERUN_TESTCASES_API =
  msl_ipaddress_trigger + "/rerun_testcase?data="
  
export const API_TESTING_REST_API =
  msl_ipaddress_trigger + "API_Testing/RESTAPI?data="

export const LOAD_RUNNER_API = msl_ipaddress_trigger + "lr_load_test?exc_cmd="

export const JMETER_API = msl_ipaddress_trigger + "/jmeter_load_test?exc_cmd="

export const LOCUST_API = msl_ipaddress_trigger + "/locust_test?exc_cmd="

export const DEVICES_FILTER_NETWORK_REGION_API =
  // "https://sb-tmapi.evqual.com/nw_geo_location?data="
  "https://mitm-geo-loc1.evqual.com/" + "geo_location_change?data="

export const GEO_LOCATION_STATUS_API =
  db_ipaddress + "/fetch_devices_under_test_data_filter_one_column?condition="

export const NETWORK_START_THROTTLING_API =
  msl_ipaddress_trigger + "nw_throttle/start?data="

export const NETWORK_STOP_THROTTLING_API =
  msl_ipaddress_trigger + "nw_throttle/stop?data="

export const NETWORK_THROTTLING_API =
  msl_ipaddress_trigger + "nw_throttle/live?data="

export const TRIGGER_TEST_API_IVI =
  msl_ipaddress_trigger + "getdata_IVI?exc_cmd="
export const TRIGGER_TEST_API = msl_ipaddress_trigger + "getdata?exc_cmd="
export const TRIGGER_TEST_ABR_API = msl_ipaddress_trigger + "test_abr?exc_cmd="

export const ABORT_API = msl_ipaddress_trigger + "abort?data="

export const SIGNUP_API = msl_ipaddress + "signup?data="

export const SIGNIN_API = msl_ipaddress + "signin?data="

export const ADD_USER_API = msl_ipaddress + "add_user?data="

export const LOGOUT_API = msl_ipaddress + "logout_session?data="

export const VALIDATE_OTP_API = msl_ipaddress + "otp_signup?data="

export const RESET_API = msl_ipaddress + "reset?data="

export const OTP_API = msl_ipaddress + "otp?data="
//

export const RESET_PASSWORD_API = msl_ipaddress + "reset_password?data="

export const DEVICE_RESERVATION_API = msl_ipaddress + "reserve?data="

export const HARD_REBOOT_API = msl_ipaddress + "hard_reboot?data="

export const RESEND_OTP_API = msl_ipaddress + "resend_otp?data="
//To send the OTP to Users emailid

export const CHECK_PASSWORD_API = msl_ipaddress + "check_password?data="

export const MAIL_REPORT_API = msl_ipaddress + "send_report_mail?data="

export const SUBMIT_ADD_DEVICE_ATTRIBUTES_API =
  msl_ipaddress + "/add_devices?data="

export const SUBMIT_EDIT_DEVICE_ATTRIBUTES_API =
  msl_ipaddress + "/edit_devices?data="

export const EXIST_FROM_LIVEKITROOM =
  msl_ipaddress_trigger + "remove_participant?data="

export const RELOGIN_API = msl_ipaddress + "logout_previous_device?data="

export const SCHEDULE_SUBMIT_ATTRIBUTES_API =
  msl_ipaddress_trigger + "/schedule?exc_cmd="

export const MANAGE_USER_REGISTRATION_API =
  msl_ipaddress + "manage_user_registration?data="

export const TRIGGER_TEST_WEB_API =
  msl_ipaddress_trigger + "getdata_web?exc_cmd="

export const BUY_LICENSE_API = msl_ipaddress + "create_license?data="

export const ACTIVATE_LICENSE_API = msl_ipaddress + "activate_license?data="

export const DELETE_USER_API = msl_ipaddress + "admin/delete_user"

export const RECORD_FILE_UPLOAD_API =
  msl_ipaddress_trigger + "robo-recorder/msl"

export const SCREENSHOT_FILE_UPLOAD_API =
  msl_ipaddress_trigger + "/robo-recorder/msl_screenshot"

//mh1-demo.evqual.com/screenshot

export const CREATE_ISSUE_JIRA_API =
  msl_ipaddress_trigger + "/add_jira_issue?exc_cmd="

export const UPDATE_ISSUE_JIRA_API =
  msl_ipaddress_trigger + "/update_jira_issue?exc_cmd="

export const LIVEKIT_MUTE_API = msl_ipaddress_trigger + "mute_devices?data="

export const JIRA_ATTACH_FILE_API = msl_ipaddress_trigger + "attach_files_jira"

export const UPLOADVIDEO_API = msl_ipaddress + "upload_video"

export const CHECK_VIDEO_QUALITY_API =
  msl_ipaddress_trigger + "check_video_quality_recorded?exc_cmd="
export const CHECK_VIDEO_QUALITY_FILE_API =
  msl_ipaddress_trigger + "check_video_quality_file?exc_cmd="

export const VIDEO_METRICS_URL_API =
  VIDEO_METRICS_DEVICE + "video_metrics_url?data="

export const VIDEO_METRICS_URL_AKSHITHA_API =
  VIDEO_METRICS_ETISILAT + "video_metrics_url_etisalat?data="

export const VIDEO_METRICS_DEVICES_API =
  VIDEO_METRICS_DEVICE + "video_metrics_devices?data="

export const GENERATE_REPORT_VQ_API =
  VIDEO_METRICS_DEVICE + "generate_pdf_video_quality?data="

export const GENERATE_REPORT_VQ_AKSHITHA_API =
  VIDEO_METRICS_ETISILAT + "generate_pdf_video_quality_etisalat?data="

export const COLLECT_LIVE_CHANNELS_API =
  VIDEO_METRICS_ETISILAT + "collect_live_data?data="
export const DELETE_LIVE_MULTIPLE_CHANNELS_API =
  VIDEO_METRICS_ETISILAT + "delete_live_data_file?data="

// export const THROTTLING_ABR_API = THROTTLING_ABR + "throttle?data="
export const THROTTLING_ABR_API = NETWORK_THOTTLE_ABR + "throttle?data="

export const START_FFMPEG_VIDEO_INSIGHTS_API =
  VIDEO_INSIGHTS_START_STOP + "start_ffmpeg?source_url="
export const STOP_FFMPEG_VIDEO_INSIGHTS_API =
  VIDEO_INSIGHTS_START_STOP + "stop_ffmpeg"
export const PROFANITY_DETECTION_CREATE_API =
  msl_ipaddress_trigger + "check_video_quality_profanity?exc_cmd="

// export const PROFANITY_REPORT_GENERATE_API =
//   msl_ipaddress_trigger + "check_video_quality_profanity?exc_cmd="

// export const PROFANITY_DETECTION_LIVE_API =
//   NETWORK_THOTTLE_ABR + "collect_live_data_profanity?exc_cmd="
// // "https://demo-prof1.evqual.com/collect_live_data_profanity?exc_cmd="

// export const DELETE_PROFANITY_REPORT_API =
//   NETWORK_THOTTLE_ABR + "Delete_Reports?exc_cmd="
// // " https://demo-prof1.evqual.com/Delete_Reports?exc_cmd={%22trigger_id%22:2222}"

export const PROFANITY_REPORT_GENERATE_API =
  msl_ipaddress_trigger + "check_video_quality_profanity?exc_cmd="

export const PROFANITY_DETECTION_LIVE_API =
  "https://demo-prof1.evqual.com/collect_live_data_profanity?exc_cmd="

export const DELETE_PROFANITY_REPORT_API =
  " https://demo-prof1.evqual.com/delete_reports?exc_cmd="
