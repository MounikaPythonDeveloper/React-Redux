import Axios from "axios"
import { REMOTE_API, REMOTE_API_PLATFORM } from "./api"
export class HomeData {
  static HomePageData(platformData) {
    return Axios.get(
      REMOTE_API +
        JSON.stringify({
          platform: [platformData],
        })
    )
  }
  static PlatformData(username, userprivilage) {
    return Axios.get(
      REMOTE_API_PLATFORM +
        JSON.stringify({ username: username, user_privilege: userprivilage })
    )
  }
}
