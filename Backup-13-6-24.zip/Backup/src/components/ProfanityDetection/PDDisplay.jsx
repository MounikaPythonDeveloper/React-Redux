import { IconButton } from "@material-ui/core"
import React from "react"
import { useTheme } from "../ThemeToggle/ThemeContext"
import CloseIcon from "@mui/icons-material/Close"
import "./PDDisplay.css"
import Report from "../../assets/images/Report.png"
import Report_light from "../../assets/images/icons8-reports-58.png"

function PDDisplay(props) {
  const { theme } = useTheme()
  const { PDLiveDataDisplay } = props

  const handlePDReport = () => {
    props.PDReportData(true)
  }
  const handlePDDisplayClose = () => {
    props.PDDisplayCloseData(true)
  }
  return (
    <div className="pd-display-container">
      <div
        className={`pd-network-video-block-insights ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div
          classname="transparent-block"
          style={{
            color: "white",
          }}
        >
          <div className="pd-video-block-top">
            <div>
              <h3
                className={`pd-video-block-heading  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Profanity Detection
              </h3>
            </div>
            <div className="pd-video-icons">
              <img
                style={{
                  border: "none",
                  height: "3vh",
                  width: "3vh",
                }}
                src={theme === "dark" ? Report : Report_light}
                title="Generate Report"
                onClick={handlePDReport}
                alt="Reports"
              />
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                className={`pd-network-video-block-insights-close ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <CloseIcon
                  fontSize="inherit"
                  style={{ color: "white" }}
                  onClick={handlePDDisplayClose}
                />
              </IconButton>
            </div>
          </div>
        </div>

        <div className="pd-display">
          <p>
            <label> Contains Profanity:</label>
            {PDLiveDataDisplay?.contains_profanity}
          </p>
          <p>
            <label>Time Stamp:</label>
            {PDLiveDataDisplay?.audio_timestamp}
          </p>
          <p>
            <label>Captured Content:</label>
            {PDLiveDataDisplay.captured_text}
          </p>
        </div>
      </div>
    </div>
  )
}

export default PDDisplay
