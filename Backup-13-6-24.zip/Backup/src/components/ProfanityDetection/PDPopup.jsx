import * as React from "react"
import Box from "@mui/material/Box"
import "./PDPopup.css"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Button from "@mui/material/Button"
import { useTheme } from "../ThemeToggle/ThemeContext"
import { useState } from "react"

function ProfanityDetection(props) {
  const { theme } = useTheme()
  const [pdInput, setpdInput] = useState("")
  const pdInputHandler = (e) => {
    setpdInput(e.target.value)
  }
  const handlePDSubmit = () => {
    if (pdInput > 40) {
      props.functionHandle(pdInput)
      setpdInput("")
    } else {
      alert("Value should be grater than 40")
    }
    // props.functionHandle(pdInput)
    // setpdInput("")
  }
  const handlePDClose = () => {
    setpdInput("")
    props.handleClose()
  }
  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`modal-container ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="pd-popup-container">
            <div className="pd-header-container">
              <h1 className="pd-header">Profanity Detection</h1>
              <div
                className={`modal-icon-div  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <IconButton
                  className="modal-icon"
                  aria-label="close"
                  color="inherit"
                  size="small"
                  onClick={handlePDClose}
                >
                  <CloseIcon fontSize="inherit" className="modal-close-icon" />
                </IconButton>
              </div>
            </div>
            <div className="modal-text-div">
              <div className="pd-input-feild">
                <div className="pd-input-feildSecond">
                  <input
                    name="appName"
                    type="number"
                    placeholder="Enter Duration in secs"
                    value={pdInput}
                    onChange={pdInputHandler}
                    className={`buildInput ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    autocomplete="off"
                  />
                </div>
              </div>
            </div>
            <div className="btn-actions">
              <Button
                className={`btn-handler ${theme === "dark" ? "dark" : "light"}`}
                onClick={handlePDClose}
              >
                Cancel
              </Button>
              <Button
                className={`btn-handler ${theme === "dark" ? "dark" : "light"}`}
                onClick={handlePDSubmit}
              >
                Submit
              </Button>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default ProfanityDetection
