/**
 * Component: LiveKit
 * File: LiveKitRoom.jsx
 * Description: This file contains the implementation of Livekit Component which will generate the
                token upon calling the api and will input this token and livekit server url
                to livekitroom component through which we can see the screen for selected device.
 *File Used:DeviceView.js
 * Author: Supriya Palve
 * */

import React, { useEffect, useState } from "react"
import { LiveKitRoom } from "./livekit-react/dist"
import "./livekit.css"
import axios from "axios"
//import { Room } from "livekit-client";
import { LIVEKITROOM_API ,LIVEKIT_STREAM_API} from "../../services/api"
import { useNavigate } from "react-router-dom"

const LiveKit = ({ devicesData, activeDevices, tokenData2 }) => {
  console.log("in livekit devicesData", tokenData2)
  const navigate = useNavigate()
  const [tokenData, setTokenData] = useState()
  const [devicesData1, setDeviceData1] = useState(devicesData)
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))

  useEffect(() => {
    livekitdata()
  }, [])
  //Api call for token generation
  const livekitdata = async () => {
    let url_device = ""
    url_device = `${LIVEKITROOM_API}${
      devicesData[0].device_name
    }?data=${JSON.stringify({
      locked_by: userProfile.username,
    })}`
    try {
      const response = await axios.post(url_device)
      //const tData = response.data;
      console.log("livekit-data", response.data)
      setTokenData(response.data)
    } catch (error) {
      console.log(error, "error")
    }
  }
  const onLeave = () => {
    navigate("/")
  }
  //livekitroom component
  return (
    <div className="roomContainer">
      {/* multiple devices */}
      {tokenData2 && (
        <LiveKitRoom
          // url="wss://avstreaminges1.evqual.com/"
        url={LIVEKIT_STREAM_API}
          token={tokenData2}
          onConnected={(room) => onConnected(room)}
          onLeave={onLeave}
        />
      )}
      {/* single device */}
      {tokenData && (
        <LiveKitRoom
          // url="wss://avstreaminges1.evqual.com/"
        url={LIVEKIT_STREAM_API}
          token={tokenData}
          onConnected={(room) => onConnected(room)}
          onLeave={onLeave}
        />
      )}
    </div>
  )
}
async function onConnected(room) {
  await room.localParticipant.setCameraEnabled(false)
  await room.localParticipant.setMicrophoneEnabled(false)
}
export default LiveKit
