/**
 * Component: LiveKit
 * File: LiveKitRoomAutomation.jsx
 * Description: This file contains the implementation of Livekit Component which will generate the
                token upon calling the api and will input this token and livekit server url
                to livekitroom component through which we can see the screen for selected device.
 *File Used:DeviceViewAutomation.js
 * Author: Supriya Palve
 * */
import React, { useEffect, useState } from "react"
import { LiveKitRoom } from "./livekit-react/dist"
import "./livekit.css"
import axios from "axios"
import { LIVEKITROOM_API, LIVEKIT_MUTE_API ,LIVEKIT_STREAM_API} from "../../services/api"
import { useNavigate } from "react-router-dom"

const LiveKit = ({ devicesData, livekitvalue }) => {
  console.log("devicesdatalivekit", devicesData, livekitvalue)
  const navigate = useNavigate()
  const [tokenData, setTokenData] = useState()
  const [devicesData1, setDeviceData1] = useState([devicesData])
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  useEffect(() => {
    if ((livekitvalue = "true")) {
      livekitMute()
    }
    livekitdata()
  }, [])

  //Api call for mute
  const livekitMute = async (i) => {
    let url_device = ""
    url_device = `${LIVEKIT_MUTE_API}${JSON.stringify({
      devices: [devicesData],
    })}`

    try {
      const response = await axios.post(url_device)
      // setTokenData(response.data)
    } catch (error) {
      console.log(error, "error")
    }
  }

  //Api call for token generation
  const livekitdata = async (i) => {
    let url_device = ""

    url_device = `${LIVEKITROOM_API}${devicesData1}?data=${JSON.stringify({
      locked_by: userProfile.username,
    })}`

    try {
      const response = await axios.post(url_device)
      setTokenData(response.data)
    } catch (error) {
      console.log(error, "error")
    }
  }

  const onLeave = () => {
    navigate("/")
  }
  const getDeviceViewManual1 = () => {
    // alert("device clicked manual")

    // setBackgroundColor("orange")
    alert("device clicked manual")
    console.log("Device clicked manual")
  }

  return (
    <div className="grid-container">
      {tokenData && (
        // <div onClick={alert("check")}>
        <LiveKitRoom
          // url="wss://avstreaminges1.evqual.com/"
        url={LIVEKIT_STREAM_API}
          token={tokenData}
          onConnected={(room) => onConnected(room)}
          onLeave={onLeave}
          // onClick={alert("jhghg")}
        />
        // </div>
      )}
    </div>
  )
}
async function onConnected(room) {
  await room.localParticipant.setCameraEnabled(false)
  await room.localParticipant.setMicrophoneEnabled(false)
}
export default LiveKit
