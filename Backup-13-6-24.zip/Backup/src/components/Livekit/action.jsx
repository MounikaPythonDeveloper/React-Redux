export const setTokenData=(tokenData)=>{
    return{
        type:'set_token_data',
        payload:tokenData,
    };
};