/**
 * Component: LiveKit
 * File: LiveKitRoom.jsx
 * Description: This file contains the implementation of Livekit Component which will generate the
                token upon calling the api and will input this token and livekit server url
                to livekitroom component through which we can see the screen for selected device.
 *File Used:VideoInsights.js
 * Author: Mounika
 * */

import React, { useEffect, useState } from "react"
import { LiveKitRoom } from "./livekit-react/dist"
import "./livekit.css"
import axios from "axios"
//import { Room } from "livekit-client";
import { LIVEKITROOM_API, LIVEKIT_STREAM_API } from "../../services/api"
import { useNavigate } from "react-router-dom"

const LiveKit = ({ tokenData2 }) => {
  console.log("in livekit VideoInsights", tokenData2)
  const navigate = useNavigate()
  const [tokenData, setTokenData] = useState("")
  //   const [devicesData1, setDeviceData1] = useState(devicesData)
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))

  useEffect(() => {
    livekitdata()
    console.log("livekit romm abr connect")
  }, [])
  //Api call for token generation
  const livekitdata = async () => {
    let url_device = ""
    url_device = `${LIVEKITROOM_API}${"Video Insights"}?data=${JSON.stringify({
      locked_by: userProfile.username,
    })}`
    console.log("livekit abr url", url_device)
    await axios
      .post(url_device)
      .then((response) => {
        console.log("livekit-data VI tokendata", response.data)
        setTokenData(response.data)
        console.log("livekit-data VI tokendata", response.data, tokenData, "..")
      })
      .catch((error) => {
        console.log(error, "livekit-data VI tokendata")
      })
    // try {
    //   const response = await axios.post(url_device)
    //   //const tData = response.data;
    //   console.log("livekit-data tokendata", response.data)
    //   setTokenData(response.data)
    // } catch (error) {
    //   console.log(error, "error")
    // }
  }
  const onLeave = () => {
    navigate("/")
  }
  //livekitroom component
  return (
    <div className="roomContainer">
      {/* multiple devices */}
      {/* {tokenData && (
        <LiveKitRoom
          // url="wss://avstreaminges1.evqual.com/"
          url={LIVEKIT_STREAM_API}
          token={tokenData2}
          onConnected={(room) => onConnected(room)}
          onLeave={onLeave}
        />
      )} */}
      {/* single device */}
      {tokenData && (
        <LiveKitRoom
          // url="wss://avstreaminges1.evqual.com/"
          url={LIVEKIT_STREAM_API}
          token={tokenData}
          onConnected={(room) => onConnected(room)}
          onLeave={onLeave}
        />
      )}
    </div>
  )
}
async function onConnected(room) {
  await room.localParticipant.setCameraEnabled(false)
  await room.localParticipant.setMicrophoneEnabled(false)
}
export default LiveKit
