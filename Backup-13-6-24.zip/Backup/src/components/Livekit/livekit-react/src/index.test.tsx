import { LiveKitRoom } from ".";

describe("LiveKitRoom", () => {
  it("is truthy", () => {
    expect(LiveKitRoom).toBeTruthy();
  });
});
