/**
 * Component: Automation DeviceView
 * File: DeviceViewAutomation.jsx
 * Description: This file contains the implementation of the Deviceview React component.
                Device  view component in automation page will make user to easily view the device screen 
                upon clicking on view button with help of livekit and iframe component.
                user can view single and multiple devices.
                
 *File Used:DeviceRack.js,StatusMonitoring.jsx
 * Author:Sanjana, Supriya Palve, Yuvaraj, Mounika
 * */

import { useEffect, useState } from "react";
import "./DeviceViewAutomation.css";
import "../../components/Livekit/livekit.css";
import LiveKit from "../Livekit/LiveKitRoomAutomation";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";
import axios from "axios";
import "./DeviceViewAutomation.css";
import { useNavigate } from "react-router-dom";
import {
  EXIST_FROM_LIVEKITROOM,
  LIVEKIT_MUTE_API,
  DEVICE_VIEW_MINI_DASHBOARD_API,
} from "../../services/api";

import * as React from "react";
import Popover from "@mui/material/Popover";
import TriggerTestPopover from "./TriggerTestPopover";
import InfoSharpIcon from "@mui/icons-material/InfoSharp";

const DeviceView = (devicesauto) => {
  const { theme } = useTheme();

  let livekitvalue = "false";
  const navigate = useNavigate();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const CloseButton = ({ onClick }) => (
    <button
      className={`close-deviceview ${theme === "dark" ? "dark" : "light"}`}
      onClick={onClick}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  );
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [dashboardInfo, setDashboardInfo] = useState([]);

  const handleClick = (event, data) => {
    setAnchorEl(event.currentTarget);
    getDeviceTestDetails(data);
  };

  const getDeviceTestDetails = async (data) => {
    let miniDashboardApi = "";
    miniDashboardApi = `${DEVICE_VIEW_MINI_DASHBOARD_API}${JSON.stringify({
      device_name: data,
    })}`;
    await axios
      .post(miniDashboardApi)
      .then((response) => {
        console.log("miniDashboardApi", response.data);
        setDashboardInfo(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const handleClose = () => {
    setAnchorEl(null);
    setDashboardInfo([]);
  };

  const open = Boolean(anchorEl);
  const [devicesData, setDeviceData] = useState(devicesauto.devicesauto);
  let devicenames = devicesData.map((devicename) => devicename.device_name);
  console.log(devicenames, "livekitmuteData");

  if (devicenames.length > 1) {
    livekitvalue = "true";
  } else {
    livekitvalue = "false";
  }

  const [devicesData1, setDeviceData1] = useState([devicesauto.devicesauto]);

  window.addEventListener("beforeunload", function (e) {
    e.preventDefault();
    e.returnValue = "";
    if ((livekitvalue = "true")) {
      livekitUnmute();
    }
    removeuserfromlivekitroom(
      // extracting the devicename - list of devicenames
      Object.values(devicesData1).map((item) => item[0].device_name)
    );
  });

  useEffect(() => {
    return () => {
      if ((livekitvalue = "true")) {
        livekitUnmute();
      }
      removeuserfromlivekitroom(
        Object.values(devicesData1).map((item) => item[0].device_name)
      );
    };
  }, []);

  const room_name = [
    Object.values(devicesData1).map((item) =>
      item[0].device_name.toLowerCase()
    ),
  ][0][0];

  //Api call for mute
  const livekitUnmute = async (i) => {
    let url_device = "";
    url_device = `${LIVEKIT_MUTE_API}${JSON.stringify({
      devices: devicenames,
    })}`;

    try {
      const response = await axios.post(url_device);
      // setTokenData(response.data)
    } catch (error) {
      console.log(error, "error");
    }
  };

  useEffect(() => {
    localStorage.setItem("room_name", JSON.stringify(room_name));
  });

  //remove user from livekit room
  const removeuserfromlivekitroom = async () => {
    let url_device = "";
    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: room_name,
    })}`;
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const getDeviceViewManual = (Data) => {
    console.log(Data, "device clicked manual");
    if (Data.platform === "Media And Entertainment") {
      navigate("/platform/M&E/DeviceFilter/deviceView", {
        state: { DeviceViewInfo: [Data] },
      });
    } else {
      navigate("/platform/" + Data.device_name + "/DeviceFilter/deviceView", {
        state: { DeviceViewInfo: [Data] },
      });
    }
  };

  const renderDevice = function (Data) {
    console.log(Data, "render");
    switch (Data?.screen_type) {
      case "Tab Screening":
      case "Console Screening":
        return (
          <>
            <div className="auto-device-view-tv-container">
              <LiveKit
                devicesData={Data.device_name}
                livekitvalue={livekitvalue}
              />
            </div>
          </>
        );
      case "TV Screening":
        return (
          <>
            <div
              className="auto-device-view-tv-container"
              style={{
                width: devicesData.length === 1 ? "100%" : "470px",
              }}
            >
              <LiveKit
                devicesData={Data.device_name}
                livekitvalue={livekitvalue}
              />
            </div>
          </>
        );

      case "Mobile Screening":
        return (
          <div className="auto-device-view-mobile-container" style={{cursor:"not-allowed"}}>
            <iframe
              class="auto-device-view-iframe"
              src={Data?.url_screen}
              style={{cursor:"not-allowed"}}
            ></iframe>
          </div>
        );
      case "Other Screening":
        return (
          <div className="device-screen-block-auto lg-screen-device">
            <iframe
              class="lg-screen-device-iframe-auto"
              src={Data?.url_screen}
            ></iframe>
          </div>
        );
      default:
        return (
          <div className="device-screen-block-auto lg-screen-device">
            <iframe
              class="lg-screen-device-iframe-auto"
              src={Data?.url_screen}
            ></iframe>
          </div>
        );
    }
  };

  return (
    <>
      <div className="popup-box-deviceview">
        <div
          className={`box-deviceview ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="automation-device-view">
            <div className="automation-device-view-header">
              <CloseButton onClick={devicesauto.handleCloseButton} />
            </div>
            <div className="automation-device-view-container">
              {devicesData.length > 0 &&
                devicesData.map((Data, index) => {
                  return (
                    <div
                      className={`auto-device-view-item ${
                        theme === "dark" ? "dark" : "light"
                      }
                   ${devicesData.length > 1 ? "device-multiview" : ""}
                   `}
                    >
                      <div className="auto-device-view-item-header">
                        <h3 onClick={() => getDeviceViewManual(Data)}>
                          {Data?.device_name}
                        </h3>
                        <InfoSharpIcon
                          className="ms-3"
                          onClick={(e) => handleClick(e, Data.device_name)}
                        />
                      </div>
                      <div className="auto-device-view-iframe-container">
                        {renderDevice(Data)}
                      </div>
                      <Popover
                        disableScrollLock={true}
                        className="trigger-test-popover"
                        open={open}
                        anchorEl={anchorEl}
                        onClose={handleClose}
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "right",
                        }}
                      >
                        <TriggerTestPopover dashboardInfo={dashboardInfo} />
                      </Popover>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default DeviceView;
