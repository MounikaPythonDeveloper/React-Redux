import { Grid } from "@mui/material";
import React from "react";
import "./TriggerTestPopover.css";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";
export default function TriggerTestPopover({ dashboardInfo }) {
  const { theme } = useTheme();
  console.log(dashboardInfo, "dashboardInfo");
  return (
    <div className="trigger-test-info-container">
      <div className="trigger-test-info-block">
        <div
          className={`trigger-test-info-header ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <h1>Mini Dashboard</h1>
        </div>

        <div
          className={`trigger-test-info-main ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <div className="trigger-test-info">
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <div className="trigger-test-input-block">
                  <label
                    className={`trigger-test-input-label ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Test Reference
                  </label>
                  <div className="trigger-test-input-container">
                    <input
                      type="text"
                      readOnly
                      className={`trigger-test-input ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      value={dashboardInfo[0]?.test_reference}
                    />
                  </div>
                </div>
              </Grid>
              <Grid item xs={12}>
                <div className="trigger-test-input-block">
                  <label
                    className={`trigger-test-input-label ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Test case in exceution
                  </label>
                  <div className="trigger-test-input-container">
                    <input
                      type="text"
                      readOnly
                      className={`trigger-test-input ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      value={dashboardInfo[0]?.test_cases}
                    />
                  </div>
                </div>
              </Grid>
              <Grid item xs={12}>
                <div
                  className={`trigger-test-input-block ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  <label
                    className={`trigger-test-input-label ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Test case start time -
                  </label>
                  <span>{dashboardInfo[0]?.date_and_time}</span>
                </div>
              </Grid>
              {/* <Grid item xs={6}>
                <div className="trigger-test-input-block">
                  <label className="trigger-test-input-label">
                    Time Zone -
                  </label>
                  <span>+5:30 Delhi/Kolkata</span>
                </div>
              </Grid> */}
              <Grid item xs={12}>
                <div className="trigger-test-input-block trigger-test-status-block">
                  <label
                    className={`trigger-test-input-label ${
                      theme === "dark" ? "dark" : "light"
                    } me-4`}
                  >
                    Status
                  </label>
                  <div className="trigger-test-status-container">
                    {/* {dashboardInfo[0].status === "Completed" ?} */}
                    <span
                      className={`test-status ${
                        dashboardInfo[0]?.status === "Completed"
                          ? "inprogress"
                          : "completed"
                      } ${theme === "dark" ? "dark" : "light"}`}
                    >
                      In Progress
                    </span>
                    <span
                      className={`test-status ${
                        dashboardInfo[0]?.status === "Completed"
                          ? "completed"
                          : "inprogress"
                      } ${theme === "dark" ? "dark" : "light"}`}
                    >
                      Completed
                    </span>
                  </div>
                </div>
              </Grid>
              <Grid item xs={12}>
                <div className="trigger-test-input-block trigger-test-status-block">
                  <label
                    className={`trigger-test-input-label ${
                      theme === "dark" ? "dark" : "light"
                    } me-4`}
                  >
                    Result
                  </label>
                  <div className="trigger-test-status-container">
                    <span
                      className={`test-status ${
                        dashboardInfo[0]?.result === "Pass"
                          ? "completed"
                          : "failed"
                      } ${theme === "dark" ? "dark" : "light"} `}
                    >
                      {dashboardInfo[0]?.result === "Pass" ? "Pass" : "Fail"}
                    </span>
                  </div>
                </div>
              </Grid>
            </Grid>
            <Grid
              container
              spacing={2}
              className={`trigger-test-device-info ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <Grid item xs={6}>
                <ul>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Device Location
                    </label>
                    <span>{dashboardInfo[0]?.city}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Model Name
                    </label>
                    <span>{dashboardInfo[0]?.model_name}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      OS Name
                    </label>
                    <span>{dashboardInfo[0]?.os_name}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Serial Number
                    </label>
                    <span>{dashboardInfo[0]?.serial_number}</span>
                  </li>
                </ul>
              </Grid>
              <Grid item xs={6}>
                <ul>
                  {" "}
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      } `}
                    >
                      IP Address
                    </label>
                    <span>{dashboardInfo[0]?.ip_address}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Lab Name
                    </label>
                    <span>{dashboardInfo[0]?.lab_name}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Manufacturer
                    </label>
                    <span>{dashboardInfo[0]?.manufacturer}</span>
                  </li>
                  <li>
                    <label
                      className={`trigger-test-input-label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Master ID
                    </label>
                    <span>{dashboardInfo[0]?.master_id}</span>
                  </li>
                </ul>
              </Grid>
            </Grid>
          </div>
        </div>
      </div>
    </div>
  );
}
