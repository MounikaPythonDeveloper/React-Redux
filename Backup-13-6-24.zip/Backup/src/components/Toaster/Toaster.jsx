import React from "react"

const Toaster = (props) => {
  return (
    <div className={`toaster ${props.type}`}>
      <p>{props.message}</p>
    </div>
  )
}

export default Toaster
