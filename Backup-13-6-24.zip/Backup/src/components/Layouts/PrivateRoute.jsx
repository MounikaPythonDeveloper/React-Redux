import { useEffect, useState } from "react"
import { Navigate } from "react-router-dom"
import { useNavigate, useLocation } from "react-router-dom"
import NavBar from "../Navbar/Navbar"
import axios from "axios"
import { LOGOUT_API, FETCH_SESSION_API } from "../../services/api"
import { Alert, Snackbar } from "@mui/material"
import { ABOUT_DB_API } from "../../services/api"

const events = ["load", "mousemove", "mousedown", "click", "scroll", "keypress"]

function PrivateRoute({ children }) {
  // const [logoutAlert,setLogoutAlert] = useState("")
  const [userSessionId, setUserSessionId] = useState("")
  const [expiry_date, setexpirydate] = useState("")
  const [alertMessage, setAlertMessage] = useState("ddddd")
  const [alertMessageState, setAlertMessageState] = useState(false)
  const [status, setStatus] = useState("")
  let navigate = useNavigate()
  let timer
  const location = useLocation()
  const handleLogoutTimer = () => {
    timer = setTimeout(() => {
      // clears any pending timer.
      resetTimer()

      // Listener clean up. Removes the existing event listener from the window
      Object.values(events).forEach((item) => {
        window.removeEventListener(item, resetTimer)
      })
      // logs out user
      handleLogout()
    }, 600000) // 600000ms = 10minutes. You can change the time.
  };
   const handleLogoutTimer1 = () => {
    // timer = setTimeout(() => {
      // clears any pending timer.
      resetTimer()

      // Listener clean up. Removes the existing event listener from the window
      Object.values(events).forEach((item) => {
        window.removeEventListener(item, resetTimer)
      })
      // logs out user
      // handleLogout()
    // }, 600000) // 600000ms = 10minutes. You can change the time.
  };
  const resetTimer = () => {
    if (timer) clearTimeout(timer)
  }

  useEffect(() => {
    Object.values(events).forEach((item) => {
      window.addEventListener(item, () => {
        about_license_api()
        resetTimer()

        // handleLogoutTimer()
        var executed = false
        if (!executed) {
          executed = true
          handleLogoutTimer(executed)
        }
      })
    })
  }, [])
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const signinData = JSON.parse(sessionStorage.getItem("signin_data"))
  const about_license_api = () => {
    axios
      .post(
        ABOUT_DB_API +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify([
            "license_key",
            "validity",
            "licensee",
            "activation_date",
            "expiry_date",
            "purchase_date",
            "status",
          ])
      )
      .then((res) => {
        if (res.data.length > 1) {
          setStatus(res.data.status)
          console.log("status Inactive check", status)
          res.data.map((item, index) =>
            // first 10 digits of date
            setexpirydate(item.expiry_date.slice(0, 10).replace(/-/g, ""))
          )
        } else {
          setStatus("Not Activated")
        }
      })
      .catch((er) => console.log(er))
  }

  const handleAlertCloseFailed = () => {
    setAlertMessageState(false)
  }

  let newDate = new Date()
  const current_date = newDate.toISOString().slice(0, 10).replace(/-/g, "")
  const expiry_date_difference = parseInt(expiry_date) - parseInt(current_date)

  useEffect(() => {
    // const interval = setInterval(() => {
    if (expiry_date_difference === 0) {
      setAlertMessageState(true)
      setAlertMessage("License is  expiring Today")
    } else if (expiry_date_difference === 1) {
      setAlertMessageState(true)
      setAlertMessage("License is  expiring  in 1 day")
    } else if (expiry_date_difference > 1 && expiry_date_difference <= 15) {
      setAlertMessageState(true)
      setAlertMessage(
        "License is expiring in" + " " + expiry_date_difference + " " + "days"
      )
    } else if (expiry_date_difference < 0) {
      setAlertMessageState(true)
      setAlertMessage("License is Expired")
    } else if (status === "Active") {
      setAlertMessageState(false)
      setAlertMessage("")
    } else if (status === "Not Activated") {
      setAlertMessageState(true)
      console.log("status check", status)
      setAlertMessage("License Not Activated")
    } else if (status === "Inactive") {
      setAlertMessageState(true)
      console.log("status check", status)
      setAlertMessage("License Inactive")
    } else {
      setAlertMessageState(false)
      // setAlertMessage("Buy License")
    }
    // }, 2000)

    // return () => clearInterval(interval)
  }, [
    expiry_date_difference < 0 ||
      (expiry_date_difference > 1 && expiry_date_difference <= 15) ||
      expiry_date_difference === 0 ||
      expiry_date_difference === 1,
  ])
  useEffect(() => {
    const id = setInterval(() => {
      handleUserSession() // <-- (3) invoke in interval callback
    }, 5000)

    handleUserSession()

    return () => clearInterval(id)
  }, [])

  const handleUserSession = (e) => {
    if (userProfile) {
      axios
        .post(
          FETCH_SESSION_API + JSON.stringify({ username: userProfile.username })
        )
        .then((response) => {
          let session_id = response.data[0].session_id
          setUserSessionId(session_id)
          if (response.data[0].session_id !== userProfile.session_id) {
            navigate("/")
          }
        })
        .catch((err) => {
          console.log(err, "Logout API Error")
        })
    }
  }

  const logout_data = {
    username: userProfile ? userProfile.username : null,
    is_login: false,
    logout_time: new Date().toISOString(),
    session_id: userProfile.session_id,
  }
  const handleLogout = (e) => {
    console.log("Cancel Reservation")
    if (userProfile) {
      axios
        .post(LOGOUT_API + JSON.stringify(logout_data))
        .then((response) => {
          console.log(response.data.Message, "autologout")
          sessionStorage.removeItem("userData")
          navigate("/Login", { state: { autoLogout: true } })
        })
        .catch((err) => {
          console.log(err, "Logout API Error")
        })
    }
  }
  let userdata = JSON.parse(sessionStorage.getItem("userData"))
  const isAuth = userdata
  // const isAuth = true
  return isAuth ? (
    <div className="app-container">
      <NavBar />
      <div className="alertDeviceview">
        {alertMessageState && (
          <Alert
            severity="success"
            variant="filled"
            onClose={handleAlertCloseFailed}
            icon={false}
            className="alertBox1"
            style={{ backgroundColor: "#1eb6b6", color: "white" }}
            // sx={alertStyle}
          >
            {alertMessage}
          </Alert>
        )}
      </div>
      {children}
    </div>
  ) : (
    <Navigate to="/" />
  )
}

export default PrivateRoute
