// import React, { useEffect, useState } from "react"
// import "./Scheduling.css"
// import DatePicker from '../ReusableComponents/ReusableComponentsScheduling/Date/DatePicker'
// import TimePicker from '../ReusableComponents/ReusableComponentsScheduling/Time/TimePicker'
// import TimeZonePicker from '../ReusableComponents/ReusableComponentsScheduling/Timezone/Timezone'
// import ScheduleType from '../ReusableComponents/ReusableComponentsScheduling/Type/Schedule-type'
// import DaysPicker from '../ReusableComponents/ReusableComponentsScheduling/Days/DayPicker'
// import EndTimePicker from '../ReusableComponents/ReusableComponentsScheduling/EndTime/EndTimePicker'
// import EndDatePicker from '../ReusableComponents/ReusableComponentsScheduling/EndDate/EndDatePicker'


// const Scheduling = ({ handleClose, onSubmit }) => {
//   const [startDate, setStartDate] = useState()
//   const [endDate, setEndDate] = useState()
//   const [startTime, setStartTime] = useState()
//   const [endTime, setEndTime] = useState()
//   const [type, setType] = useState()
//   const [hour, setHours] = useState()
//   const [minute, setMinutes] = useState()
//   const [second, setSeconds] = useState()
//   const [endHour, setEndHours] = useState()
//   const [endMinute, setEndMinutes] = useState()
//   const [endSecond, setEndSeconds] = useState()
//   const [selectedYear, setSelectedYear] = useState()
//   const [selectedMonth, setSelectedMonth] = useState()
//   const [selectedDate, setSelectedDate] = useState()
//   const [selectedDay, setSelectedDay] = useState([])
//   const [selectedEndYear, setSelectedEndYear] = useState()
//   const [selectedEndMonth, setSelectedEndMonth] = useState()
//   const [selectedEndDate, setSelectedEndDate] = useState()
//   const [selectedEndDay, setSelectedEndDay] = useState()
//   const [endDateState, setEndDateState] = useState()
//   const [endTimeState, setEndTimeState] = useState()
//   const [days, setDays] = useState()
//   const [validationStatus, setValidationStatus] = useState({});

//   const CloseButton = ({ onClick }) => (
//     <button className="close-deviceview" onClick={onClick}>
//       <svg
//         xmlns="http://www.w3.org/2000/svg"
//         viewBox="0 0 24 24"
//         width="24"
//         height="24"
//         fill="none"
//         stroke="currentColor"
//         strokeWidth="2"
//         strokeLinecap="round"
//         strokeLinejoin="round"
//         className="feather feather-x"
//       >
//         <line x1="18" y1="6" x2="6" y2="18"></line>
//         <line x1="6" y1="6" x2="18" y2="18"></line>
//       </svg>
//     </button>
//   )

//   const handleSelectedType = (type) => {
//     setType(type)
//   }  

//   const handleSelectedDate = (date) => {
//     const dayNumber = ( new Date(date).getDay())
//     setStartDate(date);
//     setSelectedDay(dayNumber)
//     const [selectedYears, selectedMonths, selectedDates] = date.split('-');
//     setSelectedYear(selectedYears);
//     setSelectedMonth(selectedMonths);
//     setSelectedDate(selectedDates);
//   }

//   const handleSelectedEndDate = (date) => {
//     const dayNumber = ( new Date(date).getDay())
//     setEndDate(date.replace(/-/g, ':'));
//     setSelectedEndDay((dayNumber+6) % 7)
//     const [selectedYears, selectedMonths, selectedDates] = date.split('-');
//     setSelectedEndYear(selectedYears);
//     setSelectedEndMonth(selectedMonths);
//     setSelectedEndDate(selectedDates);
//   }

//   const handleSelectedTime = (time) => {
//     setStartTime(time)
//     const [hours, minutes] = time.split(':');
//     setHours(hours);
//     setMinutes(minutes);
//     setEndDateState(true)
//   }  

//   const handleSelectedEndTime = (endTime) => {
//     setEndTime(endTime)
//     const [hours, minutes] = endTime.split(':');
//     setEndHours(hours);
//     setEndMinutes(minutes);
//     setEndTimeState(true)
//   }  

//   const handleSelectedDays = (days) => {
//     setDays(days)
//   }
  
//   const getMonthEndDate =  (monthNumber) =>{
//     const date = new Date();
//     date.setMonth(monthNumber - 1)
//     date.setMonth(date.getMonth() + 1 , 0);
//     return date.getDate();
//   }
  
//   const typeSelect = (type) =>{
//     switch(type){
//       case 'Timely one time':
//         return {"M" : minute, "H": hour, "D": selectedDate, "MN": selectedMonth, "W": selectedDay};
  
//       case 'Hourly':
//         return {"M" : minute, "H": endTime ? `${hour}-${endHour}` : hour, "D": selectedEndDate ? [`${selectedDate}-${getMonthEndDate(selectedEndDate)},01-${selectedEndMonth}`] : selectedDate, "MN": selectedEndDate ? [`${selectedMonth}-${selectedEndMonth}`]: selectedMonth, "W": "*"};
      
//       case 'Daily':
//         return {"M" : minute, "H": hour, "D": selectedEndDate ? [`${selectedDate}-${getMonthEndDate(selectedEndDate)},01-${selectedEndMonth}`] : selectedDate, "MN": selectedEndDate ? [`${selectedMonth}-${selectedEndMonth}`]: selectedMonth, "W": "*"};
      
//       case 'Monthly':
//         return {"M" : minute, "H": hour, "D": selectedDate, "MN": selectedEndDate ? [`${selectedMonth}-${selectedEndMonth}`]: selectedMonth, "W": "*"};

//       case 'Weekly':
//         return {"M" : minute, "H": hour, "D": selectedDate, "MN": selectedEndDate ? [`${selectedMonth}-${selectedEndMonth}`]: selectedMonth, "W": days};

//       default:
//         return null
//     }
//   }
//   console.log('fd', startTime)
//   const handleSubmit = (event) => {
//     event.preventDefault();
//     const isValid = type && startTime && startDate ;
//     const isValidDays = (type === "Weekly") ? days : true
//     setValidationStatus({
//       scheduleType: type ? '' : 'Please select a valid type',
//       time: startTime ? '' : 'Please select a valid time',
//       Date: startDate ? '' : 'Please select a valid date',
//       Days: (type === "Weekly") ?  (days ? '' : 'Please select a valid days') : '' ,
//     })   
//     const EndTime = endDate + " " + endTime
//     const StartTime = startDate + " " + startTime

//     if(!!isValid && !!isValidDays ){
//       console.log('form submitted scheduling')
//       const formatedDate = startDate + "T" + startTime + ".400Z";
//       const data = {
//         schedule_type: type,
//         schedule_time: typeSelect(type),
//         Date: formatedDate,
//         start_time: StartTime,
//         end_time: endTime || selectedEndDate ? EndTime : "",
//       };
//       console.log(data, "datasc");
//       onSubmit(data);
//       handleClose();
//     }
//   }

//   return (
//     <>
//       <div className="Scheduling-overlay">
//         <div className="Scheduling-content" style={{ backgroundColor: "black" }}>
//           <div>
//             <CloseButton onClick={handleClose}/>
//           </div>

//           <div className="components">
//             <TimeZonePicker/>
//           </div>
//           <div className="components">
//             <ScheduleType onTypeSelect={handleSelectedType}/>
//             <div className="error-message">
//               {!type && validationStatus.scheduleType}
//             </div>
//           </div>

//           <div className="components">
//             <DatePicker 
//               scheduleDate={startDate}
//               onDateSelect={handleSelectedDate}
//             />
//              <div className="error-message">
//               {!startDate && validationStatus.Date}
//             </div>
//           </div>

//           <div className="components">
//             <TimePicker 
//               scheduleDate={startDate}
//               onTimeSelect={handleSelectedTime}
//               scheduleType={type}
//             />
//             <div className="error-message">
//               {!startTime &&  validationStatus.time}
//             </div>
//           </div>

//           {type === "Timely one time" || type === undefined ? "" :
//           <div>
//           <div className="components">
//             <EndDatePicker 
//               onSelectedDate={startDate}
//               onEndTimeSelect={handleSelectedEndDate}
//             />
//             <div className="error-message">
//               {!endDate &&  validationStatus.endDate}
//             </div>
//           </div>

//           {type !== "Hourly" ? "" :
//             <div className="components">
//               <EndTimePicker
//                 onSelectedEndTime={startTime}
//                 scheduleDate={startDate}
//                 onEndTimeSelect={handleSelectedEndTime}
//                 scheduleType={type}
//               />
//               <div className="error-message">
//                 {!endTime &&  validationStatus.endTime}
//               </div>
//             </div>
//             }
//             </div>
//           }
//           <div className="components">
//           <DaysPicker 
//           scheduleType={type}
//           onSelectDays={handleSelectedDays}
//           />
//             <div className="error-message">
//               {!days &&  validationStatus.Days}
//             </div>   
//           </div>
          
          
//           <div className="Scheduling-buttons">            
//             <button onClick={handleSubmit} className="btn-submit-Schedule">
//               Schedule
//             </button>
//           </div>
//         </div>
//       </div>
//     </>
//   )
// }
// export default Scheduling

/** * 
 * File: Scheduling.jsx
 * Description: * This file contents the implementation of user Scheduling the test cases.
 * All the components are wrapped into Scheduling function
 * Used to schedule testcase for future to execute
 * Author: Yuvaraj Dakhane
 * **/

 import React, { useEffect, useState } from "react" //  Importing React, useState from react
 import "./Scheduling.css"
 //Using components for days, time and date from /ReusableComponents/ReusableComponentsScheduling/ this path
 import DatePicker from '../ReusableComponents/ReusableComponentsScheduling/Date/DatePicker'
 import TimePicker from '../ReusableComponents/ReusableComponentsScheduling/Time/TimePicker'
 import TimeZonePicker from '../ReusableComponents/ReusableComponentsScheduling/Timezone/Timezone'
 import ScheduleType from '../ReusableComponents/ReusableComponentsScheduling/Type/ScheduleType'
 import DaysPicker from '../ReusableComponents/ReusableComponentsScheduling/Days/DayPicker'
 import EndTimePicker from '../ReusableComponents/ReusableComponentsScheduling/EndTime/EndTimePicker'
 import EndDatePicker from '../ReusableComponents/ReusableComponentsScheduling/EndDate/EndDatePicker'
 
 //Components are wrapped into scheduling and calling handleClose and onSubmit function as props
 const Scheduling = ({ handleClose, onSubmit }) => {
   //useState uses to store the state for particular properties
   const [startDate, setStartDate] = useState()
   const [startTime, setStartTime] = useState()
   const [endDate, setEndDate] = useState()
   const [endTime, setEndTime] = useState()
   const [type, setType] = useState()
   const [days, setDays] = useState()
   const [selectedDay, setSelectedDay] = useState()
   const [startHour, setStartHour] = useState()
   const [startMinute, setStartMinute] = useState()
   const [startSecond, setStartSecond] = useState()
   const [endHour, setEndHour] = useState()
   const [endMinute, setEndMinute] = useState()
   const [endSecond, setEndSecond] = useState()
   const [selectedStartDate, setSelectedStartDate] = useState()
   const [startMonth, setStartMonth] = useState()
   const [startYear, setStartYear] = useState()
   const [selectedEndYear, setSelectedEndYear] = useState()
   const [selectedEndMonth, setSelectedEndMonth] = useState()
   const [selectedEndDate, setSelectedEndDate] = useState()
   const [selectedEndDay, setSelectedEndDay] = useState()
   const [endDateState, setEndDateState] = useState()
   const [endTimeState, setEndTimeState] = useState()
   const [validationStatus, setValidationStatus] = useState({});
 
   const CloseButton = ({ onClick }) => (
     <button className="close-deviceview" onClick={onClick}>
       <svg
         xmlns="http://www.w3.org/2000/svg"
         viewBox="0 0 24 24"
         width="24"
         height="24"
         fill="none"
         stroke="currentColor"
         strokeWidth="2"
         strokeLinecap="round"
         strokeLinejoin="round"
         className="feather feather-x"
       >
         <line x1="18" y1="6" x2="6" y2="18"></line>
         <line x1="6" y1="6" x2="18" y2="18"></line>
       </svg>
     </button>
   )
 
   const handleSelectedType = (type) => {
     setType(type)
   }  
 
   const handleSelectedDate = (date) => {
     const dayNumber = ( new Date(date).getDay())
     setStartDate(date);
     setSelectedDay(dayNumber)
     const [selectedYear, selectedMonth, selectedDate] = date.split('-');
     setStartYear(selectedYear);
     setStartMonth(selectedMonth);
     setSelectedStartDate(selectedDate);
   }
 
   const handleSelectedEndDate = (date) => {
     const dayNumber = ( new Date(date).getDay())
     setEndDate(date.replace(/-/g, ':'));
     setSelectedEndDay((dayNumber+6) % 7)
     const [selectedYear, selectedMonth, selectedDate] = date.split('-');
     setSelectedEndYear(selectedYear);
     setSelectedEndMonth(selectedMonth);
     setSelectedEndDate(selectedDate);
   }
 
   const handleSelectedTime = (time) => {
     setStartTime(time)
     const [hours, minutes, second] = time.split(':');
     setStartHour(hours);
     setStartMinute(minutes);
     setStartSecond(second)
     setEndDateState(true)
   }  
 
   const handleSelectedEndTime = (endTime) => {
     setEndTime(endTime)
     const [hours, minutes, second] = endTime.split(':');
     setEndHour(hours);
     setEndMinute(minutes);
     setEndSecond(second);
     setEndTimeState(true)
   }  
 
   const handleSelectedDays = (days) => {
     setDays(days)
   }
   
   const getMonthEndDate =  (monthNumber) =>{
     const date = new Date();
     date.setMonth(monthNumber - 1)
     date.setMonth(date.getMonth() + 1 , 0);
     return date.getDate();
   }
   
   const typeSelect = (type) =>{
     switch(type){
       case 'Timely one time':
         return {"M" : startMinute, "H": startHour, "D": selectedStartDate, "MN": startMonth, "W": selectedDay};
   
       case 'Hourly':
         return {"M" : startMinute, "H": endTime ? `${startHour}-${endHour}` : startHour, "D": selectedEndDate ? [`${selectedStartDate}-${getMonthEndDate(selectedEndDate)},01-${selectedEndMonth}`] : selectedStartDate, "MN": selectedEndDate ? [`${startMonth}-${selectedEndMonth}`]: startMonth, "W": "*"};
       
       case 'Daily':
         return {"M" : startMinute, "H": startHour, "D": selectedEndDate ? [`${selectedStartDate}-${getMonthEndDate(selectedEndDate)},01-${selectedEndMonth}`] : selectedStartDate, "MN": selectedEndDate ? [`${startMonth}-${selectedEndMonth}`]: startMonth, "W": "*"};
       
       case 'Monthly':
         return {"M" : startMinute, "H": startHour, "D": selectedStartDate, "MN": selectedEndDate ? [`${startMonth}-${selectedEndMonth}`]: startMonth, "W": "*"};
 
       case 'Weekly':
         return {"M" : startMinute, "H": startHour, "D": selectedStartDate, "MN": selectedEndDate ? [`${startMonth}-${selectedEndMonth}`]: startMonth, "W": days};
 
       default:
         return null
     }
   }
   console.log('fd', days)
   const handleSubmit = (event) => {
     event.preventDefault();
     const isValid = type && startTime && startDate ;
     const isValidDays = (type === "Weekly") ? days : true
     setValidationStatus({
       scheduleType: type ? '' : 'Please select a valid type',
       time: startTime ? '' : 'Please select a valid time',
       Date: startDate ? '' : 'Please select a valid date',
       Days: (type === "Weekly") ?  (days ? '' : 'Please select a valid days') : '' ,
     })   
     const EndTime = endDate + " " + endTime
     const StartTime = startDate + " " + startTime
 
     if(!!isValid && !!isValidDays ){
       console.log('form submitted scheduling')
       const formatedDate = startDate + "T" + startTime + ".400Z";
       const data = {
         schedule_type: type,
         schedule_time: typeSelect(type),
         Date: formatedDate,
         start_time: StartTime,
         end_time: endTime || selectedEndDate ? EndTime : "",
       };
       console.log(data, "datasc");
       onSubmit(data);
       handleClose();
     }
   }
 
   return (
     <>
       <div className="Scheduling-overlay">
         <div className="Scheduling-content" style={{ backgroundColor: "black" }}>
           <div>
             <CloseButton onClick={handleClose}/>
           </div>
 
           <div className="components">
             <TimeZonePicker/>
           </div>
           <div className="components">
             <ScheduleType onTypeSelect={handleSelectedType}/>
             <div className="error-message">
               {!type && validationStatus.scheduleType}
             </div>
           </div>
 
           <div className="components">
             <DatePicker 
               scheduleDate={startDate}
               onDateSelect={handleSelectedDate}
             />
              <div className="error-message">
               {!startDate && validationStatus.Date}
             </div>
           </div>
 
           <div className="components">
             <TimePicker 
               scheduleDate={startDate}
               onTimeSelect={handleSelectedTime}
               scheduleType={type}
             />
             <div className="error-message">
               {!startTime &&  validationStatus.time}
             </div>
           </div>
 
           {type === "Timely one time" || type === undefined ? "" :
           <div>
           <div className="components">
             <EndDatePicker 
               onSelectedDate={startDate}
               onEndTimeSelect={handleSelectedEndDate}
             />
             <div className="error-message">
               {!endDate &&  validationStatus.endDate}
             </div>
           </div>
 
           {type !== "Hourly" ? "" :
             <div className="components">
               <EndTimePicker
                 onSelectedEndTime={startTime}
                 scheduleDate={startDate}
                 onEndTimeSelect={handleSelectedEndTime}
                 scheduleType={type}
               />
               <div className="error-message">
                 {!endTime &&  validationStatus.endTime}
               </div>
             </div>
             }
             </div>
           }
           <div className="components">
           <DaysPicker 
           scheduleType={type}
           onSelectDays={handleSelectedDays}
           />
             <div className="error-message">
               {!days &&  validationStatus.Days}
             </div>   
           </div>
           
           
           <div className="Scheduling-buttons">            
             <button onClick={handleSubmit} className="btn-submit-Schedule">
               Schedule
             </button>
           </div>
         </div>
       </div>
     </>
   )
 }
 export default Scheduling
 
 