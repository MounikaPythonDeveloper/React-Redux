/** *
 * File: Scheduling.jsx
 * Description: * This file contents the implementation of user Scheduling the test cases.
 * All the components are wrapped into Scheduling function
 * Used to schedule testcase for future to execute
 * Author: Yuvaraj Dakhane
 * **/

import React, { useEffect, useState } from "react"; //  Importing React, useState from react
import "./Scheduling.css";
//Using components for days, time and date from /ReusableComponents/ReusableComponentsScheduling/ this path
import DatePicker from "../ReusableComponents/ReusableComponentsScheduling/Date/DatePicker";
import TimePicker from "../ReusableComponents/ReusableComponentsScheduling/Time/TimePicker";
import TimeZonePicker from "../ReusableComponents/ReusableComponentsScheduling/Timezone/Timezone";
import ScheduleType from "../ReusableComponents/ReusableComponentsScheduling/Type/ScheduleType";
import DaysPicker from "../ReusableComponents/ReusableComponentsScheduling/Days/DayPicker";
import EndTimePicker from "../ReusableComponents/ReusableComponentsScheduling/EndTime/EndTimePicker";
import EndDatePicker from "../ReusableComponents/ReusableComponentsScheduling/EndDate/EndDatePicker";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";

//Components are wrapped into scheduling and calling handleClose and onSubmit function as props
const Scheduling = ({ handleClose, onSubmit }) => {
  const { theme } = useTheme();
  //useState uses to store the state for particular properties
  const [startDate, setStartDate] = useState();
  const [startTime, setStartTime] = useState();
  const [endDate, setEndDate] = useState();
  const [endTime, setEndTime] = useState();
  const [type, setType] = useState();
  const [days, setDays] = useState();
  const [selectedDay, setSelectedDay] = useState();
  const [startHour, setStartHour] = useState();
  const [startMinute, setStartMinute] = useState();
  const [startSecond, setStartSecond] = useState();
  const [endHour, setEndHour] = useState();
  const [endMinute, setEndMinute] = useState();
  const [endSecond, setEndSecond] = useState();
  const [selectedStartDate, setSelectedStartDate] = useState();
  const [startMonth, setStartMonth] = useState();
  const [startYear, setStartYear] = useState();
  const [selectedEndYear, setSelectedEndYear] = useState();
  const [selectedEndMonth, setSelectedEndMonth] = useState();
  const [selectedEndDate, setSelectedEndDate] = useState();
  const [startDateError, setStartDateError] = useState();
  const [endDateError, setEndDateError] = useState();
  const [startTimeError, setStartTimeError] = useState();
  const [endTimeError, setEndTimeError] = useState();
  const [validationStatus, setValidationStatus] = useState({});

  const getCurrentTime = () => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    return `${hours}:${minutes}`;
  };

  const today = new Date().toISOString().split("T")[0]; //converting date into ISOString and splitted after T. Output: yyyy-mm-dd
  // const todayTime = getCurrentTime()

  //CloseButton function for closing the popup of scheduling and displaying svg image of close icon
  const CloseButton = ({ onClick }) => (
    <button className="close-Scheduling" onClick={onClick}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  );

  //function used to set type of scheduling in setType state
  const handleSelectedType = (type) => {
    setType(type);
  };

  //function used to set start Date and other properties of date for scheduling in the states
  const handleSelectedDate = (date) => {
    if (date < today) {
      setStartDateError("Please select a date in the future");
      setStartDate(date);
    } else {
      setStartDateError("");
      const dayNumber = new Date(date).getDay();
      setStartDate(date);
      setSelectedDay(dayNumber);
      const [selectedYear, selectedMonth, selectedDate] = date.split("-");
      setStartYear(selectedYear);
      setStartMonth(selectedMonth);
      setSelectedStartDate(selectedDate);
    }
  };

  //function used to set end Date and other properties of date for scheduling in the states
  const handleSelectedEndDate = (date) => {
    if (date < startDate) {
      setEndDateError("Please Select the future date");
    } else {
      setEndDateError("");
      setEndDate(date);
      const [selectedYear, selectedMonth, selectedDate] = date.split("-");
      setSelectedEndYear(selectedYear);
      setSelectedEndMonth(selectedMonth);
      setSelectedEndDate(selectedDate);
    }
  };
  const chekcIsTrue = today === startDate;
  const todayTime = chekcIsTrue ? getCurrentTime() : null;
  //function used to set start time and other properties of time for scheduling in the states
  const handleSelectedTime = (time) => {
    if (time < todayTime) {
      setStartTimeError("Please select a time in the future");
      setStartTime(time);
    } else {
      setStartTimeError("");
      setStartTime(time);
      const [hours, minutes, second] = time.split(":");
      setStartHour(hours);
      setStartMinute(minutes);
      setStartSecond(second);
    }
  };

  const checkIsEndTimeValid = startDate !== endDate;
  const endTimeValid = checkIsEndTimeValid ? null : startTime;

  //function used to set end Time and other properties of time for scheduling in the states
  const handleSelectedEndTime = (end_Time) => {
    if (end_Time < endTimeValid) {
      setEndTimeError("Please Select the future time");
    } else {
      setEndTimeError("");
      setEndTime(end_Time);
      const [hours, minutes, second] = end_Time.split(":");
      setEndHour(hours);
      setEndMinute(minutes);
      setEndSecond(second);
    }
  };

  //function the days selected from DayPicker components in setDays state
  const handleSelectedDays = (days) => {
    setDays(days);
  };

  //function used to return the end date of the particular month when getMontheEndDate
  const getMonthEndDate = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const lastDay = new Date(year, month, 0).getDate();
    return lastDay;
  };
  const hasGap = selectedEndMonth - startMonth > 1;
  const checkEqualMonth = startMonth === selectedEndMonth;
  //function the JSON format for selected type
  const typeSelect = (type) => {
    switch (type) {
      case "Timely one time":
        return {
          M: startMinute,
          H: startHour,
          D: selectedStartDate,
          MN: startMonth,
          W: selectedDay,
        };

      case "Hourly":
        return {
          M: startMinute,
          H: `${startHour}-${endHour}`,
          D: checkEqualMonth
            ? `${selectedStartDate}-${selectedEndDate}`
            : `${selectedStartDate}-${getMonthEndDate(
                new Date(endDate)
              )},01-${selectedEndDate}`,
          MN: checkEqualMonth
            ? startMonth
            : hasGap
            ? `${startMonth},*,${selectedEndMonth}`
            : `${startMonth},${selectedEndMonth}`,
          W: "*",
        };

      case "Daily":
        return {
          M: startMinute,
          H: startHour,
          D: checkEqualMonth
            ? `${selectedStartDate}-${selectedEndDate}`
            : `${selectedStartDate}-${getMonthEndDate(
                new Date(endDate)
              )},01-${selectedEndDate}`,
          MN: checkEqualMonth
            ? startMonth
            : hasGap
            ? `${startMonth},*,${selectedEndMonth}`
            : `${startMonth},${selectedEndMonth}`,
          W: "*",
        };

      case "Weekly":
        return {
          M: startMinute,
          H: startHour,
          D: checkEqualMonth
            ? `${selectedStartDate}-${selectedEndDate}`
            : `${selectedStartDate}-${getMonthEndDate(
                new Date(endDate)
              )},01-${selectedEndDate}`,
          MN: checkEqualMonth
            ? startMonth
            : hasGap
            ? `${startMonth},*,${selectedEndMonth}`
            : `${startMonth},${selectedEndMonth}`,
          W: `${days.map((day) => parseInt(day))}`,
        };

      case "Monthly":
        return {
          M: startMinute,
          H: startHour,
          D: selectedStartDate,
          MN: checkEqualMonth
            ? startMonth
            : hasGap
            ? `${startMonth},*,${selectedEndMonth}`
            : `${startMonth},${selectedEndMonth}`,
          W: "*",
        };

      default:
        return null;
    }
  };
  //Function used to call when submit button is click it check the validation schema and store the data and passes to OnSubmit
  const handleSubmit = (event) => {
    event.preventDefault();
    const isValid = type && startTime && startDate;
    const isValidDays = type === "Weekly" ? days : true;
    setValidationStatus({
      scheduleType: type ? "" : "Please select a valid type",
      startTime: startTime ? "" : "Please select a start time",
      startDate: startDate ? "" : "Please select a start date",
      Days: type === "Weekly" ? (days ? "" : "Please select a valid days") : "",
      endTime:
        type === "Timely one time"
          ? ""
          : endTime
          ? ""
          : "Please select a end Time",
      endDate:
        type === "Timely one time"
          ? ""
          : endDate
          ? ""
          : "Please select a end Date",
    });
    const EndTime = endDate + " " + endTime;
    const StartTime = startDate + " " + startTime;

    if (
      !!isValid &&
      !!isValidDays &&
      !startDateError &&
      !startTimeError &&
      !endDateError &&
      !endTimeError
    ) {
      const formatedDate = startDate + "T" + startTime + ".400Z";
      let data;
      data = {
        schedule_type: type,
        schedule_time: typeSelect(type),
        Date: formatedDate,
        start_time: StartTime,
        end_time: endTime && selectedEndDate ? EndTime : "",
      };
      onSubmit(data);
      handleClose();
    }
  };

  //It render the components
  return (
    <>
      <div
        className={`Scheduling-overlay ${theme === "dark" ? "dark" : "light"}`}
      >
        <div
          className="Scheduling-content"
          // style={{ backgroundColor: "black" }}
        >
          <div>
            <CloseButton onClick={handleClose} />
          </div>

          <div className="components">
            <TimeZonePicker />
          </div>
          <div className="components">
            <ScheduleType onTypeSelect={handleSelectedType} />
            <div className="error-message">
              {!type && validationStatus.scheduleType}
            </div>
          </div>

          <div className="components">
            <DatePicker
              scheduleDate={startDate}
              onDateSelect={handleSelectedDate}
            />
            <div className="error-message">
              {!startDate && validationStatus.startDate}
              {startDateError}
            </div>
          </div>

          <div className="components">
            <TimePicker
              scheduleDate={startDate}
              onTimeSelect={handleSelectedTime}
              scheduleType={type}
            />
            <div className="error-message">
              {!startTime && validationStatus.startTime}
              {startTimeError}
            </div>
          </div>

          {type === "Timely one time" || type === undefined ? (
            ""
          ) : (
            <div>
              <div className="components">
                <EndDatePicker
                  onSelectedDate={startDate}
                  onEndDateSelect={handleSelectedEndDate}
                />
                <div className="error-message">
                  {!endDate && validationStatus.endDate}
                  {endDateError}
                </div>
              </div>

              <div className="components">
                <EndTimePicker
                  onSelectedEndTime={startTime}
                  scheduleDate={startDate}
                  onSelectEndDate={endDate}
                  onEndTimeSelect={handleSelectedEndTime}
                />
                <div className="error-message">
                  {!endTime && validationStatus.endTime}
                  {endTimeError}
                </div>
              </div>
            </div>
          )}
          <div className="components">
            <DaysPicker scheduleType={type} onSelectDays={handleSelectedDays} />
            <div className="error-message">
              {!days && validationStatus.Days}
            </div>
          </div>

          <div className="Scheduling-buttons">
            <button onClick={handleSubmit} className="btn-submit-Schedule">
              Schedule
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default Scheduling;
