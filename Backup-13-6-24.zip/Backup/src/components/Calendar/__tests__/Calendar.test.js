import React from "react"
import { fireEvent, render, screen } from "@testing-library/react"
import Calendar from "../Calendar"
import "@testing-library/jest-dom/extend-expect"
describe("Calendar", () => {
  it("should render the button to open calendar", () => {
    const { getByText } = render(<Calendar />)
    const openButton = getByText("Open")
    expect(openButton).toBeInTheDocument()
  })

  it("should not show the modal by default", () => {
    const { queryByText } = render(<Calendar />)
    const modalContent = queryByText("Start:")
    expect(modalContent).not.toBeInTheDocument()
  })

  it("should show the modal when the button is clicked and see for start and end date textbox", () => {
    const { getByText, getByLabelText } = render(<Calendar />)
    const openButton = getByText("Open")
    fireEvent.click(openButton)
    const startDateLabel = getByLabelText("Start:")
    expect(startDateLabel).toBeInTheDocument()
    const endDateLabel = getByLabelText("End:")
    expect(endDateLabel).toBeInTheDocument()
    const CancelButton = getByText("Cancel")
    expect(endDateLabel).toBeInTheDocument()
    const SubmitButton = getByText("Submit")
    expect(endDateLabel).toBeInTheDocument()
  })

  test("close modal button is clicked", () => {
    const { getByText, getByLabelText } = render(<Calendar />)

    const openModalButton = getByText("Open")

    fireEvent.click(openModalButton)

    const closeModalButton = document.getElementsByClassName("close-modal")[0]

    fireEvent.click(closeModalButton)

    expect(document.body.classList.contains("active-modal")).toBe(false)
  })
})
