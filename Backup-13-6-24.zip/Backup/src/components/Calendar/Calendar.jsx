import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import { DateTimePicker } from "@progress/kendo-react-dateinputs";
import "./Calendar.css";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import { useLocation, useNavigate } from "react-router-dom";
import { DEVICE_RESERVATION_API } from "../../services/api";
import axios from "axios";
import { FormHelperText } from "@mui/material";
import { Button } from "@mui/material";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";

const Calendar = ({
  device = null,
  Popups,
  Remotetoast,
  toggletab,
  reservationcategory,
  handleClose,
}) => {
  const [startDate, setStartDate] = useState(new Date());
  const { theme } = useTheme();
  const [endDate, setEndDate] = useState(null);
  const [category, setCategory] = React.useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // const [modal, setModal] = useState(false);

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  console.log(device, "nikita");

  const minDate = new Date();

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  const CloseButton = ({ onClick }) => (
    <button className="close-modal" onClick={onClick}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  );

  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const location = useLocation();
  const DeviceViewInfo = location.state?.data;

  const handleChange = (event) => {
    setCategory(event.target.value);
    console.log("age", category);
  };

  const handleSubmit = (event) => {
    console.log("Form submitted");
    event.preventDefault();
    if (category || endDate) {
      const startTime = `${
        startDate &&
        startDate.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })
      }`;
      const endTime = `${
        endDate &&
        endDate.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })
      }`;
      const startDate1 = `${
        startDate && startDate.toISOString().substring(0, 10)
      }`;
      const endDate1 = `${endDate && endDate.toISOString().substring(0, 10)}`;
      console.log(
        startTime,
        endTime,
        startDate1,
        endDate1,
        "device_name",
        device,
        "reserved by",
        userProfile.username,
        "category",
        category
      );
      axios.post(
        DEVICE_RESERVATION_API +
          JSON.stringify({
            start_time: startTime,
            end_time: endTime,
            start_date: startDate1,
            end_date: endDate1,
            device_name: [device],
            reserved_by: userProfile.username,
            reservation_category: category,
          })
      );
    } else {
      setErrorMessage("Please Enter all fields");
    }
  };

  return (
    <>
      <div className="modal-overlay">
        <div
          className={`modal-content-cal ${theme === "dark" ? "dark" : "light"}`}
        >
          <CloseButton onClick={handleClose} />
          <div className="modal-form">
            <div className="modal-form-row">
              <label htmlFor="start-date">Start:</label>
              <DateTimePicker
                id="start-date"
                value={startDate}
                onChange={handleStartDateChange}
                min={minDate}
                className="modal-datetimepicker"
              />
            </div>
            &nbsp;
            <div className="modal-form-row">
              <label htmlFor="end-date">End:</label>
              <DateTimePicker
                id="datetime"
                value={endDate}
                onChange={handleEndDateChange}
                className="modal-datetimepicker"
              />
            </div>
            <div>
              <FormControl
                variant="standard"
                sx={{ m: 1, minWidth: 120 }}
                required
              >
                <InputLabel id="demo-simple-select-standard-label">
                  Select Category
                </InputLabel>
                <Select
                  labelId="demo-simple-select-standard-label"
                  id="demo-simple-select-standard"
                  value={category}
                  onChange={handleChange}
                  label="Age"
                >
                  <MenuItem value={"Manual"}>Manual</MenuItem>
                  <MenuItem value={"Automation"}>Automation</MenuItem>
                </Select>
                <FormHelperText>{errorMessage}</FormHelperText>
              </FormControl>
            </div>
          </div>
          <div className="modal-buttons">
            <button onClick={handleClose} className="btn-cancel">
              Cancel
            </button>
            <button onClick={handleSubmit} className="btn-submit">
              Submit
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default Calendar;
