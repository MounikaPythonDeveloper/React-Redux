import React, { useState, useEffect } from "react"
export default function DisableShortcuts() {
  useEffect(() => {
    const blockShortcuts = (event) => {
      if (event.ctrlKey || event.metaKey || event.altKey) {
        event.preventDefault()
      }
    }

    document.addEventListener("keydown", blockShortcuts)

    return () => {
      document.removeEventListener("keydown", blockShortcuts)
    }
  }, [])
  useEffect(() => {
    function disableRightClick(event) {
      event.preventDefault()
      // alert("right click disabled");
    }

    window.addEventListener("contextmenu", disableRightClick)

    return () => {
      window.removeEventListener("contextmenu", disableRightClick)
    }
  }, [])
  useEffect(() => {
    function handleKeyDown(event) {
      if (
        (event.ctrlKey && event.shiftKey && event.key === "I") ||
        (event.ctrlKey && event.key === "U")
      ) {
        event.preventDefault()
        // alert("Keyboard shortcut disabled");
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])
  useEffect(() => {
    function handleKeyDown(event) {
      if (event.ctrlKey || event.key === "C") {
        event.preventDefault()
        // alert("Keyboard shortcut disabled");
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])
  useEffect(() => {
    function handleKeyDown(event) {
      if (event.ctrlKey && event.key === "u") {
        event.preventDefault()
        // alert("Keyboard shortcut disabled");
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (
        (event.keyCode >= 112 && event.keyCode <= 123) ||
        event.key.startsWith("F")
      ) {
        // Function keys
        event.preventDefault()
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])

  // useEffect(() => {
  //   const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent)

  //   if (isSafari) {
  //     document.addEventListener("keydown", handleKeydown)
  //   }

  //   return () => {
  //     if (isSafari) {
  //       document.removeEventListener("keydown", handleKeydown)
  //     }
  //   }
  // }, [])

  function handleKeydown(event) {
    event.preventDefault()
  }
  return null
}
