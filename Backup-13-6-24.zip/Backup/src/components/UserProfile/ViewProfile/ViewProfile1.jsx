import React from "react";
import { useState, useEffect, useContext } from "react";
import "../ViewProfile/ViewProfile.css";
import { Link, useLocation } from "react-router-dom";
import userprofilelogo from "../../../assets/images/userprofilelogo.svg";
import ImageContext from "../../../context/ImageContext";
import Licenseinformation from "../../License/Licenseinformation";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import axios from "axios";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";

import {
  VALIDATE_BUYLICENSE_STATUS,
  FETCH_PROFILE_API,
  ABOUT_DB_API,
} from "../../../services/api";
import { useNavigate } from "react-router-dom";
const ViewProfile = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const [profilePic, setProfilePic] = useState(null);
  const { updateImageData, ImageData } = useContext(ImageContext);
  const [buildPopupOpen, setBuildPopupOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [status, setStatus] = useState("");
  const [statusLicense, setStatusLicense] = useState("");
  const [aboutdata, setaboutdata] = useState("");
  const navigate = useNavigate();
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnEditUserProfilePage =
    location.pathname === "/platform/viewprofile/edituserprofile";
  const isOnChangePasswordPage =
    location.pathname === "/platform/viewprofile/changepassword";
  const isOnAboutLicensePage =
    location.pathname === "/platform/viewprofile/aboutLicense";

  const fetchProfilePicture = () => {
    fetch(`${FETCH_PROFILE_API}${userProfile.username}.png`)
      .then((response) => {
        console.log("Image", response.url);

        updateImageData(response.url);
      })
      .catch((error) => {
        console.log("Failed to fetch image:", error); // Handle error
      });
  };

  //Validate License key to the particular use
  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )
      .then((res) => {
        setStatus(Object.values(res.data)[0]);
        console.log("apidata status", res.data.status[0] === "Active");
        if (res.data.status.length === 0) {
          setStatusLicense("Not Activated");
        } else {
          setStatusLicense(res.data.status[0]);
        }
        if (res.data.status[0] !== "Active") {
          setModalOpen(true);
        }
        if (res.data.status[0] === "Active") {
          if (
            isOnPlatformPage ||
            isOnAboutLicensePage ||
            isOnViewProfile ||
            isOnAboutPage
          ) {
            navigate("/platform/viewprofile/aboutLicense");
          } else {
            if (platform_data === "Media And Entertainment") {
              navigate("/platform/M&E/viewprofile/aboutLicense");
            } else {
              navigate(
                "/platform/" + platform_data + "/viewprofile/aboutLicense"
              );
            }
          }
        }
      })
      .catch((er) => console.log(er));
  };
  console.log("status prev", status);
  useEffect(() => {
    fetchProfilePicture();
    aboutLicense();
  }, []);

  useEffect(() => {
    if (ImageData) {
      console.log(ImageData.newImageData, "ImageDataImageData");
      setProfilePic(ImageData.newImageData);
    }
  }, [ImageData]);

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setModalOpen(false);
  };

  const aboutLicense = () => {
    axios
      .post(
        ABOUT_DB_API +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify([
            "license_key",
            "validity",
            "licensee",
            "activation_date",
            "expiry_date",
            "purchase_date",
          ])
      )
      .then((res) => {
        console.log("about", res.data);
        setaboutdata(res.data);
        sessionStorage.setItem("aboutinfo", JSON.stringify(res.data));
      })

      .catch((er) => console.log(er));
  };

  const handleSource = () => {
    if (profilePic) {
      return `${profilePic}&cache=${Date.now()}`;
    } else {
      return userprofilelogo;
    }
  };

  const functionHandle = function () {
    setOpen(false);
  };
  const buildOpenHandler = (event) => {
    event.preventDefault();
    setBuildPopupOpen(true);
  };
  const LicenseModal = (event) => {
    event.preventDefault();
    ValidateLicensestatus();
  };
  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <div className={`edit_page ${theme === "dark" ? "dark" : "light"}`}>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnChangePasswordPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Typography color="#0D6EFD">View Profile</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link Link to="/platform">
            M&E
          </Link>
          <Typography color="#0D6EFD">View Profile</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link Link to="/platform">
            {platform_data}
          </Link>
          <Typography color="#0D6EFD">View Profile</Typography>
        </Breadcrumbs>
      )}
      <div className="container">
        <div className="user_logo">
          <img
            src={handleSource()}
            onDragStart={preventDragHandler}
            alt="User Image"
            style={{
              width: "150px",
              height: "150px",
              borderRadius: "50%",
              objectFit: "cover",
            }}
          ></img>
        </div>

        <div className="user_role">
          <p>{userProfile.user_privilege}</p>
        </div>
        <div className="user_name_mail">
          <p>Username: {userProfile.username}</p>
          <p className="paragraph">Email: {userProfile.email_id}</p>
        </div>
        <div className="link_to">
          <div className="nav-link">
            <p onClick={LicenseModal}>License Information</p>
          </div>

          <Licenseinformation
            open={modalOpen}
            text={"Your Product is " + statusLicense + "...!!!"}
            handleClose={handleClosePopup}
            functionHandle={functionHandle}
            status={status}
          />

          {isOnPlatformPage ||
          isOnAboutPage ||
          isOnViewProfile ||
          isOnChangePasswordPage ? (
            <Link
              to={"/platform/viewprofile/changepassword"}
              className={`nav-link ${
                location.pathname === "/platform/viewprofile/changepassword"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <p>Change Password</p>
            </Link>
          ) : platform_data === "Media And Entertainment" ? (
            <Link
              to={"/platform/M&E/viewprofile/changepassword"}
              className={`nav-link ${
                location.pathname === "/platform/M&E/viewprofile/changepassword"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <p>Change Password</p>
            </Link>
          ) : (
            <Link
              to={"/platform/" + platform_data + "/viewprofile/changepassword"}
              className={`nav-link ${
                location.pathname ===
                "/platform/" + platform_data + "/viewprofile/changepassword"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <p>Change Password</p>
            </Link>
          )}
        </div>
        <div>
          {isOnPlatformPage ||
          isOnAboutPage ||
          isOnViewProfile ||
          isOnEditUserProfilePage ? (
            <Link
              to="/platform/viewprofile/edituserprofile"
              className={`nav-link ${
                location.pathname === "/platform/viewprofile/edituserprofile"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <button className="edit_button">Edit Profile</button>
            </Link>
          ) : platform_data === "Media And Entertainment" ? (
            <Link
              to={"/platform/M&E/viewprofile/edituserprofile"}
              className={`nav-link ${
                location.pathname ===
                "/platform/M&E/viewprofile/edituserprofile"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <button className="edit_button">Edit Profile</button>
            </Link>
          ) : (
            <Link
              to={"/platform/" + platform_data + "/viewprofile/edituserprofile"}
              className={`nav-link ${
                location.pathname ===
                "/platform/" + platform_data + "/viewprofile/edituserprofile"
                  ? "nav-active"
                  : "nav-active "
              }`}
            >
              <button className="edit_button">Edit Profile</button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewProfile;
