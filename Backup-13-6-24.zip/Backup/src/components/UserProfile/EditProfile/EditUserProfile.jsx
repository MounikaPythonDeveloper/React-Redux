import React, { useContext, useState, useEffect } from "react";
// import { useState, useEffect } from "react"
import "./EditUserProfile.css";
import defaultprofile from "../../../assets/images/userprofilelogo.svg";
import uploadlogo from "../../../assets/images/uploadlogo.svg";
import Button from "@mui/material/Button";
import Arrow from "../../../assets/images/Arrow 2.svg";
import { querySelectorAll } from "dom-helpers";
import TextField from "@material-ui/core/TextField";
import { useForm } from "react-hook-form";
import axios from "axios";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";
import { useNavigate, Link, useLocation } from "react-router-dom";

import {
  VALIDATE_USERNAME_API,
  VALIDATE_EMAIL_API,
  EDIT_USERDATA_API,
  UPLOAD_PROFILE_API,
  FETCH_PROFILE_API,
} from "../../../services/api";
import { FormHelperText, makeStyles } from "@material-ui/core";
import { Alert, Snackbar } from "@mui/material";
import ImageContext from "../../../context/ImageContext";
import { Breadcrumbs, Typography } from "@mui/material";

import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
const useStyle = makeStyles((theme) => ({
  helperText: {
    color: "red",
    fontSize: 13,
    position: "absolute",
    bottom: "-20px",
  },
}));

const EditUserProfile = () => {
  const { theme } = useTheme();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const location = useLocation();
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnEditUserProfilePage =
    location.pathname === "/platform/viewprofile/edituserprofile";
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const [usernameValid, setUsernameValid] = useState("");
  const [emailValid, setEmailValid] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState({ username: "", email_id: "" });
  const [profilePic, setProfilePic] = useState(null);
  const [uploadedConfirmation, setUploadedConfirmation] = useState(false);
  const { updateImageData } = useContext(ImageContext);

  const navigate = useNavigate();

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    const username = userProfile.username;
    const formData = new FormData();
    formData.append("username", username);
    formData.append("image", file);
    console.log(formData, "formData");

    // fetch("http://3.7.28.3:5001/update_profile_picture", {
    //   method: "POST",
    //   body: formData,
    // })
    fetch(`${UPLOAD_PROFILE_API}`, {
      method: "POST",
      // headers: {"Content-Type":"multipart/form-data; boundary=xxBOUNDARYxx"},
      body: formData,
    })
      .then((response) => {
        response.json();
        setUploadedConfirmation(response.ok);
        fetchProfilePicture();
      })

      .catch((error) => {
        console.log("Failed to upload image:", error); // Handle error
        setTimeout(() => {
          setLoadImage(`${Math.random()}`);
          console.log("Delay");
        }, 1000);
        // window.location.reload()
        // window.location.href=window.location.href;
      });
    console.log("Funtion Called");
  };

  const fetchProfilePicture = () => {
    // fetch(
    //   `http://13.127.47.2:5001/fetch_profile_picture?image=${userProfile.username}.png`
    // )
    fetch(`${FETCH_PROFILE_API}${userProfile.username}.png`)
      .then((response) => {
        console.log("Image", response.url);
        setProfilePic(response.url);
        //
        updateImageData(response.url);
        console.log("Data is Setting");
      })
      .catch((error) => {
        console.log("Failed to fetch image:", error); // Handle error
      });
  };

  useEffect(() => {
    fetchProfilePicture();
  }, []);

  const classes = useStyle();

  const texfieldInputStyle = {
    // backgroundColor:"transparent",
    borderBottom: "1px solid grey",
    color: "#FFFFFF",
    fontFamily: "Open Sans",
    fontSize: 20,
  };

  const texfieldLabelStyle = {
    color: "#FFFFFF",
    opacity: 1,
    fontSize: 18,
    fontFamily: "Open Sans",
    paddingTop: 5,
  };

  const checkUsername = (uname) => {
    axios
      .post(VALIDATE_USERNAME_API + JSON.stringify({ username: uname }))
      .then((response) => {
        if (response.data === true) {
          let value = "true";
          setUsernameValid(value);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Check email is already exist or not
  const checkEmail = (email_id) => {
    axios
      .post(VALIDATE_EMAIL_API + JSON.stringify({ email_id: email_id }))
      .then((response) => {
        if (response.data === true) {
          let value = "true";
          setEmailValid(value);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const handleUsernameBlur = (e) => {
    checkUsername(e.target.value);
    setUsernameValid("");

    if (e.target.value.length < 4) {
      setUsername(true);
    } else {
      setUsername(false);
    }
    // console.log("emailuserid", username)
  };

  const handEmailBlur = (e) => {
    checkEmail(e.target.value);
    setEmailValid("");
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(e.target.value)) {
      setEmail(true);
    } else {
      setEmail(false);
    }
  };

  const [file, setFile] = useState();
  function handleChange(e) {
    console.log(e.target.files);
    // setFile(e.target.files[0]);
    setFile(URL.createObjectURL(e.target.files[0]));
  }

  const image = document.querySelector("img"),
    input = document.querySelector("img");
  if (input) {
    input.addEventListener("change", () => {
      image.src = URL.createObjectURL(input.files[0]);
    });
  }

  // get functions to build form with useForm() hook
  const { register, handleSubmit, reset, formState } = useForm();

  //**************//
  const [selectedFile, setSelectedFile] = useState();
  const [preview, setPreview] = useState();
  const [loadImage, setLoadImage] = useState("load");

  function change_username_mail_id(data) {
    console.log(data, "daataa");
    const edit_data = {
      username: userProfile.username,
      new_email_id: data.email.toLowerCase(),
      new_username: data.uname.toLowerCase(),
    };
    console.log(edit_data, "dddddddddd");

    console.log("emailabc", email, username);
    axios
      .post(EDIT_USERDATA_API + JSON.stringify(edit_data))
      .then((response) => {
        console.log(response.data, "success");
        if (response.data.valid === "true") {
          console.log("valid_data", response.data.email_id);
          setUsername(response.data.username);
          setEmail(response.data.email_id);
          // setActive(1)
        } else {
          setError(response.data);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  }

  const clearData = () => {
    document.getElementById("edit_mail_username").reset();
  };

  const handleSource = () => {
    if (profilePic) {
      return `${profilePic}&cache=${Date.now()}`;
    } else {
      if (preview) {
        return preview;
      } else {
        return defaultprofile;
      }
    }
  };

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnEditUserProfilePage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/viewprofile"} onDragStart={preventDragHandler}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">Edit User Profile</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link Link to="/platform" onDragStart={preventDragHandler}>
            {platform_data}{" "}
          </Link>
          <Link to={"/platform/M&E/viewprofile"}>View Profile</Link>
          <Typography color="#0D6EFD">Edit User Profile</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link Link to="/platform" onDragStart={preventDragHandler}>
            {platform_data}{" "}
          </Link>
          <Link
            to={"/platform/" + platform_data + "/viewprofile"}
            onDragStart={preventDragHandler}
          >
            View Profile
          </Link>
          <Typography color="#0D6EFD">Edit User Profile</Typography>
        </Breadcrumbs>
      )}
      <div>
        <div className="DevicesView">
          {/* <div className="device-back-navigation">
          <img src={Arrow} onClick={() => navigate("/viewprofile")} />
          <div className="device-txt" onClick={() => navigate("/viewprofile")}>
            View Profile
          </div>
        </div> */}
        </div>
        <div
          className={`sub_container2 ${theme === "dark" ? "dark" : "light"}`}
        >
          <Snackbar
            className="delete-alert-message"
            open={uploadedConfirmation}
            autoHideDuration={6000}
            onClose={() => setUploadedConfirmation(false)}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {uploadedConfirmation === true && (
              <Alert icon={false}>Uploaded Profile Picture Successfully</Alert>
            )}
          </Snackbar>
          <h2>Edit Profile</h2>
          <div className="edit_user_logo">
            {console.log(
              profilePic ? profilePic : preview || defaultprofile,
              "daaataa"
            )}
            {loadImage && (
              <div>
                <img
                  src={handleSource()}
                  // key={loadImage}
                  style={{
                    width: "94px",
                    height: "94px",
                    borderRadius: "100px",
                    backgroundColor: "#FFFFFF",
                    objectFit: "cover",
                  }}
                />
                {console.log("Load Delay")}
              </div>
            )}
            <Button
              variant=""
              component="label"
              onChange={handleImageChange}
              style={{ background: "none", "margin-left": "-55px" }}
            >
              <img
                src={uploadlogo}
                style={{ width: "20px", height: "22px", "margin-top": "50px" }}
              />
              <input type="file" accept="image/jpeg" hidden />
            </Button>
            <div className="photo_text">
              <p>Click here to update your photo</p>
            </div>
            {/* <input variant="contained" component="label">Upload File<input type="file" hidden /></input> */}
          </div>
          {/* <form id = "edit_mail_username"> */}
          {/* <form
          id="edit_mail_username"
          onSubmit={handleSubmit(change_username_mail_id)}
        >
          <div
            className="text-input"
            style={{ backgroundColor: "transparent" }}
          >
            <TextField
              label="Username"
              className="text-field"
              id="standard-basic"
              variant="standard"
              {...register("uname", {
                required: "uname is required",
              })}
              // setField={setUsernameField}
              onBlur={handleUsernameBlur}
              username={username}
              helperText={[
                username ? "Atleast 4+ characters" : "",
                usernameValid === "true" &&
                  "Username already exist, please try other username",
              ]}
              InputProps={{
                style: texfieldInputStyle,
              }}
              InputLabelProps={{
                style: texfieldLabelStyle,
              }}
              FormHelperTextProps={{
                classes: { root: classes.helperText },
              }}
            />
            <br />
            {error.username && error.username}
          </div>

          <div className="text-input">
            <TextField
              id="standard-basic"
              label="Email"
              variant="standard"
              {...register("email", {
                required: "email is required",
              })}
              onBlur={handEmailBlur}
              email={email}
              helperText={[
                email ? "Invalid email" : "",
                emailValid === "true" &&
                  "email already exist, please try other email-id",
              ]}
              // error={!!errors.email}
              InputProps={{
                style: texfieldInputStyle,
              }}
              InputLabelProps={{
                style: texfieldLabelStyle,
              }}
              FormHelperTextProps={{
                classes: { root: classes.helperText },
              }}
            />
            <br />
            {error.email_id && error.email_id}
          </div>
          <div className="submit_cancel_button">
            <button
              onClick={() => navigate("/viewprofile")}
              id="disable"
              type="button"
              className="cancel_button"
            >
              Cancel
            </button>
            <button type="submit" className="submit_button">
              Submit
            </button>
          </div>
        </form> */}
        </div>
      </div>
    </>
  );
};
export default EditUserProfile;
