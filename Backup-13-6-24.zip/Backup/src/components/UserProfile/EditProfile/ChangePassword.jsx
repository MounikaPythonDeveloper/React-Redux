import React, { useState } from "react";
import "./ChangePassword.css";
import { RESET_PASSWORD_API, CHECK_PASSWORD_API } from "../../../services/api";
import axios from "axios";
import ReactDOM from "react-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import TextField from "@material-ui/core/TextField";
import { IconButton, InputAdornment } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Tooltip from "@mui/material/Tooltip";
import { tooltipClasses } from "@mui/material/Tooltip";
import { Button, Popover } from "@material-ui/core";
import { FormHelperText, makeStyles } from "@material-ui/core";
import Alert from "@mui/material/Alert";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";
import { styled } from "@mui/material/styles";
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}));

const useStyle = makeStyles((theme) => ({
  helperText: {
    color: "red",
    fontSize: 13,
    position: "absolute",
    bottom: "-10px",
    background: "transparent",
  },
}));

const useStyles = makeStyles({
  underline: {
    "&&&:before": { borderBottom: "1px solid grey" },
    "&&:after": { borderBottom: "none" },
  },
  helperText: {
    color: "red",
    fontSize: 13,
    position: "absolute",
    bottom: "0px",
    background: "transparent",
  },
});

var CryptoJS = require("crypto-js");

const SignupSchema = yup.object().shape({
  password: yup
    .string()
    .matches("", { message: "Please create a stronger password" })
    .required(),
  newPassword: yup
    .string()
    .matches(
      // /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/,
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{10,18}$/i,
      "Invalid Password"
      //mixture of uppercase and lowercase letters"
    )
    .required(),
  confirmPassword: yup
    .string()
    .required("Confirm Password is required")
    .oneOf([yup.ref("newPassword")], "Passwords must match"),
  // .required()
});

function ChangePassword() {
  const { theme } = useTheme();
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip;
  const userProfile = JSON.parse(
    sessionStorage.getItem("userData") || undefined
  );
  const [originalPass, setOriginalPass] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [userName, setUserName] = useState(userProfile.username);
  const [username, setUsername] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [errorSamePassword, setErrorSamePassword] = useState("");
  const [password, setPassword] = useState("");
  const [popup, setPop] = useState(false);
  const [forgotMes, setForgetMes] = useState("");
  const [message, setMessage] = useState("");
  const [oldPasswordEmpty, setOldPasswordEmpty] = useState(true);
  const [newPasswordEmpty, setNewPasswordEmpty] = useState(true);
  const [confirmPasswordEmpty, setConfirmPasswordEmpty] = useState(true);
  const [oldNewPassword, setOldNewPassword] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const location = useLocation();
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnChangePasswordPage =
    location.pathname === "/platform/viewprofile/changepassword";
  const navigate = useNavigate();

  const classes = useStyles();

  if (showAlert) {
    setTimeout(() => {
      handleAlertClose();
    }, 3000);
  }

  const texfieldInputStyle = {
    borderBottom: "1px solid grey",
    color: "#FFFFFF",
    fontFamily: "Open Sans",
    fontSize: 20,
    "margin-bottom": "25px",
    background: "transparent",
    caretColor: "white",
  };

  const texfieldLabelStyle = {
    color: "#FFFFFF",
    opacity: 0.7,
    fontSize: 18,
    fontFamily: "Open Sans",
    // paddingTop: 5,
    background: "transparent",
    caretColor: "white",
  };

  const handleAlertClose = () => {
    setShowAlert(false);
  };

  const reset = function (data) {
    if (data == "true") {
      navigate("/login");
      setPop(!popup);
      setForgetMes("Your Password has changed.Login with new Password");
    } else {
      setPop(popup);
    }
  };

  const closePopup = () => {
    setPop(false);
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(SignupSchema),
  });
  const [isShow, setIsShow] = React.useState(false);

  const reset_password_Submit = (data) => {
    console.log(data);
    var key = "AAAAAAAAAAAAAAAA";
    key = CryptoJS.enc.Utf8.parse(key);
    setShowAlert(true);
    var encrypted = CryptoJS.AES.encrypt(data.newPassword, key, {
      mode: CryptoJS.mode.ECB,
    });
    encrypted = encrypted.toString();
    console.log("encrypted2", encrypted);

    const reset_password_data = {
      password: encrypted,
      username: userProfile.username.toLowerCase(),
    };
    console.log("RESETDATA", reset_password_data);

    axios
      .post(RESET_PASSWORD_API + JSON.stringify(reset_password_data))
      .then((response) => {
        if (response.data.valid === "true") {
          console.log("Reset Done", response.data);
          // toast.success("Password has Successfully Changed!", {
          //   position: toast.POSITION.TOP_CENTER,
          // })
          navigate("/viewprofile", {
            state: {
              message: "Your Password has changed.Login with new Password.",
            },
          });
        } else {
          setMessage(response.data.Message);
        }
        console.log("nnnnn", response.data);
      })
      .catch((error) => {
        reset("False");
        console.log(error, "error");
      });
  };

  const onError = (errors) => {
    console.error(errors, "errors");
  };

  const oldPasswordBlur = (data) => {
    if (data.target.value === "") {
      setOldPasswordEmpty(true);
    } else {
      setOldPasswordEmpty(false);
    }
    console.log("on blur", data.target.value);
    const oldEnteredPassword = data.target.value;
    setOriginalPass(oldEnteredPassword);

    let password = data.target.value;

    console.log(password, "oldpassword");

    var key = "AAAAAAAAAAAAAAAA";
    key = CryptoJS.enc.Utf8.parse(key);

    var encrypted = CryptoJS.AES.encrypt(password, key, {
      mode: CryptoJS.mode.ECB,
    });
    password = encrypted.toString();
    console.log("encrypted2", password);

    // make old password validation api call here
    axios
      .post(
        CHECK_PASSWORD_API +
          JSON.stringify({ username: userProfile.username, password: password })
      )
      // {username,entered password}
      .then((response) => {
        if (response.data.valid === true) {
          setErrorMessage("Your Password Is Verified");
          setPassword(true);
          console.log(response.data.valid, "response");
        } else {
          setPassword(false);
          setErrorMessage("Enter Valid Password");
          // setErrorMessage(response.data.message)
          console.log(response.data.valid, "response");
        }
      })
      .catch((error) => {
        console.log(error);
      });
    checkOldNewPassword(oldEnteredPassword, newPassword);
  };

  const newPasswordBlur = (data) => {
    if (data.target.value === "") {
      setNewPasswordEmpty(true);
    } else {
      setNewPasswordEmpty(false);
    }
    const newEnteredPassword = data.target.value;
    setNewPassword(newEnteredPassword);
    console.log(originalPass, "olPassword");
    checkOldNewPassword(newEnteredPassword, originalPass);
  };
  console.log("newPassword", newPassword);

  const checkOldNewPassword = (oldPassword, newPassword) => {
    console.log("funtion Called");
    if (oldPassword === newPassword) {
      if (newPassword.length !== 0) {
        setErrorSamePassword("Old password and new password cannot be same");
        setOldNewPassword(true);
        console.log("Error Called");
      }
    } else {
      setErrorSamePassword("");
      setOldNewPassword(false);
    }
  };

  const handlePaste = function (event) {
    event.preventDefault();
  };

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnChangePasswordPage ||
      isOnAdminPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/viewprofile"} onDragStart={preventDragHandler}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">Change Password</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link Link to="/platform" onDragStart={preventDragHandler}>
            M&E
          </Link>
          <Link
            to={"/platform/M&E/viewprofile"}
            onDragStart={preventDragHandler}
          >
            View Profile
          </Link>
          <Typography color="#0D6EFD">Change Password</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link Link to="/platform">
            {platform_data}
          </Link>
          <Link to={"/platform/" + platform_data + "/viewprofile"}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">Change Password</Typography>
        </Breadcrumbs>
      )}
      <div
        className={`entire_change_password_container  ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div className="change_password_container">
          <h2>Change Password</h2>
          <form onSubmit={handleSubmit(reset_password_Submit)}>
            <div>
              {/* <pre>{JSON.stringify(forgotMes)}</pre> */}
              <TextField
                label="Old Password"
                className="text-field"
                onPaste={handlePaste}
                id="standard-basic-oldpass"
                {...register("password", {
                  required: "password is required",
                })}
                // setField={setUsernameField}
                onBlur={oldPasswordBlur}
                type={showPassword ? "text" : "password"}
                helperText={[
                  password
                    ? ""
                    : errorMessage ||
                      (errors.password && errors.password.message),
                ]}
                InputProps={{
                  endAdornment: (
                    <InputAdornment
                      sx={{
                        position: "absolute",
                        right: "8px",
                        transform: "translateY(-50%)",
                      }}
                    >
                      <IconButton
                        sx={{ color: "white" }}
                        aria-label="toggle password visibility"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <Visibility /> : <VisibilityOff />}
                      </IconButton>
                    </InputAdornment>
                  ),
                  style: texfieldInputStyle,
                  classes: { underline: classes.underline },
                }}
                InputLabelProps={{
                  style: texfieldLabelStyle,
                }}
                FormHelperTextProps={{
                  classes: { root: classes.helperText },
                }}
              />
            </div>
            <div></div>
            <div className="new_password_text_input">
              <TooltipComponent
                title={
                  <>
                    <Typography color="inherit" style={{ fontSize: "11px" }}>
                      Password Should contain:
                    </Typography>
                    <Typography
                      color="inherit"
                      component="div"
                      style={{ fontSize: "11px" }}
                    >
                      <ul>
                        <li>10+ characters </li>
                        <li>Atleast 1 no. </li>
                        <li>Atleast one special character($,%,@, etc.) </li>
                        <li>
                          Have mixture of uppercase and lowercase letters{" "}
                        </li>
                      </ul>
                    </Typography>
                  </>
                }
                style={{ fontFamily: "Open Sans" }}
                placement="right"
              >
                <TextField
                  label="New Password"
                  className="text-field"
                  id="standard-basic-newpass"
                  onPaste={handlePaste}
                  {...register("newPassword", {
                    required: "New password is required",
                  })}
                  onBlur={newPasswordBlur}
                  type={showNewPassword ? "text" : "password"}
                  helperText={[
                    (errors.newPassword && errors.newPassword.message) ||
                      errorSamePassword,
                  ]}
                  // helperText={errorSamePassword}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment
                        sx={{
                          position: "absolute",
                          right: "8px",
                          transform: "translateY(-50%)",
                        }}
                      >
                        <IconButton
                          sx={{ color: "white" }}
                          aria-label="toggle password visibility"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                        >
                          {showNewPassword ? <Visibility /> : <VisibilityOff />}
                        </IconButton>
                      </InputAdornment>
                    ),
                    style: texfieldInputStyle,
                    classes: { underline: classes.underline },
                  }}
                  InputLabelProps={{
                    style: texfieldLabelStyle,
                  }}
                  FormHelperTextProps={{
                    classes: { root: classes.helperText },
                  }}
                />
              </TooltipComponent>
            </div>
            <div>
              <TextField
                label="Confirm Password"
                className="text-field"
                id="standard-basic-confpass"
                onPaste={handlePaste}
                {...register("confirmPassword", {
                  required: "New password is required",
                })}
                type={showConfirmPassword ? "text" : "password"}
                helperText={[
                  errors.confirmPassword && errors.confirmPassword.message,
                ]}
                InputProps={{
                  endAdornment: (
                    <InputAdornment
                      sx={{
                        position: "absolute",
                        right: "8px",
                        transform: "translateY(-50%)",
                      }}
                    >
                      <IconButton
                        sx={{ color: "white" }}
                        aria-label="toggle password visibility"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                      >
                        {showConfirmPassword ? (
                          <Visibility />
                        ) : (
                          <VisibilityOff />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                  style: texfieldInputStyle,
                  classes: { underline: classes.underline },
                }}
                InputLabelProps={{
                  style: texfieldLabelStyle,
                }}
                FormHelperTextProps={{
                  classes: { root: classes.helperText },
                }}
              />
            </div>
            {isOnPlatformPage ||
            isOnAboutPage ||
            isOnViewProfile ||
            isOnChangePasswordPage ||
            isOnAdminPage ? (
              <div className="submit_cancel_button">
                <button
                  onClick={() =>
                    navigate("/platform/" + platform_data + "/viewprofile")
                  }
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  onClick={() =>
                    navigate("/platform/" + platform_data + "/viewprofile")
                  }
                  type="submit"
                  className="submit_button"
                  disabled={
                    !!oldPasswordEmpty ||
                    !!oldNewPassword ||
                    !!newPasswordEmpty ||
                    errorMessage.length === 20
                    // !! ||
                  }
                >
                  Submit
                </button>
              </div>
            ) : platform_data === "Media And Entertainment" ? (
              <div className="submit_cancel_button">
                <button
                  onClick={() => navigate("/platform/M&E/viewprofile")}
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  onClick={() => navigate("/platform/M&E/viewprofile")}
                  type="submit"
                  className="submit_button"
                  disabled={
                    !!oldPasswordEmpty ||
                    !!oldNewPassword ||
                    !!newPasswordEmpty ||
                    errorMessage.length === 20
                    // !! ||
                  }
                >
                  Submit
                </button>
              </div>
            ) : (
              <div className="submit_cancel_button">
                <button
                  onClick={() =>
                    navigate("/platform/" + platform_data + "/viewprofile")
                  }
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  onClick={() =>
                    navigate("/platform/" + platform_data + "/viewprofile")
                  }
                  type="submit"
                  className="submit_button"
                  disabled={
                    !!oldPasswordEmpty ||
                    !!oldNewPassword ||
                    !!newPasswordEmpty ||
                    errorMessage.length === 20
                    // !! ||
                  }
                >
                  Submit
                </button>
              </div>
            )}
          </form>
          <div>
            {popup ? (
              <div className="main">
                <div className="popup">
                  <div className="popup-header">
                    <p> Password changed Successfully </p>
                    <p onClick={closePopup}>x</p>
                  </div>
                  <div></div>
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
          {showAlert && (
            <div className="alertDiv1">
              <Alert
                severity="success"
                variant="filled"
                onClose={handleAlertClose}
                icon={false}
                className="alertBox1"
                sx={{ fontSize: "24px" }}
              >
                Your Password Changed Successfully
              </Alert>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default ChangePassword;
