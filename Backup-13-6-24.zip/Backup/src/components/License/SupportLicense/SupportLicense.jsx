import "./SupportLicense.css"
import { Link, useNavigate, useLocation } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import Arrow from "../../../../src/assets/images/Arrow 2.svg"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
function AboutTable() {
  const { theme } = useTheme()
  const navigate = useNavigate()
  const about_info = JSON.parse(sessionStorage.getItem("aboutinfo"))
  const homeBack = function () {
    if (isOnPlatformPage || isOnAboutPage || isOnViewProfile) {
      navigate("/platform/viewProfile")
    } else if (platform_data === "Media And Entertainment") {
      navigate("/platform/M&E/viewProfile")
    } else {
      navigate("/platform/" + platform_data + "/viewProfile")
    }
  }
  const location = useLocation()
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnViewProfile = location.pathname === "/platform/viewprofile"
  const isOnBuyLicensePage =
    location.pathname === "/platform/viewprofile/buyLicense"
  const isOnSupportLicensePage =
    location.pathname === "/platform/viewprofile/supportLicense"
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  return (
    <div
      className={`license_data_heading ${theme === "dark" ? "dark" : "light"}`}
    >
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnSupportLicensePage ||
      isOnBuyLicensePage ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/viewprofile"}>View Profile</Link>
          <Typography color="#0D6EFD" style={{ paddingTop: "12px" }}>
            Support License
          </Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/"}>M&E</Link>
          <Link to={"/platform/M&E/viewprofile"}>View Profile</Link>
          <Typography color="#0D6EFD" style={{ paddingTop: "12px" }}>
            Support License
          </Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/"}>{platform_data}</Link>
          <Link to={"/platform/" + platform_data + "/viewprofile"}>
            View Profile
          </Link>
          <Typography color="#0D6EFD" style={{ paddingTop: "12px" }}>
            Support License
          </Typography>
        </Breadcrumbs>
      )}
      <div className="device-back-navigation"></div>
      <h1>Contact Details</h1>

      <div className="centered" style={{ paddingBlockStart: "60px" }}>
        <p>
          Your license request is successfully sumbitted to EvQUAL support team.
        </p>

        <p>
          you will get response within few days. For further information contact
          below.
        </p>
      </div>

      <div className={`license_data ${theme === "dark" ? "dark" : "light"}`}>
        <tbody>
          <tr>
            <th>Contact Person:</th>
            <th>Email ID:</th>
            <th>Website:</th>
          </tr>

          <tr>
            <td>{"Nithin Madathil"}</td>
            <td>{"nithin.madathil@ltts.com"}</td>
            <td>
              <a href="https://www.ltts.com/solutions/EvQUAL">
                https://www.ltts.com/solutions/EvQUAL
              </a>
            </td>
          </tr>
        </tbody>
      </div>
    </div>
  )
}

export default AboutTable
