import React, { useEffect, useState } from "react"
import "./BuyLicense.css"
import { Link, useNavigate, useLocation } from "react-router-dom"
import { useForm, Controller } from "react-hook-form"
import TextField from "@material-ui/core/TextField"
import Tooltip from "@mui/material/Tooltip"
import { Typography } from "@material-ui/core"
import { makeStyles } from "@material-ui/core"
import { yupResolver } from "@hookform/resolvers/yup"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import { Breadcrumbs } from "@mui/material"
import { FormHelperText } from "@mui/material"
import Select from "@mui/material/Select"
import InputLabel from "@mui/material/InputLabel"
import Box from "@mui/material/Box"
import * as Yup from "yup"
import axios from "axios"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import PopupMessage from "../../ReusableComponents/PopupMessage/PopupMessage"
import MultiSelectDropdown from "../../ReusableComponents/MultiSelectDropdown/MultiSelectDrodownLicense"
import {
  VALIDATE_USERNAME_API,
  VALIDATE_EMAIL_API,
  BUY_LICENSE_API,
  GET_PLATFORMS_API,
} from "../../../services/api"
import { yellow } from "@material-ui/core/colors"
var CryptoJS = require("crypto-js")

const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
})

const BuyLicense = () => {
  const { theme } = useTheme()
  const [username, setUsername] = useState("")
  const [userPrivilege, setUserPrivilege] = useState([])
  const [apiResponse1, setApiResponse1] = useState("")
  const [errorMessage, setErrorMessage] = useState("")
  const [errorMessagePlatform, setErrorMessagePlatform] = useState("")
  const [Datetime, setDatetime] = useState("")
  const [email, setEmail] = useState("")
  const [Validity, setValidity] = useState("")
  const [category, setCategory] = useState("")
  const [apiResponse, setApiResponse] = useState("")
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [conformation, setConformation] = useState(false)
  const [open, setOpen] = useState(false)
  const [Active, setActive] = useState("")
  const dateandtime = new Date()
  const navigate = useNavigate()
  const classes = useStyles()
  const location = useLocation()
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnViewProfile = location.pathname === "/platform/viewprofile"
  const isOnBuyLicensePage =
    location.pathname === "/platform/viewprofile/buyLicense"
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const [selectedPlatforms, setSelectedPlatforms] = useState([])
  const [optionPlatformData, setOptionPlatformData] = useState([
    // "Telecom",
    // "M&E",
    // "Healthcare",
    // "Transportation",
  ])
  const validationSchema = Yup.object().shape({
    uname: Yup.string().required("User name is required"),
    userPrivilege: Yup.string().required("user privilege is required"),
    platforms: Yup.array().required("Platfroms is required"),
    email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
    duration: Yup.string().required("Select the duration"),
  })
  const formOptions = { resolver: yupResolver(validationSchema) }
  // get functions to build form with useForm() hook
  const { register, handleSubmit, reset, formState, control } =
    useForm(formOptions)
  const { errors } = formState
  const [showAlert, setShowAlert] = useState(false)
  console.log(
    userProfile.user_privilege,
    userProfile.user_privilege === "Tester"
      ? selectedPlatforms
      : optionPlatformData,
    "check statis"
  )

  useEffect(() => {
    getPlatforms()
  }, [])
  const getPlatforms = async () => {
    axios
      .post(GET_PLATFORMS_API + JSON.stringify(["platform"]))
      .then((res) => {
        setOptionPlatformData(res.data.platform)
      })
      .catch((er) => console.log(er))
  }
  const onClosepopup = function () {
    setOpen(false)
    navigate("/platform/viewProfile")
    // if (
    //   isOnPlatformPage ||
    //   isOnAboutPage ||
    //   isOnViewProfile ||
    //   isOnBuyLicensePage
    // ) {
    //   navigate("/platform/viewProfile")
    // } else if (platform_data === "Media And Entertainment") {
    //   navigate("/platform/M&E/viewProfile")
    // } else {
    //   navigate("/platform/" + platform_data + "/viewProfile")
    // }
  }
  const handlecategory = (event) => {
    setCategory(event.target.value)
    setErrorMessage("")
  }

  function onSubmit(data) {
    if (selectedPlatforms.length === 0) {
      setErrorMessagePlatform("Please Select Platform")
    }
    if (!category) {
      setErrorMessage("Please Select Duration")
    } else {
      const user_data = {
        licensee: userProfile.username.toLowerCase(),
        email: userProfile.email_id.toLowerCase(),
        validity: category,
        date: new Date().toISOString(),
        platform:
          userProfile.user_privilege === "Tester"
            ? selectedPlatforms
            : optionPlatformData,
      }

      axios
        .post(BUY_LICENSE_API + JSON.stringify(user_data))
        .then((response) => {
          console.log(response.data, "success")
          let apiResponse1 = response.data.message
          setApiResponse1(response.data.message)
          console.log(apiResponse1, "message here 1")
          if (
            response.data.message ===
              "Thanks! Your License request for EvQUAL product has been forwarded to support team and they will contact you shortly." ||
            response.data.message === "License Key already generated and sent!"
          ) {
            setOpen(true)
          }
          if (response.data.valid === "true") {
            setUsername(response.data.username)
            setEmail(response.data.email_id)
            setValidity(response.data.Validity)
            setDatetime(new Date().toISOString())
            setActive(1)
          } else {
          }
        })
        .catch((error) => {
          console.log(error, "error")
        })
      console.log("sup", errorMessage)
    }
  }
  console.log("alert", showAlert)
  console.log("apivalue", apiResponse)
  const texfieldInputCSS = {
    borderBottom: "1px solid grey",
    color: "#FFFFFF",
    fontFamily: "Open Sans",
    fontSize: 18,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "20px",
  }

  const texfieldLabelCSS = {
    color: "#1eb6b6",
    opacity: 1.0,
    fontSize: 18,
    fontFamily: "Open Sans",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "15px",
  }
  console.log("selected Platforms", selectedPlatforms)
  console.log("userProfile.userPrivilege", userProfile.user_privilege)
  return (
    <React.Fragment>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnBuyLicensePage ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/viewprofile"}>View Profile</Link>
          <Typography color="#0D6EFD">Buy License</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/"}>M&E</Link>
          <Link to={"/platform/M&E/viewprofile"}>View Profile</Link>
          <Typography color="#0D6EFD">Buy License</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          <Link to={"/platform/"}>{platform_data}</Link>
          <Link to={"/platform/" + platform_data + "/viewprofile"}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">Buy License</Typography>
        </Breadcrumbs>
      )}
      <div>
        <PopupMessage
          open={open}
          text1="Thanks!"
          text={apiResponse1}
          handleClose={onClosepopup}
        />

        <div className="Add_user">
          <div class="add_user_form">
            <div class="col-md-5 add_user_div">
              <div></div>
              <form
                onSubmit={handleSubmit(onSubmit)}
                method="post"
                className="registration-form"
              >
                <div className="div_contents">
                  <div
                    className={`title_buylicense ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <h3>Buy License</h3>
                  </div>
                  <div className="text_input">
                    <InputLabel
                      className={`buylicense_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Username
                    </InputLabel>
                    <TextField
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      id="standard-basic-Buyusername"
                      {...register("uname", {
                        required: "uname is required",
                      })}
                      value={userProfile.username}
                      error={username}
                      InputProps={{
                        style: texfieldInputCSS,
                        classes: { underline: classes.underline },
                        maxLength: 12,
                      }}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>
                  <div className="fielddropdown-text">
                    <Box sx={{ minWidth: 300, m: 1 }}>
                      <InputLabel
                        className={`buylicense_label ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Duration
                      </InputLabel>
                      <FormControl variant="standard" fullWidth>
                        <Select
                          labelId="demo-simple-select-standard-label"
                          id="demo-simple-select"
                          value={category}
                          onChange={handlecategory}
                          label=""
                          className={`buylicense-dropdown ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          MenuProps={{
                            PaperProps: {
                              style: {
                                background:
                                  theme === "light"
                                    ? "linear-gradient(to right, #034e88, #40a7f6)"
                                    : "",
                              },
                            },
                          }}
                          error={!!errorMessage}
                          displayEmpty
                        >
                          <MenuItem value={""}>Duration</MenuItem>
                          <MenuItem value={"1 month"}>1 Month</MenuItem>
                          <MenuItem value={"3 months"}>3 Months</MenuItem>
                          <MenuItem value={"6 months"}>6 Months</MenuItem>
                          <MenuItem value={"12 months"}>12 Months</MenuItem>
                        </Select>

                        <FormHelperText error={!!errorMessage}>
                          {errorMessage}
                        </FormHelperText>
                      </FormControl>
                    </Box>
                  </div>
                  {userProfile.user_privilege === "Tester" && (
                    <div className="fielddropdown-text">
                      <Box sx={{ minWidth: 300, m: 1 }}>
                        <InputLabel
                          className={`buylicense_label ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          Platforms
                        </InputLabel>

                        <FormControl
                          variant="standard"
                          fullWidth
                          className={`Buylicense_platform ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <MultiSelectDropdown
                            selectedPlatforms={selectedPlatforms}
                            setSelectedPlatforms={setSelectedPlatforms}
                            optionPlatformData={optionPlatformData}
                            title="Platforms"
                            error={!!errorMessagePlatform}
                            displayEmpty
                          />

                          <FormHelperText error={!!errorMessagePlatform}>
                            {errorMessagePlatform}
                          </FormHelperText>
                        </FormControl>
                      </Box>
                    </div>
                  )}
                  <div className="text_input">
                    <InputLabel
                      className={`buylicense_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      User Privilege
                    </InputLabel>
                    <TextField
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      id="standard-basic-Buyusername"
                      {...register("userPrivilege", {
                        required: "userPrivilege is required",
                      })}
                      value={userProfile.user_privilege}
                      error={userPrivilege}
                      InputProps={{
                        style: texfieldInputCSS,
                        classes: { underline: classes.underline },
                        maxLength: 12,
                      }}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>

                  <div className="text_input">
                    <InputLabel
                      className={`buylicense_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Email ID
                    </InputLabel>
                    <TextField
                      id="standard-basic-buyemail"
                      variant="standard"
                      {...register("email", {
                        required: "email is required",
                      })}
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      value={userProfile.email_id}
                      InputProps={{
                        style: texfieldInputCSS,
                        classes: { underline: classes.underline },
                      }}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>

                  <div className="submit-cancel-button">
                    {isOnPlatformPage ||
                    isOnBuyLicensePage ||
                    isOnAboutPage ||
                    isOnViewProfile ? (
                      <button
                        onClick={() => navigate("/platform/viewProfile")}
                        id="disable"
                        type="button"
                        className={`cancel_button1 ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                    ) : platform_data === "Media And Entertainment" ? (
                      <button
                        onClick={() => navigate("/platform/M&E/viewProfile")}
                        id="disable"
                        type="button"
                        className={`cancel_button1 ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                    ) : (
                      <button
                        onClick={() =>
                          navigate(
                            "/platform/" + platform_data + "/viewProfile"
                          )
                        }
                        id="disable"
                        type="button"
                        className={`cancel_button1 ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                    )}
                    <button
                      type="submit"
                      className={`submit_button1 ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      onClick={onSubmit}
                      method="post"
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}

export default BuyLicense
