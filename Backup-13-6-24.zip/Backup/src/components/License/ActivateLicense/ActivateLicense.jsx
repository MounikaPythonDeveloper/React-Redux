import React, { useState } from "react"
import "./ActivateLicense.css"
import { Link, useNavigate, useLocation } from "react-router-dom"
import TextField from "@material-ui/core/TextField"
import { Typography, Unstable_TrapFocus } from "@material-ui/core"
import { makeStyles } from "@material-ui/core"
import { useForm } from "react-hook-form"
import { Breadcrumbs } from "@mui/material"
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import axios from "axios"
import InputLabel from "@mui/material/InputLabel"
import { VERIFY_LICENSE_API, ACTIVATE_LICENSE_API } from "../../../services/api"
import { Alert, Snackbar } from "@mui/material"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import { styled } from "@mui/material/styles"

const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
})

const ActivateLicense = () => {
  const { theme } = useTheme()
  const [username, setUsername] = useState("")
  const [errorMessage, setErrorMessage] = useState("")
  const [Datetime, setDatetime] = useState("")
  const [email, setEmail] = useState("")
  const [Validity, setValidity] = useState("")
  const [licenseKeyEmpty, setLicenseKeyEmpty] = useState(true)
  const [licenseKey, setLicenseKey] = useState("")
  const [conformation, setConformation] = useState(false)
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  let licenseResponse = ""
  const location = useLocation()
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnViewProfile = location.pathname === "/platform/viewprofile"
  const isOnActivateLicensePage =
    location.pathname === "/platform/viewprofile/activateLicense"
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const [Active, setActive] = useState("")
  const dateandtime = new Date()
  const navigate = useNavigate()
  const classes = useStyles()

  const validationSchema = Yup.object().shape({
    licenseKey: Yup.string().required("License Key is required"),
  })
  const formOptions = { resolver: yupResolver(validationSchema) }
  const { register, handleSubmit, reset, formState } = useForm(formOptions)
  const { errors } = formState

  const validateLicense = async (data) => {
    console.log(data.license_key, "passingData")
    await axios
      .get(`${VERIFY_LICENSE_API} + ${JSON.stringify(data)}`)
      .then((response) => {
        console.log(`getting response as ${response.data}`)
        licenseResponse = response.data
        console.log(licenseResponse, "licenseResponse")
        if (response.data === true) {
          setErrorMessage("")
        } else {
          setErrorMessage("Please enter the valid License Key")
        }
      })
  }

  const handleLicenseKey = (e) => {
    const validateData = {
      licensee: userProfile.username.toLowerCase(),
      license_key: e.target.value,
    }
    if (e.target.value.length >= 1) {
      setLicenseKeyEmpty(false)
    }
    validateLicense(validateData)
  }
  function onSubmit(data) {
    if (licenseResponse === false) {
      console.log(licenseKey, "licenseKey")
      setErrorMessage("Please enter the valid License Key")
    } else {
      const user_data = {
        licensee: userProfile.username.toLowerCase(),
        email: userProfile.email_id.toLowerCase(),
        date: new Date().toISOString(),
        license_key: licenseKey,
      }
      console.log(user_data, "Activate License Data")
      axios
        .post(ACTIVATE_LICENSE_API + JSON.stringify(user_data))
        .then((response) => {
          console.log(response.data.message, "success")
          if (response.data.message === "License Activated") {
            setConformation(true)
          }
          if (response.data.valid === true) {
            console.log("trueabc", response.data.email_id)
            setUsername(response.data.username)
            setEmail(response.data.email_id)
            setValidity(response.data.Validity)
            setDatetime(new Date().toISOString())
            setActive(1)
          } else {
          }
        })
        .catch((error) => {
          console.log(error, "error")
        })
      console.log("sup", errorMessage)
    }
  }

  const preventDragHandler = (e) => {
    e.preventDefault()
  }

  return (
    <React.Fragment>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnActivateLicensePage ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/viewprofile"} onDragStart={preventDragHandler}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">Activate License</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            M&E
          </Link>
          <Link
            to={"/platform/M&E/viewprofile/"}
            onDragStart={preventDragHandler}
          >
            View Profile
          </Link>
          <Typography color="#0D6EFD">Activate License</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            {platform_data}
          </Link>
          <Link
            to={"/platform/" + platform_data + "/viewprofile"}
            onDragStart={preventDragHandler}
          >
            viewprofile
          </Link>
          <Typography color="#0D6EFD">Activate License</Typography>
        </Breadcrumbs>
      )}
      <div>
        {isOnPlatformPage || isOnAboutPage || isOnViewProfile ? (
          <Snackbar
            className="delete-alert-message"
            open={conformation}
            autoHideDuration={3000}
            onClose={() => navigate("/platform/viewProfile")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {conformation === true && (
              <Alert icon={false}>License activated successfully</Alert>
            )}
          </Snackbar>
        ) : platform_data === "Media And Entertainment" ? (
          <Snackbar
            className="delete-alert-message"
            open={conformation}
            autoHideDuration={3000}
            onClose={() => navigate("/platform/M&E/viewProfile")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {conformation === true && (
              <Alert icon={false}>License activated successfully</Alert>
            )}
          </Snackbar>
        ) : (
          <Snackbar
            className="delete-alert-message"
            open={conformation}
            autoHideDuration={3000}
            onClose={() =>
              navigate("/platform/" + platform_data + "/viewProfile")
            }
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {conformation === true && (
              <Alert icon={false}>License activated successfully</Alert>
            )}
          </Snackbar>
        )}
        <div className="activate_license">
          <div class="activate_license_form">
            <div class="activate_license_div">
              <form
                onSubmit={handleSubmit(onSubmit)}
                method="post"
                className="registration-form"
              >
                <div className="activate_license_div_contents">
                  <div
                    className={`reg_title ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <h3>Activate License</h3>
                  </div>
                  <div className="text_input_activate">
                    <InputLabel
                      className={`input_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Username
                    </InputLabel>

                    <TextField
                      id="standard-basic-activate-uname"
                      {...register("uname", {
                        required: "uname is required",
                      })}
                      value={userProfile.username}
                      error={username}
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>

                  <div className="text_input_activate">
                    <InputLabel
                      className={`input_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Email ID
                    </InputLabel>
                    <TextField
                      id="standard-basic-activate-mail"
                      variant="standard"
                      {...register("email", {
                        required: "email is required",
                      })}
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      value={userProfile.email_id}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>

                  <div className="text_input_activate">
                    <InputLabel
                      className={`input_label ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      License Key
                    </InputLabel>
                    <TextField
                      id="standard-basic-License Key"
                      variant="standard"
                      // className="text-field"
                      className={`textfiled-activate ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      placeholder="xxxx-xxxx-xxxx-xxxx"
                      {...register("License Key", {
                        required: "License Key is required",
                      })}
                      onChange={handleLicenseKey}
                      error={errors}
                      helperText={[errorMessage ? errorMessage : ""]}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>
                  {isOnPlatformPage ||
                  isOnAboutPage ||
                  isOnActivateLicensePage ||
                  isOnViewProfile ? (
                    <div className="submit-cancel-button">
                      <button
                        onClick={() => navigate("/platform/viewProfile")}
                        id="disable"
                        type="button"
                        className={`cancel_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className={`submit_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        onClick={onSubmit}
                        method="post"
                        disabled={errorMessage || licenseKeyEmpty}
                      >
                        Activate
                      </button>
                    </div>
                  ) : platform_data === "Media And Entertainment" ? (
                    <div className="submit-cancel-button">
                      <button
                        onClick={() => navigate("/platform/M&E/viewProfile")}
                        id="disable"
                        type="button"
                        className={`cancel_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className={`submit_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        onClick={onSubmit}
                        method="post"
                        disabled={errorMessage || licenseKeyEmpty}
                      >
                        Activate
                      </button>
                    </div>
                  ) : (
                    <div className="submit-cancel-button">
                      <button
                        onClick={() =>
                          navigate(
                            "/platform/" + platform_data + "/viewProfile"
                          )
                        }
                        id="disable"
                        type="button"
                        className={`cancel_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className={`submit_button ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        onClick={onSubmit}
                        method="post"
                        disabled={errorMessage || licenseKeyEmpty}
                      >
                        Activate
                      </button>
                    </div>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default ActivateLicense
