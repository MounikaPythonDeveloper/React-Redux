import * as React from "react"
import Box from "@mui/material/Box"
import "./Licenseinformation.css"
import Typography from "@mui/material/Typography"
import { Link, useLocation } from "react-router-dom"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Button from "@mui/material/Button"
import EvQuallogo from "../../assets/images/EvQuallogo.svg"
import { useTheme } from "../../../src/components/ThemeToggle/ThemeContext"

export default function Licenseinformation(props) {
  const { theme } = useTheme()
  const { status } = props
  console.log("status in license", status)
  const location = useLocation()
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnViewProfile = location.pathname === "/platform/viewprofile"
  const isOnActivateLicensePage =
    location.pathname === "/platform/viewprofile/activateLicense"
  const isOnBuyLicensePage =
    location.pathname === "/platform/viewprofile/buyLicense"
  const isOnSupportLicensePage =
    location.pathname === "/platform/null/viewprofile/supportLicense"
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))

  let linkTo = "/ " // Default link
  if (status[0] === "Expired" || typeof status[0] === "undefined") {
    if (
      isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnBuyLicensePage
    ) {
      linkTo = "/platform/viewprofile/buyLicense"
    } else if (platform_data === "Media And Entertainment") {
      linkTo = "/platform/M&E/viewprofile/buyLicense"
    } else {
      linkTo = "/platform/" + platform_data + "/viewprofile/buyLicense"
    }
  } else if (status[0] === "Inactive") {
    if (isOnPlatformPage || isOnAboutPage || isOnViewProfile) {
      linkTo = "/platform/viewprofile/supportLicense"
    } else if (platform_data === "Media And Entertainment") {
      linkTo = "/platform/M&E/viewprofile/supportLicense"
    } else {
      linkTo = "/platform/" + platform_data + "/viewprofile/supportLicense"
    }
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`license-container ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="row-first">
            <div
              className={`logo-container ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img
                src={EvQuallogo}
                alt="Logo"
                className={`license-logo ${
                  theme === "dark" ? "dark" : "light"
                }`}
              />
            </div>
            <div className="license-modal-icon-div1">
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`license-modal-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div className="row-second">
            <Typography
              className={`license-text1 ${theme === "dark" ? "dark" : "light"}`}
            >
              {props.text}
            </Typography>
          </div>
          <div className="row-third">
            <p className="license-paragraph">
              Please Click "Activate Online" button if you purchased the
              application.
            </p>

            <p className="license-paragraph">
              Click "Buy License" Button to buy new license
            </p>
            {/* )} */}
            <p className="license-paragraph">
              Click "Exit" button to close Application
            </p>
          </div>
          <div className="row-fourth">
            {isOnPlatformPage ||
            isOnAboutPage ||
            isOnViewProfile ||
            isOnActivateLicensePage ||
            platform_data === null ? (
              <div className="license-btn-actions1">
                <Link to="/platform/viewprofile/activateLicense">
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Activate Online
                  </Button>
                </Link>

                <Link to={linkTo}>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Buy License
                  </Button>
                </Link>

                <Link>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.handleClose}
                  >
                    Exit
                  </Button>
                </Link>
              </div>
            ) : platform_data === "Media And Entertainment" ? (
              <div className="license-btn-actions1">
                <Link to={"/platform/M&E/viewprofile/activateLicense"}>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Activate Online
                  </Button>
                </Link>

                <Link to={linkTo}>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Buy License
                  </Button>
                </Link>

                <Link>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.handleClose}
                  >
                    Exit
                  </Button>
                </Link>
              </div>
            ) : platform_data !== null ? (
              <div className="license-btn-actions1">
                <Link
                  to={
                    "/platform/" +
                    platform_data +
                    "/viewprofile/activateLicense"
                  }
                >
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Activate Online
                  </Button>
                </Link>

                <Link to={linkTo}>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.functionHandle}
                  >
                    Buy License
                  </Button>
                </Link>

                <Link>
                  <Button
                    className={`license-btn-handler1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={props.handleClose}
                  >
                    Exit
                  </Button>
                </Link>
              </div>
            ) : (
              ""
            )}
          </div>
        </Box>
      </Modal>
    </div>
  )
}
