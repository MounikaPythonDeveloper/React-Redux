import "./AboutLicense.css"
import { useNavigate, Link, useLocation } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"

function AboutTable() {
  const navigate = useNavigate()
  const { theme } = useTheme()
  const about_info = JSON.parse(sessionStorage.getItem("aboutinfo"))
  const location = useLocation()
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnViewProfile = location.pathname === "/platform/viewprofile"
  const isOnAboutLicensePage =
    location.pathname === "/platform/viewprofile/aboutLicense"

  const homeBack = function () {
    navigate(-1)
  }

  const preventDragHandler = (e) => {
    e.preventDefault()
  }

  return (
    <>
      {isOnPlatformPage ||
      isOnAboutLicensePage ||
      isOnViewProfile ||
      isOnAboutPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/viewprofile"} onDragStart={preventDragHandler}>
            View Profile
          </Link>
          <Typography color="#0D6EFD">About License</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link Link to="/platform" onDragStart={preventDragHandler}>
            M&E
          </Link>
          )
          <Link
            to={"/platform/M&E/viewprofile"}
            onDragStart={preventDragHandler}
          >
            View Profile
          </Link>
          <Typography color="#0D6EFD">About Licesne</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link Link to="/platform">
            {platform_data}onDragStart={preventDragHandler}
          </Link>
          )
          <Link
            to={"/platform/" + platform_data + "/viewprofile"}
            onDragStart={preventDragHandler}
          >
            View Profile
          </Link>
          <Typography color="#0D6EFD">About Licesne</Typography>
        </Breadcrumbs>
      )}
      <div
        className={`license_data_heading ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <h2>ABOUT LICENSE</h2>

        <div className={`license_data ${theme === "dark" ? "dark" : "light"}`}>
          <tbody>
            <tr>
              <th>UserName</th>
              <th>Activation Date</th>
              <th>Expiry Date</th>
              <th>License Key</th>
              <th>Purchase Date</th>
              <th>Validity</th>
            </tr>
            {about_info.map((item, index) => (
              <tr key={index}>
                <td>{item.licensee}</td>
                <td>{item.activation_date.split(" ")[0]}</td>
                <td>{item.expiry_date.split(" ")[0]}</td>
                <td>{item.license_key}</td>
                <td>{item.purchase_date.split(" ")[0]}</td>
                <td>{item.validity}</td>
              </tr>
            ))}
          </tbody>
        </div>
      </div>
    </>
  )
}

export default AboutTable
