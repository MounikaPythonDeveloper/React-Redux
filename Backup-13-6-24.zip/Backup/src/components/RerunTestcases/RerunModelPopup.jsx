import React, { useState } from "react"
import Button from "react-bootstrap/Button"
import Modal from "react-bootstrap/Modal"
// import styled from "styled-components"
import "./RerunModelPopup.css"
import { useTheme } from "../ThemeToggle/ThemeContext"

const Model_Popup = ({
  model_title,
  canShow,
  model_body,
  handleClose,
  handleYes,
}) => {
  const { theme } = useTheme()
  return (
    <Modal show={canShow} onHide={handleClose}>
      <Modal.Header>
        <Modal.Title>{model_title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {model_body}
        {/* <div>{model_body[1]}</div> */}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>

        <Button variant="primary" onClick={handleYes}>
          OK
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default Model_Popup
