import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import { DateTimePicker } from "@progress/kendo-react-dateinputs";
import "./StatusCalendar.css";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import { useLocation, useNavigate } from "react-router-dom";
import { DEVICE_RESERVATION_API } from "../../services/api";
import axios from "axios";
import { FormHelperText } from "@mui/material";
import { Button, Alert } from "@mui/material";
import { toast } from "react-toastify";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";

const Calendar = ({ device = null, Popups, Remotetoast, handleClose }) => {
  console.log("deviceyuvi", device);
  const { theme } = useTheme();
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(null);
  const [category, setCategory] = React.useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [alertState, setAlertState] = useState("");
  const [message, setMessage] = useState("");

  // const [modal, setModal] = useState(false);

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  const minDate = new Date();

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  const CloseButton = ({ onClick }) => (
    <button className="cal-close-btn" onClick={onClick}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  );

  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const location = useLocation();
  const DeviceViewInfo = location.state?.data;

  const handleChange = (event) => {
    setCategory(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const startTime = `${
      startDate &&
      startDate.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      })
    }`;

    const endTime = `${
      endDate &&
      endDate.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      })
    }`;

    const startDate1 = `${
      startDate && startDate.toISOString().substring(0, 10)
    }`;
    const endDate1 = `${endDate && endDate.toISOString().substring(0, 10)}`;

    if (category && endDate && endDate1 >= startDate1 && endTime >= startTime) {
      axios
        .post(
          DEVICE_RESERVATION_API +
            JSON.stringify({
              start_time: startTime,
              end_time: endTime,
              start_date: startDate1,
              end_date: endDate1,
              device_name: device,
              reserved_by: userProfile.username,
              reservation_category: category,
              location_id: "IN-002",
              brand_name: "name",
            })
        )
        .then((response) => {
          setMessage(response.data.Message);
          // setModal(false);
          setAlertState(true);
        });
      setMessage("");
    } else {
      setMessage("Please Enter valid data");
    }
  };

  return (
    <>
      <div
        className={`status-overlay-cal ${theme === "dark" ? "dark" : "light"}`}
      >
        <div className="status-content-cal">
          {alertState && (
            <Alert variant="success" icon={false}>
              {message}
            </Alert>
          )}
          <div className="status-form">
            <CloseButton className="close-btn" onClick={handleClose} />
            <div className="status-form-row">
              <label htmlFor="start-date">Start:</label>

              <DateTimePicker
                id="start-date"
                value={startDate}
                onChange={handleStartDateChange}
                min={minDate}
                className="status-datetimepicker"
              />
            </div>
            &nbsp;
            <div className="status-form-row">
              <label htmlFor="end-date">End:</label>
              <DateTimePicker
                id="end-date"
                value={endDate}
                onChange={handleEndDateChange}
                min={startDate}
                className="status-datetimepicker"
                // disabled={!startDate}
              />
            </div>
            <div className="formcontrol-content">
              <FormControl
                variant="standard"
                sx={{ m: 1, minWidth: "95%" }}
                className="dropdown-select-category"
                required
              >
                <InputLabel id="demo-simple-select-standard-label">
                  Select Category
                </InputLabel>
                <Select
                  labelId="demo-simple-select-standard-label"
                  id="demo-simple-select-standard"
                  value={category}
                  onChange={handleChange}
                  label="Age"
                >
                  <MenuItem value={"Manual"}>Manual</MenuItem>
                  <MenuItem value={"Automation"}>Automation</MenuItem>
                </Select>
                <FormHelperText className="helpertext-message">
                  {errorMessage}
                </FormHelperText>
              </FormControl>
            </div>
          </div>
          <div className="status-buttons">
            <button onClick={handleClose} className="btn-cancel">
              Cancel
            </button>
            <Button
              onClick={handleSubmit}
              variant="contained"
              className="btn-submit"
            >
              Submit
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};
export default Calendar;
