import React, { useEffect, useState } from "react";
import axios from "axios";
import TextField from "@material-ui/core/TextField";
import { Typography, makeStyles, useMediaQuery } from "@material-ui/core";
import "./FileUpload.css";
import MyButton from "../ReusableComponents/Buttons";
import { Drag_and_Drop_Availability_API } from "../../services/api";
import { useTheme } from "../ThemeToggle/ThemeContext";

//Styles for Mui components
const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
  root: {
    "& .MuiInputBase-input::placeholder": {
      color: "white",
      fontStyle: "italic",
      fontSize: 15,
    },
  },
});

const texfieldInputStyleDark = {
  borderBottom: "1px solid grey",
  color: "#fff",
  fontFamily: "Open Sans",
  fontSize: 18,
  fontStyle: "normal",
  fontWeight: 400,
  lineHeight: "30px",
  background: "transparent",
};
const texfieldInputStyleLight = {
  borderBottom: "2px solid #ffcc29",
  color: "black",
  fontFamily: "Open Sans",
  fontSize: 18,
  fontStyle: "normal",
  fontWeight: 400,
  lineHeight: "30px",
  background: "transparent",
};

const texfieldLabelStyleDark = {
  color: "#1eb6b6",
  opacity: 1.0,
  fontSize: 16,
  fontFamily: "Open Sans",
  fontStyle: "normal",
  fontWeight: 500,
  paddingTop: 1,
  lineHeight: "30px",
  background: "transparent",
};
const texfieldLabelStyleLight = {
  color: "#1eb6b6",
  // opacity: 1.0,
  fontSize: 16,
  fontFamily: "Open Sans",
  fontStyle: "normal",
  fontWeight: 500,
  paddingTop: 1,
  lineHeight: "30px",
  background: "transparent",
};

const FileUpload = ({
  scriptName,
  handleClose,
  handleUpload,
  errorMessage,
}) => {
  const { theme } = useTheme();
  const [errorMessage1, setErrorMessage] = useState("");
  const [filename, setFilename] = useState("");
  const classes = useStyles();

  const handleFilenameChange = (event) => {
    scriptName(event.target.value);
    checkAvailibility(event.target.value);
    setFilename(event.target.value);
    if (filename === "" || scriptName === "") {
      setErrorMessage("Script is required");
    }
  };

  const checkAvailibility = async (script_name) => {
    await axios
      .post(
        Drag_and_Drop_Availability_API +
          JSON.stringify({ test_case_name: script_name })
      )
      .then((response) => {
        console.log("response", response);
        if (response.data === "Testcase already exists") {
          setErrorMessage(response.data);
        } else {
          setErrorMessage("");
        }
      });
  };

  const CloseButton = ({ onClick }) => (
    <button
      className={`close-deviceview-1  ${theme === "dark" ? "dark" : "light"}`}
      onClick={onClick}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  );

  return (
    <div className={`popup-box-fu  ${theme === "dark" ? "dark" : "light"}`}>
      <div className={`box-fu ${theme === "dark" ? "dark" : "light"}`}>
        <div className="DevicesView">
          <div className="device-back-navigation-auto-1">
            <CloseButton className="file-upload-close" onClick={handleClose} />
          </div>
        </div>
        {theme === "dark" ? (
          <div className="textfield-holder-fu">
            {/* <input type="text" className="fileName" onChange={handleFilenameChange}/> */}
            <TextField
              id="standard-basic-filename"
              label="Script Name"
              variant="standard"
              placeholder="Please enter a script name"
              className={classes.root}
              type="text"
              onChange={handleFilenameChange}
              autoComplete="off"
              InputProps={{
                style: texfieldInputStyleDark,
                classes: { underline: classes.underline },
              }}
              InputLabelProps={{
                style: texfieldLabelStyleDark,
              }}
              helperText={[
                errorMessage1
                  ? errorMessage1
                  : "" || errorMessage
                  ? errorMessage
                  : "",
              ]}
              FormHelperTextProps={{ className: "my-helper-text" }}
            />
          </div>
        ) : (
          <div className="textfield-holder-fu">
            <TextField
              id="standard-basic-filename"
              label="Script Name"
              variant="standard"
              placeholder="Please enter a script name"
              className={classes.root}
              type="text"
              onChange={handleFilenameChange}
              autoComplete="off"
              InputProps={{
                style: texfieldInputStyleLight,
                classes: { underline: classes.underline },
              }}
              InputLabelProps={{
                style: texfieldLabelStyleLight,
              }}
              helperText={[
                errorMessage1
                  ? errorMessage1
                  : "" || errorMessage
                  ? errorMessage
                  : "",
              ]}
              FormHelperTextProps={{ className: "my-helper-text" }}
            />
          </div>
        )}

        <div className="button-container">
          <MyButton
            type="submit"
            variant="contained"
            className="fileupload-button"
            onClick={handleUpload}
            label="Upload"
            disabled={filename === ""}
          ></MyButton>
        </div>
      </div>
    </div>
  );
};
export default FileUpload;
