import React, { useEffect, useState } from "react"
import TextField from "@material-ui/core/TextField"
import { Typography, makeStyles, useMediaQuery } from "@material-ui/core"
import "./FileUpload.css"
import MyButton from "../ReusableComponents/Buttons"

//Styles for Mui components
const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
  root: {
    "& .MuiInputBase-input::placeholder": {
      color: "white",
      fontStyle: "italic",
      fontSize: 15,
    },
  },
})

const texfieldInputStyle = {
  borderBottom: "1px solid grey",
  color: "#fff",
  fontFamily: "Open Sans",
  fontSize: 18,
  fontStyle: "normal",
  fontWeight: 400,
  lineHeight: "30px",
  background: "transparent",
}

const texfieldLabelStyle = {
  color: "#1eb6b6",
  opacity: 1.0,
  fontSize: 16,
  fontFamily: "Open Sans",
  fontStyle: "normal",
  fontWeight: 400,
  paddingTop: 1,
  lineHeight: "30px",
  background: "transparent",
}

const ImageFileUpload = ({
  cropScreenshot,
  scriptName,
  handleClose,
  handleUpload,
}) => {
  const [errorMessage1, setErrorMessage] = useState("")
  const [filename, setFilename] = useState("")
  const classes = useStyles()

  const handleFilenameChange = (event) => {
    scriptName(event.target.value)
    setFilename(event.target.value)
    if (scriptName === "") {
      setErrorMessage("Filename is required")
    } else {
      setErrorMessage("")
    }
  }

  const CloseButton = ({ onClick }) => (
    <button className="close-deviceview" onClick={onClick}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        width="24"
        height="24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="feather feather-x"
      >
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  )

  return (
    <div className="popup-box-fu">
      <div className="box-fu">
        <div className="DevicesView">
          <div className="device-back-navigation-auto">
            <CloseButton onClick={handleClose} />
          </div>
        </div>
        <div className="textfield-holder-fu">
          <div>
            <img src={cropScreenshot} />
          </div>
          <TextField
            id="standard-basic-filename"
            label="Filename"
            variant="standard"
            placeholder="Please enter a filename"
            className={classes.root}
            type="text"
            onChange={handleFilenameChange}
            autoComplete="off"
            InputProps={{
              style: texfieldInputStyle,
              classes: { underline: classes.underline },
            }}
            InputLabelProps={{
              style: texfieldLabelStyle,
            }}
            helperText={[errorMessage1 ? errorMessage1 : ""]}
            FormHelperTextProps={{ className: "my-helper-text" }}
          />
        </div>
        <div className="button-container">
          <MyButton
            type="submit"
            variant="contained"
            className="fileupload-button"
            onClick={handleUpload}
            label="Upload"
            disabled={filename === ""}
          ></MyButton>
        </div>
      </div>
    </div>
  )
}
export default ImageFileUpload
