import Box from "@mui/material/Box";
import axios from "axios";
import "./ScreenShotCrop.css";
import React, { useEffect, useRef, useState } from "react";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import ReactCrop from "react-image-crop";
import { Alert, Snackbar } from "@mui/material";
import "react-image-crop/dist/ReactCrop.css";
import { canvasPreview } from "../../cropImage";
import { SCREENSHOT_FILE_UPLOAD_API } from "../../services/api";
import { Toast } from "react-bootstrap";
import { ToastContainer, toast } from "react-toastify";
import { useTheme } from "../ThemeToggle/ThemeContext";

import "react-toastify/dist/ReactToastify.css";

function ScreenShotCrop(props) {
  const imgRef = useRef(null);
  let filename = "Youtube";
  const [output, setOutput] = useState();
  const [imgCoordinates, setImgCoordinates] = useState(null);
  const [crop, setCrop] = useState(null);
  const [completedCrop, setCompletedCrop] = useState(null);
  const [height, setHeight] = useState("");
  const [width, setWidth] = useState("");
  const [submitAlert, setSumbitAlert] = useState(false);
  const [screenShotRes, setScreenShotRes] = useState(false);
  const [screenShotError, setScreenShotError] = useState(false);
  const [textData, setTextdata] = useState(false);
  const [cropFileName, setCropFileName] = useState("");
  const [fileNameError, setFileNameError] = useState(false);

  const TO_RADIANS = Math.PI / 180;

  const { theme } = useTheme();
  if (theme === "dark") {
    document.documentElement.classList.remove("light");
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
    document.documentElement.classList.add("light");
  }

  const screenshotUpload = async (fileImage) => {
    const formData = new FormData();
    formData.append("text_file", imgCoordinates);
    formData.append("image_file", fileImage);
    formData.append("script_name", cropFileName);
    formData.append("device_name", props.buildDeviceName);
    console.log(formData, "cropfile");

    try {
      const response = await axios.post(SCREENSHOT_FILE_UPLOAD_API, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      if (response.status === 200) {
        setScreenShotRes(true);
        // toast("Reference Icon Saved")
        console.log("res", response.data);
      }
    } catch (error) {
      setScreenShotError(true);
      console.error("errormessage", error);
    }
    setCompletedCrop("");
    setHeight("");
    setWidth("");
    setCrop("");
    setScreenShotError(false);
    // setScreenShotRes(false)
    setSumbitAlert(false);
    setFileNameError(false);
    setCropFileName("");
  };

  const canvasPreview = async (image, crop, scale = 1, rotate = 0) => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    console.log(image);
    if (!ctx) {
      throw new Error("No 2d context");
    }

    const scaleX = image?.naturalWidth / image?.width;
    const scaleY = image?.naturalHeight / image?.height;
    const pixelRatio = window?.devicePixelRatio;
    canvas.width = Math.floor(crop.width * scaleX * pixelRatio);
    canvas.height = Math.floor(crop.height * scaleY * pixelRatio);
    ctx.scale(pixelRatio, pixelRatio);
    ctx.imageSmoothingQuality = "high";
    const cropX = crop.x * scaleX;
    const cropY = crop.y * scaleY;
    const rotateRads = rotate * TO_RADIANS;
    const centerX = image.naturalWidth / 2;
    const centerY = image.naturalHeight / 2;
    ctx.save();

    // 5) Move the crop origin to the canvas origin (0,0)
    ctx.translate(-cropX, -cropY);
    // 4) Move the origin to the center of the original position
    ctx.translate(centerX, centerY);
    // 3) Rotate around the origin
    ctx.rotate(rotateRads);
    // 2) Scale the image
    ctx.scale(scale, scale);
    // 1) Move the center of the image to the origin (0,0)
    ctx.translate(-centerX, -centerY);
    ctx.drawImage(
      image,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight
    );

    ctx.restore();

    const base64Image = canvas.toDataURL("image/jpeg");
    setOutput(base64Image);
    console.log(output, "check crop output");

    return new Promise((resolve, reject) => {
      let screenshotname = "screenshot.png";
      canvas.toBlob((blob) => {
        const fileImage = new File([blob], screenshotname, {
          type: "image/png",
        });
        // setOutput(fileImage);
        screenshotUpload(fileImage);
      });
      // props.screenShotCloseHandler()
    });
  };

  const onImageLoad = (e) => {
    setHeight(e?.currentTarget?.height);
    setWidth(e?.currentTarget?.width);
    setCompletedCrop({
      x: 0,
      y: 0,
      height: e?.currentTarget?.height,
      width: e?.currentTarget?.width,
      unit: "px",
    });
    const text = `Selected coordinates: x1 = ${completedCrop?.x}, y1 = ${completedCrop?.y}, x2 = ${completedCrop?.width}, y2 = ${completedCrop?.height}`;
    setImgCoordinates(text);
    const blob = new Blob([text], { type: "text/plain" });
    const coordinates = new File([blob], filename, { type: "text/plain" });
    setImgCoordinates(coordinates);
  };
  const download = async () => {
    // toast("Reference icon saved")
    if (crop !== null && cropFileName.length > 1) {
      await canvasPreview(imgRef.current, completedCrop);
      setTextdata(true);
      // toast("Reference icon saved")
      // toast("Success")
      // props.returnValueCrop("Reference Icon Saved")
      // props.returnValueCrop(true)
    } else if (cropFileName === "") {
      setFileNameError(true);
      props.returnValueCrop("Backend Issue");
      // toast("Backend Error")
    } else if (crop === null) {
      setSumbitAlert(true);
      props.returnValueCrop("Backend Issue");
      // toast("Backend Error")
    } else {
      // alert("sorry")
      props.returnValueCrop("Backend Issue");
      // toast("Backend Error")
    }
  };
  console.log(completedCrop, "completedCrop");
  console.log(imgRef, "imgRef");

  const closeHandle = function () {
    props.screenShotCloseHandler();
    setImgCoordinates("");
    setOutput("");
    setCompletedCrop("");
    setHeight("");
    setWidth("");
    setCrop("");
    setScreenShotError(false);
    setScreenShotRes(false);
    setSumbitAlert(false);
    setFileNameError(false);
    setCropFileName("");
  };
  const reset = function () {
    setCompletedCrop("");
    setHeight("");
    setWidth("");
    setCrop("");
    setScreenShotError(false);
    setScreenShotRes(false);
    setSumbitAlert(false);
    setFileNameError(false);
    setCropFileName("");
  };
  const fileNameHandler = function (e) {
    setCropFileName(e.target.value);
  };

  return (
    <div className="screen-shot-crop">
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`screen-shot-crop-wrapper ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <Snackbar
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            open={submitAlert === true}
            autoHideDuration={6000}
            onClose={() => setSumbitAlert("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {submitAlert === true && (
              <Alert icon={true}>Please Crop The Image</Alert>
            )}
          </Snackbar>
          <Snackbar
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            open={fileNameError === true}
            autoHideDuration={6000}
            onClose={() => setFileNameError("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {fileNameError === true && (
              <Alert icon={true}>Please Enter File Name</Alert>
            )}
          </Snackbar>
          <Snackbar
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            open={screenShotRes === true}
            autoHideDuration={6000}
            onClose={() => setScreenShotRes("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {screenShotRes === true && (
              <Alert icon={true}>Reference Icon Saved</Alert>
            )}
          </Snackbar>
          <Snackbar
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            open={screenShotError === true}
            autoHideDuration={6000}
            onClose={() => setScreenShotError("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {screenShotError === true && (
              <Alert icon={true}>Something Went Worng</Alert>
            )}
          </Snackbar>
          <div className="screen-shot-crop-first-row">
            <div
              className={`screen-shot-crop-heading ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              Device Image
            </div>
            <div
              className={`screen-shot-crop-icon-div ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <IconButton aria-label="close" color="inherit" size="small">
                <CloseIcon onClick={closeHandle} fontSize="inherit" />
              </IconButton>
            </div>
          </div>
          {/* <div className="screen-shot-crop-third-row">
            <div className="file-name">
              <input
                className="file-text-input"
                type="text"
                placeholder="Enter File Name...."
                value={cropFileName}
                onChange={fileNameHandler}
              />
            </div>
            <button className="screen-shot-button" onClick={download}>
              Crop
            </button>
            <button onClick={reset} className="screen-shot-button">
              Reset
            </button>
          </div> */}
          <div className="screen-shot-crop-third-row">
            <div className="screen-shot-crop-third-row-B">
              <div className="file-name">
                <input
                  className={`file-text-input  ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  type="text"
                  placeholder="Text File Name"
                  value={cropFileName}
                  onChange={fileNameHandler}
                />
              </div>
              <button
                className={`screen-shot-button ${
                  theme === "dark" ? "dark" : "light"
                }`}
                onClick={download}
                title="Select Region Of Interest"
              >
                Select ROI
              </button>
              <button
                onClick={reset}
                className={`screen-shot-button ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Reset
              </button>
            </div>
          </div>
          <div className="screen-shot-main-container">
            <div className="screen-shot-crop-main-A">
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="test-validation"
              >
                Text Validation
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="image-validation"
              >
                Image Validation
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="loop"
              >
                Loop
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="conditions"
              >
                Conditions
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="black-screen-detection"
              >
                Black Screen Detection
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="audio-validation"
              >
                Audio Validation
              </button>
              <button
                className={`crop-btn ${theme === "dark" ? "dark" : "light"}`}
                id="video-quality"
              >
                Video Quality
              </button>
            </div>
            <div className="screen-shot-crop-main-B">
              <ReactCrop
                crop={crop}
                onChange={(e) => setCrop(e)}
                onComplete={(e) => {
                  if (e?.height == 0 || e?.width == 0) {
                    setCompletedCrop({
                      x: 0,
                      y: 0,
                      height: height,
                      width: width,
                      unit: "px",
                    });
                  } else {
                    setCompletedCrop(e);
                  }
                }}
              >
                <img
                  ref={imgRef}
                  className="screen-shot-crop-img"
                  src={props.screenShotDownloadImg}
                  onLoad={onImageLoad}
                />
              </ReactCrop>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
}
export default ScreenShotCrop;
