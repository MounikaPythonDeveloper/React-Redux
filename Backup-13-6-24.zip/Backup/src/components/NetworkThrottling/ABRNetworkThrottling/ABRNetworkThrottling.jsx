import Box from "@mui/material/Box"
import axios from "axios"
import "./ABRNetworkThrottling.css"
import React, { useEffect, useState } from "react"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import { Alert, Snackbar } from "@mui/material"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import { THROTTLING_ABR_API } from "../../../services/api"
import { motion } from "framer-motion"

export default function ABRNetworkThroattling(props) {
  const [abrInputText, setAbrInputText] = useState("")
  const [abrInputError, setAbrInputError] = useState(false)
  const [updateSpeedAlertMsg, setUpdateSpeedAlertMsg] = useState(false)
  const [errorUpdateSpeed, setErrorupdateSpeed] = useState(false)
  const [throttlingRes, setThrottlingRes] = useState(null)

  const { theme } = useTheme()
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }

  const abrNetworkThrottlingUpdate = async () => {
    let abrUpdateThrottling = `${THROTTLING_ABR_API}${JSON.stringify({
      bandwidth: abrInputText,
    })}`
    await axios
      .post(abrUpdateThrottling)
      .then((response) => {
        if (response.status === 200) {
          setUpdateSpeedAlertMsg(true)
          setThrottlingRes(response.data.current_throttling)
          console.log(response.data, "networkStartThrottling")
        }
      })
      .catch((error) => {
        console.log(error, "error")
        setErrorupdateSpeed(true)
      })
    // setAbrInputText("");
  }

  const abrSubmitHandler = () => {
    if (abrInputText.length > 0) {
      abrNetworkThrottlingUpdate()
    } else {
      setAbrInputError(true)
    }
  }
  const abrCloseHandler = () => {
    setAbrInputError(false)
    setAbrInputText("")
    setThrottlingRes(null)
    props.handleClose()
  }

  return (
    <div>
      <Snackbar
        open={errorUpdateSpeed}
        autoHideDuration={6000}
        onClose={() => setErrorupdateSpeed("")}
        className="schedule-confirmation"
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {errorUpdateSpeed && (
          <Alert severity="error" onClose={() => setErrorupdateSpeed("")}>
            Backend Error
          </Alert>
        )}
      </Snackbar>
      {/* <Snackbar
        className={`abr-network-throttling-alert ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={updateSpeedAlertMsg}
        autoHideDuration={6000}
        onClose={() => setUpdateSpeedAlertMsg("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {updateSpeedAlertMsg && (
          <Alert icon={true}>{`Updated Speed is ${abrInputText} Mbps`}</Alert>
        )}
      </Snackbar> */}
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <motion.Box
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="abr-network-throttling"
        >
          <div className="abr-network-throttling-first-row">
            <div className="abr-network-throttling-text-div">
              <Typography className="network-throttling-text">
                Network Throttling
              </Typography>
            </div>
            <div className="abr-network-throttling-icon-div">
              <IconButton
                className="modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`network-throttling-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  onClick={abrCloseHandler}
                />
              </IconButton>
            </div>
          </div>
          {throttlingRes === null ? (
            <motion.div
              className="abr-network-throttling-speed"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
            >
              <span className="abr-span-text">ABR Update Speed</span>
              <span>:</span>
              <span className="abr-span-text">
                <input
                  type="number"
                  value={abrInputText}
                  min="0"
                  step="1"
                  maxLength={4}
                  onChange={(e) => {
                    setAbrInputText(e.target.value)
                    setAbrInputError(false)
                  }}
                  className="abr-network-throttling-speed-input"
                  placeholder="Mbps"
                />
                {"  "}
                Mbps
              </span>
            </motion.div>
          ) : (
            <motion.div
              className="abr-current-throttling-div"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
            >
              <div className="abr-current-throttling-text">
                Current Throttling Speed is :{" "}
                {Number(throttlingRes?.slice(0, -4)) / 1000 + "Mbps"}
              </div>
            </motion.div>
          )}

          {abrInputError ? (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="abr-network-throttling-error-msg"
            >
              Please Enter The Updated Speed.
            </motion.div>
          ) : (
            ""
          )}

          <div className="abr-network-throttling-btn-div">
            {throttlingRes === null ? (
              <motion.button
                whileHover={{ scale: 1.1 }}
                transition={{ type: "spring" }}
                className="abr-network-throttling-btn"
                onClick={abrSubmitHandler}
              >
                Update
              </motion.button>
            ) : (
              <motion.button
                whileHover={{ scale: 1.1 }}
                transition={{ type: "spring" }}
                className="abr-network-throttling-btn"
                onClick={abrCloseHandler}
              >
                Close
              </motion.button>
            )}
          </div>
        </motion.Box>
      </Modal>
    </div>
  )
}
