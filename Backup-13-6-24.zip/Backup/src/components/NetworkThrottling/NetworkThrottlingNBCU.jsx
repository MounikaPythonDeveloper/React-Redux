import Box from "@mui/material/Box"
import axios from "axios"
import "./NetworkThroattling.css"
import React, { useEffect, useState } from "react"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import { Alert, Snackbar } from "@mui/material"
import {
  NETWORK_START_THROTTLING_API,
  NETWORK_STOP_THROTTLING_API,
  NETWORK_THROTTLING_STATUS_API,
} from "../../services/api"
import BackNavigateImg from "../../assets/images/Arrow 2.svg"
import { ToastContainer, toast } from "react-toastify"

import "react-toastify/dist/ReactToastify.css"
import Loader from "../ReusableComponents/Loader/Loader"
import ThrottlingLoader from "../ReusableComponents/ThroattlingLoader/ThrottlingLoader"

export default function BasicModal(props) {
  const [updateThrottlingClicked, setUpdateThrottlingClicked] = useState(false)
  const [currentSpeedToggle, setCurrentSpeedToggle] = useState(false)
  const [throttlingErrorMsg, setThrottlingErrorMsg] = useState(false)
  const [throttlingResponse, setThrottlingResponse] = useState("")
  const [startThrottlingResponse, setStartThrottlingResponse] = useState("")
  const [inputText, setInputText] = useState("")
  const [networkStatusState, setNetworkStatusState] = useState("")
  const [networkLoader, setNetworkLoader] = useState(false)

  useEffect(() => {
    const networkThrottlingStatus = setInterval(() => {
      networkStatusApi() // <-- (3) invoke in interval callback
    }, 5000)
    networkStatusApi()
    return () => clearInterval(networkThrottlingStatus)
  }, [])

  const networkStatusApi = async () => {
    let networkStatus = ""
    networkStatus = `${NETWORK_THROTTLING_STATUS_API}${JSON.stringify({
      // device_name: ["Apple TV"],
      device_name: [props.DeviceName],
    })}&attributes=["throttling_status"]`
    await axios
      .post(networkStatus)
      .then((response) => {
        console.log(response.data.throttling_status[0], "network-status")
        setNetworkStatusState(response.data.throttling_status[0])
        if (response.data.throttling_status[0] === "Started") {
          setUpdateThrottlingClicked(true)
        }
      })
      .catch((error) => {
        console.log(error, "error")
        // toast("Network Error");
        // setNetworkStausResponse(error);
      })
  }

  // Network-Throttling-Start-Time API Function
  const networkStartThrottling = async (updatedSpeed) => {
    setNetworkLoader(true)
    let startThrottling = `${NETWORK_START_THROTTLING_API}${JSON.stringify({
      device_name: props.DeviceName,
      throttle_speed: updatedSpeed,
    })}`
    await axios
      .post(startThrottling)
      .then((response) => {
        console.log(response.data, "networkStartThrottling")
        setStartThrottlingResponse(response.data.Message)
        if (response.data.Message === "Started Throttling") {
          toast("Throttling is Started")
          setNetworkLoader(false)
        } else if (
          response.data.message ===
          "Backend Server Error, please try again after sometime"
        ) {
          setUpdateThrottlingClicked(false)
          toast("Backend Server Error")
          setInputText("")
          setThrottlingErrorMsg(false)
        }
      })
      .catch((error) => {
        console.log(error, "error")
        toast("Network Error")
      })
  }

  // Network-Throttling-Stop-Time API Function
  const networkStopThrottling = async () => {
    setNetworkLoader(true)
    let stopThrottling = ""
    stopThrottling = `${NETWORK_STOP_THROTTLING_API}${JSON.stringify({
      device_name: props.DeviceName,
    })}`
    await axios
      .post(stopThrottling)
      .then((response) => {
        console.log(response.data, "networkStopThrottling")

        if (response.data.Message === "Stopped Throttling") {
          toast("Throttling is Stoped")
          setNetworkLoader(false)
          setNetworkStatusState("")
          setUpdateThrottlingClicked(false)
          setStartThrottlingResponse("")
          setThrottlingResponse(response.data.Message)
          setInputText("")
        } else if (
          response.data.message ===
          "Backend Server Error, please try again after sometime"
        ) {
          // setUpdateThrottlingClicked(false);
          toast("Backend Server Error")
        }
      })
      .catch((error) => {
        console.log(error, "error")
        // toast("Network Error");
      })
  }

  const networkThrottlingSubmit = function (e) {
    let updatedSpeed = Math.trunc(inputText) + "Mbps"
    // let updatedSpeed = inputText + "Mbps";
    console.log(updatedSpeed, "KANNNNNNNNA")
    if (
      inputText.trim().length > 0 &&
      Number(inputText) > 1 &&
      Number(inputText) < 2000
    ) {
      console.log(Number(inputText), "inputvalue")
      networkStartThrottling(updatedSpeed)
      setCurrentSpeedToggle(false)
      // setNetworkStatusState(true);
    } else {
      setThrottlingErrorMsg(true)
    }
  }

  // startThrottling
  const startThrottling = function () {
    setUpdateThrottlingClicked(true)
    setCurrentSpeedToggle(true)
  }

  const popUpClose = function () {
    props.handleClose()
    setUpdateThrottlingClicked(false)
    // setStartThrottlingResponse("");
    if (networkStatusState !== "Started") {
      setCurrentSpeedToggle(false)
    }
    setInputText("")
    setThrottlingErrorMsg(false)
  }
  const throttleBackNavigate = function () {
    setUpdateThrottlingClicked(false)
    setStartThrottlingResponse("")
    setCurrentSpeedToggle(false)
    setInputText("")
    setThrottlingErrorMsg(false)
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box className="network-throttling">
          <div className="network-throttling-first-row">
            {currentSpeedToggle === true ? (
              <div className="throttle-back-navigate">
                <img
                  className="throttle-back-navigate-img"
                  src={BackNavigateImg}
                  onClick={throttleBackNavigate}
                />
              </div>
            ) : (
              ""
            )}
            <div className="network-throttling-text-div">
              <Typography className="network-throttling-text">
                Network Throttling
              </Typography>
            </div>
            <div className="network-throttling-icon-div">
              <IconButton
                className="modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={popUpClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className="network-throttling-close-icon"
                />
              </IconButton>
            </div>
          </div>
          {props.throattlingCurrentSpeed !== "401" ? (
            <div>
              {currentSpeedToggle === false ? (
                <div className="network-throttling-third-row">
                  {networkLoader ? (
                    <ThrottlingLoader />
                  ) : (
                    <div className="current-throttle-speed">
                      <span>Bandwidth Speed</span>
                      <span>:</span>
                      <span>
                        {Number(props.throattlingCurrentSpeed?.slice(0, -4)) /
                          1000 +
                          "Mbps"}
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                ""
              )}
              <div className="network-throttling-second-row">
                {updateThrottlingClicked === false ? (
                  <button
                    className="network-throttling-btn"
                    onClick={startThrottling}
                  >
                    Update
                  </button>
                ) : (
                  ""
                )}
                {networkStatusState === "Started" ? (
                  <div>
                    {networkLoader ? (
                      <ThrottlingLoader />
                    ) : (
                      <button
                        className="network-throttling-btn"
                        onClick={networkStopThrottling}
                      >
                        Stop
                      </button>
                    )}
                  </div>
                ) : (
                  ""
                )}
              </div>
              {currentSpeedToggle === true ? (
                <div className="network-throttling-fourth-row">
                  <div className="network-throttling-device-name">
                    <span>Device Name </span>
                    <span>:</span>
                    <span>{props.DeviceName}</span>
                  </div>
                  <div className="network-throttling-speed">
                    <span>Update Speed</span>
                    <span>:</span>
                    <span>
                      <input
                        type="number"
                        value={inputText}
                        min="0"
                        step="1"
                        onChange={(e) => {
                          setInputText(e.target.value)
                          setThrottlingErrorMsg(false)
                        }}
                        className="network-throttling-speed-input"
                        placeholder="Mbps"
                      />
                      {"  "}
                      Mbps
                    </span>
                  </div>
                  {throttlingErrorMsg ? (
                    <div className="network-throttling-error-msg">
                      Please Enter The Band Speed In Between 1-2000 Mbps
                    </div>
                  ) : (
                    ""
                  )}

                  <div className="network-throttling-btn-div">
                    <button
                      className="network-throttling-btn"
                      onClick={networkThrottlingSubmit}
                    >
                      Submit
                    </button>
                  </div>
                </div>
              ) : (
                ""
              )}
            </div>
          ) : (
            <div className="network-not-available">
              Network Throattling is Not Available
            </div>
          )}
        </Box>
      </Modal>
    </div>
  )
}
