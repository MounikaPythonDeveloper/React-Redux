import React, { useEffect } from "react";
import "./ThemeToggle.css";

import { useTheme } from "./ThemeContext";
import { useState } from "react";

function ToggleSwitch() {
  const { theme, toggleTheme } = useTheme();
  console.log(theme, "theme in navbar");

  return (
    <div className={`view-profile-toggle ${theme ? "dark" : "light"}`}>
      {/* <label className="switch">
        <input type="checkbox" checked={theme} onChange={toggleTheme} />
        <span className="slider"></span>
      </label> */}
      {/* <input
        type="checkbox"
        id="toggle_checkbox"
        // checked={theme}
        onChange={toggleTheme}
      />

      <label for="toggle_checkbox">
        <div id="star">
          <div class="star" id="star-1">
            ★
          </div>
          <div class="star" id="star-2">
            ★
          </div>
        </div>
        <div id="moon"></div>
      </label> */}
      <label class="view-toggle">
        <input class="toggle-checkbox" type="checkbox" onChange={toggleTheme} />
        <div class="toggle-switch"></div>
      </label>
      <p>{theme === "dark" ? "Dark Theme" : "Light Theme"}</p>
    </div>
  );
}

export default ToggleSwitch;
// import React from "react"
// import "./ThemeToggle.css"

// import { useTheme } from "./ThemeContext"

// function ToggleSwitch() {
//   const { isDarkTheme, toggleTheme } = useTheme("dark")
//   const handleToggleTheme = () => {
//     toggleTheme()
//     const currentTheme = isDarkTheme ? "dark" : "light"
//     console.log(currentTheme, "Current Theme")
//     const savedTheme = sessionStorage.getItem("theme")
//     if (savedTheme !== currentTheme) {
//       document.documentElement.classList.remove(savedTheme)
//       document.documentElement.classList.add(currentTheme)
//     } else {
//       document.documentElement.classList.remove(savedTheme)
//       document.documentElement.classList.add(savedTheme)
//     }
//   }

//   return (
//     <>
//       <div className="view-profile-light">
//         <p className={``}>Light Theme</p>
//         <label
//           className={`switch light-theme-slider ${
//             isDarkTheme ? "dark" : "light"
//           }`}
//         >
//           <input
//             type="checkbox"
//             checked={isDarkTheme}
//             onChange={handleToggleTheme}
//           />
//           <span className="slider round"></span>
//         </label>
//       </div>
//     </>
//   )
// }

// export default ToggleSwitch
