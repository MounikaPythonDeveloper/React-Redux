import React from "react"
import "./Model.css"
import { useTheme } from "@mui/material"

const Popup = (props) => {
  const theme=useTheme()
  return (
    <div className="popup-box">
      <div 
       className={`boxbox ${
              theme === "dark" ? "dark" : "light"
            }`}
      >{props.content}</div>
    </div>
  )
}

export default Popup
