import React, { useEffect, useState } from "react"
import { ToastContainer, toast } from "react-toastify"
import "./ReservationDetails.css"
import { Button } from "@material-ui/core"
import { DELETE_MANAGE_RESERVATION_API } from "../../services/api"
import Modalcancel from "../../components/ModalCancel/Model"
import close from "../../assets/images/Close.png"
import Axios from "axios"
import { useLocation, useNavigate } from "react-router-dom"
const ReservationDetails = ({ data, reservefalse }) => {
  const navigate = useNavigate()
  const [DeviceReservationDetail, setDeviceReservationDetails] = useState()
  console.log(DeviceReservationDetail, "aaaaaaaa")
  const [isOpen, setIsOpen] = useState(false)
  const [activeDevice, setActiveDevice] = useState("")
  const [reservecancel, setReservecancel] = useState(false)

  var userdata = JSON.parse(sessionStorage.getItem("userData"))
  console.log(userdata, "dddd")

  const DeviceReservationDetails = () => {}
  useEffect(() => {
    const id = setInterval(() => {
      DeviceReservationDetails()
    }, 5000)
  }, [])

  const confirmDelete = () => {
    let dataURL =
      DELETE_MANAGE_RESERVATION_API +
      JSON.stringify({ reservation_number: [data[0].reservation_number] })
    Axios.post(dataURL)
      .then((res) => {
        DeviceReservationDetails()

        toast.success("Delete Reservation done successfully")
        console.log(res.data, "yuvaraj")
        setIsOpen(false)
        navigate("/bigCalendar")
      })
      .catch((err) => {
        console.log(err)
      })
    console.log(data, "datatej")
  }

  const Delete_Confirmation = () => {
    setIsOpen(!isOpen)
    console.log("deleted")
  }
  const closepopop = () => {
    setIsOpen(false)
  }

  console.log(data, reservefalse, "chandanabig")
  return (
    <div className="listnames">
      {reservefalse &&
        data.map((item) => {
          return (
            <ul className="ultag">
              <li>
                <span>Brand Name</span>
                {item.brand_name}
              </li>
              <li>
                <span>Date</span>
                {item.date}
              </li>
              <li>
                <span>Device Name</span>
                {item.device_name}
              </li>
              <li>
                <span>Duration</span>
                {item.duration}
              </li>
              <li>
                <span>Location Id</span>
                {item.location_id}
              </li>
              <li>
                <span>Reserved By</span>
                {item.reserved_by}
              </li>
              <li>
                <span>Start Time</span>
                {item.start_time}
              </li>
            </ul>
          )
        })}

      <div className="deleteblue">
        <i
          class="fa fa-trash delete"
          aria-hidden="true"
          onClick={Delete_Confirmation}
        ></i>
      </div>

      {isOpen && (
        <Modalcancel
          content={
            <div className="maindiv">
              <img
                src={close}
                alt="Close"
                onClick={closepopop}
                className="popupsclose "
              />
              <br />
              <h3 className="deleteHeading">
                Do you want to delete reservation for this device ?{" "}
              </h3>
              <div className="popupallbtnpopup">
                <Button
                  onClick={closepopop}
                  className="popupcancelbtncancel"
                  variant="outlined"
                >
                  Cancel
                </Button>
                <Button
                  onClick={confirmDelete}
                  className="popupconfirmbtnconfirm"
                  variant="contained"
                >
                  Confirm
                </Button>
              </div>
            </div>
          }
        />
      )}
    </div>
  )
}

export default ReservationDetails
