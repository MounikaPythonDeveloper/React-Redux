import React, { useRef, useState, useEffect } from "react"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import moment from "moment"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { LineChart } from "@mui/x-charts/LineChart"
import { ReactSmartScroller } from "react-smart-scroller"
import axios from "axios"
import "./VideoInsights.css"
import {
  UPLOADVIDEO_API,
  CHECK_VIDEO_QUALITY_API,
  FETCH_DEVICE_NAMES_VIDEO_METRICS_API,
  CHECK_VIDEO_QUALITY_FILE_API,
  VIDEO_METRICS_URL_API,
  VIDEO_METRICS_URL_AKSHITHA_API,
  GENERATE_REPORT_VQ_API,
  FETCH_REPORT_API,
  GENERATE_REPORT_VQ_AKSHITHA_API,
} from "../../../services/api"
import CloseIcon from "@mui/icons-material/Close"
import IconButton from "@mui/material/IconButton"
import Report from "../../../../src/assets/images/Report.png"
import Report_light from "../../../../src/assets/images/icons8-reports-58.png"
import { Alert, Snackbar, Tooltip } from "@mui/material"
import generateUniqueId from "../../UniqueID/generateUniqueId"

export default function VideoInsights() {
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const [isValidURL, setIsValidURL] = useState(true)
  const [errorMessage, setErrorMessage] = useState("")
  const [closeQualityInfo, setCloseQualityInfo] = useState(true)
  const { theme } = useTheme()
  const [reportMessage, setReportMessage] = useState("")
  const [report, setReport] = useState("")
  const [url, setUrl] = useState("")
  const [currentValue, setCurrentValue] = useState(null)
  const [prevValue, setPrevValue] = useState([])
  const [accumulatedFrameCount, setAccumulatedFrameCount] = useState(0)
  const [qualityScore, setQualityScore] = useState([0, 0, 0, 0, 0])
  const [VMAveragePSNRValue, setVMAveragePSNRValue] = useState([0, 0, 0, 0, 0])
  const [xAxisData, setXAxisData] = useState([1, 2, 3, 4, 5])
  const [bandingRate, setBandingRate] = useState([0, 0, 0, 0, 0])
  const [blockingRate, setBlockingRate] = useState([0, 0, 0, 0, 0])
  const [blackFrames, setBlackFrames] = useState([0, 0, 0, 0, 0])
  const [dataVideoMetrics, setDataVideoMetrics] = useState([])
  const [viewButton, setViewButton] = useState(true)
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const fileInputRef = useRef(null)
  const [selectedFile, setSelectedFile] = useState(null)
  const [selectedVideo, setSelectedVideo] = useState()
  const [deviceDataVideo, setDeviceDataVideo] = useState([])
  const [selectedDevice, setSelectedDevice] = useState("")
  const [duration, setDuration] = useState("")
  const [videoMetricsData, setVideoMetricsData] = useState({})
  const [generateMessage, setGenerateMessage] = useState("")
  const [videoMessage, setVideoMessage] = useState("")
  const [urlMessage, setUrlMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const [ReportData, setReportData] = useState("")
  const currentDate = new Date()
  const [isButtonDisabled, setButtonDisabled] = useState(true)
  const [filename, setFilename] = useState("")
  const [isButtonDisabledVideo, setButtonDisabledVideo] = useState(true)
  const [triggerId, setTriggerID] = useState("")
  const [platformData, setplatformData] = useState(
    location.state?.data.platform ?? ""
  )
  const [buttonInput, setButtonInput] = useState(0)
  const [showAlert, setShowAlert] = useState(false)
  const [alertMessage, setAlertMessage] = useState("")
  const [alertSeverity, setAlertSeverity] = useState("success")
  const { isDarkTheme } = useTheme()
  const [uploading, setUploading] = useState(false)
  const [qualityInfo, setQualityInfo] = useState(false)
  const [inputType, setInputType] = useState("file")
  const isValidURLRegex = new RegExp(/^(ftp|http|https|rtp|udp):\/\/[^ "]+$/)
  const [ABRStatus, setABRStatus] = useState(false)
  const textfieldStyle = {
    background: "transparent",
    borderBottom: "2px solid #424242",
  }

  const handleUrl = (e) => {
    let url_value = e.target.value
    setUrl(url_value)
    setIsValidURL(isValidURLRegex.test(e.target.value))
  }
  useEffect(() => {
    if (qualityInfo) {
      const videoMetricsData = setInterval(() => {
        getVideoMetrics() // <-- (3) invoke in interval callback
      }, 1000)
      // getVideoMetrics()
      return () => clearInterval(videoMetricsData)
    }
  }, [qualityInfo])
  const getVideoMetrics = async () => {
    if (!isValidURL) {
      setSnackBarMessage("Invalid URL")
      setSnackBarSeverity("error")
      setQualityInfo(false)
    } else if (!url) {
      setSnackBarMessage("Enter URL")
      setSnackBarSeverity("error")
      setQualityInfo(false)
    } else {
      setQualityInfo(true)
      await axios
        .get(
          userProfile.username === "akshitha"
            ? VIDEO_METRICS_URL_AKSHITHA_API +
                JSON.stringify({
                  url: url,
                  trigger_id: triggerId,
                  // username: userProfile.username,
                })
            : VIDEO_METRICS_URL_API +
                JSON.stringify({
                  url: url,
                  trigger_id: triggerId,
                  // username: userProfile.username,
                })
        )
        .then((response) => {
          let data = response.data
          console.log(data, "Data..")
          // Update the data array with the new JSON data point
          setDataVideoMetrics((prevData) => [...prevData.slice(-4), data])
          setVideoMetricsData(data)
          // console.log("acumulate initial", accumulatedFrameCount)
          setCurrentValue(data.Dropped_Frames)
          setPrevValue((prev) => [...prev, data.Dropped_Frames])
          setAccumulatedFrameCount(
            (prevTotal) => prevTotal + data.Dropped_Frames
          )
          // console.log("acumulate final", accumulatedFrameCount)
          setVMAveragePSNRValue((prevData) =>
            [...prevData, data.Avg_PSNR_Value].slice(-5)
          )
          setQualityScore((prevData) =>
            [...prevData, data.Quality_Score].slice(-5)
          )
          setBandingRate((prevData) =>
            [...prevData, data.Banding_Rate].slice(-5)
          )
          console.log(bandingRate, "Banding Rate")
          setBlockingRate((prevData) =>
            [...prevData, data.Blocking_Rate].slice(-5)
          )
          console.log(blockingRate, "Blocking Rate")
          setBlackFrames((prevData) =>
            [...prevData, data.black_frames].slice(-5)
          )
          console.log(VMAveragePSNRValue, "Average PSNR Value")
          // Generate an array of timestamps for the X-axis representing every second
          const xAxis = Array.from(
            { length: VMAveragePSNRValue.length },
            (_, index) => index + 1
          )
          setXAxisData(xAxis)
          console.log(xAxis, "X axis")
        })
        .catch((error) => {
          console.log(error, " video error")
          // setErrorMessage("Backend Issue")
        })
      // .finally(setLoading(true))
    }
  }

  const generateReportMSL = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
      )
      .then((res) => {
        if (res.data === "True") {
          setSnackBarMessage("Generating The Report")
          setSnackBarSeverity("success")
        } else {
          setSnackBarMessage("Report Not Generated")
          setSnackBarSeverity("error")
        }
      })
      .catch((er) => {
        setSnackBarMessage("Backend Issue")
        setSnackBarSeverity("error")
      })
      .finally(setSnackBarMessage("Please wait.."))
  }
  const getVideoMetricsData = async () => {
    setQualityInfo(true)
    setTriggerID(generateUniqueId())
  }

  const handleCloseQuality = () => {
    // setQualityInfo(false)
    setUrl("")
    setCloseQualityInfo(false)
    closeVideoQuality()
  }

  const generateReport = () => {
    setUrl("")
    generateReportMSL()
    setQualityInfo(false)
  }
  const closeVideoQuality = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: url,
                device_name: "",
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: url,
                device_name: "",
              })
      )
      .then((res) => {
        console.log("generateReport MSL", res.data === "True")
        if (res.data === "True") {
          setAlertMessage("Generating the Report")
          setLoading(false)
        } else {
          setLoading(false)
        }
      })
      .catch((er) => console.log(er))
      .finally(setLoading(true))
  }

  const getReset = () => {
    setUrl("")
    setReportData("")
  }

  useEffect(() => {
    console.log("Trigger ID Updated", triggerId)
  }, [triggerId])

  return (
    <div className="ABR-page">
      <div className="ABR-page-title">
        <h3>Video Insights</h3>
      </div>
      <div className="ABR-page-form">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-4">
              <input
                type="text"
                class="form-control"
                placeholder="URL"
                onChange={handleUrl}
                value={url}
              />
            </div>
            <div class="col-sm-1">
              <button
                type="submit"
                className="ABR-Btn-sbmt"
                onClick={getVideoMetricsData}
              >
                Load
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="ABR-Data-Streaming">
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-6">
              {url.length > 1 &&
              qualityInfo === true &&
              Object.keys(videoMetricsData).length > 0 &&
              inputType === "url" &&
              closeQualityInfo === true ? (
                <div>
                  <video src={url} controls />
                </div>
              ) : (
                <div>
                  <video
                    src="https://www.sample-videos.com/video321/mp4/720/big_buck_bunny_720p_50mb.mp4"
                    type="video/mp4"
                    controls
                  />
                </div>
              )}
            </div>
            <div class="col-md-4">
              <div
                className={`network-video-block-insights ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <div
                  classname="transparent-block"
                  style={{
                    color: "white",
                  }}
                >
                  <div className="video-block-top">
                    <div>
                      <h3
                        className={`video-block-heading  ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Video Insights
                      </h3>
                    </div>
                    <div className="video-icons">
                      {Object.keys(videoMetricsData).length > 0 && (
                        <img
                          style={{
                            border: "none",
                            height: "3vh",
                            width: "3vh",
                          }}
                          src={theme === "dark" ? Report : Report_light}
                          title="Generate Report"
                          onClick={() => generateReport()}
                          alt="Reports"
                        />
                      )}
                      <IconButton
                        aria-label="close"
                        color="inherit"
                        size="small"
                        className={`network-video-block-insights-close ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        <CloseIcon
                          onClick={handleCloseQuality}
                          fontSize="inherit"
                          style={{ color: "white" }}
                        />
                      </IconButton>
                    </div>
                  </div>
                  {Object.keys(videoMetricsData).length > 0 ? (
                    <>
                      <ReactSmartScroller
                        vertical
                        style={{
                          height: "200px",
                          overflowX: "hidden",
                          overflowY: "auto",
                        }}
                      >
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {qualityScore && qualityScore.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Quality Score
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    data: qualityScore,
                                    label: "Quality Score",
                                  },
                                ]}
                                series={[
                                  {
                                    data: qualityScore,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {VMAveragePSNRValue &&
                            VMAveragePSNRValue.length > 0 && (
                              <div>
                                <div className="custom-y-axis-label">
                                  Average PSNR Values
                                </div>
                                <LineChart
                                  xAxis={[
                                    {
                                      data: xAxisData,
                                      label: "Time in Seconds",
                                    },
                                  ]}
                                  yAxis={[
                                    {
                                      data: VMAveragePSNRValue,
                                      label: "Average PSNR",
                                    },
                                  ]}
                                  series={[
                                    {
                                      data: VMAveragePSNRValue,
                                    },
                                  ]}
                                  width={400}
                                  height={200}
                                />
                              </div>
                            )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {blockingRate && blockingRate.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Blocking Rate
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    label: "Blocking Rate",
                                  },
                                ]}
                                series={[
                                  {
                                    data: blockingRate,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {bandingRate && bandingRate.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Banding Rate
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    label: "Banding Rate",
                                  },
                                ]}
                                series={[
                                  {
                                    data: bandingRate,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                      </ReactSmartScroller>

                      <table
                        className={`video-quilty-data  ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        <tr>
                          <th>Quality Score</th>
                          <td>:</td>
                          <td>{videoMetricsData.Quality_Score}</td>
                        </tr>
                        <tr>
                          <th>FPS</th>
                          <td>:</td>
                          <td>{videoMetricsData.FPS}</td>
                        </tr>
                        <tr>
                          <th>Dropped Frames</th>
                          <td>:</td>
                          <td>{videoMetricsData.Dropped_Frames}</td>
                        </tr>
                        <tr>
                          <th>Total Frames</th>
                          <td>:</td>
                          <td>{accumulatedFrameCount}</td>
                        </tr>
                        <tr>
                          <th>Resolution</th>
                          <td>:</td>
                          <td>{videoMetricsData.Resolution}</td>
                        </tr>
                        <tr>
                          <th>Blur Detected</th>
                          <td>:</td>
                          <td>
                            {videoMetricsData.Blur_Detected === null
                              ? videoMetricsData.Blur_Detected.length + "Frames"
                              : "0 Frames"}
                          </td>
                        </tr>
                        <tr>
                          <th>Blur Score</th>
                          <td>:</td>
                          <td>{videoMetricsData.Blur_Score}</td>
                        </tr>
                        <tr>
                          <th>Macro Blocking</th>
                          <td>:</td>
                          <td>{videoMetricsData.macro_blocking}</td>
                        </tr>
                        <tr>
                          <th>Black Frames</th>
                          <td>:</td>
                          <td>{videoMetricsData.black_frames}</td>
                        </tr>
                        {/* <tr>
                          <th>Average PSNR</th>
                          <td>:</td>
                          <td>
                            {Number(videoMetricsData.Avg_PSNR_Value).toFixed(2)}
                          </td>
                        </tr> */}
                        <tr>
                          <th>SSIM Score</th>
                          <td>:</td>
                          <td>{videoMetricsData.ssim_score}</td>
                        </tr>
                        <tr>
                          <th>Banding Rate</th>
                          <td>:</td>
                          <td>
                            {Number(videoMetricsData.Banding_Rate).toFixed(2)}
                          </td>
                        </tr>
                        <tr>
                          <th>Blocking Rate</th>
                          <td>:</td>
                          <td>
                            {Number(videoMetricsData.Blocking_Rate).toFixed(2)}
                          </td>
                        </tr>
                        <tr>
                          <th>Connection Speed</th>
                          <td>:</td>
                          <td>{videoMetricsData.connection_speed}</td>
                        </tr>
                        <tr>
                          <th>Data Used</th>
                          <td>:</td>
                          <td>{videoMetricsData.network_activity}</td>
                        </tr>
                        <tr>
                          <th>Timestamp</th>
                          <td>:</td>
                          <td>{videoMetricsData.time_stamp}</td>
                        </tr>
                      </table>
                    </>
                  ) : (
                    <div className="video-quality-nodata">
                      No Data Available
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <>
        <Snackbar
          open={snackBarMessage}
          autoHideDuration={10000}
          className={`crop-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClose={() => setSnackBarMessage("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            severity={snackBarSeverity}
            onClose={() => setSnackBarMessage("")}
          >
            {snackBarMessage}
          </Alert>
        </Snackbar>
      </>
    </div>
  )
}
