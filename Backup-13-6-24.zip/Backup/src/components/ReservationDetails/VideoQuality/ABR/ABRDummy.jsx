import React, { useState, useEffect } from "react"
import "./ABR.css"
import HLSVideoPlayer from "./HLSVideoPlayer/HLSVideoPlayer"
import TriggerTestABR from "../../../modules/Automation/TriggerTest/TriggerTestABR/TriggerTestABR"
import NetworkThrottlig from "../../NetworkThrottling/NetworkThrottlig"
import loadurl from "../../../assets/images/play.png"

export default function ABR() {
  const isValidURLRegex = new RegExp(/^(ftp|http|https|rtp):\/\/[^ "]+$/)
  const [ABRUrl, setABRUrl] = useState("")
  const [isValidURL, setIsValidURL] = useState(true)
  const [ABRDataValue, setABRDataValue] = useState(false)
  const [ThrottleStatus, setThrottleStatus] = useState(false)

  const getABRUrl = (e) => {
    setABRUrl(e.target.value)
    setIsValidURL(isValidURLRegex.test(e.target.value))
    console.log(ABRUrl, "ABR")
  }
  const getABRData = () => {
    setABRDataValue(true)
  }
  console.log(ABRUrl, ABRUrl.length, "ABRUrl")

  const handleThrottle = () => {
    setThrottleStatus(true)
  }
  return (
    <div className="ABR-page">
      <div className="ABR-page-title">
        <div>
          {" "}
          <h3>Adaptive Bitrate Streaming</h3>
          {/* <button
            type="reset"
            onClick={handleThrottle}
            className="ABR-Btn-sbmt"
          >
            Throttle
          </button> */}
        </div>
      </div>
      <div className="ABR-page-form">
        <div class="row justify-content-md-center">
          <div class="row">
            <div class="col-sm-1">
              <select class="form-select" aria-label="Default select example">
                {/* <option selected>HLS URL</option> */}
                <option value="hls-url">HLS URL</option>
                <option value="dash-url">DASH URL</option>
              </select>
            </div>
            <div class="col-sm-4">
              <input
                type="text"
                class="form-control"
                placeholder="URL"
                value={ABRUrl}
                onChange={getABRUrl}
              />
              {!isValidURL && (
                <div class="sub-partition2">
                  <p style={{ color: "red" }}>Invalid URL</p>
                </div>
              )}
            </div>
            <div class="col-sm-1">
              {/* <button
                type="submit"
                className="ABR-Btn-sbmt"
                onClick={getABRData}
              >
                Load
              </button> */}
              <img
                src={loadurl}
                onClick={getABRData}
                className="loadurl-img"
              ></img>
            </div>
            {/* <div class="col-sm-4">
              <div class="row">
                <div class="col">
                  <button
                    type="reset"
                    onClick={handleThrottle}
                    className="ABR-Btn-sbmt"
                  >
                    Throttle
                  </button>
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>

      <div className="ABR-Data-Streaming">
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-6">
              {ABRDataValue ? (
                <div>
                  <HLSVideoPlayer ABRUrl={ABRUrl}></HLSVideoPlayer>
                </div>
              ) : (
                <div>
                  <video controls />
                </div>
              )}
            </div>
            <div class="col-md-6">
              <TriggerTestABR></TriggerTestABR>
            </div>
            {ThrottleStatus && (
              <div>
                <NetworkThrottlig> </NetworkThrottlig>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
