import React, { useState, useEffect } from "react"
import "./HLSVideoPlayer.css"
import Hls from "hls.js"

export default function HlsPlayer({ ABRUrl }) {
  const [validationError, setValidationError] = useState("")
  const [levels, setLevels] = useState(null)
  const [currentlevel, setCurrentlevel] = useState(null)
  const isM3U8Url = (url) => {
    const m3u8Pattern = /\.m3u8$/i // Case-insensitive pattern to match ".m3u8" at the end of the URL
    return m3u8Pattern.test(url)
  }

  useEffect(() => {
    playerInit()
  }, [])

  const playerInit = () => {
    if (isM3U8Url(ABRUrl)) {
      if (Hls.isSupported()) {
        var video = document.getElementById("hls-player")
        const hls = new Hls()
        hls.attachMedia(video)
        hls.on(Hls.Events.MEDIA_ATTACHED, function () {
          hls.loadSource(ABRUrl)
        })

        hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
          setLevels(data?.levels)
          console.log("MANIFEST_PARSED", data.levels)
        })
        hls.on(Hls.Events.LEVEL_SWITCHED, (event, data) => {
          console.log(data, "LEVEL_SWITCHED")
          setCurrentlevel(data.level)
        })
      }
    } else {
      setValidationError("Invalid URL")
    }
  }

  return (
    <div className="hls-player-container">
      <video id="hls-player" controls />
      {levels !== null && (
        <div>
          Current Resolution - {levels[currentlevel]?.width} {"*"}
          {levels[currentlevel]?.height}, Bitrate -{" "}
          {levels[currentlevel]?.bitrate}bps, Codec-{" "}
          {levels[currentlevel]?.videoCodec}
        </div>
      )}
    </div>
  )
}
