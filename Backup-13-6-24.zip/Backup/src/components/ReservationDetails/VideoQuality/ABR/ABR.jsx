import React, { useState, useEffect } from "react"
import "./ABR.css"
import loadurl from "../../../assets/images/play.png"
import HLSVideoPlayer from "./HLSVideoPlayer/HLSVideoPlayer"
import {
  NETWORK_THROTTLING_API,
  TESTCASES_API,
  TESTSUITES_DEVICES_API,
} from "../../../services/api"
import { Alert, Snackbar, Tooltip } from "@mui/material"
// import { useTheme } from "../ThemeToggle/ThemeContext"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import axios from "axios"
import NetworkThroattling from "../../NetworkThrottling/NetworkThrottlig"
import TriggerTestABR from "../../../modules/Automation/TriggerTest/TiggerTestABR/TriggerTestABR"

export default function ABR() {
  // const isValidURLRegex = new RegExp(/^(ftp|http|https|rtp):\/\/[^ "]+$/)
  const { theme } = useTheme()
  const [testcasesData, setTestcasesData] = useState([])
  const [testsuiteData, setTestsuiteData] = useState([])
  const hlsURLRegex = new RegExp(/^https?:\/\/.+\.m3u8$/)
  const dashURLRegex = new RegExp(/^https?:\/\/(.*?)(\.mpd|\.xml)$/)
  // const dashURLRegex = /^https?:\/\/(.*?)(\.mpd|\.xml)$/
  const [networkStatusResponse, setNetworkStausResponse] = useState("")
  const [throattlingCurrentSpeed, setThroattlingCurrentSpeed] = useState([])
  const [ABRUrl, setABRUrl] = useState("")
  const [open, setOpen] = useState(false)
  const [isValidURL, setIsValidURL] = useState(true)
  const [ABRDataValue, setABRDataValue] = useState(false)
  const [throttleABRComponent, setThrottleABRComponent] = useState(false)
  const [video, setVideo] = useState("")
  const [urlType, setUrlType] = useState("")
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  let prevResolution = ""
  let prevBitrate = ""
  let prevCodec = ""
  const getUrlType = (e) => {
    setUrlType(e.target.value)
  }
  const getABRUrl = (e) => {
    setABRUrl(e.target.value)
    // setIsValidURL(isValidURLRegex.test(e.target.value))
    console.log(ABRUrl, "ABR")
  }

  const getABRData = () => {
    if (!urlType) {
      setSnackBarMessage("Invalid Input")
      setSnackBarSeverity("error")
    } else if (urlType === "HLS URL") {
      setIsValidURL(hlsURLRegex.test(ABRUrl))
      if (!isValidURL) {
        setSnackBarMessage("Invalid URL")
        setSnackBarSeverity("error")
        setABRDataValue(false)
      } else {
        setABRDataValue(true)
      }
    } else {
      setIsValidURL(dashURLRegex.test(ABRUrl))

      if (!isValidURL) {
        setSnackBarMessage("Invalid URL")
        setSnackBarSeverity("error")
        setABRDataValue(false)
      } else {
        setABRDataValue(true)
      }
    }
    // setABRDataValue(true)
  }

  const throttleABR = () => {
    setThrottleABRComponent(true)
    setOpen(true)
  }
  const handleClosePopup = function () {
    setOpen(false)
  }
  useEffect(() => {
    const networkThrottling = setInterval(() => {
      networkThroattlingCurrentSpeed()
    }, 5000)
    networkThroattlingCurrentSpeed()

    return () => clearInterval(networkThrottling)
  }, [])
  // Network-Throttling-Current-Time API Function
  const networkThroattlingCurrentSpeed = async () => {
    let currentSpeed = ""
    currentSpeed = `${NETWORK_THROTTLING_API}${JSON.stringify({
      device_name: "ABR",
    })}`
    await axios
      .post(currentSpeed)
      .then((response) => {
        console.log(response.data.Error, "kanna")
        if (response.data.current_throttling) {
          setThroattlingCurrentSpeed(response.data.current_throttling)
        } else {
          setThroattlingCurrentSpeed(response.data.Error)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  return (
    <div className="ABR-page">
      <div className="ABR-page-title">
        <h3>Adaptive Bitrate Streaming</h3>
      </div>
      <div className="ABR-page-form">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-1">
              <select
                class="ABR-Btn-sbmt"
                aria-label="Default select example"
                onChange={getUrlType}
              >
                <option value="">URL Type</option>
                <option value="HLS URL">HLS URL</option>
                <option value="DASH URL">DASH URL</option>
              </select>
            </div>
            <div class="col-sm-4">
              <input
                type="text"
                class="form-control"
                placeholder="URL"
                value={ABRUrl}
                onChange={getABRUrl}
              />
            </div>
            <div class="col-sm-1">
              {/* <img
                src={loadurl}
                onClick={getABRData}
                className="loadurl-img"
              ></img> */}
              <button
                type="submit"
                className="ABR-Btn-sbmt"
                onClick={getABRData}
              >
                Load
              </button>
            </div>
            <div class="col-sm-1">
              <button
                type="reset"
                className="ABR-Btn-sbmt"
                onClick={throttleABR}
              >
                Throttle
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* {ABRUrl && ABRDataValue && ( */}
      <div className="ABR-Data-Streaming">
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-7">
              {ABRDataValue ? (
                <div>
                  <HLSVideoPlayer ABRUrl={ABRUrl}></HLSVideoPlayer>
                </div>
              ) : (
                <div>
                  <video controls />
                </div>
              )}
            </div>
            <div class="col-md-5">
              <TriggerTestABR ABRUrl={ABRUrl}></TriggerTestABR>
            </div>
            {throttleABRComponent && (
              <NetworkThroattling
                DeviceName="ABR"
                open={open}
                handleClose={handleClosePopup}
                throattlingCurrentSpeed={throattlingCurrentSpeed}
                networkStatusResponse={networkStatusResponse}
              ></NetworkThroattling>
            )}
          </div>
        </div>
      </div>
      <>
        <Snackbar
          open={snackBarMessage}
          autoHideDuration={10000}
          className={`crop-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClose={() => setSnackBarMessage("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            severity={snackBarSeverity}
            onClose={() => setSnackBarMessage("")}
          >
            {snackBarMessage}
          </Alert>
        </Snackbar>
      </>
    </div>
  )
}
