import React from "react"
import "./AutoGeneration.css"
import { useState, useEffect, useRef } from "react"
import Snackbar from "@mui/material/Snackbar"
import { Alert } from "@mui/material"
import axios from "axios"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import AutoSCriptPopup from "../AutoSCriptPopup/AutoSCriptPopup"
import { AUTO_SCRIPT_GENERATION } from "../../../services/api"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"

export default function AutoScriptGeneration() {
  const navigate = useNavigate()
  const [inputType, setInputType] = useState("none")
  const [genExecutionType, setGenExecutionType] = useState("none")
  const [frameworkType, setFrameworkType] = useState("none")
  const [selectedLanguage, setSelectedLanguage] = useState("none")
  const [selectedType, setSelectedType] = useState(null)
  const [reportMessage, setReportMessage] = useState(false)
  const [alertMsg, setAlertMsg] = useState(false)
  const [scriptOpenPopup, setScriptOpenPopup] = useState(false)
  //for Animation
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState(false)
  const { theme } = useTheme()
  const [selectedFile, setSelectedFile] = useState(null)
  const fileInputRef = useRef(null)
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const [platformValue, setPlatformValue] = useState("none")
  const [ApplicationValue, setApplicationValue] = useState("none")
  const [handleResetValue, setHandleResetValue] = useState(false)
  const [autoScriptRes, setAutoScriptRes] = useState([])
  const [UploadFileValue, setUploadFileValue] = useState(null)

  const handleLanguageChange = (event) => {
    const language = event.target.value
    setSelectedLanguage(language)
    if (language === "none") {
      setSelectedType(null)
    }
  }

  const handleGenExecutionChange = (event) => {
    setGenExecutionType(event.target.value)
  }

  const handleFrameworkChange = (event) => {
    setFrameworkType(event.target.value)
  }

  const handleUpload = async () => {
    try {
      if (
        (inputType === "none",
        genExecutionType === "none",
        selectedLanguage === "none",
        frameworkType === "none")
      ) {
        setReportMessage(true)
        return false
      }
    } catch (error) {
      console.error("Options are not selected:", error.message)
      return false
    }

    const formData = new FormData()
    formData.append("file", UploadFileValue)
    formData.append("gen_and_exec_type", genExecutionType)
    formData.append("framework_type", frameworkType)
    formData.append("script_language_type", selectedLanguage)
    formData.append("input_type", inputType)
    try {
      const response = await axios.post(AUTO_SCRIPT_GENERATION, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      if (response.status === 200) {
        setAlertMsg(true)
        setAutoScriptRes(response.data.result)
      }
    } catch (error) {
      setErrorMsg(true)
    }
  }

  const handleViewScript = () => {
    window.open(autoScriptRes, "_blank")
  }

  const handleInputChange = (event) => {
    setInputType(event.target.value)
    setScriptOpenPopup(true)
  }
  const autoScriptPopupCloseHandler = (scriptFileState) => {
    setSelectedFile(scriptFileState)
    setScriptOpenPopup(false)
  }
  const preventDragHandler = (e) => {
    e.preventDefault()
  }
  const AutoGenBack = function () {
    navigate(-1)
  }
  const handleReset = () => {
    setInputType("none")
    setGenExecutionType("none")
    setFrameworkType("none")
    setSelectedLanguage("none")
    setApplicationValue("none")
    setPlatformValue("none")
    setSelectedFile("null")
    setUploadFileValue(null)
    setHandleResetValue(true)
    setAutoScriptRes([])
  }
  const handlePlatform = (e) => {
    setPlatformValue(e.target.value)
  }
  const handleApplication = (e) => {
    setApplicationValue(e.target.value)
  }
  const UploadFileFun = (value) => {
    setUploadFileValue(value)
  }
  return (
    <>
      <div>
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          {platform_data === "Media And Entertainment" ? (
            <Link onClick={AutoGenBack} onDragStart={preventDragHandler}>
              M&E
            </Link>
          ) : (
            <Link onClick={AutoGenBack}>{platform_data}</Link>
          )}
          <Link onClick={AutoGenBack}>AiTest</Link>
          <Typography color="#0D6EFD">Auto Script</Typography>
        </Breadcrumbs>
        <Snackbar
          open={reportMessage}
          autoHideDuration={6000}
          onClose={() => setReportMessage("")}
        >
          <Alert
            onClose={() => setReportMessage("")}
            severity="error"
            variant="filled"
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            Please select all the options.!
          </Alert>
        </Snackbar>
        <Snackbar
          open={errorMsg}
          autoHideDuration={6000}
          onClose={() => setErrorMsg("")}
        >
          <Alert
            onClose={() => setErrorMsg("")}
            severity="error"
            variant="filled"
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            Script generation failed!!!
          </Alert>
        </Snackbar>
        <Snackbar
          open={alertMsg}
          autoHideDuration={6000}
          onClose={() => setAlertMsg("")}
        >
          <Alert
            onClose={() => setAlertMsg("")}
            severity="success"
            variant="filled"
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            Script generation completed successfully!!!
          </Alert>
        </Snackbar>
        <Snackbar
          className="auto-script-loading"
          open={loading}
          autoHideDuration={6000}
          onClose={() => setLoading("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          {loading && <Alert icon={true}>Script Loading..</Alert>}
        </Snackbar>
      </div>
      <AutoSCriptPopup
        value={UploadFileValue}
        onChangeHandler={UploadFileFun}
        open={scriptOpenPopup}
        closeHandler={autoScriptPopupCloseHandler}
      />
      <div class={`auto-script-content ${theme === "dark" ? "dark" : "light"}`}>
        <header>
          <div class="top-box">
            <div class="autoscript">
              AutoScript - AI Based TestScript Generation
            </div>
          </div>
        </header>
        <div class="auto-gen-box">
          <div className="auto-gen-part-A">
            <div className="auto-gen-lables-container">
              <label className="auto-gen-lables" for="dropdown1">
                SOURCE INPUT
              </label>
              <label className="auto-gen-lables" for="dropdown2">
                PLATFORM
              </label>
              <label className="auto-gen-lables" for="dropdown5">
                APPLICATION
              </label>
              <label className="auto-gen-lables" for="dropdown3">
                FUNCTIONS
              </label>
              <label className="auto-gen-lables" for="dropdown4">
                SCRIPT LANGUAGE
              </label>
            </div>
            <div className="auto-gen-dots-container">
              <div className="auto-gen-dots">:</div>
              <div className="auto-gen-dots">:</div>
              <div className="auto-gen-dots">:</div>
              <div className="auto-gen-dots">:</div>
              <div className="auto-gen-dots">:</div>
            </div>
            <div className="auto-gen-select-box-container">
              <select
                value={inputType}
                onChange={handleInputChange}
                id="dropdown1"
                name="dropdown1"
              >
                <option value="none" disabled selected>
                  --Please choose an option--
                </option>
                <option value="2">Text input</option>
              </select>

              <select
                id="dropdown2"
                value={platformValue}
                onChange={handlePlatform}
                name="dropdown2"
              >
                <option value="none" disabled selected>
                  --Please choose an option--
                </option>
                <option value="windows">Windows</option>
              </select>
              <select
                id="dropdown5"
                value={ApplicationValue}
                onChange={handleApplication}
                name="dropdown5"
              >
                <option value="none" disabled selected>
                  --Please choose an option--
                </option>
                <option value="web">Web</option>
              </select>
              <select
                value={genExecutionType}
                onChange={handleGenExecutionChange}
                id="dropdown3"
                name="dropdown3"
              >
                <option value="none" disabled selected>
                  --Please choose an option--
                </option>
                <option value="1">Script Generation</option>
                <option value="2">Script Generation and View</option>
              </select>
              <select
                value={selectedLanguage}
                onChange={handleLanguageChange}
                id="dropdown4"
                name="dropdown4"
              >
                <option value="none" disabled selected>
                  --Please choose an option--
                </option>
                <option value="pyt">Python</option>
              </select>
              {selectedLanguage === "pyt" && (
                <select
                  value={frameworkType}
                  onChange={handleFrameworkChange}
                  class="sub-droptext"
                  id="sub-demo-video"
                  name="sub-demo-video"
                >
                  <option value="none" disabled selected>
                    --Select Framework Type --
                  </option>
                  <option value="gen">General</option>
                </select>
              )}
            </div>
          </div>
          <div className="auto-gen-part-B">
            <div className="auto-gen-button-container">
              <button
                class="auto-gen-submit"
                onClick={handleUpload}
                disabled={loading}
              >
                Submit
              </button>
              <button
                class="auto-gen-reset"
                onClick={handleReset}
                disabled={loading}
              >
                Reset
              </button>
              {autoScriptRes.length > 0 && (
                <button class="auto-gen-reset" onClick={handleViewScript}>
                  View Script
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export { AutoScriptGeneration }
