import React, { useEffect, useState, useRef } from "react"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import "./AutoSCriptPopup.css"
import closeIcon from "../../../assets/images/Close.png"

const AutoSCriptPopup = (props) => {
  const [scriptFileState, setScriptFileState] = useState(null)
  const scriptFileInput = useRef(null)
  let timer = ""
  const [
    autoSCriptClosePopupAndScriptFile,
    setAutoSCriptClosePopupAndScriptFile,
  ] = useState()
  const [handleClose, setHandleClose] = useState()
  const { theme } = useTheme()

  const handlescriptFile = (event) => {
    props.onChangeHandler(event.target.files[0])
  }
  const AutoScriptCloseHandler = () => {
    scriptFileInput.current.value = ""
    setAutoSCriptClosePopupAndScriptFile(props.closeHandler(scriptFileState))
  }
  const autoScriptPopupCloseHandler = (e) => {
    setHandleClose(props.closeHandler)
    scriptFileInput.current.value = ""
  }

  return (
    <Modal
      keepMounted
      open={props.open}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box
        className={`autoScriptPopupContainer ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div className="autoScriptPopupHeading">
          <div className="null"></div>
          <div className="autoScriptUpload">
            <i class="fa fa-cloud-upload" aria-hidden="true"></i>
            <span class="up">upload</span>
          </div>
          <div className="autoScriptPopupClose">
            <img
              src={closeIcon}
              alt="Close"
              onClick={autoScriptPopupCloseHandler}
            />
          </div>
        </div>
        <div className="autoScriptPopupMiddle">
          <i class="fa fa-file-text-o" aria-hidden="true"></i>
          <div className="autoScriptText">
            <p class="pointer-none">
              <b> Upload files here </b> <br />
            </p>
            <input
              value={props.value?.fileName}
              type="file"
              ref={scriptFileInput}
              onChange={handlescriptFile}
            />
          </div>
        </div>
        <div className="uploadButtonDiv">
          {props.value === null ? (
            <button
              disabled={true}
              title="Disabled"
              className="UploadBtn-disable"
            >
              Upload
            </button>
          ) : (
            <button className="UploadBtn" onClick={AutoScriptCloseHandler}>
              Upload
            </button>
          )}
        </div>
      </Box>
    </Modal>
  )
}
export default AutoSCriptPopup
