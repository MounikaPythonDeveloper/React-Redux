import React from "react"
import "./AiTest.css"
import { useTheme } from "../ThemeToggle/ThemeContext"
import AsLogo from "../../assets/images/logo_as.png"
import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"

export default function AutoScript() {
  const [selectedPlatform, setSelectedPlatform] = useState("none")
  const [selectedType, setSelectedType] = useState(null)
  const { theme } = useTheme()
  const navigate = useNavigate()
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const handlePlatformChange = (event) => {
    const platform = event.target.value
    setSelectedPlatform(platform)
    // Reset selected type if the platform is set to 'none'
    if (platform === "none") {
      setSelectedType(null)
    }
  }
  const handleTypeChange = (event) => {
    const type = event.target.value
    setSelectedType(type)
  }

  const playVideo = () => {
    if (selectedPlatform !== "none" && selectedType) {
      const videoPath = `https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Autoscript/${selectedPlatform.toLowerCase()}_${selectedType.toLowerCase()}.mp4`
      // Open video in a new tab
      try {
        window.open(videoPath, "_blank")
      } catch (error) {
        console.error("Error could not play the video:", error.message)
        alert("Could not play the video!!")
      }
    }
  }

  useEffect(() => {
    // Check if both platform and type are selected before playing the video
    if (selectedPlatform && selectedType) {
      playVideo()
    }
  }, [selectedPlatform, selectedType])

  const preventDragHandler = (e) => {
    e.preventDefault()
  }
  const AutoScriptBack = function () {
    navigate(-1)
  }

  return (
    <div className={`ai-test ${theme === "dark" ? "dark" : "light"}`}>
      <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
        <Link to={"/platform"} onDragStart={preventDragHandler}>
          Platform
        </Link>
        {platform_data === "Media And Entertainment" ? (
          <Link onClick={AutoScriptBack} onDragStart={preventDragHandler}>
            M&E
          </Link>
        ) : (
          <Link onClick={AutoScriptBack}>{platform_data}</Link>
        )}
        <Typography color="#0D6EFD">AiTest</Typography>
      </Breadcrumbs>
      <header class="header">
        <div class="logo">
          <span class="logo-auto">EvQUAL-AiTest</span>
        </div>
      </header>

      <div className="autoscript-wrapper">
        <div className="autoscript-gen">
          <Link to={"/platform/M&E/aiTest/autoGeneration"}>
            AutoScript Generation
          </Link>
        </div>
        <div class="autoscript-gen" href="{% url 'auto_test_gen' %}">
          AutoTest Generation
        </div>
      </div>
      <footer class="auto-script-footer">
        <div class="demo-dropdown">
          <label class="demotext" for="demo-video">
            Demo Video:
          </label>
          <select
            class="droptext"
            value={selectedPlatform}
            onChange={handlePlatformChange}
            id="demo-video"
            name="demo-video"
          >
            <option value="none">Select Platform</option>
            <option value="windows">Windows</option>
            <option value="linux">Linux</option>
            <option value="macos">macOS</option>
          </select>
          {selectedPlatform !== "none" && (
            <select
              class="sub-droptext"
              value={selectedType}
              onChange={handleTypeChange}
              id="sub-demo-video"
              name="sub-demo-video"
            >
              <option value="none">Select Application</option>
              <option value="web">Web</option>
              <option value="desktop">Desktop</option>
              <option value="mobile">Mobile</option>
            </select>
          )}
        </div>
      </footer>

      <div className="description-wrapper">
        <div class="logo-image-container">
          <div className="logo-image">
            <img src={AsLogo} style={{ paddingTop: "5px" }} alt="ASLogo" />
          </div>
          <div class="steps-container">
            <div class="top-steps">
              <div class="step step-top step-animation">
                <div className="steps">
                  <div>Step 1:Select DUT/AUT</div> <div>and platform</div>
                </div>
              </div>
              <div class="step step-top1 step-animation">
                <div className="steps">
                  <div>Step 2: Test cases</div> <div>Generated/Input/Voice</div>
                </div>
              </div>
            </div>
            <div class="bottom-steps">
              <div class="step_bottom0 step-bottom step-animation">
                <div className="steps">
                  <div>Step 4: Script Generation </div>{" "}
                  <div> and Execution </div>
                </div>
              </div>
              <div class="step_bottom1 step-bottom step-animation">
                <div className="steps">
                  <div> Step 3: Select Program </div>{" "}
                  <div>Language(py,robot,js,C#,C++) </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="sub-description">
          <div class="description">
            <h2>GenAI based AutoTest and AutoScript Generation</h2>
            <p>
              The "Autoscript Tool" is a powerful and versatile software
              designed to enhance testing & scripting capabilities for multiple
              platforms & multiple operating systems.
              <b>Autotest Generation</b> from the given
              specification/requirement to reduce manual effort.
              <b>AutoScript Generation</b> to provide comprehensive environment
              for scripting,managing automation workflows,and optimizing
              multiple system administration.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export { AutoScript }
