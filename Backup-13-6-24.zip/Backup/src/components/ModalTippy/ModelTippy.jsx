import React from "react"
import "./ModelTippy.css"

const Popup = (props) => {
  return (
    <div className="popup-box1">
      <div className="box1">{props.content}</div>
    </div>
  )
}

export default Popup
