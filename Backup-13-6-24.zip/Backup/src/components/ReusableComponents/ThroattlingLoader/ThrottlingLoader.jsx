import React from "react"
import "./ThrottlingLoader.css"
import { useTheme } from "../../ThemeToggle/ThemeContext"

function ThrottlingLoader() {
  const { theme } = useTheme()
  return (
    <div class="throttling-page-loader">
      <div className={`throttling-txt ${theme === "dark" ? "dark" : "light"}`}>
        Loading....
      </div>
    </div>
  )
}
export default ThrottlingLoader
