import React from "react";
import { Link } from "react-router-dom";
import { FormHelperText, makeStyles } from "@material-ui/core";
import { PropTypes } from "prop-types";

const useStyle = makeStyles((theme) => ({
  link: {
    color: "#07F265",
    fontWeight: "600",
  },
}));

const ReusableLink = ({ to, className, children }) => {
  const classes = useStyle();
  return (
    <Link to={to} className={`${classes.link} ${className}`}>
      {children}
    </Link>
  );
};

ReusableLink.propTypes = {
  to: PropTypes.string.isRequired,
  className: PropTypes.string,
  children: PropTypes.node.isRequired,
};

export default ReusableLink;
