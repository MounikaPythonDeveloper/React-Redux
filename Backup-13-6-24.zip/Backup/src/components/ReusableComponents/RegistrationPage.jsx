import React from "react"
import "../modules/SignUp/SignUp.css"
import MyLink from "../components/Basic/Links"
var CryptoJS = require("crypto-js")

const RegistrationPage = () => {
  return (
    <React.Fragment>
      <div class="col-md-6 register-left">
        <div className="account">
          Already have an Account?&#160;
          <MyLink
            to="/login"
            className="signupBtn"
            style={{ color: "#07F265" }}
          >
            Sign In
          </MyLink>
        </div>
        <div className="account">
          Create an account?&#160;
          <MyLink
            to="/Register"
            className="signupBtn"
            style={{ color: "#07F265" }}
          >
            Sign Up
          </MyLink>
        </div>
      </div>
    </React.Fragment>
  )
}
export default RegistrationPage
