import * as React from "react"
import Box from "@mui/material/Box"
import "./PopupMessage.css"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Button from "@mui/material/Button"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"

export default function BasicModal(props) {
  const { theme } = useTheme()
  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`modal-container-license ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <div className="modal-first-row">
            <div className="modal-icon-div">
              <IconButton
                className="modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
                style={{ float: "right" }}
              >
                <CloseIcon fontSize="inherit" className="modal-close-icon" />
              </IconButton>
            </div>
            <div className="modal-text-div">
              <Typography
                className="modal-text1"
                style={{ color: "white", paddingBlock: "16px" }}
              >
                {props.text1}
              </Typography>
              <Typography
                className="modal-text"
                style={{ paddingBlock: "10px" }}
              >
                {props.text}
              </Typography>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}
