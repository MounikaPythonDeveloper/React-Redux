import * as React from "react"
import Box from "@mui/material/Box"
import "./DeviceLockPopup.css"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Button from "@mui/material/Button"

export default function DeviceLockPopup(props) {
  const DeviceUnlockBlur = function () {
    props.blurFunction()
    props.deviceUnlock()
  }
  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box className="modal-container">
          <div className="modal-icon-div">
            <IconButton
              className="modal-icon"
              aria-label="close"
              color="inherit"
              size="small"
              onClick={props.handleClose}
            >
              <CloseIcon fontSize="inherit" className="modal-close-icon" />
            </IconButton>
          </div>
          <div className="modal-text-div">
            <Typography className="modal-text">{props.text}</Typography>
          </div>
          <div className="btn-actions">
            <Button className="btn-handler" onClick={props.handleClose}>
              Cancel
            </Button>
            <Button className="btn-handler" onClick={DeviceUnlockBlur}>
              Confirm
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  )
}
