import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

const useStyles = makeStyles((theme) => ({
scrollContainer: {
position: 'relative',
overflowY: 'auto',
maxHeight: '200px', // Set the max height for the scrollbar container
padding: theme.spacing(1),
// Add other styles as needed
},
customScrollbar: {
position: 'absolute',
top: 0,
right: 0,
bottom: 0,
width: '6px', // Set the width of the custom scrollbar
backgroundColor: theme.palette.grey[300],
borderRadius: '3px',
opacity: 0.8,
transition: 'opacity 0.3s ease',
'&:hover': {
opacity: 1,
},
},
thumb: {
backgroundColor: theme.palette.grey[600],
borderRadius: '3px',
cursor: 'pointer',
'&:hover': {
backgroundColor: theme.palette.grey[700],
},
},
}));

const CustomScrollbar = ({ children }) => {
const classes = useStyles();

return (
<div className={classes.scrollContainer}>
{children}
<div className={classes.customScrollbar}>
<div className={classes.thumb} />
</div>
</div>
);
};

CustomScrollbar.propTypes = {
children: PropTypes.node.isRequired,
};

export default CustomScrollbar;