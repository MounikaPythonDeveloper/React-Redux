import React from "react"
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"
import OutlinedInput from "@mui/material/OutlinedInput"
import "./MultiSelectDrodown.css"
import { makeStyles } from "@material-ui/core"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"

const useStyles = makeStyles({
  inputLabel: {
    color: "white",
  },
})

const MultiSelectDropdown = ({
  selectedPlatforms,
  setSelectedPlatforms,
  optionPlatformData,
  title,
}) => {
  const { theme } = useTheme()
  const handleChange = (event) => {
    setSelectedPlatforms(event.target.value)
  }
  const classes = useStyles()

  const ITEM_HEIGHT = 48
  const ITEM_PADDING_TOP = 8
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
        background:
          theme === "light"
            ? "linear-gradient(to right, #034e88, #40a7f6)"
            : "",
      },
    },
  }

  const dropDownColor = {
    color: "white",
    backgroundColor: "yellow",
  }
  return (
    <>
      <FormControl variant="standard" sx={{ width: "100%", color: "white" }}>
        {optionPlatformData ? (
          <Select
            inputProps={{ style: dropDownColor }}
            labelId="multi-select-label"
            id="multi-select"
            multiple
            value={selectedPlatforms}
            onChange={handleChange}
            MenuProps={MenuProps}
            renderValue={(selected) => {
              if (selected.length === 0) {
                return <em>Placeholder</em>
              }
              return selected.join(", ")
            }}
          >
            {" "}
            {optionPlatformData.map((item, index) => {
              return <MenuItem value={item}>{item}</MenuItem>
            })}
          </Select>
        ) : (
          <p>No Platforms Available</p>
        )}
      </FormControl>
    </>
  )
}

export default MultiSelectDropdown
