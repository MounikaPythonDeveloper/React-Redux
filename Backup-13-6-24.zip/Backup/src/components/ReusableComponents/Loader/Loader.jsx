import React from "react"
import "./Loader.css"

function Loader() {
  return (
    <div class="page-loader">
      <div class="spinner"></div>
      <div className="txt">Loading....</div>
    </div>
  )
}
export default Loader
