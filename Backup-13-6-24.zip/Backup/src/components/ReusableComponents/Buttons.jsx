import React from 'react';
import Button from '@mui/material/Button';

function useButton(props) {
const {
    variant = 'contained',
    type = 'button',
    disabled = false,
    onClick,
    label = 'Button',
} = props;

return (
<Button
    variant={variant}
    type={type}
    disabled={disabled}
    onClick={onClick}
    className="my-button"
>
{label}
</Button>
);
}

export default useButton;