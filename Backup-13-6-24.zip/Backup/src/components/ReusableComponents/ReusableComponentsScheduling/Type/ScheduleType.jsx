/** *
 * File: DatePicker.jsx
 * Description: * This file contents for the implmentation fo schedule type to select and parse throught props .
 * ScheduleType components is wrapped into ScheduleType function
 * Author: Yuvaraj Dakhane
 * **/
import React, { useState } from "react";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import "./Scheduletype.css";
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";

//Components are wrapped into ScheduleType
const ScheduleType = ({ onTypeSelect }) => {
  const { theme } = useTheme();
  const [selectedOption, setSelectedOption] = useState("");

  const handleChange = (event) => {
    setSelectedOption(event.target.value);
    onTypeSelect(event.target.value);
  };

  return (
    <div className={`main-div ${theme === "dark" ? "dark" : "light"}`}>
      <label className="label-Componets">Schedule Type</label>
      <div className="select-dropdown-div">
        <select
          value={selectedOption}
          onChange={handleChange}
          className="select-dropdown"
          required
        >
          <option value="">Select an option</option>
          <option value="Timely one time">Timely one time</option>
          <option value="Hourly">Hourly</option>
          <option value="Daily">Daily</option>
          <option value="Weekly">Weekly</option>
          <option value="Monthly">Monthly</option>
        </select>
        <ArrowDropDownIcon className="ArrowDropDownType" fontSize="large" />
      </div>
    </div>
  );
};

export default ScheduleType;
