/** *
 * File: DatePicker.jsx
 * Description: * This file contents for the implmentation for Timezone input field.
 * Timezone components is wrapped into MyComponents function
 * Author: Yuvaraj Dakhane
 * **/
import React from "react";
import "./Timezone.css";
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";

//Components are wrapped into MYcomponent
const MyComponent = () => {
  const { theme } = useTheme();
  return (
    <div className={`main-div  ${theme === "dark" ? "dark" : "light"}`}>
      <label className="label-Componets">Timezone</label>
      <div className="timezoneSelect">
        <input
          className="e-input"
          type="text"
          placeholder="Time zone in India (GMT +5.30)"
          disabled={true}
        />
      </div>
    </div>
  );
};

export default MyComponent;
