/** * 
 * File: DatePicker.jsx
 * Description: * This file contents for selecting date from input field .
 * DatePicker components is wrapped into DatePickerMain function
 * It is return the input datepicker.
 * Author: Yuvaraj Dakhane
 * **/
import React from 'react'
import 'react-datepicker/dist/react-datepicker.css';

//components is wrapped into DatePickerMain
const DatePickerMain = ({onSelectedDate, onEndDateSelect}) =>{    
    const date = new Date(onSelectedDate).toISOString().split('T')[0]

    //function used to set the selected date when handleDateChange function calls
    const handleDateChange = ( date) =>{
        onEndDateSelect(date) //passing the date to onEndDateSelect props
    }

    //rendering the input date picker 
    return(
        <>
        <div className="main-div">
            <label className='label-Componets'>End Date</label>
            <div className='date-picker-secondary'>
                <input min={date} type="date" onChange={(e) => handleDateChange(e.target.value)} className="datepicker" />
            </div>
        </div>
        </>
    )
}

export default DatePickerMain