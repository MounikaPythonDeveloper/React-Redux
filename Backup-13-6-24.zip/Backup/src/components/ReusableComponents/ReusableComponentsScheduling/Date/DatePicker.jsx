/** *
 * File: DatePicker.jsx
 * Description: * This file contents for selecting date from input field .
 * DatePicker components is wrapped into DatePickerMain function
 * It is return the input datepicker.
 * Author: Yuvaraj Dakhane
 * **/
import React, { useState } from "react";
import "react-datepicker/dist/react-datepicker.css"; //style foro react-datepicker
import "./DatePicker.css"; //using DatePicker.css to give style
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";

//components is wrapped into DatePickerMain
const DatePickerMain = ({ onDateSelect }) => {
  const { theme } = useTheme();
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  //function used to set the selected date when handleDateChange function calls
  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  onDateSelect(selectedDate); //passing the selectedDate to OnDateSelect props
  const today = new Date().toISOString().split("T")[0]; //converting date into ISOString and splitted after T. Output: yyyy-mm-dd

  //returning the components to render
  return (
    <>
      <div className={`main-div ${theme === "dark" ? "dark" : "light"}`}>
        <label className="label-Componets">Start Date</label>
        <div className="date-picker-secondary">
          <input
            min={today}
            value={selectedDate}
            type="date"
            onChange={(e) => handleDateChange(e.target.value)}
            className="datepicker"
          />
        </div>
      </div>
    </>
  );
};

export default DatePickerMain;
