
import React, {useState} from 'react';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { renderTimeViewClock } from '@mui/x-date-pickers/timeViewRenderers';
import { withStyles, makeStyles} from '@material-ui/core';
import { FormControlLabel} from '@mui/material';
import './Timepicker.css'
import dayjs from 'dayjs';

const StyledFormControlLabel = withStyles((theme) => ({
  root:{
    '& .MuiRadio-root':{
      display: 'none',
      
    },
    '& .MuiStack-root':{
      heigth: 10,
      backgroundColor: 'pink'
    },
    selectedLabel:{
      color: 'pink'
    }
  },
}))(FormControlLabel);

const useStyle = makeStyles({
    underline: {
      "&&&:before": {
        borderBottom: "none",
      },
      "&&:after": {
        borderBottom: "none",
      },
    },
    selectedLabel:{
      backgroundColor: '#1eb6b6'
    },
    inputRoot:{
      height: '5px',
    }
});

const TimePickerMain = ({onTimeSelect, scheduleType, scheduleDate}) => {
  const classes= useStyle();
  const [selectedTime, setSelectedTime] = useState();
  const [isTimeValid, setIsTimeValid] = useState(true);

  const handleTimeChange = (time) => {
    setSelectedTime(time.format('HH:mm:ss'))
    onTimeSelect(time.format('HH:mm:ss'), true)
    setIsTimeValid(true)
  }

  const handleBlur = () =>{
    if(!selectedTime){
      setIsTimeValid(false)
      onTimeSelect(null, false);
    }
  }

  const currentDate = dayjs().format('YYYY-MM-DD')
  const somethibg = currentDate === scheduleDate
  const minTime = somethibg ? dayjs()  : null;
 
  return (
    <div style={{ display: 'flex', alignItems: 'center' }} className="main-div">
      <label className='label-Componets'>Start Time</label>
      <div className='second-container' >
        {scheduleType === 'Hourly' ? 
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer
              components={[
                'TimePicker'
              ]}
              className="demoContainerTime"
              sx={{overflow: "hide", marginTop: -1}}              
            >      
              <TimePicker
                viewRenderers={{
                  minutes: renderTimeViewClock,
                }}
                openTo={"minutes"}
                onChange={handleTimeChange}
                onBlur={handleBlur}
                className="TimePickerStyle"
                ampm={false}
                format="mm"
                InputProps={{
                  classes:{
                    input: classes.inputRoot,
                    underline: classes.underline,
                  }
                }}            
                views={['minutes']}
              />
            </DemoContainer>
          </LocalizationProvider>
            :
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer
              components={[
                'TimePicker',
              ]}
              className="demoContainerTime"
              sx={{overflow: "hide", marginTop: -1}}
            >
              <TimePicker
                viewRenderers={{
                  hours: renderTimeViewClock,
                  minutes: renderTimeViewClock,
                }}
                openTo={"hours"}
                onChange={handleTimeChange}
                className="TimePickerStyle"
                ampm={false}
                format="HH:mm"
                minTime={minTime}
                InputProps={{
                  classes:{
                    input: classes.inputRoot,
                  }
                }} 
              />
            </DemoContainer>
          </LocalizationProvider>
          
        }
      </div>
    </div>
  );
}

export default TimePickerMain
