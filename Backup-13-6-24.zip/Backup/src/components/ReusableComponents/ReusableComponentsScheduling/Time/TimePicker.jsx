/** *
 * File: DatePicker.jsx
 * Description: * This file contents for the implmentation of Time Picker to select the time and parse throught props.
 * TimePicker components is wrapped into TimePickerMain function
 * Author: Yuvaraj Dakhane
 * **/
import React from "react";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import { makeStyles } from "@material-ui/core";
import "./Timepicker.css";
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";
import dayjs from "dayjs"; //library use to provide time of dayjs to AdapterDayJS
import { createTheme, ThemeProvider } from "@mui/material/styles"; //Used to provide and create theme for compoent

//function use to make style for TimePicker Component
const useStyle = makeStyles({
  inputRoot: {
    height: "5px",
  },
});

//Var use store createTheme into theme
const theme = createTheme();

//style to be store.
const DemoContainerStyle = {
  overflow: "hide",
  marginTop: -1,
  borderBottom: "none",
};

//Components are wrapped into TimePickerMain
const TimePickerMain = ({ onTimeSelect, scheduleDate }) => {
  const { theme } = useTheme();
  const classes = useStyle(); // store the style into classes

  //function to parse the time in 'HH:mm' format whenever you change the time
  const handleTimeChange = (time) => {
    onTimeSelect(time.format("HH:mm"), true);
  };

  const currentDate = dayjs().format("YYYY-MM-DD"); //get the date in "YYYY-MM-DD"
  const matched = currentDate === scheduleDate; //check the currentDate and scheduleDate is same or not
  const minTime = matched ? dayjs() : null; //If matched the return dayjs() time or else null

  return (
    <div className={`main-div ${theme === "dark" ? "dark" : "light"}`}>
      <label className="label-Componets">Start Time</label>
      <div className="second-container">
        <ThemeProvider theme={theme}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer
              components={["TimePicker"]}
              className="demoContainerTime"
              sx={DemoContainerStyle}
            >
              <TimePicker
                viewRenderers={{
                  hours: renderTimeViewClock,
                  minutes: renderTimeViewClock,
                }}
                openTo={"hours"}
                onChange={handleTimeChange}
                className="TimePickerStyle"
                ampm={false}
                format="HH:mm"
                minTime={minTime}
                InputProps={{
                  classes: {
                    input: classes.inputRoot,
                  },
                }}
              />
            </DemoContainer>
          </LocalizationProvider>
        </ThemeProvider>
      </div>
    </div>
  );
};

export default TimePickerMain;
