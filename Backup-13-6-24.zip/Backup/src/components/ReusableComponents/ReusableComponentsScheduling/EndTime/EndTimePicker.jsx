/** * 
 * File: DatePicker.jsx
 * Description: * This file contents for the implmentation of Time Picker to select the time and parse throught props.
 * TimePicker components is wrapped into EndTimePicker function
 * Author: Yuvaraj Dakhane
 * **/
import React from 'react';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { renderTimeViewClock } from '@mui/x-date-pickers/timeViewRenderers';
import { makeStyles} from '@material-ui/core';
import dayjs from 'dayjs';//library use to provide time of dayjs to AdapterDayJS
import { createTheme, ThemeProvider } from '@mui/material/styles';//Used to provide and create theme for compoent

//function use to make style for TimePicker Component
const useStyle = makeStyles({
    inputRoot:{
      height: '5px',
    }
});

//Var use store createTheme into theme
const theme = createTheme();

//style to be store.
const DemoContainerStyle = {
  overflow: 'hide',
  marginTop: -1,
  borderBottom: "none"
}

//Components are wrapped into TimePickerMain
const EndTimePicker = ({onSelectedEndTime, scheduleDate, onSelectEndDate, onEndTimeSelect }) => {
  const classes= useStyle();// store the style into classes

  //function to parse the time in 'HH:mm' format whenever you change the time
  const handleTimeChange = (time) => {
    onEndTimeSelect(time.format('HH:mm'))
  }
  console.log("enddateequal", scheduleDate === onSelectEndDate, scheduleDate, onSelectEndDate)
  return (
    <div className="main-div">
      <label className='label-Componets'>End Time</label>
      <div className='second-container' >
        <ThemeProvider theme={theme}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer
              components={[
                'TimePicker',
              ]}
              className="demoContainerTime"
              sx={DemoContainerStyle}
            >
              <TimePicker
                viewRenderers={{
                  hours: renderTimeViewClock,
                  minutes: renderTimeViewClock,
                }}
                openTo={"hours"}
                onChange={handleTimeChange}
                className="TimePickerStyle"
                ampm={false}
                format="HH:mm"
                minTime={scheduleDate === onSelectEndDate ? dayjs(`${scheduleDate} ${onSelectedEndTime}`, 'YYYY-MM-DD HH:mm') : null} //minTime getting from start time picker and converting into 'YYYY-MM-DD HH:mm' format
                InputProps={{
                  classes:{
                    input: classes.inputRoot,
                  }
                }} 
              />
            </DemoContainer>
          </LocalizationProvider>
        </ThemeProvider>
      </div>
    </div>
  );
}

export default EndTimePicker
