/** *
 * File: DayPicker.jsx
 * Description: * This file contents for selecting days from input field .
 * DayPicker components is wrapped into DayPicker hook
 * It is return the input DayPicker.
 * Author: Yuvaraj Dakhane
 * **/
import React, { useState } from "react";
import "./DayPicker.css";

//compoenents are wrapped into DayPicker hook
const DaysPicker = ({ scheduleType, onSelectDays }) => {
  const [selectedDay, setSelectedDay] = useState([]);

  //function uses to set the selected Day into setSElectedDay
  const handleDayChange = (event) => {
    const value = event.target.value;
    //condition is checking if the values is exist or not
    if (selectedDay.includes(value)) {
      setSelectedDay(selectedDay.filter((item) => item !== value)); //If exists then it removing the selected day
    } else {
      setSelectedDay([...selectedDay, value]);
    }
  };
  onSelectDays(selectedDay); // parsing the selectedDay to onSelectDays() props

  return (
    <div>
      {scheduleType === "Weekly" ? (
        <div className="main-div">
          <label className="label-Componets">Days</label>
          <label
            className={`days-label ${
              selectedDay.includes("1") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="1"
              checked={selectedDay.includes("1")}
              onChange={handleDayChange}
            />
            MON
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("2") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="2"
              checked={selectedDay.includes("2")}
              onChange={handleDayChange}
            />
            TUE
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("3") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="3"
              checked={selectedDay.includes("3")}
              onChange={handleDayChange}
            />
            WED
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("4") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="4"
              checked={selectedDay.includes("4")}
              onChange={handleDayChange}
            />
            THUR
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("5") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="5"
              checked={selectedDay.includes("5")}
              onChange={handleDayChange}
            />
            FRI
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("6") ? "selected" : ""
            }`}
          >
            <input
              type="checkbox"
              name="day"
              value="6"
              checked={selectedDay.includes("6")}
              onChange={handleDayChange}
            />
            SAT
          </label>

          <label
            className={`days-label ${
              selectedDay.includes("0") ? "selected" : ""
            }`}
          >
            <input
              type="radio"
              name="day"
              value="0"
              checked={selectedDay.includes("0")}
              onChange={handleDayChange}
            />
            SUN
          </label>
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default DaysPicker;
