import React from 'react';
import { FormControl, Input, InputLabel, InputAdornment, IconButton } from '@material-ui/core';
// import SearchIcon from "../Images/Search.svg";

const SearchField = ({ label, placeholder, onSearch, iconSrc }) => {
const handleSearch = (event) => {
// Call the onSearch callback with the search query
onSearch(event.target.value);
};

return (
<FormControl className="search-field" variant="standard" color="secondary">
    <InputLabel htmlFor="searchdevicemodel">{label}</InputLabel>
        <Input
            id="searchdevicemodel"
            type="text"
            placeholder={placeholder}
            endAdornment={
                <InputAdornment position="end">
                    <IconButton style={{backgroundColor:"black"}}>
                        <img src={iconSrc} alt="Search" />
                    </IconButton>
                </InputAdornment>
        }
    onChange={handleSearch}
    />
</FormControl>
);
};

export default SearchField;