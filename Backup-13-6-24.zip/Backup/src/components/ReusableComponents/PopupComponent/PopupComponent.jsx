import * as React from "react"
import Box from "@mui/material/Box"
import "./PopupComponent.css"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Button from "@mui/material/Button"
import { useTheme } from "../../ThemeToggle/ThemeContext"

export default function BasicModal(props) {
  const { theme } = useTheme()
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }
  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`modal-container ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="modal-row">
            <div className="modal-text-div">
              <Typography
                className={`modal-text ${theme === "dark" ? "dark" : "light"}`}
              >
                {props.text}
              </Typography>
            </div>
            <div
              className={`modal-icon-div  ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <IconButton
                className="modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon fontSize="inherit" className="modal-close-icon" />
              </IconButton>
            </div>
          </div>
          <div className="btn-actions">
            <Button
              className={`btn-handler ${theme === "dark" ? "dark" : "light"}`}
              onClick={props.handleClose}
            >
              Cancel
            </Button>
            <Button
              className={`btn-handler ${theme === "dark" ? "dark" : "light"}`}
              onClick={props.functionHandle}
            >
              Confirm
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  )
}
