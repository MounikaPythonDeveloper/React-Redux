import React from "react"
import PropTypes from "prop-types"
import { TextField, FormHelperText, makeStyles } from "@material-ui/core"

const useStyle = makeStyles((theme) => ({
  helperText: {
    color: "red",
    fontSize: 13,
    position: "absolute",
    bottom: "-20px",
  },
}))
const MyTextField = ({
  label,
  className,
  type,
  register,
  onBlur,
  error,
  value,
  name,
  helperText,
  setField,
}) => {
  const texfieldInputStyle = {
    borderBottom: "1px solid grey",
    color: "white",
    fontFamily: "Open Sans",
    fontSize: 20,
  }

  const texfieldLabelStyle = {
    color: "white",
    opacity: 0.7,
    fontSize: 20,
    fontFamily: "Open Sans",
    paddingTop: 5,
  }
  const classes = useStyle()
  const handleTextFieldChange = (e) => {
    setField(e.target.value)
  }
  return (
    <TextField
      id="standard-basic"
      label={label}
      variant="standard"
      className={className}
      type={type}
      {...register}
      onBlur={onBlur}
      onChange={handleTextFieldChange}
      error={error}
      name={name}
      value={value}
      helperText={helperText}
      InputProps={{
        style: texfieldInputStyle,
      }}
      InputLabelProps={{
        style: texfieldLabelStyle,
      }}
      FormHelperTextProps={{
        classes: { root: classes.helperText },
      }}
    />
  )
}

MyTextField.propTypes = {
  label: PropTypes.string.isRequired,
  name: PropTypes.string,
  value: PropTypes.string,
  className: PropTypes.string,
  type: PropTypes.string,
  register: PropTypes.object,
  onBlur: PropTypes.func,
  error: PropTypes.bool,
  helperText: PropTypes.string,
}

export default MyTextField
