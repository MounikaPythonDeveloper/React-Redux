// import React, { useState } from "react"
// import "./DropDownComponent.css"
// import { Dropdown, DropdownButton } from "react-bootstrap"

// function DropDownComponent() {
//   const [selected, setSelected] = useState("")
//   return (
//     <DropdownButton
//       title={selected === "" ? "select" : selected}
//       className="select-dropdown"
//     >
//       <input type="text" className="form-control" placeholder="Search" />
//       <div className="select-dropdown-list">
//         <Dropdown.Item eventKey="1" onClick={() => setSelected("1")}>
//           1
//         </Dropdown.Item>
//         <Dropdown.Item eventKey="2" onClick={() => setSelected("2")}>
//           2
//         </Dropdown.Item>
//         <Dropdown.Item eventKey="3" onClick={() => setSelected("3")}>
//           3
//         </Dropdown.Item>
//       </div>
//     </DropdownButton>
//   )
// }
// export default DropDownComponent
import React, { useEffect, useState } from "react";
import "./DropDownComponent.css";
import { Dropdown, DropdownButton } from "react-bootstrap";
import { useTheme } from "../../ThemeToggle/ThemeContext";
import NetworkThroattling from "../../NetworkThrottling/NetworkThrottlig";

function DropDownComponent(props) {
  const [selected, setSelected] = useState("");
  const [open, setOpen] = useState(false);

  const handleClosePopup = function () {
    setOpen(false);
    setSelected("");
  };
  const networkLog = function () {
    setSelected("Network Logs");
    props.networkLogsToggle();
  };
  const networkThroattling = function () {
    setSelected("Network Throattling");
    setOpen(true);
  };
  const { theme } = useTheme();
  if (theme === "dark") {
    document.documentElement.classList.remove("light");
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
    document.documentElement.classList.add("light");
  }

  return (
    <div className="dropDownCom">
      <NetworkThroattling
        DeviceName={props.DeviceName}
        open={open}
        handleClose={handleClosePopup}
        throattlingCurrentSpeed={props.throattlingCurrentSpeed}
        networkStatusResponse={props.networkStatusResponse}
      />

      <DropdownButton
        // style="position: absolute;inset: 0px auto auto 0px;transform: translate(0px, 32px);"
        title={selected === "" ? "Network" : selected}
        className={`select-dropdown ${theme === "dark" ? "dark" : "light"}`}
      >
        <div
          // style="position: absolute;inset: 0px auto auto 0px;transform: translate(0px, 32px);"
          className={`select-dropdown-list ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <Dropdown.Item onClick={networkLog}>Network Logs</Dropdown.Item>
          <Dropdown.Item onClick={networkThroattling}>
            Network Throttling
          </Dropdown.Item>
        </div>
      </DropdownButton>
    </div>
  );
}
export default DropDownComponent;
