/** * Component: SampleComponent
    * File:OTP.jsx
    * Description: This file contents the implementation of user OTP page.
                   Wrapping all the components into OTP.
                   It consists the form for entering OTP in user sign up and return the validation msg as per response.
    * Author: Yuvaraj Dakhane
* **/
import React, { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { useNavigate } from "react-router-dom"
import "../OTP/OTP.css"
import axios from "axios"
import { TextField, makeStyles, useMediaQuery, Button } from "@material-ui/core"
import Alert from "@mui/material/Alert"
import { VALIDATE_OTP_API, RESEND_OTP_API } from "../../services/api"
import MyButton from "../ReusableComponents/Buttons"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"

//Style for mui components
const useStyle = makeStyles({
  helperText: {
    color: "red",
    fontSize: 13,
    position: "absolute",
    bottom: "-20px",
  },
  buttonEnabled: {
    color: "#07F265",
    position: "relative",
    textDecoration: "none",
    border: "none",
    textTransform: "none",
    textAlign: "left",
    "&:hover": {
      backgroundColor: "none",
    },
    "&:onClick": {
      border: "none",
    },
  },
  buttonDisabled: {
    color: "#07F265",
    position: "relative",
    textDecoration: "none",
    border: "hidden",
    textTransform: "none",
    "&:hover": {
      backgroundColor: "none",
    },
    "&:disabled": {
      color: "white",
      border: "none",
    },
  },
})

const texfieldInputStyle = {
  borderBottom: "1px solid grey",
  color: "white",
  fontFamily: "Open Sans",
  fontSize: 20,
}

const texfieldLabelStyle = {
  color: "white",
  opacity: 0.7,
  fontSize: 20,
  fontFamily: "Open Sans",
  paddingTop: 5,
}

//Calling OTP fucntion from singup.jsx with username, email_id, handleactiveblock using props
const Otp = ({ username, email_id, handleactiveblock }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  let navigate = useNavigate() //useNavigate is use to navigate to some url.

  //Define the states and data.
  const [showAlert, setShowAlert] = useState(false)
  const { theme } = useTheme()
  const [attemptsRemaining, setAttemptsRemaining] = useState(3)
  const [error, setError] = useState()
  const [disabled, setDisabled] = useState(true)
  const [remainingTime, setRemainingTime] = useState(0)
  const [headingText, setHeadingText] = useState("OTP Confirmation")
  const [buttonText, setButtonText] = useState("Resend OTP")
  const [otpEmpty, setOTPEmpty] = useState(true)
  const classes = useStyle()
  const data = "OTP verification failed.Try again"
  const isMobile = useMediaQuery("(max-width: 480px)")

  const alertStyle = {
    fontSize: isMobile ? "15px" : "24px",
    color: "#fff",
  }

  //Define the function for calling validateOTP function
  const onSubmitEmail = (data) => {
    typeof data === "string" ? validateOTP(data) : validateOTP(data.otp)
  }

  //when it load the otp.jsx it will set the timer to 30 sec
  useEffect(() => {
    setRemainingTime(30)
    setTimeout(() => {
      setDisabled(false)
      setRemainingTime(0)
    }, 30000)
  }, [])

  //If the button is disabled for resend otp it will set remaining time for timer
  useEffect(() => {
    let timer
    if (disabled) {
      timer = setInterval(() => {
        setRemainingTime((prev) => (prev === 0 ? 0 : prev - 1))
      }, 1000)
    }
    return () => clearInterval(timer)
  }, [disabled])

  //to change the text of OTP page when width is below 480px
  useEffect(() => {
    if (window.matchMedia("(max-width: 480px)").matches) {
      setHeadingText("OTP Confirmation")
      setButtonText("Resend OTP")
    } else {
      setHeadingText("OTP Confirmation")
      setButtonText("Resend OTP")
    }
  }, [])

  //Define a function to call resend otp api
  const resendOtp = () => {
    setDisabled(true)
    setRemainingTime(30)
    setTimeout(() => {
      setDisabled(true)
      setRemainingTime(0)
    }, 5000)
    axios.post(
      RESEND_OTP_API + JSON.stringify({ username: username, email: email_id })
    )
  }

  //Define the function to validate the otp using VALIDATE_OTP_API.
  const validateOTP = (otp) => {
    axios
      .post(VALIDATE_OTP_API + JSON.stringify({ otp: otp, username: username }))
      .then((response) => {
        if (response.data.valid === "true") {
          console.log("otp success", response.data)
          setTimeout(() => {
            navigate("/", {
              state: {
                message:
                  "Your Registration Completed. Please Wait for Admin Approval.",
              },
            })
          }, 2000)
          setShowAlert(true)
        } else {
          setError(response.data.message)

          // TODO: display error message
          if (attemptsRemaining === 1 || response.data.account === "Blocked") {
            console.log("attempt for blocking", attemptsRemaining)
            navigate("/register", { state: { data: data } })
            // deleteUser()
            handleactiveblock(0)
          } else {
            setAttemptsRemaining(attemptsRemaining - 1)
            handleactiveblock(1)
          }
        }
        console.log("sendotp", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  //Define the function to close the alert box
  const handleAlertClose = () => {
    setShowAlert(false)
  }

  //If it showAlert is true then it will call handleAlertClose() function
  if (showAlert) {
    setTimeout(() => {
      handleAlertClose()
    }, 2000)
  }

  //Define a function to check the lsetOTPEmpty string true or false
  const handleOtpChange = (e) => {
    if (e.target.value.length < 5 || e.target.value.length > 5) {
      setOTPEmpty(true)
    } else {
      setOTPEmpty(false)
    }
  }

  //Define the function to call onSubmitEmail when user click on enter button from keyboard
  const handleKeyPress = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault()
      onSubmitEmail(event.target.value)
    }
  }

  return (
    <React.Fragment>
      <div className="background-div">
        <div className={`Registration1 ${theme === "dark" ? "dark" : "light"}`}>
          <div class="row">
            <div class=" register-right1">
              <form
                className="registration-form"
                onSubmit={handleSubmit(onSubmitEmail)}
              >
                <div className="otp-container">
                  <h3 className="reg_title">{headingText}</h3>
                  <div class="otp-div-container">
                    <div class="otp-textfield-container otp-textfield">
                      <TextField
                        id="standard-basic-otp"
                        className="resentOtpTextfield"
                        label="OTP"
                        variant="standard"
                        {...register("otp", {
                          required: "Enter your OTP",
                          pattern: {
                            value: /^[0-9]{5}$/s,
                            message: "Enter a valid OTP",
                          },
                        })}
                        type="number"
                        inputProps={{ maxLength: 5 }}
                        onChange={handleOtpChange}
                        onKeyDown={(event) => handleKeyPress(event)}
                        helperText={[
                          errors.otp && errors.otp.message,
                          error && error,
                        ]}
                        InputProps={{
                          style: texfieldInputStyle,
                          classes: { underline: classes.underline },
                        }}
                        InputLabelProps={{
                          style: texfieldLabelStyle,
                        }}
                        FormHelperTextProps={{
                          classes: { root: classes.helperText },
                        }}
                      />
                    </div>

                    <div class="otp-textfield-container button-otp">
                      <Button
                        variant="outlined"
                        className={
                          remainingTime === 0
                            ? "otp-button-enabled"
                            : "otp-button"
                        }
                        id="resendButton"
                        disabled={disabled}
                        onClick={resendOtp}
                      >
                        <span
                          className={
                            remainingTime === 0
                              ? "otp-button-enabled"
                              : "otp-button"
                          }
                        >
                          {buttonText}
                          <p className={"otp-timer"}>{` ${remainingTime}s`}</p>
                        </span>
                      </Button>
                    </div>
                  </div>

                  <div className="input_css1 reset-align">
                    <MyButton
                      variant="contained"
                      type="submit"
                      label="Submit"
                      disabled={!!otpEmpty}
                    />
                  </div>
                </div>
              </form>
              <div></div>
              {attemptsRemaining < 3 && (
                <p>Attempts remaining: {attemptsRemaining}</p>
              )}
            </div>
          </div>
          {/* if showAlert is true it will show the alert box */}
          {showAlert && (
            <div className="alertDiv2">
              <Alert
                severity="success"
                variant="filled"
                onClose={handleAlertClose}
                icon={false}
                className="alertBox"
                sx={alertStyle}
              >
                Successfully Registered
              </Alert>
            </div>
          )}
        </div>
      </div>
    </React.Fragment>
  )
}

export default Otp
