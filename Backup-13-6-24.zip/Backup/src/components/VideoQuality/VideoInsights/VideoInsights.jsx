import React, { useState, useEffect } from "react"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import { useLocation } from "react-router-dom"
import { LineChart } from "@mui/x-charts/LineChart"
import { ReactSmartScroller } from "react-smart-scroller"
import Livekit from "../../Livekit/LivekitRoomVideoInsights"
import "../../../components/Livekit/livekit.css"
import axios from "axios"
import "./VideoInsights.css"
import {
  EXIST_FROM_LIVEKITROOM,
  START_FFMPEG_VIDEO_INSIGHTS_API,
  STOP_FFMPEG_VIDEO_INSIGHTS_API,
  CHECK_VIDEO_QUALITY_API,
  CHECK_VIDEO_QUALITY_FILE_API,
  VIDEO_METRICS_URL_API,
  VIDEO_METRICS_URL_AKSHITHA_API,
  COLLECT_LIVE_CHANNELS_API,
  DELETE_LIVE_MULTIPLE_CHANNELS_API,
  GENERATE_REPORT_VQ_API,
  LIVEKITROOM_API,
  GENERATE_REPORT_VQ_AKSHITHA_API,
} from "../../../services/api"
import CloseIcon from "@mui/icons-material/Close"
import IconButton from "@mui/material/IconButton"
import { Alert, Snackbar } from "@mui/material"
import generateUniqueId from "../../UniqueID/generateUniqueId"

export default function VideoInsights() {
  const [currentChannel, setCurrentChannel] = useState(null)
  const [previousChannel, setPreviousChannel] = useState(null)
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const [isValidURL, setIsValidURL] = useState(true)
  const [closeQualityInfo, setCloseQualityInfo] = useState(true)
  const { theme } = useTheme()
  const [url, setUrl] = useState("")
  const [tokenData, setTokenData] = useState("")
  const [currentValue, setCurrentValue] = useState(null)
  const [prevValue, setPrevValue] = useState([])
  const [accumulatedFrameCount, setAccumulatedFrameCount] = useState(0)
  const [qualityScore, setQualityScore] = useState([0, 0, 0, 0, 0])
  const [VMAveragePSNRValue, setVMAveragePSNRValue] = useState([0, 0, 0, 0, 0])
  const [xAxisData, setXAxisData] = useState([1, 2, 3, 4, 5])
  const [bandingRate, setBandingRate] = useState([0, 0, 0, 0, 0])
  const [blockingRate, setBlockingRate] = useState([0, 0, 0, 0, 0])
  const [blackFrames, setBlackFrames] = useState([0, 0, 0, 0, 0])
  const [dataVideoMetrics, setDataVideoMetrics] = useState([])
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [videoMetricsData, setVideoMetricsData] = useState({})
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const [ReportData, setReportData] = useState("")
  const currentDate = new Date()
  const [triggerId, setTriggerID] = useState("")
  const [alertMessage, setAlertMessage] = useState("")
  const [alertSeverity, setAlertSeverity] = useState("success")
  const { isDarkTheme } = useTheme()
  const [qualityInfo, setQualityInfo] = useState(false)
  const isValidURLRegex = new RegExp(/^(ftp|http|https|rtp|udp):\/\/[^ "]+$/)
  const textfieldStyle = {
    background: "transparent",
    borderBottom: "2px solid #424242",
  }
  const [isChecked, setChecked] = useState("Single Channel")
  const [totalChannels, setTotalChannels] = useState(2)

  const handleUrl = (e) => {
    let url_value = e.target.value
    setUrl(url_value)
    setIsValidURL(isValidURLRegex.test(e.target.value))
  }
  const handleTotalChannels = (e) => {
    setTotalChannels(e.target.value)
  }
  useEffect(() => {
    if (url && qualityInfo === true) {
      const videoMetricsData = setInterval(() => {
        getVideoMetrics()
      }, 5000)
      return () => clearInterval(videoMetricsData)
    }
  }, [qualityInfo, url])

  const getVideoMetrics = async () => {
    if (!isValidURL) {
      setSnackBarMessage("Invalid URL")
      setSnackBarSeverity("error")
      setQualityInfo(false)
    } else if (!url) {
      setSnackBarMessage("Enter URL")
      setSnackBarSeverity("error")
      setQualityInfo(false)
    } else {
      setQualityInfo(true)
      await axios
        .get(
          userProfile.username === "akshitha"
            ? COLLECT_LIVE_CHANNELS_API +
                JSON.stringify({ trigger_id: triggerId })
            : VIDEO_METRICS_URL_API +
                JSON.stringify({
                  trigger_id: triggerId,
                  url: url,
                })
        )
        .then((response) => {
          let data = response.data
          console.log(data, "Data..")
          if (data.status === "Completed") {
            setSnackBarMessage("Assessment is Completed")
            setSnackBarSeverity("success")
            if(url){
              resetVideoInsights()
            }
           
          } else {
            // Update the data array with the new JSON data point
            setDataVideoMetrics((prevData) => [...prevData.slice(-4), data])
            setVideoMetricsData(data)
            setCurrentChannel(data.channel_number)
            console.log("acumulate initial", accumulatedFrameCount)

            setCurrentValue(data.Dropped_Frames)
            setPrevValue((prev) => [...prev, data.Dropped_Frames])
            setAccumulatedFrameCount(
              (prevTotal) => prevTotal + data.Dropped_Frames
            )
            console.log("acumulate final", accumulatedFrameCount)
            setVMAveragePSNRValue((prevData) =>
              [...prevData, data.Avg_PSNR_Value].slice(-5)
            )
            setQualityScore((prevData) =>
              [...prevData, data.Quality_Score].slice(-5)
            )
            setBandingRate((prevData) =>
              [...prevData, data.Banding_Rate].slice(-5)
            )
            console.log(bandingRate, "Banding Rate")
            setBlockingRate((prevData) =>
              [...prevData, data.Blocking_Rate].slice(-5)
            )
            console.log(blockingRate, "Blocking Rate")
            setBlackFrames((prevData) =>
              [...prevData, data.black_frames].slice(-5)
            )
            console.log(VMAveragePSNRValue, "Average PSNR Value")
            // Generate an array of timestamps for the X-axis representing every second
            const xAxis = Array.from(
              { length: VMAveragePSNRValue.length },
              (_, index) => index + 1
            )
            setXAxisData(xAxis)
            console.log(xAxis, "X axis")
          }
        })
        .catch((error) => {
          console.log(error, " video error")
        })
    }
  }
  useEffect(() => {
    if (
      videoMetricsData &&
      currentChannel !== null &&
      currentChannel !== previousChannel
    ) {
      setAlertSeverity("success")
      setPreviousChannel(currentChannel)
    }
  }, [currentChannel, previousChannel])

  const generateReportMSL = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
      )
      .then((res) => {
        if (res.data === "True") {
          setSnackBarMessage("Generating The Report")
          setSnackBarSeverity("success")
        } else {
          setSnackBarMessage("Report Not Generated")
          setSnackBarSeverity("error")
        }
      })
      .catch((er) => {
        setSnackBarMessage("Backend Issue")
        setSnackBarSeverity("error")
      })
      .finally(setSnackBarMessage("Please wait.."))
  }
  useEffect(() => {
    let uniqueId = generateUniqueId()
    setTriggerID(uniqueId)
    console.log("Trigger ID Updated", triggerId)
  }, [triggerId])

  const getVideoMetricsData = async () => {
    if (isChecked && url) {
      getChannelsCreatePDFFile()
      setQualityInfo(true)
      getLivekitToken()
      startFFMPEGLivekit()
    } else {
      setSnackBarMessage("Select Required Fields")
      setSnackBarSeverity("error")
    }
  }
  const getLivekitToken = async () => {
    let url_device = ""
    url_device = `${LIVEKITROOM_API}${"Video Insights"}?data=${JSON.stringify({
      locked_by: userProfile.username,
    })}`
    try {
      const response = await axios.post(url_device)
      console.log("livekit-data deviceview", response.data)
      setTokenData(response.data)
    } catch (error) {
      setSnackBarMessage("Backend Issue for Generating token")
      setSnackBarSeverity("error")
    }
  }
  const startFFMPEGLivekit = async () => {
    try {
      const response = await axios.post(
        START_FFMPEG_VIDEO_INSIGHTS_API + JSON.stringify(url)
      )
      console.log("livekit start FFMPEG", response.data)
    } catch (error) {
      setSnackBarMessage("Backend Issue for startFFMPEG")
      setSnackBarSeverity("error")
    }
  }
  const stopFFMPEGLivekit = async () => {
    try {
      const response = await axios.post(STOP_FFMPEG_VIDEO_INSIGHTS_API)
      console.log("livekit stop FFMPEG", response.data)
    } catch (error) {
      setSnackBarMessage("Backend Issue for stop FFMPEG")
      setSnackBarSeverity("error")
    }
  }
  const deleteLiveDataFile = () => {
    setCloseQualityInfo(false)
    closeVideoQuality()
  }
  const handleCloseQuality = () => {
    setUrl("")
    setCloseQualityInfo(false)
    closeVideoQuality()
  }

  const generateReport = () => {
    setUrl("")
    generateReportMSL()
    setQualityInfo(false)
  }
  const closeVideoQuality = () => {
    console.log("close video quality")
    axios
      // .get(
      //   userProfile.username === "akshitha"
      //     ? GENERATE_REPORT_VQ_AKSHITHA_API +
      //         JSON.stringify({
      //           trigger_id: triggerId,
      //           user_name: userProfile.username,
      //           action: "close",
      //           url: url,
      //           device_name: "",
      //         })
      //     : GENERATE_REPORT_VQ_API +
      //         JSON.stringify({
      //           trigger_id: triggerId,
      //           user_name: userProfile.username,
      //           action: "close",
      //           url: url,
      //           device_name: "",
      //         })
      // )
      .get(
        DELETE_LIVE_MULTIPLE_CHANNELS_API +
          JSON.stringify({ trigger_id: triggerId })
      )
      .then((res) => {
        console.log("generateReport MSL", res.data === "True")
        if (res.data === "True") {
          setAlertMessage("Generating the Report")
          setLoading(false)
        } else {
          setLoading(false)
        }
      })
      .catch((er) => console.log(er))
      .finally(setLoading(true))
  }

  const getReset = () => {
    setUrl("")
    setReportData("")
  }

  const handleChange = (event) => {
    setChecked(event.target.value)
  }

  const getChannelsCreatePDFFile = async () => {
    await axios
      .get(
        userProfile.username === "akshitha"
          ? VIDEO_METRICS_URL_AKSHITHA_API +
              JSON.stringify({
                url: url,
                trigger_id: triggerId,
                channel_number:
                  isChecked === "Single Channel" ? 1 : parseInt(totalChannels),
              })
          : VIDEO_METRICS_URL_API +
              JSON.stringify({
                url: url,
                trigger_id: triggerId,
              })
      )

      .then((response) => {
        if (response.data === "Total Channels Exceeds Limit") {
          setSnackBarMessage("Total Channels Exceeds Limit")
          setSnackBarSeverity("error")
          if(url){
            resetVideoInsights()
          }
         
        }
      })
      .catch((error) => {})
  }
  window.addEventListener("beforeunload", function (e) {
    e.preventDefault()
    e.returnValue = ""
    removeuserfromlivekitroom("Video Insights")
    stopFFMPEGLivekit()
  })

  //remove user from livekitroom-single device
  const removeuserfromlivekitroom = async (devicesData) => {
    let url_device = ""
    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: devicesData[0].toLowerCase(),
    })}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  const resetVideoInsights = () => {
    setChecked("Single Channel")
    setVideoMetricsData({})
    if(url){
      stopFFMPEGLivekit()
    }
    setUrl("")
    setQualityInfo(false)
    setCloseQualityInfo(false)
    setIsValidURL(false)
    removeuserfromlivekitroom("Video Insights")
   
  }

  return (
    <div className="VI-page">
      <div className={`VI-page-title ${theme === "dark" ? "dark" : "light"}`}>
        <h3>Video Insights</h3>
      </div>
      <div className="VI-page-form">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-2 radio-VI">
              <input
                type="radio"
                value="Multiple Channels"
                id="MultipleChannelsRadio"
                name="channelType"
                onChange={handleChange}
                className="Multichannels-checkbox"
                checked={isChecked === "Multiple Channels"}
              />
              <label
                for="MultipleChannelsRadio"
                className={`Multichannels-label ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Multiple Channels
              </label>
            </div>
            <div class="col-sm-2 radio-VI">
              <input
                onChange={handleChange}
                type="radio"
                id="SingleChannelRadio"
                name="channelType"
                value="Single Channel"
                className="Multichannels-checkbox"
                checked={isChecked === "Single Channel"}
              />
              <label
                for="SingleChannelRadio"
                className={`Multichannels-label ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Single Channel
              </label>
            </div>

            {isChecked === "Multiple Channels" && (
              <div class="col-sm-1">
                <input
                  type="number"
                  // className={`form-control ${
                  //   theme === "dark" ? "dark" : "light"
                  // }`}
                  class="form-control"
                  onChange={handleTotalChannels}
                  value={totalChannels}
                />
              </div>
            )}
            <div class="col-sm-3">
              <input
                type="text"
                className={`form-control ${
                  theme === "dark" ? "dark" : "light"
                }`}
                placeholder="URL"
                onChange={handleUrl}
                value={url}
              />
            </div>
            <div class="col-sm-1">
              <button
                type="submit"
                className={`VI-Btn-sbmt ${theme === "dark" ? "dark" : "light"}`}
                onClick={getVideoMetricsData}
              >
                Load
              </button>
            </div>
            <div class="col-sm-1">
              <button
                type="submit"
                className={`VI-Btn-sbmt ${theme === "dark" ? "dark" : "light"}`}
                onClick={resetVideoInsights}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="Video-Insight-streaming">
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-6">
              {url && qualityInfo === true ? (
                <div>
                  <Livekit tokenData2={tokenData} />
                </div>
              ) : (
                <div>
                  <video
                    src=""
                    controls
                    style={{ height: "600px !important" ,width:"100%"}}
                  />
                </div>
              )}
            </div>
            <div class="col-md-4">
              <div
                className={`network-video-block-insights ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <div
                  classname="transparent-block"
                  style={{
                    color: "white",
                  }}
                >
                  <div className="video-block-top">
                    <div>
                      <h3
                        className={`video-block-heading  ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Video Insights
                      </h3>
                    </div>
                    <div className="video-icons">
                      {/* {Object.keys(videoMetricsData).length > 0 && (
                        <img
                          style={{
                            border: "none",
                            height: "3vh",
                            width: "3vh",
                          }}
                          src={theme === "dark" ? Report : Report_light}
                          title="Generate Report"
                          onClick={() => generateReport()}
                          alt="Reports"
                        />
                      )} */}
                      <IconButton
                        aria-label="close"
                        color="inherit"
                        size="small"
                        className={`network-video-block-insights-close ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        <CloseIcon
                          onClick={deleteLiveDataFile}
                          fontSize="inherit"
                          style={{ color: "white" }}
                        />
                      </IconButton>
                    </div>
                  </div>
                  {url && Object.keys(videoMetricsData).length > 0 ? (
                    <>
                      <ReactSmartScroller
                        vertical
                        style={{
                          height: "200px",
                          overflowX: "hidden",
                          overflowY: "auto",
                        }}
                      >
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {qualityScore && qualityScore.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Quality Score
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    data: qualityScore,
                                    label: "Quality Score",
                                  },
                                ]}
                                series={[
                                  {
                                    data: qualityScore,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {VMAveragePSNRValue &&
                            VMAveragePSNRValue.length > 0 && (
                              <div>
                                <div className="custom-y-axis-label">
                                  Average PSNR Values
                                </div>
                                <LineChart
                                  xAxis={[
                                    {
                                      data: xAxisData,
                                      label: "Time in Seconds",
                                    },
                                  ]}
                                  yAxis={[
                                    {
                                      data: VMAveragePSNRValue,
                                      label: "Average PSNR",
                                    },
                                  ]}
                                  series={[
                                    {
                                      data: VMAveragePSNRValue,
                                    },
                                  ]}
                                  width={400}
                                  height={200}
                                />
                              </div>
                            )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {blockingRate && blockingRate.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Blocking Rate
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    label: "Blocking Rate",
                                  },
                                ]}
                                series={[
                                  {
                                    data: blockingRate,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                        <div
                          style={{
                            margin: "5px",
                            padding: "1px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {bandingRate && bandingRate.length > 0 && (
                            <div>
                              <div className="custom-y-axis-label">
                                Banding Rate
                              </div>
                              <LineChart
                                xAxis={[
                                  {
                                    data: xAxisData,
                                    label: "Time in Seconds",
                                  },
                                ]}
                                yAxis={[
                                  {
                                    label: "Banding Rate",
                                  },
                                ]}
                                series={[
                                  {
                                    data: bandingRate,
                                  },
                                ]}
                                width={400}
                                height={200}
                              />
                            </div>
                          )}
                        </div>
                      </ReactSmartScroller>

                      <table
                        className={`video-quilty-data-VI  ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        <div className="video-quilty-data-VI-A">
                          <tr>
                            <th>Channel</th>
                            <td>:</td>
                            <td>{videoMetricsData.channel_number}</td>
                          </tr>
                          <tr>
                            <th>Quality Score</th>
                            <td>:</td>
                            <td>{videoMetricsData.Quality_Score}</td>
                          </tr>
                          <tr>
                            <th>FPS</th>
                            <td>:</td>
                            <td>{videoMetricsData.FPS}</td>
                          </tr>
                          <tr>
                            <th>Dropped Frames</th>
                            <td>:</td>
                            <td>{videoMetricsData.Dropped_Frames}</td>
                          </tr>
                          {/*<tr>
                        //   <th>Total Frames</th>
                        //   <td>:</td>
                        //   <td>{accumulatedFrameCount}</td>
                        // </tr>*/}
                          <tr>
                            <th>Resolution</th>
                            <td>:</td>
                            <td>{videoMetricsData.Resolution}</td>
                          </tr>
                          <tr>
                            <th>Blur Detected</th>
                            <td>:</td>
                            <td>
                              {videoMetricsData.Blur_Detected === null
                                ? videoMetricsData.Blur_Detected.length +
                                  "Frames"
                                : "0 Frames"}
                            </td>
                          </tr>
                          <tr>
                            <th>Blur Score</th>
                            <td>:</td>
                            <td>{videoMetricsData.Blur_Score}</td>
                          </tr>
                          <tr>
                            <th>Macro Blocking</th>
                            <td>:</td>
                            <td>{videoMetricsData.macro_blocking}</td>
                          </tr>
                          <tr>
                            <th>Black Frames</th>
                            <td>:</td>
                            <td>{videoMetricsData.black_frames}</td>
                          </tr>
                        </div>
                        <div className="video-quilty-data-VI-B">
                          <tr>
                            <th>Average PSNR</th>
                            <td>:</td>
                            <td>
                              {Number(videoMetricsData.Avg_PSNR_Value).toFixed(
                                2
                              )}
                            </td>
                          </tr>
                          <tr>
                            <th>SSIM Score</th>
                            <td>:</td>
                            <td>{videoMetricsData.ssim_score}</td>
                          </tr>
                          <tr>
                            <th>Banding Rate</th>
                            <td>:</td>
                            <td>
                              {Number(videoMetricsData.Banding_Rate).toFixed(2)}
                            </td>
                          </tr>
                          <tr>
                            <th>Blocking Rate</th>
                            <td>:</td>
                            <td>
                              {Number(videoMetricsData.Blocking_Rate).toFixed(
                                2
                              )}
                            </td>
                          </tr>
                          <tr>
                            <th>Connection Speed</th>
                            <td>:</td>
                            <td>{videoMetricsData.connection_speed}</td>
                          </tr>
                          <tr>
                            <th>Data Used</th>
                            <td>:</td>
                            <td>{videoMetricsData.network_activity}</td>
                          </tr>
                          <tr>
                            <th>Timestamp</th>
                            <td>:</td>
                            <td>{videoMetricsData.time_stamp}</td>
                          </tr>
                        </div>
                      </table>
                    </>
                  ) : (
                    <div className="video-quality-nodata">
                      No Data Available
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <>
        <Snackbar
          open={snackBarMessage}
          autoHideDuration={10000}
          className={`crop-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClose={() => setSnackBarMessage("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            severity={snackBarSeverity}
            onClose={() => setSnackBarMessage("")}
          >
            {snackBarMessage}
          </Alert>
        </Snackbar>
      </>
    </div>
  )
}
