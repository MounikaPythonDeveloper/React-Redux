import React, { useState, useEffect } from "react";
import "./ABR.css";
import { ABR_TUNNELING } from "../../../services/api";
import { useTheme } from "../../ThemeToggle/ThemeContext";

export default function ABR() {
  const { theme } = useTheme();

  return (
    <div className="ABR-page">
      <div className={`ABR-page-title ${theme === "dark" ? "dark" : "light"}`}>
        <h3>Adaptive Bitrate Streaming</h3>
      </div>
      <div className="ABR-Data-Streaming">
        <div class="iframe-container-abr">
          <iframe src={ABR_TUNNELING} title="ABR tunneling"></iframe>
        </div>
      </div>
    </div>
  );
}
