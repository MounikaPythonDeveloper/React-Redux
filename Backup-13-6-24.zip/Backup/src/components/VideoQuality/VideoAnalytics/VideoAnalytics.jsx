import React, { useRef, useState, useEffect } from "react"
import { useTheme } from "../../ThemeToggle/ThemeContext"
import moment from "moment"
import "../AV.css"
import Checkbox from "@mui/material/Checkbox"
import FormControlLabel from "@mui/material/FormControlLabel"
import DirectionsRunIcon from "@mui/icons-material/DirectionsRun"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { LineChart } from "@mui/x-charts/LineChart"
import { ReactSmartScroller } from "react-smart-scroller"
import Button from "@mui/material/Button"
import { TextField } from "@mui/material"
import axios from "axios"
import {
  UPLOADVIDEO_API,
  CHECK_VIDEO_QUALITY_API,
  FETCH_DEVICE_NAMES_VIDEO_METRICS_API,
  CHECK_VIDEO_QUALITY_FILE_API,
  VIDEO_METRICS_URL_API,
  VIDEO_METRICS_URL_AKSHITHA_API,
  GENERATE_REPORT_VQ_API,
  FETCH_REPORT_API,
  GENERATE_REPORT_VQ_AKSHITHA_API,
} from "../../../services/api"
import CloseIcon from "@mui/icons-material/Close"
import IconButton from "@mui/material/IconButton"
import Report from "../../../../src/assets/images/Report.png"
import Report_light from "../../../../src/assets/images/icons8-reports-58.png"
import { Alert, Snackbar, Tooltip } from "@mui/material"
import generateUniqueId from "../../UniqueID/generateUniqueId"

export default function VideoAnalytics() {
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const [isValidURL, setIsValidURL] = useState(true)
  const [errorMessage, setErrorMessage] = useState("")
  const [closeQualityInfo, setCloseQualityInfo] = useState(true)
  const { theme } = useTheme()
  const [reportMessage, setReportMessage] = useState("")
  const [report, setReport] = useState("")
  const [url, setUrl] = useState("")
  const [currentValue, setCurrentValue] = useState(null)
  const [prevValue, setPrevValue] = useState([])
  const [accumulatedFrameCount, setAccumulatedFrameCount] = useState(0)
  const [qualityScore, setQualityScore] = useState([0, 0, 0, 0, 0])
  const [VMAveragePSNRValue, setVMAveragePSNRValue] = useState([0, 0, 0, 0, 0])
  const [xAxisData, setXAxisData] = useState([1, 2, 3, 4, 5])
  const [bandingRate, setBandingRate] = useState([0, 0, 0, 0, 0])
  const [blockingRate, setBlockingRate] = useState([0, 0, 0, 0, 0])
  const [blackFrames, setBlackFrames] = useState([0, 0, 0, 0, 0])
  const [dataVideoMetrics, setDataVideoMetrics] = useState([])
  const [viewButton, setViewButton] = useState(true)
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const fileInputRef = useRef(null)
  const [selectedFile, setSelectedFile] = useState(null)
  const [selectedVideo, setSelectedVideo] = useState()
  const [deviceDataVideo, setDeviceDataVideo] = useState([])
  const [selectedDevice, setSelectedDevice] = useState("")
  const [duration, setDuration] = useState("")
  const [videoMetricsData, setVideoMetricsData] = useState({})
  const [generateMessage, setGenerateMessage] = useState("")
  const [videoMessage, setVideoMessage] = useState("")
  const [urlMessage, setUrlMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const [ReportData, setReportData] = useState("")
  const currentDate = new Date()
  const [isButtonDisabled, setButtonDisabled] = useState(true)
  const [filename, setFilename] = useState("")
  const [isButtonDisabledVideo, setButtonDisabledVideo] = useState(true)
  const [triggerId, setTriggerID] = useState("")
  const [platformData, setplatformData] = useState(
    location.state?.data.platform ?? ""
  )
  const [buttonInput, setButtonInput] = useState(0)
  const [showAlert, setShowAlert] = useState(false)
  const [alertMessage, setAlertMessage] = useState("")
  const [alertSeverity, setAlertSeverity] = useState("success")
  const { isDarkTheme } = useTheme()
  const [uploading, setUploading] = useState(false)
  const [qualityInfo, setQualityInfo] = useState(false)
  const [inputType, setInputType] = useState("file")
  const isValidURLRegex = new RegExp(/^(ftp|http|https|rtp|udp):\/\/[^ "]+$/)
  const [ABRStatus, setABRStatus] = useState(false)
  const textfieldStyle = {
    background: "transparent",
    borderBottom: "2px solid #424242",
  }
  const handleInputChange = (event) => {
    setInputType(event.target.value)
  }
  const handleUrl = (e) => {
    let url_value = e.target.value
    setUrl(url_value)
    setIsValidURL(isValidURLRegex.test(e.target.value))
  }
  useEffect(() => {
    if (qualityInfo) {
      const videoMetricsData = setInterval(() => {
        getVideoMetrics() // <-- (3) invoke in interval callback
        console.log(triggerId, "Unique ID")
      }, 1000)
      // getVideoMetrics()
      return () => clearInterval(videoMetricsData)
    }
  }, [qualityInfo])
  const getVideoMetrics = async () => {
    setQualityInfo(true)
    await axios
      .get(
        userProfile.username === "akshitha"
          ? VIDEO_METRICS_URL_AKSHITHA_API +
              JSON.stringify({
                url: url,
                trigger_id: triggerId,
                // username: userProfile.username,
              })
          : VIDEO_METRICS_URL_API +
              JSON.stringify({
                url: url,
                trigger_id: triggerId,
                // username: userProfile.username,
              })
      )
      .then((response) => {
        let data = response.data
        console.log(data, "Data..")
        // Update the data array with the new JSON data point
        setDataVideoMetrics((prevData) => [...prevData.slice(-4), data])
        setVideoMetricsData(data)
        // console.log("acumulate initial", accumulatedFrameCount)
        setCurrentValue(data.Dropped_Frames)
        setPrevValue((prev) => [...prev, data.Dropped_Frames])
        setAccumulatedFrameCount((prevTotal) => prevTotal + data.Dropped_Frames)
        // console.log("acumulate final", accumulatedFrameCount)
        setVMAveragePSNRValue((prevData) =>
          [...prevData, data.Avg_PSNR_Value].slice(-5)
        )
        setQualityScore((prevData) =>
          [...prevData, data.Quality_Score].slice(-5)
        )
        setBandingRate((prevData) => [...prevData, data.Banding_Rate].slice(-5))
        console.log(bandingRate, "Banding Rate")
        setBlockingRate((prevData) =>
          [...prevData, data.Blocking_Rate].slice(-5)
        )
        console.log(blockingRate, "Blocking Rate")
        setBlackFrames((prevData) => [...prevData, data.black_frames].slice(-5))
        console.log(VMAveragePSNRValue, "Average PSNR Value")
        // Generate an array of timestamps for the X-axis representing every second
        const xAxis = Array.from(
          { length: VMAveragePSNRValue.length },
          (_, index) => index + 1
        )
        setXAxisData(xAxis)
        console.log(xAxis, "X axis")
      })
      .catch((error) => {
        console.log(error, " video error")
        // setErrorMessage("Backend Issue")
      })
    // .finally(setLoading(true))
  }

  useEffect(() => {
    if (inputType === "file") {
      const id = setInterval(() => {
        fetchVideoMetrics() // <--  invoke in interval callback
      }, 1000)
      fetchVideoMetrics()
      return () => clearInterval(id)
    }
  }, [])

  const fetchVideoMetrics = () => {
    axios
      .post(
        FETCH_DEVICE_NAMES_VIDEO_METRICS_API +
          JSON.stringify({
            username: userProfile.username,
            platform: platform_data,
            device_category: [
              "STB",
              "Smart TV",
              "OTT",
              "iOS",
              "Android",
              "Gaming",
              "iOS Tab",
              "Android Tab",
            ],
            current_date: moment().format("YYYY-MM-D"),
            current_time:
              currentDate.getHours() +
              ":" +
              currentDate.getMinutes() +
              ":" +
              currentDate.getSeconds(),
            video_metrics: "True",
          })
      )
      .then((res) => {
        console.log("video devicesdata", res.data)
        setDeviceDataVideo(res.data)
      })
      .catch((er) => console.log(er))
  }

  const handleDeviceName = (e) => {
    console.log(e.target.value, "trhfhjghjb")
    let devicename = e.target.value
    setSelectedDevice(devicename)
    console.log(selectedDevice, "selected device")
  }
  const handleDuration = (e) => {
    let duration_value = e.target.value
    setDuration(duration_value)
    setButtonDisabled(false)
  }

  const handleUploadVideo = async () => {
    const formData = new FormData()
    formData.append("file", selectedVideo)
    if (!selectedVideo) {
      setSnackBarMessage("Please Attach File")
      setSnackBarSeverity("error")
      return
    }
    try {
      setSnackBarMessage("Uploading...")
      setSnackBarSeverity("success")
      const response = await axios.post(UPLOADVIDEO_API, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      if (response.status === 200) {
        if (response.data.Message === "File Uploaded Successfully") {
          setSnackBarMessage("File Uploaded Successfully")
          setSnackBarSeverity("success")
          setFilename(response.data.file_name)
          setSelectedFile(null)
          setButtonDisabledVideo(false)
        }
      }
      if (response.data.errorMessages) {
        setSnackBarMessage(response.data.errorMessages)
        setSnackBarSeverity("error")
      }
    } catch (error) {
      setSnackBarMessage("Backend Issue")
      setSnackBarSeverity("error")
    }
  }
  const generateVideoQualityUpload = (event) => {
    axios
      .post(
        CHECK_VIDEO_QUALITY_FILE_API +
          JSON.stringify({
            video_name: filename,
            platform: platform_data,
            locked_by: userProfile.username,
          })
      )
      .then((res) => {
        setSnackBarMessage("Video Quality Assessment Started");
        // setSnackBarMessage("Video Quality Assessment is Started")
        setSnackBarSeverity("success")
        setButtonDisabledVideo(true)
      })
      .catch((er) => {
        setButtonDisabledVideo(true)
        setSnackBarMessage("Backend Issue")
        setSnackBarSeverity("error")
      })
      .finally(setSnackBarMessage("Please Wait.."))
  }
  const generateVideoQualityRecord = (event) => {
    event.preventDefault()
    if (duration > 60 || duration <= 0) {
      
      setSnackBarMessage("Duration should be between 0 and 60");
      setSnackBarSeverity("error")
    } else {
      if (selectedDevice.length > 0 && duration.length > 0) {
        axios
          .post(
            CHECK_VIDEO_QUALITY_API +
              JSON.stringify({
                locked_by: userProfile.username,
                device_name: selectedDevice,
                duration: duration,
                platform: platform_data,
              })
          )
          .then((res) => {
            // setSnackBarMessage("Video Quality Assessment is Started")
            setSnackBarMessage("Video Quality Assessment Started");
            setSnackBarSeverity("success")
            setDeviceDataVideo([])
            setDuration("")
            setButtonDisabled(true)
             setSelectedDevice([]);
          })
          .catch((er) => {
            setSelectedDevice([])
            setLoading(false)
            setDuration("")
            setButtonDisabled(true)
            setSnackBarMessage("Backend Issue")
            setSnackBarSeverity("error")
          })
          .finally(setSnackBarMessage("Please Wait..."))
      } else {
        setSnackBarMessage("Please Select Device ")
        setSnackBarSeverity("error")
      }
    }
  }
  const generateReportMSL = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "generate_report",
                url: url,
                device_name: "",
              })
      )
      .then((res) => {
        if (res.data === "True") {
          setSnackBarMessage("Generating The Report")
          setSnackBarSeverity("success")
        } else {
          setSnackBarMessage("Report Not Generated")
          setSnackBarSeverity("error")
        }
      })
      .catch((er) => {
        setSnackBarMessage("Backend Issue")
        setSnackBarSeverity("error")
      })
      .finally(setSnackBarMessage("Please wait.."))
  }
  const getVideoMetricsData = async () => {
    setQualityInfo(true)
    setTriggerID(generateUniqueId())
  }

  const handleFileSelect = (e) => {
    const file = e.target.files[0]
    setSelectedVideo(e.target.files[0])
    console.log(file, "FLies")
    if (file) {
      setSelectedFile(file.name)
    } else {
      setSelectedFile(null)
    }
  }

  const [videoCheckboxes, setVideoCheckboxes] = useState({
    all: false, // Initial state of "All" checkbox
    psnr: false,
    mse: false,
    msad: false,
    snr: false,
    rmse: false,
    ssim: false,
    pcc: false,
    pcc_org: false,
    mae: false,
    asceptratio: false,
    // Add more checkboxes as needed
  })
  const [audioCheckboxes, setAudioCheckboxes] = useState({
    all: false,
    RMS: false,
    AMPLITUDE: false,
    PSNR: false,
    MSE: false,
  })

  const handleVideoSelectall = () => {
    setVideoCheckboxes((prevCheckboxes) => {
      const updatedCheckboxes = { ...prevCheckboxes }
      for (const key in updatedCheckboxes) {
        updatedCheckboxes[key] = !updatedCheckboxes[key]
      }
      return updatedCheckboxes
    })
  }

  const handleAudioSelectAll = () => {
    setAudioCheckboxes((prevCheckboxes) => {
      const updatedCheckboxes = { ...prevCheckboxes }
      for (const key in updatedCheckboxes) {
        updatedCheckboxes[key] = !updatedCheckboxes[key]
      }
      return updatedCheckboxes
    })
  }

  const handleCheckboxChange = (checkbox, type) => {
    if (type === "video") {
      setVideoCheckboxes((prevCheckboxes) => ({
        ...prevCheckboxes,
        [checkbox]: !prevCheckboxes[checkbox],
      }))
    } else if (type === "audio") {
      setAudioCheckboxes((prevCheckboxes) => ({
        ...prevCheckboxes,
        [checkbox]: !prevCheckboxes[checkbox],
      }))
    }
  }

  const handleCloseAlert = () => {
    setShowAlert(false)
  }
  const navigate = useNavigate()
  const preventDragHandler = (e) => {
    e.preventDefault()
  }
  const deviceFilterBack = function () {
    navigate(-1)
  }
  const handleCloseQuality = () => {
    // setQualityInfo(false)
    setUrl("")
    setCloseQualityInfo(false)
    closeVideoQuality()
  }

  const generateReport = () => {
    setUrl("")
    generateReportMSL()
    setQualityInfo(false)
  }
  const closeVideoQuality = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: url,
                device_name: "",
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: url,
                device_name: "",
              })
      )
      .then((res) => {
        console.log("generateReport MSL", res.data === "True")
        if (res.data === "True") {
          setAlertMessage("Generating the Report")
          setLoading(false)
        } else {
          setLoading(false)
        }
      })
      .catch((er) => console.log(er))
      .finally(setLoading(true))
  }

  const getReset = () => {
    setUrl("")
    setReportData("")
  }

  useEffect(() => {
    console.log("Trigger ID Updated", triggerId)
  }, [triggerId])

  return (
    <div className="ABR-page">
      <div className={`VA-page-title ${theme === "dark" ? "dark" : "light"}`}>
        <h3>Video Analytics</h3>
      </div>

      <div className="ABR-Data-Streaming">
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-6">
              <div
                className={`sub-partition2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <div
                  className="sub-partition2-text"
                  style={{ marginleft: "15px" }}
                >
                  {" "}
                  Project Folder
                </div>

                <div className="sub-partition2-text-feild">
                  <TextField
                    id="standard-basic-username"
                    label=""
                    variant="standard"
                    autoComplete="off"
                    type=""
                    value={selectedFile || ""}
                    readOnly
                    InputProps={{ style: textfieldStyle }}
                  />
                </div>
                <div className="av2Button">
                  <Button
                    variant="contained"
                    color="primary"
                    style={{ backgroundColor: "#1eb6b6" }}
                    onClick={() => fileInputRef.current.click()}
                  >
                    Select File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    style={{ display: "none" }}
                    accept="MP4/mkv/webm/flv/vob/wmv/rm/rmvb/m4p/mp2/nsv/mov/gif"
                    onChange={handleFileSelect}
                  />
                </div>
              </div>
              <div
                className={`avUploadButton ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <span onClick={handleUploadVideo} style={{ cursor: "pointer" }}>
                  UPLOAD
                </span>
              </div>
              <div
                className={`partition3 ${theme === "dark" ? "dark" : "light"}`}
              >
                <div className="partition3.0">
                  <div
                    className={`partition3-text ${
                      theme === "dark" ? "drak" : "light"
                    }`}
                  >
                    Test Run
                  </div>
                </div>
                <div className="partition3-2">
                  <div className="partition3.1">
                    <DirectionsRunIcon style={{ fontSize: 30 }} />
                  </div>
                  <div className="partition3-2-text">
                    Begin Execution for Selected Video:
                  </div>
                  <div className="avButton">
                    <Button
                      variant="contained"
                      color="primary"
                      style={{ backgroundColor: "#1eb6b6" }}
                      disabled={isButtonDisabledVideo}
                      onClick={generateVideoQualityUpload}
                    >
                      Start
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <div
                style={{
                  display: "flex",
                  textAlign: "center",
                  alignItems: "center",
                }}
              >
                <div>
                  <form onSubmit={generateVideoQualityRecord}>
                    <div>
                      <div
                        className={`partition2-text ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AV Analysis Panel
                      </div>
                      <div>
                        <div
                          className={`AVSelect ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <FormControlLabel
                            className="text"
                            control={<Checkbox color="primary" />}
                            label="Video Analysis"
                            checked
                          />
                          <FormControlLabel
                            control={<Checkbox color="primary" />}
                            label="Audio Analysis"
                            disabled
                          />
                        </div>
                        <div className="VideoAttributes">
                          {/* <Form.Group> */}
                          <select
                            className={`VideoAttributesSelect ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                            onChange={handleDeviceName}
                          >
                            <option value="">Select Device</option>
                            {deviceDataVideo &&
                              deviceDataVideo.length > 0 &&
                              deviceDataVideo.map((item, index) => {
                                return (
                                  <option value={item} id={item}>
                                    {item}
                                  </option>
                                )
                              })}
                            {!deviceDataVideo ||
                              (deviceDataVideo.length === 0 && (
                                <option>No Device Available</option>
                              ))}
                          </select>
                          <input
                            type="number"
                            onChange={handleDuration}
                            value={duration}
                            className={`VideoAttributesInput ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                            placeholder="Enter Duration in Seconds"
                          ></input>
                        </div>
                      </div>
                      <div className="av1Button">
                        <Button
                          variant="contained"
                          color="primary"
                          style={
                            theme === "dark"
                              ? { backgroundColor: "#1eb6b6" }
                              : {
                                  background:
                                    "linear-gradient(to right, #034e88, #40a7f6)",
                                }
                          }
                          type="submit"
                          disabled={isButtonDisabled}
                        >
                          Record & Start
                        </Button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <>
        <Snackbar
          open={snackBarMessage}
          autoHideDuration={10000}
          className={`crop-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClose={() => setSnackBarMessage("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            severity={snackBarSeverity}
            onClose={() => setSnackBarMessage("")}
          >
            {snackBarMessage}
          </Alert>
        </Snackbar>
      </>
    </div>
  )
}
