import React from "react"

export default function generateUniqueId() {
  let id = ""
  const characters = "0123456789"
  const charactersLength = characters.length

  for (let i = 0; i < 6; i++) {
    id += characters.charAt(Math.floor(Math.random() * charactersLength))
  }

  return id
}
