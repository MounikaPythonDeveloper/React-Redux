
import React from "react"
import "./ErrorBoundary.css"
import oopsImage from "../../assets/images/oops.png"

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true }
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    // logErrorToMyService(error, errorInfo);
  }

  handleGoBack = () => {
    // Logic to go back to the previous action
    window.history.back()
  }

  render() {
    if (this.state.hasError) {
      // Fallback UI when an error occurs
      return (
    <div className="ErrorBoundary">
    <div >
    <img src={oopsImage} alt="OOPs"  className="oops-image"/>
    </div>
          <div>
            <h3>Something Went Wrong.</h3>
          </div>
          <div className="BackAction">
            <button onClick={this.handleGoBack}>Go Back</button>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

export default ErrorBoundary
