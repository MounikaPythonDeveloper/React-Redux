/**
 * Component: Context
 * File: Navbar.jsx
 * Description: This file contains the implementation of navigation bars with respect to their 
                platforms
*  File Used:App.js
*  Author: R.Harine Parvathi,Mounika,Jagadeesh,Yuvaraj
* */
import React, { useState, useEffect, useContext, NavLink } from "react";
import { useTheme } from "../ThemeToggle/ThemeContext";
import "./Navbar.css";
import PopupComponent from "../../components/ReusableComponents/PopupComponent/PopupComponent";
import { Link, useLocation, useNavigate } from "react-router-dom";
//importing images
import logout from "../../assets/images/logout_new.svg";
import userlogo from "../../assets/images/userlogo.svg";
import viewprofile from "../../assets/images/ViewProfile.svg";
import EvQuallogo from "../../assets/images/EvQuallogo.svg";
import lttsLogo from "../../assets/images/ltts.png";
import managedevices from "../../assets/images/managedevices.svg";
//importing profile picture
import ImageContext from "../../context/ImageContext";
import axios from "axios";
//importing apis for logout and profile picture
import { LOGOUT_API, FETCH_PROFILE_API } from "../../services/api";
import ThemeToggle from "../ThemeToggle/ThemeToggle";

const NavBar = ({ platform }) => {
  console.log("Platform selected navbar", platform);
  const showExtraPages = platform !== null;
  const [open, setOpen] = useState(false);
  //variable declaration for profile picture
  const [profilePic, setProfilePic] = useState(null);
  const { updateImageData, ImageData } = useContext(ImageContext);
  //function for fetching profile picture
  const fetchProfilePicture = () => {
    fetch(`${FETCH_PROFILE_API}${userProfile.username}.png`)
      .then((response) => {
        console.log("Image", response.url);
        updateImageData(response.url);
      })
      .catch((error) => {
        console.log("Failed to fetch image:", error); // Handle error
      });
  };

  window.addEventListener("beforeunload", function (e) {
    e.preventDefault();
    return handleLogoutSession();
  });

  useEffect(() => {
    fetchProfilePicture();
  }, []);
  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  useEffect(() => {
    if (ImageData) {
      console.log(ImageData.newImageData, "ImageDataImageData");
      setProfilePic(ImageData.newImageData);
    }
  }, [ImageData]);

  const location = useLocation();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  //declare path variables for platform filtering
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnChangePasswordPage =
    location.pathname === "/platform/viewprofile/changepassword";
  const isOnAdminMangeUserPage =
    location.pathname === "/platform/adminHomePage/addUser";
  const isOnAdminManageDevicePage =
    location.pathname === "/platform/adminHomePage/addDevice";
  const isOnEditUserProfilePage =
    location.pathname === "/platform/viewprofile/edituserprofile";
  const isOnActivateLicensePage =
    location.pathname === "/platform/viewprofile/activateLicense";
  const isOnBuyLicensePage =
    location.pathname === "/platform/viewprofile/buyLicense";
  const isOnAboutLicensePage =
    location.pathname === "/platform/viewprofile/aboutLicense";
  const isOnEditUserPage =
    location.pathname === "/platform/adminHomePage/editUser";
  const isOnAdminEditDevicePage =
    location.pathname === "/platform/adminHomePage/editDevice/:id";
  const isOnAdminEditDevicePage1 =
    location.pathname ===
    "/platform/" + platform_data + "adminHomePage/editDevice/:id";
  const isOnLicensePage = location.pathname === "/aboutlicense";
  const isOnSupportLicensePage =
    location.pathname === "/platform/viewprofile/supportLicense";
  const navigate = useNavigate();
  //json input format of logout_data
  const logout_data = {
    username: userProfile.username,
    logout_time: new Date().toISOString(),
    session_id: userProfile.session_id,
    is_login: false,
  };
  //function for logout
  const handleLogout = (e) => {
    axios
      .post(LOGOUT_API + JSON.stringify(logout_data))
      .then((response) => {
        navigate("/Login");
        sessionStorage.removeItem("userData");
      })
      .catch((err) => {
        console.log(err, "Logout API Error");
      });
  };
  //function for logout session
  const handleLogoutSession = (e) => {
    axios
      .post(LOGOUT_API + JSON.stringify(logout_data))
      .then((response) => {
        console.log("logout");
      })
      .catch((err) => {
        console.log(err, "Logout API Error");
      });
  };

  //function for signout
  const sign_Out_handle = function () {
    handleOpen();
  };
  const handleOpen = () => setOpen(true);
  //popup
  const handleClosePopup = function () {
    setOpen(false);
  };
  //platform data for filtering platform

  const handleSource = () => {
    if (profilePic) {
      return `${profilePic}&cache=${Date.now()}`;
    } else {
      return userlogo;
    }
  };
  // const { savedTheme } = useTheme()
  // const isDarkTheme = savedTheme
  const { theme } = useTheme();
  console.log("navbar theme:", theme, theme === "dark" ? "dark" : "light");
  // console.log("theme", isDarkTheme, String(isDarkTheme));

  return (
    <React.Fragment>
      <PopupComponent
        open={open}
        text="Are you sure you want to sign out ?"
        handleClose={handleClosePopup}
        functionHandle={handleLogout}
      />
      <div className={`main_div ${theme === "dark" ? "dark" : "light"}`}>
        <nav
          class={`navbar navbar-expand-lg navbar-dark ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <div class={`container-fluid ${theme === "dark" ? "dark" : "light"}`}>
            {theme === "dark" ? (
              <Link
                to="/platform"
                class={`navlink-dark ${theme === "dark" ? "dark" : "light"}`}
              >
                <img src={EvQuallogo} style={{ paddingTop: "5px" }} />
                {/* <img src={lttsLogo} style={{ paddingTop: "5px" }} /> */}
              </Link>
            ) : (
              <Link
                to="/platform"
                class={`navlink-dark ${theme === "dark" ? "dark" : "light"}`}
              >
                <img src={EvQuallogo} style={{ paddingTop: "5px" }} />
              </Link>
            )}

            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarText"
              aria-controls="navbarText"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div
              class="collapse navbar-collapse"
              id="navbarText"
              style={{ justifyContent: "flex-end" }}
            >
              {/* 191-356 without selecting platform */}
              {isOnPlatformPage ||
              isOnAboutPage ||
              isOnViewProfile ||
              isOnChangePasswordPage ||
              isOnAdminMangeUserPage ||
              isOnAdminManageDevicePage ||
              isOnEditUserProfilePage ||
              isOnActivateLicensePage ||
              isOnBuyLicensePage ||
              isOnAboutLicensePage ||
              isOnEditUserPage ||
              isOnAdminEditDevicePage ||
              isOnSupportLicensePage ||
              isOnAdminPage ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to="/about"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        About
                      </Link>
                    </li>
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",

                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to="/platform/viewprofile"
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  src={viewprofile}
                                  onDragStart={preventDragHandler}
                                  // style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          <Link
                            aria-current="page"
                            to="/platform/adminHomePage"
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      src={managedevices}
                                      onDragStart={preventDragHandler}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : isOnLicensePage ? null : platform_data === "Telecom" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Home
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>

                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  src={viewprofile}
                                  onDragStart={preventDragHandler}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      src={managedevices}
                                      onDragStart={preventDragHandler}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : platform_data === "5G" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        5G
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to="/about"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        About
                      </Link>
                    </li>

                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  src={viewprofile}
                                  onDragStart={preventDragHandler}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      src={managedevices}
                                      onDragStart={preventDragHandler}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : platform_data === "Desktop" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          location.pathname === "/home"
                            ? "nav-active"
                            : "nav-active "
                        }`}
                      >
                        Desktop
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  src={viewprofile}
                                  onDragStart={preventDragHandler}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      src={managedevices}
                                      onDragStart={preventDragHandler}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : platform_data === "HMI" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item   ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Home
                      </Link>
                    </li>
                    <li
                      class={`nav-item    ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item    ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  src={viewprofile}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      onDragStart={preventDragHandler}
                                      src={managedevices}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : platform_data === "Healthcare" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Home
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  onDragStart={preventDragHandler}
                                  src={viewprofile}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      onDragStart={preventDragHandler}
                                      src={managedevices}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : // Transportation

              platform_data === "Transportation" ? (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Home
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/" + platform_data + "/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              onDragStart={preventDragHandler}
                              src={handleSource()}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  onDragStart={preventDragHandler}
                                  src={viewprofile}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/" + platform_data + "/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      onDragStart={preventDragHandler}
                                      src={managedevices}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              ) : (
                <div className="navigation_bar_components">
                  <ul
                    class="navbar-nav"
                    style={{
                      margin: "0 auto",
                      marginBottom: "-4px",
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        to="/platform"
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Home
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/M&E/automation"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Automation
                      </Link>
                    </li>

                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/M&E/dashboard"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li
                      class={`nav-item ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <Link
                        aria-current="page"
                        to={"/platform/M&E/aiTest"}
                        className={`nav-link ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        AI Test
                      </Link>
                    </li>
                    {/* <li class="nav-item">
                      <Link
                        aria-current="page"
                        to={"/platform/M&E/VideoQuality"}
                        className={`nav-link ${theme==="dark" ? "dark" : "light"}`}
                      >
                        Quality Metrics
                      </Link>
                    </li> */}
                    {userProfile.profileObj ? (
                      ""
                    ) : (
                      <div class="dropdown UserProfile">
                        <button
                          class="btn dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {userProfile.user_privilege === "Admin" ? (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          ) : (
                            <img
                              src={handleSource()}
                              onDragStart={preventDragHandler}
                              style={{
                                width: "32.56px",
                                height: "38px",
                                borderRadius: "50%",
                                objectFit: "cover",
                              }}
                            ></img>
                          )}
                        </button>

                        <div class="dropdown-menu dropdown-menu-right">
                          <div className="user_details">
                            <div>
                              <img
                                src={handleSource()}
                                onDragStart={preventDragHandler}
                                style={{
                                  width: "47.3534049987793px",
                                  height: "56.91743087768555px",
                                  borderRadius: "50%",
                                  objectFit: "cover",
                                }}
                              ></img>
                            </div>
                            <div className="userprofile">
                              <span className="userprofileName">
                                {userProfile.username}
                              </span>
                              <span className="userprofileEmail">
                                {userProfile.email_id}
                              </span>
                            </div>
                          </div>
                          <div>
                            <span className="user_role">
                              {userProfile.user_privilege}
                            </span>
                          </div>
                          <Link
                            aria-current="page"
                            to={"/platform/M&E/viewprofile"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <button
                              className={`view_profile ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              <span>
                                <img
                                  onDragStart={preventDragHandler}
                                  src={viewprofile}
                                  style={{ paddingRight: "10px" }}
                                />
                              </span>{" "}
                              <div>View Profile</div>
                            </button>
                          </Link>
                          <ThemeToggle />
                          {/* </div> */}
                          <Link
                            aria-current="page"
                            to={"/platform/M&E/adminHomePage"}
                            className={`nav-link ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <div className="admin_privileges">
                              {userProfile.user_privilege === "Admin" && (
                                <button
                                  className={`manage_devices ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                >
                                  <span>
                                    <img
                                      onDragStart={preventDragHandler}
                                      src={managedevices}
                                      style={{ paddingRight: "10px" }}
                                    />
                                  </span>
                                  <div>Admin Functionalities</div>
                                </button>
                              )}
                            </div>
                          </Link>
                          <div className="profile_line"></div>
                          <div
                            className={`sign_out ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            <span>
                              <img
                                onDragStart={preventDragHandler}
                                src={logout}
                                class="rounded float-start"
                                alt="logout"
                                style={{
                                  width: "35px",
                                  height: "25px",
                                  paddingTop: "10px",
                                  paddingLeft: "10px",
                                }}
                              />
                            </span>
                            <span
                              style={{ display: "flex", paddingTop: "3px" }}
                            >
                              <Link
                                aria-current="page"
                                className="up-logout"
                                onClick={sign_Out_handle}
                              >
                                Sign out
                              </Link>
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </nav>
      </div>
      <div className="line"></div>
    </React.Fragment>
  );
};
export default NavBar;
