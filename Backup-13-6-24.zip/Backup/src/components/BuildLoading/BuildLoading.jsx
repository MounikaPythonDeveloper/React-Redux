import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import "./BuildLoading.css";
import close from "../../assets/images/Close.png";
import { useTheme } from "../ThemeToggle/ThemeContext";
import { Form } from "react-bootstrap";

export default function KeepMountedModal(props) {
  const [closePopup, setClosePopup] = useState();
  const [activeType, setActiveType] = useState("");
  const [activeSource, setActiveSource] = useState("");
  const [user, setUser] = useState({
    type: "",
    appName: "",
    source: "",
    sourceLink: "",
    deviceCategory: "",
  });
  const [error, setErrors] = useState({});
  const [isSubmit, setIssubmit] = useState(false);

  useEffect(() => {
    setUser({
      ...user,
      deviceCategory: props.devicesData[0].device_category,
    });
    console.log(props.devicesData[0].device_category, "BUILD_devicesData");
    // props.devicesData[0].device_category === "iOS"
  }, []);

  const mainClose = function () {
    setClosePopup(props.handleClose);
    setActiveType("");
    setActiveSource("");
    setUser({
      type: "",
      appName: "",
      source: "",
      sourceLink: "",
    });
    setErrors({});
  };

  const applicationHandler = function () {
    userApp();
    setActiveType("Application");
    setActiveSource("");
  };
  const firmWareHandler = function () {
    userFirmWare();
    setActiveType("FirmWare");

    setActiveSource("");
  };
  const playStoreHandler = function () {
    setActiveSource("Playstore");
    userPlaystore();
  };
  const otherHandler = function () {
    setActiveSource("Other");
    userOther();
  };
  const userHandler = function (e) {
    console.log(e.target.value);
    setUser({
      ...user,
      [e.target.name]: e.target.value,
    });
  };
  const userApp = function () {
    setUser({
      ...user,
      type: "App",
    });
  };
  const userFirmWare = function () {
    setUser({
      ...user,
      type: "Firmware",
    });
  };
  const userPlaystore = function () {
    setUser({
      ...user,
      source: "playstore",
    });
  };
  const userOther = function () {
    setUser({
      ...user,
      source: "other",
    });
  };

  const submitHandler = function (e) {
    const regExp = /\.(apk)$/i;

    e.preventDefault();
    // props.buildApi(user)
    // mainClose()

    setErrors(validate(user));

    setIssubmit(true);
    // props.buildApi(user);
    // mainClose();

    if (user.type === "App") {
      if (user.appName.length !== 0) {
        if (user.source === "other") {
          if (user.sourceLink.length !== 0) {
            props.buildApi(user);
            mainClose();
          } else {
          }
        } else if (user.source === "playstore") {
          props.buildApi(user);
          mainClose();
        }
      } else {
      }
    } else if (user.type === "Firmware") {
      if (props.devicesData[0].device_category === "iOS") {
        props.buildApi(user);
        mainClose();
      } else if (user.sourceLink.length !== 0) {
        props.buildApi(user);
        mainClose();
      } else {
      }
    }
  };
  const validate = (val) => {
    const errors = {};
    // const regExp=/https:\/\/\s+/g;
    // const regExp = /\.(apk)$/i;
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    // if (!val.sourceLink) {
    //   errors.sourceLink = "URL is Required";
    // } else if (!regExp.test(val.sourceLink)) {
    //   errors.sourceLink = "This is not a valid URL";
    // }
    if (!val.sourceLink) {
      errors.sourceLink = "Source Link is Required";
    }
    if (!val.appName) {
      errors.appName = "Username is Required";
    }
    if (!val.type) {
      errors.type = "Type is Required";
    }
    if (!val.source) {
      errors.source = "Source is Required";
    }
    return errors;
  };
  useEffect(() => {
    console.log("erorrrr", error);
    if (Object.keys(error).length === 0 && isSubmit) {
      console.log("kgggggggggggg", user);
    }
  }, [error]);
  const { theme } = useTheme();
  if (theme === "dark") {
    document.documentElement.classList.remove("light");
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
    document.documentElement.classList.add("light");
  }
  const getIOSVersion = (e) => {
    console.log(e, "VERSION");
  };
  return (
    <div>
      <Modal
        keepMounted
        open={props.open}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        {/* className={`filter-devices-icon ${theme === "dark" ? "dark" : "light"}`} */}
        <Box
          className={`buildPopupMaincontainer ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <div className="buildCloseIcon">
            <img
              src={close}
              alt="Close"
              className={`closeIcon ${theme === "dark" ? "dark" : "light"}`}
              onClick={mainClose}
            />
          </div>
          <form className="buildPopupcontainer" onSubmit={submitHandler}>
            <div className="buildPopupcontainerFirst">
              <div className="buildType">
                <div
                  className={`buildTypeFirst ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Type :
                </div>
                <div className="buildTypeSecond">
                  <div
                    className={`buildTypeHandler ${
                      activeType === "Application" ? "active" : ""
                    } ${theme === "dark" ? "dark" : "light"}`}
                    onClick={applicationHandler}
                  >
                    Application
                  </div>
                  <div
                    className={`buildTypeHandler ${
                      activeType === "FirmWare" ? "active" : ""
                    } ${theme === "dark" ? "dark" : "light"}`}
                    onClick={firmWareHandler}
                  >
                    FirmWare
                  </div>
                  <div className="typeErrorMsg">{error.type}</div>
                </div>
              </div>

              {activeType === "FirmWare" ? (
                // <div className="buildVersion">
                //   <div
                //     className={`buildVersionFirst ${
                //       theme === "dark" ? "dark" : "light"
                //     }`}
                //   >
                //     Version :
                //   </div>
                //   <div className="buildVersionSecond">
                //     <Form.Group>
                //       <Form.Select
                //         className={`deviceFilterForm ${
                //           theme === "dark" ? "dark" : "light"
                //         }`}
                //         onChange={(e) => getIOSVersion(e.target.value)}
                //       >
                //         <option value="Select Versions">Select Versions</option>
                //         <option>17.4.1</option>
                //         <option>17.5</option>
                //         <option>17.5.1</option>
                //         <option>17.5.2</option>
                //       </Form.Select>
                //     </Form.Group>
                //   </div>
                // </div>
                ""
              ) : (
                <div className="buildAppName">
                  <div
                    className={`buildAppNameFirst ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    App Name :
                  </div>
                  <div className="buildAppNameSecond">
                    <input
                      name="appName"
                      type="text"
                      placeholder="Application Name"
                      value={user.appName}
                      onChange={userHandler}
                      className={`buildInput ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      autocomplete="off"
                    />
                    <p className="nameErrorMsg">{error.appName}</p>
                  </div>
                </div>
              )}

              {activeType === "FirmWare" ? (
                ""
              ) : (
                <div className="buildSource">
                  <div
                    className={`buildSourceFirst ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Source :
                  </div>
                  <div className="buildSourceSecond">
                    <>
                      <div
                        className={`buildSourceHandler ${
                          activeSource === "Playstore" ? "active" : ""
                        } ${theme === "dark" ? "dark" : "light"}`}
                        onClick={playStoreHandler}
                      >
                        Play Store
                      </div>
                      <div
                        className={`buildSourceHandler ${
                          activeSource === "Other" ? "active" : ""
                        } ${theme === "dark" ? "dark" : "light"}`}
                        onClick={otherHandler}
                      >
                        Other
                      </div>
                      <p className="sourceErrorMsg">{error.source}</p>
                    </>
                  </div>
                </div>
              )}

              {activeSource === "Playstore" ? (
                ""
              ) : activeType === "FirmWare" &&
                props.devicesData[0].device_category === "iOS" ? (
                ""
              ) : (
                <div className="buildLink">
                  <div
                    className={`buildLinkFirst ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Source Link :
                  </div>
                  <div className="buildLinkSecond">
                    <input
                      name="sourceLink"
                      type="text"
                      placeholder="Source Link...."
                      className={`buildLinkInput ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                      value={user.sourceLink}
                      onChange={userHandler}
                    />

                    <p className="nameErrorMsg">{error.sourceLink}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="buildPopupcontainerSecond">
              {props.devicesData[0].device_category === "iOS" &&
              activeType === "FirmWare" ? (
                <div className="buildActions">
                  <button
                    className={`buildActionsHandler ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Update Version
                  </button>
                </div>
              ) : (
                <div className="buildActions">
                  <button
                    className={`buildActionsHandler ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Submit
                  </button>
                </div>
              )}
            </div>
          </form>

          <div className="buildPopupcontainerThird">
            <div className="buildActions">
              <button
                className={`cancelAction ${
                  theme === "dark" ? "dark" : "light"
                }`}
                onClick={mainClose}
              >
                Cancel
              </button>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
}
