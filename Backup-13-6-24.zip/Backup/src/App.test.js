import { render, screen } from "@testing-library/react"
import { BrowserRouter as Router } from "react-router-dom"
import userEvent from "@testing-library/user-event"
// import App from "./App"
import DevicesFilter from "./modules/Devices/DevicesFilter/DevicesFilter"
import { shallow } from "enzyme"
import SignUp from "./modules/SignUp/SignUp.jsx"

describe("Device Locking", () => {
  it("Test the devices header", () => {
    render(
      <Router>
        <DevicesFilter />
      </Router>
    )
    const linkElement = screen.getByText("Devices")

    expect(linkElement).toBeInTheDocument()
  })
})

// describe("Device Locking", () => {
//   let wrapper

//   beforeEach(() => {
//     wrapper = shallow(
//       <Router>
//         <DevicesFilter />
//       </Router>
//     )
//   })
//   it("Test the devices header", () => {
//     const linkElement = screen.getByText("Devices")

//     expect(linkElement).toBeInTheDocument()
//   })
// })

describe("Register Component", () => {
  it("renders learn react link", () => {
    render(
      <Router>
        {" "}
        <SignUp />
      </Router>
    )

    const linkElement = screen.getByText(/User Sign Up/i)

    expect(linkElement).toBeInTheDocument()
  })

  it("Check links", () => {
    render(
      <Router>
        {" "}
        <SignUp />
      </Router>
    )

    const linkElement = screen.getByText(/Create an account/i)

    expect(linkElement).toBeInTheDocument()
  })

  let wrapper

  beforeEach(() => {
    wrapper = shallow(
      <Router>
        <SignUp />
      </Router>
    )
  })

  it("renders the RegistrationForm component", () => {
    expect(wrapper).toMatchSnapshot()
  })

  // it("renders the registration element", () => {
  //   const myDiv = wrapper.find(".Registration")

  //   expect(myDiv.exists()).toBeTruthy()
  // })
})

//shilpa explained
// describe("App", () => {
//   const localStorageMock = (() => {
//     const store = { Name: "User" };
//     return {
//       getItem(key) {
//         return store[key];
//       },
//       setItem(key, value) {
//         store[key] = value;
//       },

//       removeItem(key) {
//         delete store[key];
//       },
//     };
//   })();

//   Object.defineProperty(window, "localStorage", {
//     value: localStorageMock,
//   });
//   it("renders App component", () => {
//     render(<App />);
//     const button = screen.getByRole("button");
//     expect(button).toBeInTheDocument;
//   });

//   it("check click funtionality of button", () => {
//     render(<App />);
//     const button = screen.getByRole("button");
//     fireEvent.click(button);
//     expect(localStorage.getItem("Name")).toBe("User");
//   });

//   it("snapshot test", () => {
//     const { container } = render(<App />);
// expect(container).toMatchSnapshot();
//   })
// });
