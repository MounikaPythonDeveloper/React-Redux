import React, { createContext, useState, useContext } from 'react';
export const DeviceContext = createContext();
 
export const DeviceProvider = ({ children }) => {
  const [selectedDevices, setSelectedDevices] = useState([]);
 
  const updateSelectedDevices = (newSelectedDevices) => {
    setSelectedDevices(newSelectedDevices);
  };
 
  return (
    <DeviceContext.Provider value={{ selectedDevices, updateSelectedDevices }}>
      {children}
    </DeviceContext.Provider>
  );
};
 
export const useDeviceContext = () => useContext(DeviceContext);