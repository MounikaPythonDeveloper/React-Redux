/**
 * Component: Context
 * File: ImageState.jsx
 * Description: This file contains the implementation of the context React component.
                ImageState will make the context value accessible to all the child components.
                Wrapping all the components into ImageState
 *File Used:App.js
 * Author: B.Jagadeesh
 * */
import React, { useState } from "react"
import ImageContext from "./ImageContext"

const ImageState = ({ children }) => {
  // Define state or data you want to share
  const [ImageData, setImageData] = useState(null)

  // Define a function to update the state
  const updateImageData = (newImageData) => {
    console.log("Data is Setting in state", newImageData)
    const updatedImage = { ...ImageData, newImageData }
    setImageData(updatedImage)
  }

  const contextValue = {
    ImageData,
    updateImageData,
  }

  // Provide the context value and functions through the provider
  return (
    <ImageContext.Provider value={contextValue}>
      {children}
    </ImageContext.Provider>
  )
}

export default ImageState
