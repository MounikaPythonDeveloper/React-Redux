/**
 * Component: Context
 * File: ImageContext.jsx
 * Description: This file contains the implementation of the context React component.
                To share data across components without having to pass props through each intermediate component.
 *File Used:ImageState.jsx,ViewProfile.jsx,Navbar.jsx
 * Author: B.Jagadeesh
 * */
import React from "react"

//Define Context
const ImageContext = React.createContext({
  /* Context created to provide a default(null) value. 
This default(null) value will be used if no matching Provider value is found  */
  ImageData: null,
  updateImageData: () => {},
})

export default ImageContext
