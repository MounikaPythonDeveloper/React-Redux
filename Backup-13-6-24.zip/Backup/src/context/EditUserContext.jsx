import React, { createContext, useState, useContext } from "react"
export const EditUserContext = createContext()

export const EditUserStatus = ({ children }) => {
  const [userUpdated, setUserUpdated] = useState(false)

  const updateUserStatus = (newUserUpdated) => {
    setUserUpdated(newUserUpdated)
  }

  return (
    <EditUserContext.Provider value={{ userUpdated, updateUserStatus }}>
      {children}
    </EditUserContext.Provider>
  )
}

export const useEditUserContext = () => useContext(EditUserContext)
