/** * Component: SampleComponent
 * File: SignUp.jsx
 * Description: * This file contents the implementation of user reservation calendar.
 * Wrapping all the components into ReservationCalendar
 * Used to view, reserve and delete the reservation for devices
 * Author: Yuvaraj Dakhane
 * **/
import { Snackbar } from "@mui/material";
import { useEffect, useState } from "react";
import { useTheme } from "../../components/ThemeToggle/ThemeContext.jsx";
import React from "react";
import "../../components/ReservationDetails/ReservationDetails.css";
import Modal from "../../components/ReusableComponents/Modal/Modal";
import "./BigCalendar.css";
import "../../components/Calendar/Calendar.css";
import { DateTimePicker } from "@progress/kendo-react-dateinputs";
import { FETCH_RESERVATION_DETAILS_CALENDAR_API } from "../../services/api";
import { DELETE_MANAGE_RESERVATION_API } from "../../services/api";
import axios from "axios";
import ReservationDetails from "../../components/ReservationDetails/ReservationDetails";
import Modalcancel from "../../components/ModalCancel/Model";
import close from "../../assets/images/Close.png";
import { Button } from "@material-ui/core";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import { Select, Alert, FormHelperText } from "@mui/material";
import { DEVICE_RESERVATION_API } from "../../services/api";
import { useLocation, useNavigate } from "react-router-dom";
import { useMediaQuery } from "@material-ui/core";
import Axios from "axios";
import { Link } from "react-router-dom";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import { Padding } from "@mui/icons-material";

//All the components are wrap
const ReservationCalendar = () => {
  //Defined the states and var
  const { theme } = useTheme();
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState();
  const [alertMessage, setAlertMessage] = useState();
  const [alertState, setAlertState] = useState(false);
  const [modal, setModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [category, setCategory] = React.useState("");
  const [getdatecalendar, setGetdatacalendar] = useState(
    new Date("2023-05-25")
  );
  const [dates, setDates] = useState(null);
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [day, setDay] = useState({
    day: new Date().getDay(),
    date: new Date().getDate(),
  });
  const [events, setEvents] = useState("");
  const [reservefalse, setReservefalse] = useState(false);
  const [datareservelist, setDatareservelist] = useState([]);
  const [dateforevents, setDateforevents] = useState();
  const [itemDetails, setItemDetails] = useState();
  const [deviceNameList, setDeviceNameList] = useState();
  const allEvents = [];
  const location = useLocation();
  const [devicesData, setDeviceData] = useState(
    location.state ? location.state.DeviceData : ""
  );
  const [pastEvent, setPastevent] = useState(null);
  const devicedataname = JSON.parse(
    sessionStorage.getItem("deviceinformationinfo")
  );
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const DeviceViewInfo = location.state?.data;
  const minDate = new Date();
  const navigate = useNavigate();
  const oneDate = new Date();

  //Styles for Moble view
  const isMobile = useMediaQuery("(max-width: 480px)");
  const alertStyle = {
    fontSize: isMobile ? "15px" : "24px",
    color: "#fff",
  };

  // useEffect will map the devicesData into setDeviceNameList whenever DOM will update
  useEffect(() => {
    devicesData.map((item) => {
      setDeviceNameList(item.device_name);
    });
  }, []);

  //Defined weeks
  const week = ["S", "M", "T", "W", "T", "F", "S"];

  //Defined months
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  //Defined the time from 00:00:00 to 23:30:00
  const times = [
    "00:00:00",
    "00:30:00",
    "01:00:00",
    "01:30:00",
    "02:00:00",
    "02:30:00",
    "03:00:00",
    "03:30:00",
    "04:00:00",
    "04:30:00",
    "05:00:00",
    "05:30:00",
    "06:00:00",
    "06:30:00",
    "07:00:00",
    "07:30:00",
    "08:00:00",
    "08:30:00",
    "09:00:00",
    "09:30:00",
    "10:00:00",
    "10:30:00",
    "11:00:00",
    "11:30:00",
    "12:00:00",
    "12:30:00",
    "13:00:00",
    "13:30:00",
    "14:00:00",
    "14:30:00",
    "15:00:00",
    "15:30:00",
    "16:00:00",
    "16:30:00",
    "17:00:00",
    "17:30:00",
    "18:00:00",
    "18:30:00",
    "19:00:00",
    "19:30:00",
    "20:00:00",
    "20:30:00",
    "21:00:00",
    "21:30:00",
    "22:00:00",
    "22:30:00",
    "23:00:00",
    "23:30:00",
  ];

  //Define the function to get startDate
  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  //Define the function to get enDate
  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  //Define a function to set the model state
  const toggleModal = () => {
    setModal(!modal);
  };

  if (modal) {
    document.body.classList.add("active-modal");
  } else {
    document.body.classList.remove("active-modal");
  }

  const handleCancel = () => {
    toggleModal();
  };

  //Define the function to get category
  const handleChange = (event) => {
    setCategory(event.target.value);
  };

  //Define the function to return the formated Time
  const formatTime = (date) => {
    if (endDate?.length === 0) {
      // alert("hi");
    } else {
      const hours = date?.getHours();
      const minutes = date?.getMinutes();

      // const hours = 25;
      // const minutes = 40;
      // console.log(date.getHours(), "date?.getHours()");
      // const hours = date?.getHours();
      // const minutes = date?.getMinutes();
      return `${hours}:${minutes}`;
    }
  };

  //Define the function to return the formated Date
  const formatDate = (date) => {
    if (endDate?.length === 0) {
      // alert("HELLO");
    } else {
      // const year = 10;
      // const month = 20;
      // const day = 3;
      const year = date?.getFullYear();
      const month = String(date?.getMonth() + 1).padStart(2, "0");
      const day = String(date?.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
  };

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  //Define the function to call DEVICE_RESERVATION_API and set the Reservations.
  const handleSubmit = (event) => {
    event.preventDefault();
    const startTime = formatTime(startDate);
    const endTime = formatTime(endDate);
    const startDate1 = formatDate(startDate);
    const endDate1 = formatDate(endDate);

    if (category && endDate && endDate1 >= startDate1 && endTime > startTime) {
      axios
        .post(
          DEVICE_RESERVATION_API +
            JSON.stringify({
              start_time: startTime,
              end_time: endTime,
              start_date: startDate1,
              end_date: endDate1,
              device_name: [deviceNameList],
              reserved_by: userProfile.username,
              reservation_category: category,
              location_id: "IN-002",
              brand_name: "name",
            })
        )
        .then((response) => {
          setAlertMessage(response.data.Message);
          console.log(response.data.Message, "MAD");
          setModal(false);
          setAlertState(true);
          if (category?.length !== 0) {
            setEndDate("");
          }
          setCategory("");
        });
      setErrorMessage("");
      if (category?.length !== 0) {
        setEndDate("");
      }
      setCategory("");
    } else {
      setErrorMessage("Please Enter valid data");
      if (category?.length !== 0) {
        setEndDate("");
      }
      setCategory("");
    }
  };

  //Define a function to close the alert box and update the errrorConfirmDelete state as false
  const handleAlertClose = () => {
    setAlertState(false);
    setEndDate("");
  };

  //Condition is to check if alertState is true then it will call the handleAlertClose function in 3 seconds
  if (alertState) {
    setTimeout(() => {
      handleAlertClose();
    }, 3000);
  }

  const getDaysInMonth = (month, year) => {
    var date = new Date(year, month, 1);
    var days = [];
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  };

  const Detailsofreserveby = (item) => {
    setItemDetails([item]);
    setReservefalse(true);
  };

  useEffect(() => {
    setDates(getDaysInMonth(month, year));
    allEvents.push(datareservelist);
  }, []);

  const updateMonth = (month1) => {
    if (month1 > 11) {
      getEventdisplay(oneDate);
      setReservefalse(false);
      setItemDetails("");
      return 0;
    } else if (month1 < 0) {
      getEventdisplay(oneDate);
      setReservefalse(false);
      setItemDetails("");
      return 11;
    } else {
      getEventdisplay(oneDate);
      setReservefalse(false);
      setItemDetails("");
      return month1;
    }
  };

  const getPreviousMonth = () => {
    if (month === 0) {
      return months[11];
    } else {
      return months[month - 1];
    }
  };
  const getNextMonth = () => {
    if (month === 11) {
      return months[0];
    } else {
      return months[month + 1];
    }
  };

  const showReservations = (event, info) => {
    console.log(event.target, "showtarget");
    if (pastEvent !== null) {
      pastEvent.target.style.color = "white";
      pastEvent.target.style.fontWeight = "normal";
      if (pastEvent.target != null && pastEvent.curTarget != null) {
        pastEvent.curTarget.style.color = "white";
        pastEvent.curTarget.style.fontWeight = "normal";
      }
    }

    if (event.target === event.currentTarget) {
      setPastevent({ target: event.target, curTarget: null });
      event.target.style.color = "#1EB6B6";
      event.target.style.fontWeight = "bold";
    } else {
      setPastevent({ target: event.target, curTarget: event.currentTarget });

      event.currentTarget.style.color = "#1EB6B6";
      event.currentTarget.style.fontWeight = "bold";
      event.target.style.color = "#1EB6B6";
      event.target.style.fontWeight = "bold";
    }

    setDay({ day: info.day, date: info.date });
    var exactMonth = parseInt(month) + 1;
    var exactDate = info.date;
    console.log(exactDate, "todaydate");
    if (exactMonth <= 9) {
      exactMonth = "0" + exactMonth;
    }
    if (day.date <= 9) {
      exactDate = "0" + day.date;
    }
    const date = year + "-" + exactMonth + "-" + exactDate;
    getEventdisplay(year + "-" + exactMonth + "-" + exactDate);
    console.log("inputdate", date, event);
    setDateforevents(date);
    setGetdatacalendar(date);
    console.log("harine", allEvents[date]);
    setEvents(allEvents[date]);
    setReservefalse(false);
    setItemDetails("");
  };
  console.log("harine", events);
  console.log("checking", day);

  const [isOpen1, setIsOpen1] = useState(false);
  var userdata = JSON.parse(sessionStorage.getItem("userData"));
  console.log(userdata, "dddd");
  const confirmDelete = () => {
    let dataURL =
      DELETE_MANAGE_RESERVATION_API +
      JSON.stringify({
        reservation_number: [itemDetails[0]?.reservation_number],
      });
    Axios.post(dataURL)
      .then((res) => {
        setIsOpen1(false);
        setReservefalse(false);
        getEventdisplay(oneDate);
        setItemDetails("");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getEventdisplay = (e) => {
    console.log("getdatenow", e);
    axios
      .get(
        FETCH_RESERVATION_DETAILS_CALENDAR_API +
          JSON.stringify({
            date: e,
            device_name: deviceNameList,
          })
      )
      .then((response) => {
        console.log(response.data, "getresponsedata");
        setDatareservelist(response.data);
      });
  };
  const Delete_Confirmation = () => {
    setIsOpen1(!isOpen1);
    console.log("deleted");
  };
  const closepopop = () => {
    setIsOpen1(false);
  };

  const roundedTime = (time) => {
    const [hours, minutes, seconds] = time.split(":");
    let roundedHours = parseInt(hours, 10);
    let roundedMinutes = parseInt(minutes, 10);
    let roundedSeconds = parseInt(seconds, 10);
    if (roundedMinutes < 29) {
      roundedMinutes = 0;
    } else if (roundedMinutes > 30 && roundedMinutes < 59) {
      roundedMinutes = 30;
    }

    if (roundedSeconds < 59) {
      roundedSeconds = 0;
    }
    return `${roundedHours.toString().padStart(2, "0")}:${roundedMinutes
      .toString()
      .padStart(2, "0")}:${roundedSeconds.toString().padStart(2, "0")}`;
  };

  const deviceFilterBack = function () {
    navigate(-1);
  };
  const deviceFilterBack1 = function () {
    navigate(-2);
  };

  const isOnAutomationCalenderPage =
    location.pathname ===
    "/platform/" + platform_data + "/automation/bigCalendar";
  const isOnAutomationCalenderPageME =
    location.pathname === "/platform/M&E/automation/bigCalendar";

  if (dates) {
    return (
      <>
        {isOnAutomationCalenderPage || isOnAutomationCalenderPageME ? (
          <Breadcrumbs
            separator={<KeyboardArrowLeft />}
            aria-label="breadcrumb"
          >
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              Platform
            </Link>
            {platform_data === "Media And Entertainment" ? (
              <Link to="/platform" onDragStart={preventDragHandler}>
                M&E
              </Link>
            ) : (
              <Link to="/platform">
                {platform_data}onDragStart={preventDragHandler}
              </Link>
            )}
            {platform_data === "Media And Entertainment" ? (
              <Link
                to={"/platform/M&E/automation"}
                onDragStart={preventDragHandler}
              >
                Automation
              </Link>
            ) : (
              <Link
                to={"/platform/" + platform_data + "/automation"}
                onDragStart={preventDragHandler}
              >
                Automation
              </Link>
            )}
            <Typography color="#0D6EFD">Big Calender</Typography>
          </Breadcrumbs>
        ) : (
          <Breadcrumbs
            separator={<KeyboardArrowLeft />}
            aria-label="breadcrumb"
          >
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              Platform
            </Link>
            {platform_data === "Media And Entertainment" ? (
              <Link
                onClick={deviceFilterBack1}
                onDragStart={preventDragHandler}
              >
                M&E
              </Link>
            ) : (
              <Link onClick={deviceFilterBack}>
                {platform_data}onDragStart={preventDragHandler}
              </Link>
            )}
            <Link onClick={deviceFilterBack} onDragStart={preventDragHandler}>
              Device Filter
            </Link>
            <Typography color="#0D6EFD">Big Calender</Typography>
          </Breadcrumbs>
        )}

        <div className={`Calendarmain ${theme === "dark" ? "dark" : "light"}`}>
          {/* {alertState && (
            <div className="alerDivBig">
              <Alert
                severity="success"
                variant="filled"
                onClose={handleAlertClose}
                icon={false}
                className="alertBoxBig"
                sx={alertStyle}
              >
                {alertMessage}
              </Alert>
            </div>
          )} */}
          <Snackbar
            className={`cal-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            open={alertState}
            autoHideDuration={6000}
            onClose={() => setAlertState(false)}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            {alertState === true && <Alert icon={false}>{alertMessage}</Alert>}
          </Snackbar>

          <div className="backdevicebtn"></div>
          <div
            className={`Calendarheading ${theme === "dark" ? "dark" : "light"}`}
          >
            Reservation
          </div>
          <div className="monthmainname">
            <div className="Calendarpart1">
              <div
                className="Calendarpart2"
                onClick={() => {
                  if (month === 0) {
                    setYear(year - 1);
                  }

                  console.log(month, year, "month&year");
                  setMonth(updateMonth(month - 1));
                  setDates(getDaysInMonth(updateMonth(month - 1), year));
                }}
              >
                <h3
                  className={`leftarrow ${theme === "dark" ? "dark" : "light"}`}
                >
                  &lt;
                </h3>
                <h3
                  className={`Monthprevious ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  {getPreviousMonth()}{" "}
                </h3>
              </div>
              <h2
                className={`MonthandYear ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                {months[month]} {year}
              </h2>
              <div
                className="headingname"
                onClick={() => {
                  if (month === 11) {
                    setYear(year + 1);
                  }

                  console.log(month, year, "after");
                  setMonth(updateMonth(month + 1));
                  setDates(getDaysInMonth(updateMonth(month + 1), year));
                }}
              >
                <h3
                  className={`Monthprevious ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  {getNextMonth()}
                </h3>
                <h3
                  className={`rightarrow ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  &gt;
                </h3>
              </div>
            </div>

            <div
              className={`h-dates-section ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              {dates.map((date) => {
                const currentDay = date.getDay();
                const d = new Date();
                let day = d.getDate();
                const current = date.getDate();
                let month = d.getMonth();
                const currentMonthcolor = date.getMonth();
                const currentDate = date.getDate();
                return (
                  <div
                    className={
                      "dateactive " +
                      (currentDay == "6"
                        ? `showline ${theme === "dark" ? "dark" : "light"}`
                        : " ") +
                      (current === day && currentMonthcolor === month
                        ? "currentdaycolor"
                        : " ")
                    }
                    onClick={(e) =>
                      showReservations(e, {
                        date: currentDate,
                        day: date.getDay(),
                      })
                    }
                  >
                    <p>{week[currentDay]}</p>
                    <p className="datecolor"> {currentDate}</p>
                  </div>
                );
              })}
            </div>
          </div>
          <div
            className={`displaymainevent ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            <div
              className={`event-display2 ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              {
                <div className="alignments-2">
                  {times.map((time) => {
                    return (
                      <>
                        <div
                          className={`eventboxtime ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <p className="time2">{time}</p>
                          {datareservelist.map((item) => {
                            const start_time_rounded = roundedTime(
                              item.start_time
                            );
                            return item &&
                              start_time_rounded == [time] &&
                              item.date == dateforevents ? (
                              <div
                                style={{ height: (item.duration / 60) * 100 }}
                                onClick={() => Detailsofreserveby(item)}
                                className={`eventtime2 ${
                                  theme === "dark" ? "dark" : "light"
                                }`}
                              >
                                <p
                                  // className="eventdistext"
                                   className={`eventdistext${
                                  theme === "dark" ? "dark" : "light"
                                }`}
                                  // style={{
                                  //   lineHeight: "Normal",
                                  //   fontSize:
                                  //     item.duration > 30
                                  //       ? "16px"
                                  //       : item.duration,
                                  // }}
                                >
                                  {item.reserved_by}
                                </p>
                              </div>
                            ) : null;
                          })}
                        </div>
                      </>
                    );
                  })}
                </div>
              }
            </div>
            <div
              onClick={toggleModal}
              className={`addiconforreserve ${
                theme === "dark" ? "dark" : "light"
              }`}
              disabled={modal}
            >
              <i class="fa fa-plus add" aria-hidden="true"></i>
            </div>
            {modal && (
              <div
                className={`modal-overlay ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <div
                  className="modal-content"
                  // style={{ backgroundColor: "red" }}
                >
                  <div className="modal-form">
                    <button className="close-deviceview" onClick={handleCancel}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="feather feather-x"
                      >
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                      </svg>
                    </button>
                    <div className="modal-form-row">
                      <label htmlFor="start-date">Start:</label>

                      <DateTimePicker
                        id="start-date"
                        value={startDate}
                        onChange={handleStartDateChange}
                        min={minDate}
                        className="modal-datetimepicker"
                      />
                    </div>
                    &nbsp;
                    <div className="modal-form-row">
                      <label htmlFor="end-date">End:</label>
                      <DateTimePicker
                        id="end-date"
                        value={endDate}
                        onChange={handleEndDateChange}
                        min={startDate}
                        className="modal-datetimepicker"
                      />
                    </div>
                    <div className="formcontrol-content">
                      <FormControl
                        variant="standard"
                        sx={{ m: 1, minWidth: "95%" }}
                        className="dropdown-select-category"
                        required
                      >
                        <InputLabel id="demo-simple-select-standard-label">
                          Select Category
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-standard-label"
                          id="demo-simple-select-standard"
                          value={category}
                          onChange={handleChange}
                          label="Age"
                        >
                          <MenuItem value={"Manual"}>Manual</MenuItem>
                          <br />
                          <MenuItem value={"Automation"}>Automation</MenuItem>
                        </Select>
                        <FormHelperText className="helpertext-message">
                          {errorMessage}
                        </FormHelperText>
                      </FormControl>
                    </div>
                  </div>
                  <div className="modal-buttons">
                    <button onClick={handleCancel} className="btn-cancel-cal">
                      Cancel
                    </button>
                    {/* <Button
                         onClick={handleSubmit}
                         variant="contained"
                         className="btn-submit-cal"
                       >
                         Submit
                       </Button> */}
                    <button onClick={handleSubmit} className="btn-cancel-cal">
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            )}
            <div className="reservationbox">
              {reservefalse ? (
                <h3
                  className={`details ${theme === "dark" ? "dark" : "light"}`}
                >
                  Reservation Details
                </h3>
              ) : (
                <h3
                  className={`selectfordetail ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Select any reservation to get its details.
                </h3>
              )}
              {reservefalse &&
                itemDetails.map((item) => {
                  return (
                    <ul
                      className={`ultag ${theme === "dark" ? "dark" : "light"}`}
                    >
                      <li>
                        <span>Brand Name</span>
                        {item.brand_name}
                      </li>
                      <li>
                        <span>Date</span>
                        {item.date}
                      </li>
                      <li>
                        <span>Device Name</span>
                        {item.device_name}
                      </li>
                      <li>
                        <span>Duration</span>
                        {item.duration}
                      </li>
                      <li>
                        <span>Lab Name</span>
                        {item.lab_name}
                      </li>
                      <li>
                        <span>Reserved By</span>
                        {item.reserved_by}
                      </li>
                      <li>
                        <span>Start Time</span>
                        {item.start_time}
                      </li>
                    </ul>
                  );
                })}
              {reservefalse ? (
                <div
                  className={`deleteblue ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  <i
                    class="fa fa-trash delete"
                    aria-hidden="true"
                    onClick={Delete_Confirmation}
                  ></i>
                </div>
              ) : (
                ""
              )}

              {isOpen1 && (
                <Modalcancel
                  content={
                    <div className="maindiv">
                      <img
                        src={close}
                        alt="Close"
                        onClick={closepopop}
                        className="popupsclose "
                      />
                      <br />
                      <h3 className="deleteHeading">
                        Do you want to delete reservation for this device ?{" "}
                      </h3>
                      <div className="popupallbtnpopup">
                        <Button
                          onClick={closepopop}
                           className={`popupcancelbtncancel ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          variant="outlined"
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={confirmDelete}
                          className="popupconfirmbtnconfirm"
                          variant="contained"
                        >
                          Confirm
                        </Button>
                      </div>
                    </div>
                  }
                />
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
};
export default ReservationCalendar;
