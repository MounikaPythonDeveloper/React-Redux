import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { Breadcrumbs, Typography } from "@mui/material";
import "./Platform.css";
import { useState } from "react";
import Loader from "../../components/ReusableComponents/Loader/Loader";
import { HomeData } from "../../services/ApiFunction";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";
import Navbar from "../../components/Navbar/Navbar";
import { USER_PRIVILAGE } from "../../services/api";
import axios from "axios";
import { EditUserContext } from "../../context/EditUserContext";

function Platform() {
  // const [userUpdated, updateUserStatus] = EditUserContext()
  const [loading, setLoading] = useState(false);
  const [remotePageData, setRemotePageData] = useState([]);
  const [uniqueRemotePageData, SetUniqueRemotePageData] = useState([]);
  const [userSelectedPlatform, setUserSelectedPlatform] = useState("");
  const [privilage, setPrivilage] = useState("");
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  // console.log(userUpdated, "Edit status")
  let size;
  if (remotePageData.length >= 5) {
    size = 4;
  } else {
    size = 3;
  }

  const user_privilege_func = async () => {
    axios
      .post(
        USER_PRIVILAGE +
          JSON.stringify({
            username: userProfile.username,
          }) +
          "&attributes=" +
          JSON.stringify(["user_privilege"])
      )
      .then((res) => {
        getRemoteDevices(res.data.user_privilege[0]);
      })
      .catch((er) => console.log(er));
  };

  useEffect(() => {
    user_privilege_func();
  }, []);

  const getRemoteDevices = async function (userprivilage) {
    try {
      setLoading(true);
      let response = await HomeData.PlatformData(
        userProfile.username,
        userprivilage
      );
      setRemotePageData(response.data);
      const unique = [
        ...new Map(
          response.data.map((item) => [item["platform"], item])
        ).values(),
      ];
      console.log(unique);
      SetUniqueRemotePageData(unique);
      setLoading(false);
    } catch (error) {
      console.log(error);
    }
  };

  const HandlePlatformSelection = (platForm) => {
    let platform = platForm;
    setUserSelectedPlatform(platform);
    sessionStorage.setItem("platform", JSON.stringify(platform));
  };
  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  const { theme } = useTheme();
  const storedThemeData = sessionStorage.getItem("theme");

  if (theme === "dark") {
    document.documentElement.classList.remove("light");
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
    document.documentElement.classList.add("light");
  }

  console.log("theme in platform", theme, theme === "dark" ? "dark" : "light");
  return (
    <>
      <Breadcrumbs aria-label="breadcrumb">
        <Typography
          // className={`breadcrumbs-link ${theme === "dark" ? "dark" : "light"}`}
          to={"/platform"}
        >
          Platform
        </Typography>
      </Breadcrumbs>
      {loading === false ? (
        <div className={`remote ${theme === "dark" ? "dark" : "light"}`}>
          {userSelectedPlatform.length > 0 && (
            <Navbar platform={userSelectedPlatform} />
          )}
          <div
            className={`re-category  ${theme === "dark" ? "dark" : "light"}`}
          >
            Platform
          </div>
          <div
            className={`re-sub-heading  ${theme === "dark" ? "dark" : "light"}`}
          >
            Select a Platform to get Started
          </div>
          <div
            className="re-category-container"
            style={{
              display: "grid",
              "grid-template-columns": "repeat(" + size + ", 1fr)",
            }}
          >
            {uniqueRemotePageData.map((remoteItems) => {
              return (
                <div className="remote-items hover">
                  {remoteItems.platform === "Media And Entertainment" ? (
                    <Link
                      to={"/platform/M&E"}
                      state={{ data: remoteItems }}
                      onClick={() =>
                        HandlePlatformSelection(remoteItems.platform)
                      }
                    >
                      {theme === "dark" ? (
                        <img
                          className="remote-item-img"
                          src={remoteItems.platform_image_url}
                          alt="Platform"
                          onDragStart={preventDragHandler}
                        />
                      ) : (
                        <img
                          className="remote-item-img"
                          src={remoteItems.light_theme_image_url}
                          alt="Platform"
                          onDragStart={preventDragHandler}
                        />
                      )}
                    </Link>
                  ) : (
                    <Link
                      to={"/platform/" + remoteItems.platform}
                      state={{ data: remoteItems }}
                      onClick={() =>
                        HandlePlatformSelection(remoteItems.platform)
                      }
                    >
                      {theme === "dark" ? (
                        <img
                          className="remote-item-img"
                          src={remoteItems.platform_image_url}
                          alt="Platform"
                          onDragStart={preventDragHandler}
                        />
                      ) : (
                        <img
                          className="remote-item-img"
                          src={remoteItems.light_theme_image_url}
                          alt="Platform"
                          onDragStart={preventDragHandler}
                        />
                      )}
                    </Link>
                  )}

                  <h3
                    className={`remote-item-title  ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    src={remoteItems.light_theme_image_url}
                  >
                    {remoteItems.platform === "Media And Entertainment"
                      ? "M&E"
                      : remoteItems.platform}
                  </h3>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div>
          <Loader />
        </div>
      )}
    </>
  );
}

export default Platform;
