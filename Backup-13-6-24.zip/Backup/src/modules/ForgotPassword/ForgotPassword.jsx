/**
 * Component: Context
 * File:ForgetPassword.jsx
 * Description: This file contains the implementation forget password and change password
 *  File Used:App.js
 *  Author: R.Harine Parvathi
 * */

/* eslint-disable */
import React, { useState, useEffect, useCallback, useRef } from "react";
import { useForm } from "react-hook-form";
import { useTheme } from "../../components/ThemeToggle/ThemeContext";
import "./ForgotPassword.css";
import crypto from "crypto-js";
//importing apis for send otp,submit and submit password
import { RESET_API, OTP_API, RESET_PASSWORD_API } from "../../services/api";
import { FormHelperText, makeStyles } from "@material-ui/core";
import axios from "axios";
import Alert from "@mui/material/Alert";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, Typography, Popover } from "@material-ui/core";
import * as Yup from "yup";
import { toast } from "react-toastify";
import Tooltip from "@mui/material/Tooltip";
import "react-toastify/dist/ReactToastify.css";
//importing link and button reusable component
import MyButton from "../../components/ReusableComponents/Buttons";
import MyLink from "../../components/ReusableComponents/Links";
import { IconButton, InputAdornment, TextField } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
//importing evqual logo
import EvQuallogo from "../../assets/images/EvQuallogo.svg";
import "../DeviceView/DeviceView.css";

var CryptoJS = require("crypto-js");
//styles for text input
const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
});

export default function ForgotPassword(props) {
  const { theme } = useTheme();
  const [attemptsRemaining, setAttemptsRemaining] = useState(3);
  const [message, setMessage] = useState("");
  const [password, setPassword] = useState("");
  const [emailid, setemailid] = useState("");
  const [forgotMes, setForgetMes] = useState("");
  const [verifypasswordold, setverifypasswordold] = useState("");
  const [verifypasswordnew, setverifypasswordnew] = useState("");
  const [otpFail, setOtpFail] = useState(false);
  const [active, setActive] = useState(0);
  const [popup, setPop] = useState(false);
  const [buttonText1, setButtonText1] = useState("Send OTP", null);
  const [bgclr, setbgclr] = useState("#07F265");
  const mybuttonref = useRef(null);
  let navigate = useNavigate();
  //changing the button text from send otp to resend otp

  const changeText1 = (text, timr) => setButtonText1(text, resetTimer());
  //function for declaring the pop up while submitting the password and confirm password
  const reset = function (data) {
    if (data == "True") {
      setPop(!popup);
      setForgetMes("Your Password has changed.Login with new Password");
    } else {
      setPop(popup);
    }
  };

  //regex matching for password
  const regexPass1 =
    /^[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~](?=.*[a-zA-Z0-9])[a-zA-Z0-9]{8,14}[a-zA-Z0-9]{0,6}$/;
  const regexPass2 =
    /^(?=.*[a-zA-Z0-9])[a-zA-Z0-9]{8,14}[a-zA-Z0-9]{0,6}[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~]$/;
  const regexPass3 =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~])[A-Za-z\d!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~]{10,18}$/;
  const validationSchema = Yup.object().shape({
    password: Yup.string().matches(
      regexPass2 && regexPass1 && regexPass3,
      "10 chars,1 letter,number and special chars"
    ),
    confirm_password: Yup.string().oneOf(
      [Yup.ref("password")],
      "Passwords must match"
    ),
  });

  //declaring height and width of screen for pop up alignment
  const height = screen.height / 15;
  const width = screen.width / 4;

  //onchange function for password
  const handlePasswordBlur = (e) => {
    console.log(e);
    setPassword("");
    const regex = regexPass1 && regexPass2 && regexPass3;
    if (!regex.test(e.target.value)) {
      setPassword(true);
    } else {
      setPassword(false);
    }
  };
  if (theme === "dark") {
    document.documentElement.classList.remove("light");
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
    document.documentElement.classList.add("light");
  }

  const formOptions = { resolver: yupResolver(validationSchema) };
  //declaring submit functions
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const {
    register: register2,
    formState: { errors: errors2 },
    handleSubmit: handleSubmit2,
  } = useForm();

  const {
    register: register3,
    formState: { errors: errors3 },
    handleSubmit: handleSubmit3,
    watch,
  } = useForm(formOptions);
  const [otp, setOtp] = useState();
  const [otpError, setOtpError] = useState("");
  const [timer, setTimer] = useState("");
  const [username, setUsername] = useState("");

  const timeOutCallback = useCallback(
    () => setTimer((currTimer) => currTimer - 1),
    []
  );

  //declaring timer in send otp button
  useEffect(() => {
    timer > 0 && setTimeout(timeOutCallback, 1000);
  }, [timer, timeOutCallback]);

  //function for verifying the email address entered
  const sendEmail = (email) => {
    setbgclr("white");
    console.log(email, "keyvalue email har");
    const reset_data = {
      email_id: email,
    };
    console.log("keyvalue", reset_data);
    axios
      .post(RESET_API + JSON.stringify(reset_data))
      .then((response) => {
        if (response.data.valid === "true") {
          setUsername(response.data.username);
          verfiy_password_api(email);
        } else {
          setMessage(response.data.Message);
          console.log("data", response.data.Message);
        }
        if (response.data.Message === "This email id does not exist") {
          setemailid(true);
        } else {
          setemailid(false);
        }
        console.log("nnnnn", response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //function for verifying the otp entered
  const sendOtp = (otp) => {
    console.log("keyvalue23", otp);
    const otp_data = {
      otp: otp,
      username: username,
    };

    axios
      .post(OTP_API + JSON.stringify(otp_data))
      .then((response) => {
        if (response.data.valid === "true") {
          setActive(1);
          setOtpEmpty(true);
          setotp(true);
        } else {
          console.log(otp_data);
          setOtpError(response.data.message);
          setOtpEmpty(false);
          setotp(false);
          if (attemptsRemaining === 1 || response.data.account === "Blocked") {
            console.log("attempt for blocking", attemptsRemaining);
            setAttemptsRemaining(3);
            setActive(0);
            setOtpFail(true);
          } else {
            setAttemptsRemaining(attemptsRemaining - 1);
          }
        }
        console.log("nnnnn", response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };
  //function for submitting email address
  function onSubmitEmail(data) {
    // handlesubmit(data)
    sendEmail(data.email);
    console.log("Data submitted: keyvalue ", data);
  }

  const [buttonText, setButtonText] = useState("Next");
  const changeText = (text) => setButtonText(text);
  function onSubmitOtp(data) {
    sendOtp(data.otp);
  }
  //style for input field
  const texfieldInputStyle = {
    borderBottom: "1px solid grey",
    color: "#fff",
    fontFamily: "Open Sans",
    fontSize: 15,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "30px",
    background: "transparent",
    // caretColor: "white",
  };

  const texfieldLabelStyle = {
    color: "#fff",
    opacity: 1.0,
    fontSize: 18,
    fontFamily: "Open Sans",
    fontStyle: "normal",
    fontWeight: 400,
    paddingTop: 1,
    lineHeight: "30px",
    background: "transparent",
    // caretColor: "white",
  };

  //function for verifying new password and confirm password
  const reset_password_Submit = (data) => {
    var key = "AAAAAAAAAAAAAAAA";
    key = CryptoJS.enc.Utf8.parse(key);
    var encrypted = CryptoJS.AES.encrypt(data.password, key, {
      mode: CryptoJS.mode.ECB,
    });
    encrypted = encrypted.toString();
    console.log("encrypted2", encrypted);

    const reset_password_data = {
      password: encrypted,
      username: username.toLowerCase(),
    };

    axios
      .post(RESET_PASSWORD_API + JSON.stringify(reset_password_data))
      .then((response) => {
        if (response.data.valid === "true") {
          reset("True");
          console.log("djlk", encrypted);
          console.log("Reset Done", response.data);
          toast.success("Password has Successfully Changed!", {
            position: toast.POSITION.TOP_CENTER,
          });
        } else {
          setMessage(response.data.Message);
        }
        console.log("nnnnn", response.data);
      })
      .catch((error) => {
        reset("False");
        console.log(error, "error");
      });
  };

  const [emailEmpty, setEmailEmpty] = useState(true);
  const [OtpEmpty, setOtpEmpty] = useState(true);
  const [email, setEmail] = useState(true);
  const [errorEmail, setErrorEmail] = useState(true);
  const [validemail, setvalidemail] = useState("");
  const [Otp, setotp] = useState(false);
  const [isRevealPwd1, setIsRevealPwd1] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [password1, setPassword1] = useState("");
  const [showPassword1, setShowPassword1] = useState(false);
  const [disable, setDisable] = useState(true);

  const btn1 = useRef(null);
  const btn2 = useRef(null);
  const tf1 = useRef(null);
  const tf2 = useRef(null);

  //pop up display

  if (popup) {
    setTimeout(() => {
      handleAlertClose();
    }, 3000);
  }

  const resetTimer = function () {
    if (!timer) {
      setTimer(30);
    }
    return timer;
  };

  //enter function for OTP
  const handleKeyDown = (e) => {
    console.log(e.target.value, "keyvalue");
    if (e.keyCode === 13) {
      e.preventDefault();
      sendOtp(e.target.value);
    }
  };

  //enter function for Email
  const onKeyDownResentOTP = (e) => {
    console.log(e.target.value.toLowerCase(), "keyvalueemail");

    if (e.keyCode === 13) {
      e.preventDefault();

      sendEmail(e.target.value);
      changeText1("Resend OTP");
    }
  };

  //closing pop up
  const handleAlertClose = () => {
    setPop(false);
    navigate("/");
  };

  //onchange function for otp
  const handleOtpBlur = (e) => {
    const regex = /^[0-9]{5}$/;
    if (!regex.test(e.target.value)) {
      setOtpEmpty(true);
    } else {
      setOtpEmpty(false);
    }
  };

  //onchange function for email
  const handEmailBlur = (e) => {
    const regex = /^[a-zA-Z0-9_.+-]+@ltts\.com$/;
    if (!regex.test(e.target.value)) {
      setErrorEmail("");
      setEmailEmpty(true);
      setEmail(true);
    } else {
      setEmailEmpty(false);
      setErrorEmail("");
      setEmail(false);
    }
  };
  //function to prevent pasting password from new password to confirm password
  const handleChangePaste = (e) => {
    e.preventDefault();
  };

  const classes = useStyles();
  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <React.Fragment>
      <div
        className={`ForgotPassword page ${theme === "dark" ? "dark" : "light"}`}
      >
        <div className="logo-container4">
          <img
            src={EvQuallogo}
            alt="Logo"
            className="logo"
            onDragStart={preventDragHandler}
          />
        </div>

        <div class="row">
          <div class="col-md-6 register-left">
            <div className="account sign-in">
              Already have an Account?&#160;
              <br />
              <MyLink to="/" className="signupBtn">
                Sign in
              </MyLink>
            </div>
          </div>

          <div className="col-md-5 register-right">
            {active === 0 && (
              <form
                onSubmit={handleSubmit(onSubmitEmail)}
                className="registration-form"
              >
                <div>
                  {otpFail === true && (
                    <h3>OTP Verification Failed. Try again</h3>
                  )}
                </div>

                <div className="input-text">
                  <h2 className="reg_title"> Forget Password</h2>
                  {/* <div className="text-field"> */}
                  <div ref={tf1} className="text-field">
                    <TextField
                      // style={{ color: "white" }}
                      id="standard"
                      variant="standard"
                      type="text"
                      label="Email"
                      varient="Email"
                      autoComplete="off"
                      onKeyDown={(e) => {
                        onKeyDownResentOTP(e);
                      }}
                      inputProps={{
                        "data-testid": "email-input",
                      }}
                      {...register("email", {})}
                      onChange={handEmailBlur}
                      error={errors.email && errors.email.message}
                      helperText={[
                        email ? errorEmail : "",
                        errors.email && errors.email.message,
                        emailid ? "Invalid Email Id" : "",
                      ]}
                      InputProps={{
                        style: texfieldInputStyle,
                        // className: "text-field-input"
                        classes: { underline: classes.underline },
                      }}
                      InputLabelProps={{
                        style: texfieldLabelStyle,
                      }}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                    />
                  </div>

                  <div className="mail_id" data-testid="otp-button">
                    <button
                      style={
                        theme === "dark"
                          ? { color: bgclr }
                          : { color: "#07F265", fontWeight: "600" }
                      }
                      disabled={!!emailEmpty}
                      ref={mybuttonref}
                      onClick={(onSubmitEmail) => changeText1("Resend OTP")}
                    >
                      {buttonText1}
                      {"\n"}
                      {buttonText1 == "Resend OTP"
                        ? timer == 0
                          ? setButtonText1("Send OTP") || setbgclr("#07F265")
                          : timer + "s"
                        : ""}
                    </button>
                  </div>

                  <br />
                  <div ref={tf2} className="text-field">
                    <TextField
                      // style={{ color: "white" }}
                      id="standard"
                      variant="standard"
                      inputProps={{ maxLength: 5 }}
                      disabled={!!emailEmpty || emailid}
                      type="number"
                      label="OTP"
                      varient="OTP"
                      helperText={otpError}
                      {...register2("otp", {
                        pattern: {
                          value: /^[0-9]{5}$/s,
                          message: "Enter a valid OTP",
                        },
                      })}
                      onKeyDown={(e) => handleKeyDown(e)}
                      onChange={handleOtpBlur}
                      InputProps={{
                        style: texfieldInputStyle,
                        classes: { underline: classes.underline },
                      }}
                      InputLabelProps={{
                        style: texfieldLabelStyle,
                      }}
                      FormHelperTextProps={{ className: "my-helper-text" }}
                      autoComplete="off"
                    />
                  </div>
                  <br />
                  <br />
                  <br />

                  <div
                    ref={btn2}
                    className="btn1"
                    data-testid="fpsubmit-button"
                  >
                    <MyButton
                      type="submit"
                      variant="contained"
                      label="Submit"
                      onClick={handleSubmit2(onSubmitOtp)}
                      disabled={!!OtpEmpty}
                    ></MyButton>
                  </div>
                </div>
              </form>
            )}

            {active === 1 && (
              <div>
                <div className="input-text">
                  {!!popup && (
                    <div className="alertDiv1">
                      <Alert
                        severity="success"
                        variant="filled"
                        onClose={handleAlertClose}
                        icon={false}
                        style={{
                          height: height,
                          width: width,
                          left: height / 6,
                        }}
                        className="alertBox1"
                        // sx={alertStyle}
                      >
                        Password Changed Successfully
                      </Alert>
                    </div>
                  )}

                  <h2 className="reg_title2">Change Password</h2>
                  <form onSubmit={handleSubmit3(reset_password_Submit)}>
                    <div className="text-field">
                      <Tooltip
                        classes={{ tooltip: classes.tooltip }}
                        title={
                          <>
                            <Typography
                              color="inherit"
                              style={{ fontSize: "11px" }}
                            >
                              Password Should contain:
                            </Typography>
                            <Typography
                              color="inherit"
                              component="div"
                              style={{ fontSize: "11px" }}
                            >
                              <ul>
                                <li>10+ characters </li>
                                <li>Atleast 1 no. </li>
                                <li>
                                  Atleast one special character($,%,@, etc.){" "}
                                </li>
                                <li>
                                  Have mixture of uppercase and lowercase
                                  letters{" "}
                                </li>
                              </ul>
                            </Typography>
                          </>
                        }
                        placement="bottom"
                      >
                        <TextField
                          // style={{ color: "white" }}
                          label="New Password"
                          id="standard"
                          variant="standard"
                          varient="Password"
                          onClick={handlePasswordBlur}
                          onCut={handleChangePaste}
                          onCopy={handleChangePaste}
                          onPaste={handleChangePaste}
                          // onChange={setPassword(true)}

                          type={showPassword ? "text" : "password"}
                          {...register3("password")}
                          helperText={[
                            password ? "Invalid password" : "",

                            errors3.password && errors3.password.message,
                          ]}
                          InputLabelProps={{
                            style: texfieldLabelStyle,
                          }}
                          FormHelperTextProps={{ className: "my-helper-text" }}
                          autoComplete="off"
                          InputProps={{
                            style: texfieldInputStyle,
                            autoComplete: "chrome-off" || "edge-off",
                            // className: "text-field-input"
                            classes: { underline: classes.underline },
                            endAdornment: (
                              <InputAdornment
                                sx={{
                                  position: "absolute",
                                  right: "8px",
                                  transform: "translateY(-50%)",
                                }}
                              >
                                <IconButton
                                  sx={{ color: "white" }}
                                  aria-label="toggle password visibility"
                                  onClick={() => setShowPassword(!showPassword)}
                                >
                                  {showPassword ? (
                                    <Visibility
                                      onDragStart={preventDragHandler}
                                    />
                                  ) : (
                                    <VisibilityOff
                                      onDragStart={preventDragHandler}
                                    />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            ),
                            style: texfieldInputStyle,
                          }}
                        />
                      </Tooltip>
                      <br />
                      <br />
                    </div>

                    <div className="text-field">
                      <TextField
                        // style={{ color: "white" }}
                        label="Confirm Password"
                        id="standard"
                        variant="standard"
                        varient="Password"
                        disabled={!!password}
                        onCut={handleChangePaste}
                        onCopy={handleChangePaste}
                        onPaste={handleChangePaste}
                        type={showPassword1 ? "text" : "password"}
                        {...register3("confirm_password")}
                        helperText={
                          errors3.confirm_password &&
                          errors3.confirm_password.message
                        }
                        InputLabelProps={{
                          style: texfieldLabelStyle,
                          // className: 'text-field-label'
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                        autoComplete="off"
                        InputProps={{
                          style: texfieldInputStyle,
                          // className: "text-field-input"
                          classes: { underline: classes.underline },
                          endAdornment: (
                            <InputAdornment
                              sx={{
                                position: "absolute",
                                right: "8px",
                                transform: "translateY(-50%)",
                              }}
                            ></InputAdornment>
                          ),
                          style: texfieldInputStyle,
                        }}
                      />
                    </div>

                    <div>
                      <br />
                      <br />
                      <br />
                      <MyButton
                        type="submit"
                        variant="contained"
                        label="Submit"
                        onClick={reset}
                      >
                        Submit
                      </MyButton>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
