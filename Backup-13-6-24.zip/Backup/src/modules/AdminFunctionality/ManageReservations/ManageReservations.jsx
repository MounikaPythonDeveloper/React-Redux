import React, { useEffect, useReducer, useState } from "react";
import "./ManageReservations.css";
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent";
import Pagination from "../../Automation/Pagination/Pagination";
import {
  MANAGE_RESERVATION_API,
  DELETE_MANAGE_RESERVATION_API,
  SEARCH_RESERVATION_API,
} from "../../../services/api";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";

import { Alert, Snackbar } from "@mui/material";
import axios from "axios";
import searchIcon from "../../../assets/images/img/icon _search_normal.svg";
import deleteuserlogo from "../../../assets/images/img/delete_user_icon.svg";

function ManageReservations() {
  const { theme } = useTheme();
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [deletedResponse, setDeletedResponse] = useState(false);
  const [reservationData, setReservationData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);
  const [checkReservationItem, setCheckReservationItem] = useState([]);
  const [reducerValue, forceUpdate] = useReducer((x) => x + 1, 0);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = reservationData.slice(indexOfFirstPost, indexOfLastPost);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const keys = ["category_reservation", "device_name", "reserved_by"];

  console.log(searchValue, "searchValue");
  useEffect(() => {
    // if (searchValue.length === 0 || checkReservationItem.length === 0) {
    //   ManageReservationsData();
    // }
    if (searchValue.length === 0) {
      ManageReservationsData();
    }
  }, [reducerValue, searchValue, checkReservationItem]);

  const ManageReservationsData = async () => {
    let data_url = "";
    data_url = `${MANAGE_RESERVATION_API}`;
    await axios
      .get(data_url)
      .then((response) => {
        console.log(response.data, "MANAGE RESERVATIONS");
        setReservationData(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    // forceUpdate();
  };

  // POPUP OPEN FUNCTION
  const handleOpen = function () {
    if (checkReservationItem.length !== 0) {
      setOpen(true);
      console.log("handle open");
    }
  };

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setCheckReservationItem([]);
    setOpen(false);
  };

  const searchApi = async (searchTearm) => {
    let searchData = "";
    searchData = `${SEARCH_RESERVATION_API}${searchTearm}`;
    await axios
      .post(searchData)
      .then((response) => {
        setReservationData(response.data);
        console.log("SEARCH API DATA", response.data);
        setCurrentPage(1);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    // forceUpdate();
  };
  const enterAPIHandler = function (event) {
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      console.log("Enter key was pressed. Run your function.", searchValue);
      event.preventDefault();
      searchApi(searchValue);
    }
  };

  const manageDeletetHandler = async () => {
    let deleteReservationsItems = "";
    deleteReservationsItems =
      `${DELETE_MANAGE_RESERVATION_API}` +
      `${JSON.stringify({
        reservation_number: checkReservationItem,
      })}`;
    await axios
      .post(deleteReservationsItems)
      .then((response) => {
        setDeletedResponse(response.data);
        console.log("delete user", response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    setCheckReservationItem("");
    handleClosePopup();
    forceUpdate();
  };

  const searchHandler = function (event) {
    setSearchValue(event.target.value);
  };

  const onSearch = function (searchTearm) {
    console.log(searchTearm, "searchTearm");
    searchApi(searchTearm);
  };

  const getReservationItem = function (event, value) {
    console.log(value, "getReservationItem");
    if (event.target.checked === true) {
      setCheckReservationItem([...checkReservationItem, value]);
      console.log(checkReservationItem, "checkReservationItem");
    } else {
      setCheckReservationItem(
        checkReservationItem.filter((val) => val !== value)
      );
    }
  };

  return (
    <>
      <Snackbar
        className={`delete-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={deletedResponse}
        autoHideDuration={6000}
        onClose={() => setDeletedResponse(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {deletedResponse === true && (
          <Alert icon={false}>Deleted the selected Reservation</Alert>
        )}
      </Snackbar>
      <div
        className={`manage-res-container ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div className="manage-res-top">
          <div className="manage-res-heading">Manage Reservations</div>
          <div className="manage-res-search">
            <input
              className="manage-res-search-input"
              placeholder="search"
              type="text"
              value={searchValue}
              onChange={searchHandler}
              onKeyUp={enterAPIHandler}
            />
            {searchValue === "" ? (
              <img
                className="manage-res-search-icon"
                src={searchIcon}
                alt="Search"
                disabled
                onClick={() => onSearch(searchValue)}
                title="Search"
              />
            ) : (
              <img
                className="manage-res-search-icon"
                src={searchIcon}
                alt="Search"
                onClick={() => onSearch(searchValue)}
                title="Search"
              />
            )}
          </div>
        </div>
        <div className="manage-res-lower">
          <div
            className={`manage-res-table-container ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            {reservationData.length === 0 ? (
              <div className="table-empty-message">No Data Available</div>
            ) : (
              <table class="table">
                <thead className="manage-res-table_head ">
                  <tr className="manage-res-table_header">
                    <th>S.No</th>
                    <th>Device Name</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Location</th>
                    <th>Duration </th>
                    <th>Reserved By</th>
                    <th>
                      <img
                        className="magage-res-icon"
                        onClick={handleOpen}
                        alt="Delete User"
                        src={deleteuserlogo}
                        title="Delete"
                      />
                    </th>
                  </tr>
                </thead>

                <tbody className="table_body">
                  {currentPosts.map((reservations, index) => {
                    return (
                      <tr>
                        <td>{indexOfFirstPost + index + 1}</td>
                        <td key={reservations.device_name}>
                          {reservations.device_name}
                        </td>
                        <td>{reservations.category_reservation}</td>
                        <td>{reservations.brand_name}</td>
                        <td>{reservations.location_id}</td>
                        <td>{reservations.reservation_duration}</td>
                        <td>{reservations.reserved_by}</td>
                        <td className="managereservations-checkbox">
                          <input
                            type="checkbox"
                            checked={checkReservationItem.includes(
                              reservations.reservation_number
                            )}
                            onChange={(event) =>
                              getReservationItem(
                                event,
                                reservations.reservation_number
                              )
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
          <PopupComponent
            open={open}
            text="Are you sure you want to delete?"
            handleClose={handleClosePopup}
            functionHandle={manageDeletetHandler}
          />
          {reservationData.length !== 0 && (
            <Pagination
              currentPage={currentPage}
              postsPerPage={postsPerPage}
              totalPosts={reservationData.length}
              paginate={paginate}
            />
          )}
        </div>
      </div>
    </>
  );
}
export default ManageReservations;
