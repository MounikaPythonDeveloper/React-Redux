import React, { useState } from "react";
import "./AddUser.css";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import "../../../SignUp/SignUp.css";
import axios from "axios";
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";
import {
  VALIDATE_USERNAME_API,
  VALIDATE_EMAIL_API,
  ADD_USER_API,
} from "../../../../services/api";
import TextField from "@material-ui/core/TextField";
import Tooltip from "@mui/material/Tooltip";

import { makeStyles } from "@material-ui/core";
import Alert from "@mui/material/Alert";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
var CryptoJS = require("crypto-js");

const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
});

const AddUser = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const [active, setActive] = useState(0);
  const [username, setUsername] = useState("");
  const [usernameField, setUsernameField] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userRole, setUserRole] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState({ username: "", email_id: "" });
  const [errorEmail, setErrorEmail] = useState({ username: "", email_id: "" });
  const [usernameValid, setUsernameValid] = useState("");
  const [emailValid, setEmailValid] = useState("");
  const [errorUsername, setUsernameError] = useState("");
  const [usernameEmpty, setUsernameEmpty] = useState(true);
  const [emailEmpty, setEmailEmpty] = useState(true);
  const [passwordEmpty, setPasswordEmpty] = useState(true);
  const [confirmPasswordEmpty, setconfirmPasswordEmpty] = useState(true);
  const navigate = useNavigate();
  const [showAlert, setShowAlert] = useState(false);
  const [showAlertFailed, setShowAlertFailed] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [confirmPasswordError, setConfirmPasswordError] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [role, setRole] = useState("");
  const [roleError, setRoleError] = useState("");

  const classes = useStyles();

  const validationSchema = Yup.object().shape({
    password: Yup.string()
      .required("Password is required")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{10,18}$/,
        "Invalid Password"
      ),
    confirmPassword: Yup.string()
      .required("Confirm Password is required")
      .oneOf([Yup.ref("password")], "Passwords must match"),
    uname: Yup.string().required("User name is required"),
    email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
    role: Yup.string().required("Select the User role"),
  });
  const formOptions = { resolver: yupResolver(validationSchema) };
  // get functions to build form with useForm() hook
  const { register, handleSubmit, reset, formState } = useForm(formOptions);
  const { errors } = formState;

  function onSubmit(data) {
    var key = "AAAAAAAAAAAAAAAA";
    key = CryptoJS.enc.Utf8.parse(key);

    var encrypted = CryptoJS.AES.encrypt(data.password, key, {
      mode: CryptoJS.mode.ECB,
    });
    encrypted = encrypted.toString();
    console.log("encrypted2", encrypted);

    const adduser_data = {
      username: data.uname.toLowerCase(),
      email_id: data.email.toLowerCase(),
      password: encrypted,
      user_privilege: role,
      verified: "true",
    };

    console.log(adduser_data, "emailabc");

    axios

      .post(ADD_USER_API + JSON.stringify(adduser_data))
      .then((response) => {
        console.log(response.data, "success");
        if (response.data.valid === "true") {
          console.log("trueabc", response.data.email_id);
          setUsername(response.data.username);
          setEmail(response.data.email_id);
          setEmail(response.data.email_id);
          setUserRole(response.data.user_privilege);
          setActive(1);
        } else {
          setError(response.data);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
    if (isOnPlatformPage || isOnAboutPage || isOnAddUserPage || isOnAdminPage) {
      navigate("/platform/adminHomePage");
    } else if (platform_data === "Media And Entertainment") {
      navigate("/platform/M&E/adminHomePage");
    } else {
      navigate("/platform/" + platform_data + "/adminHomePage");
    }
  }

  if (showAlert) {
    setTimeout(() => {
      handleAlertClose();
    }, 2000);
  }

  if (showAlertFailed) {
    setTimeout(() => {
      handleAlertCloseFailed();
    }, 2000);
  }

  const texfieldInputCSS = {
    borderBottom: "1px solid grey",
    color: "#FFFFFF",
    fontFamily: "Open Sans",
    fontSize: 18,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "20px",
  };

  const texfieldLabelCSS = {
    color: "#fff",
    opacity: 1.0,
    fontSize: 16,
    fontFamily: "Open Sans",
    fontStyle: "normal",
    fontWeight: 400,
    paddingTop: 1,
    lineHeight: "30px",
  };

  const handleAlertCloseFailed = () => {
    setShowAlertFailed(false);
  };

  const handleAlertClose = () => {
    setShowAlert(false);
  };
  //Check username is already exist or not
  const checkUsername = (uname) => {
    axios
      .post(VALIDATE_USERNAME_API + JSON.stringify({ username: uname }))
      .then((response) => {
        if (response.data === true) {
          let value = "true";
          setUsernameValid(value);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const checkEmail = (email_id) => {
    axios
      .post(VALIDATE_EMAIL_API + JSON.stringify({ email_id: email_id }))
      .then((response) => {
        if (response.data === true) {
          let value = "true";
          setEmailValid(value);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const handleUsernameBlur = (e) => {
    checkUsername(e.target.value);
    setUsernameValid("");
    const regex = /^[a-zA-Z0-9_]{4,18}$/;
    if (!regex.test(e.target.value)) {
      setUsernameError(
        "Should have 4-18 characters & special character is not Allowed"
      );
      setUsername(true);
      setUsernameEmpty(true);
    } else {
      setUsernameError("");
      setUsername(false);
      setUsernameEmpty(false);
    }
  };

  const handEmailBlur = (e) => {
    checkEmail(e.target.value);
    const emailLength = e.target.value;
    console.log(emailLength.length, "Length");
    setEmailValid("");
    const regex = /^[a-zA-Z0-9_.+-]+@ltts\.com$/;
    if (emailLength.length <= 0) {
      setErrorEmail("Email is required");
      setEmail(true);
      setEmailEmpty(true);
    } else {
      if (!regex.test(e.target.value)) {
        setErrorEmail("Invalid email or Invalid domain");
        setEmail(true);
        setEmailEmpty(true);
      } else {
        setErrorEmail("");
        setEmail(false);
        setEmailEmpty(false);
      }
    }
  };

  const handlePasswordBlur = (e) => {
    setPassword("");
    const regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{10,18}$/;
    if (!regex.test(e.target.value)) {
      setPassword(true);
      setPasswordEmpty(true);
    } else {
      setPasswordEmpty(false);
      setPassword(false);
    }
  };

  const handleConfirmPasswordBlur = (e) => {
    setConfirmPassword("");

    if (e.target.value === "") {
      setConfirmPassword(true);
      setconfirmPasswordEmpty(true);
    } else {
      setconfirmPasswordEmpty(false);
      setConfirmPassword(false);
    }
  };

  const handleRole = (event) => {
    setRole(event.target.value);
    let selectedRole = event.target.value;
    console.log(selectedRole.length, "selectedRole");
    if (selectedRole.length === 0) {
      setRoleError("User role is required");
    }
  };
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnAddUserPage =
    location.pathname === "/platform/adminHomePage/addUser";

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <React.Fragment>
      <div>
        {isOnPlatformPage ||
        isOnAboutPage ||
        isOnAddUserPage ||
        isOnAdminPage ? (
          <Breadcrumbs
            separator={<KeyboardArrowLeft />}
            aria-label="breadcrumb"
          >
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              Platform
            </Link>
            <Link
              to={"/platform/adminHomePage"}
              onDragStart={preventDragHandler}
            >
              Admin Home Page
            </Link>
            <Typography color="#0D6EFD">Add User</Typography>
          </Breadcrumbs>
        ) : platform_data === "Media And Entertainment" ? (
          <Breadcrumbs
            separator={<KeyboardArrowLeft />}
            aria-label="breadcrumb"
          >
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              Platform
            </Link>
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              M&E
            </Link>
            <Link
              to={"/platform/M&E/adminHomePage"}
              onDragStart={preventDragHandler}
            >
              Admin Home Page
            </Link>
            <Typography color="#0D6EFD">Add User</Typography>
          </Breadcrumbs>
        ) : (
          <Breadcrumbs
            separator={<KeyboardArrowLeft />}
            aria-label="breadcrumb"
          >
            <Link to={"/platform"} onDragStart={preventDragHandler}>
              Platform
            </Link>
            <Link to={"/platform"}>
              {platform_data}onDragStart={preventDragHandler}
            </Link>
            <Link
              to={"/platform/" + platform_data + "/adminHomePage"}
              onDragStart={preventDragHandler}
            >
              Admin Home Page
            </Link>
            <Typography color="#0D6EFD">Add User</Typography>
          </Breadcrumbs>
        )}
        <div className={`Add_user ${theme === "dark" ? "dark" : "light"}`}>
          <div class="add_user_form">
            <div class="col-md-5 add_user_div">
              {active === 0 && (
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  method="post"
                  className="registration-form"
                >
                  <div className="div_contents">
                    <div className="reg_title">
                      <h3>Add User</h3>
                    </div>
                    <div className="text_input">
                      <TextField
                        label="Username"
                        className="text-field"
                        id="standard-basic-adusername"
                        autoComplete="off"
                        {...register("uname", {
                          required: "uname is required",
                        })}
                        onChange={handleUsernameBlur}
                        error={username}
                        helperText={[
                          username ? errorUsername : errors.uname?.message,
                          usernameValid === "true" &&
                            "Username already exist, please try other username",
                        ]}
                        InputProps={{
                          style: texfieldInputCSS,
                          classes: { underline: classes.underline },
                          maxLength: 12,
                        }}
                        InputLabelProps={{
                          style: texfieldLabelCSS,
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                        autoComplete="off"
                      />
                      {console.log(errorUsername.length, "errorUsername")}
                      {error.username && error.username}
                    </div>

                    <div className="text_input">
                      <TextField
                        id="standard-basic-mailid"
                        label="Email"
                        className="text-field"
                        variant="standard"
                        autoComplete="off"
                        {...register("email", {
                          required: "email is required",
                        })}
                        onBlur={handEmailBlur}
                        error={email}
                        helperText={[
                          email ? errorEmail : errors.email?.message,
                          emailValid === "true" &&
                            "email already exist, please try other email-id",
                        ]}
                        InputProps={{
                          style: texfieldInputCSS,
                          classes: { underline: classes.underline },
                        }}
                        InputLabelProps={{
                          style: texfieldLabelCSS,
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                        autoComplete="off"
                      />
                      {error.email_id && error.email_id}
                      {console.log(errorEmail, "errorUsername")}
                    </div>
                    <div className="text_input">
                      <Tooltip
                        classes={{ tooltip: classes.tooltip }}
                        title={
                          <>
                            <Typography
                              color="inherit"
                              style={{ fontSize: "11px" }}
                            >
                              Password Should contain:
                            </Typography>
                            <Typography
                              color="inherit"
                              component="div"
                              style={{ fontSize: "11px" }}
                            >
                              <ul>
                                <li>10+ characters </li>
                                <li>Atleast 1 no. </li>
                                <li>
                                  Atleast one special character($,%,@, etc.){" "}
                                </li>
                                <li>
                                  Have mixture of uppercase and lowercase
                                  letters{" "}
                                </li>
                              </ul>
                            </Typography>
                          </>
                        }
                        placement="bottom"
                      >
                        <TextField
                          id="standard-basic-aduserpwd"
                          label="Password"
                          className="text-field"
                          variant="standard"
                          type="password"
                          autoComplete="off"
                          {...register("password", {
                            required: "Password is required",
                          })}
                          onChange={handlePasswordBlur}
                          error={password}
                          helperText={[
                            password
                              ? "Invalid password"
                              : errors.password?.message,
                          ]}
                          InputProps={{
                            style: texfieldInputCSS,
                            classes: { underline: classes.underline },
                          }}
                          InputLabelProps={{
                            style: texfieldLabelCSS,
                          }}
                          FormHelperTextProps={{ className: "my-helper-text" }}
                        />
                      </Tooltip>
                    </div>
                    <div className="text_input">
                      <TextField
                        id="standard-basic-aduserconfirmpwd"
                        label="Confirm Password"
                        className="text-field"
                        variant="standard"
                        type="password"
                        autoComplete="off"
                        {...register("confirmPassword", {
                          required: " Confirm Password is required",
                        })}
                        onChange={handleConfirmPasswordBlur}
                        error={confirmPassword}
                        helperText={[
                          confirmPassword
                            ? "Password Mismatch"
                            : errors.confirmPassword?.message,
                        ]}
                        InputProps={{
                          style: texfieldInputCSS,
                          classes: { underline: classes.underline },
                        }}
                        InputLabelProps={{
                          style: texfieldLabelCSS,
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                      />
                    </div>
                    <div className="edit-user-role">
                      <TextField
                        id="standard-basic-aduserrole"
                        select
                        label="User Role"
                        SelectProps={{
                          native: true,
                        }}
                        {...register("role", {
                          required: "User role is required",
                        })}
                        onChange={handleRole}
                        error={role}
                        helperText={[role ? "" : errors.role?.message]}
                        variant="standard"
                        InputProps={{
                          style: texfieldInputCSS,
                          classes: { underline: classes.underline },
                        }}
                        InputLabelProps={{
                          style: texfieldLabelCSS,
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                      >
                        <option></option>
                        <option value="Admin"> Admin</option>
                        <option value="Tester"> Tester</option>
                      </TextField>
                    </div>
                    {isOnPlatformPage ||
                    isOnAboutPage ||
                    isOnAddUserPage ||
                    isOnAdminPage ? (
                      <div className="submit-cancel-button">
                        <button
                          onClick={() => navigate("/platform/adminHomePage")}
                          id="disable"
                          type="button"
                          className="cancel_button"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="submit_button"
                          disabled={errorUsername || errorEmail}
                        >
                          Submit
                        </button>
                      </div>
                    ) : platform_data === "Media And Entertainment" ? (
                      <div className="submit-cancel-button">
                        <button
                          onClick={() =>
                            navigate("/platform/M&E/adminHomePage")
                          }
                          id="disable"
                          type="button"
                          className="cancel_button"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="submit_button"
                          disabled={errorUsername || errorEmail}
                        >
                          Submit
                        </button>
                      </div>
                    ) : (
                      <div className="submit-cancel-button">
                        <button
                          onClick={() =>
                            navigate(
                              "/platform/" + platform_data + "/adminHomePage"
                            )
                          }
                          id="disable"
                          type="button"
                          className="cancel_button"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="submit_button"
                          disabled={errorUsername || errorEmail}
                        >
                          Submit
                        </button>
                      </div>
                    )}
                  </div>
                </form>
              )}
            </div>
          </div>

          {showAlert && (
            <div className="alertDiv1">
              <Alert
                severity="success"
                variant="filled"
                onClose={handleAlertClose}
                icon={false}
                className="alertBox1"
              >
                New user Account has created
              </Alert>
            </div>
          )}
        </div>
      </div>
    </React.Fragment>
  );
};
export default AddUser;
