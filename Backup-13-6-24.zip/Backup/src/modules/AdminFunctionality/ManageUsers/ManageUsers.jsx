import React, { useState, useEffect, useReducer } from "react";
import "./ManageUsers.css";
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent";
import axios from "axios";
import Pagination from "../../Automation/Pagination/Pagination";
import {
  VIEW_USERS_API,
  DELETE_USER_API,
  SEARCH_USER_API,
} from "../../../services/api";
import edituserlogo from "../../../assets/images/img/edit_user_icon.svg";
import deleteuserlogo from "../../../assets/images/img/delete_user_icon.svg";
import adduserlogo from "../../../assets/images/img/adduserbutton.svg";
import { Link, useLocation, useNavigate } from "react-router-dom";
import searchIcon from "../../../../src/assets/images/img/icon _search_normal.svg";
import { Alert, Snackbar } from "@mui/material";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";

const ManageUsers = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = details.slice(indexOfFirstPost, indexOfLastPost);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const [open, setOpen] = useState(false);
  const [userComponent, setUserComponent] = useState();
  const [clickedUser, setClickedUser] = useState();
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [reducerValue, forceUpdate] = useReducer((x) => x + 1, 0);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnChangePasswordPage =
    location.pathname === "/platform/viewprofile/changepassword";
  const isOnAdminMangeUserPage =
    location.pathname === "/platform/adminHomePage/addUser";
  const isOnEditUserPage =
    location.pathname === "/platform/adminHomePage/editUser";
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));

  console.log(indexOfLastPost, "indexOfLastPost");

  const getUserDeletedItem = (event, value) => {
    console.log(value, "deleteusersvalue");
    if (event.target.checked === true) {
      setSelectedUsers([...selectedUsers, value]);
      console.log(selectedUsers, "setSelectedUsers");
    } else {
      setSelectedUsers(selectedUsers.filter((val) => val !== value));
    }
  };

  useEffect(() => {
    viewUsers();
    viewUsers();
  }, [reducerValue]);

  const viewUsers = async () => {
    let viewUsers = "";
    viewUsers = `${VIEW_USERS_API}`;
    await axios
      .get(viewUsers)
      .then((response) => {
        setDetails(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };
  console.log(details, "Details");

  const handleSearch = async (searchTerm) => {
    console.log("started Searching", `${JSON.stringify(searchTerm)}`);
    try {
      const response = await axios.get(`${SEARCH_USER_API}${searchTerm}`);
      setDetails(response.data);
      console.log(response.data, "API called");
      setCurrentPage(1);
    } catch (error) {
      console.log(error, "Can't Find");
    }
  };
  console.log(results, "SearchedDetails");

  const enterAPIHandler = function (event) {
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      console.log("Enter key was pressed. Run your function.", searchTerm);
      event.preventDefault();
      handleSearch(searchTerm);
    }
  };

  const delete_user_handle = function (user) {
    console.log(user, "ClickedUserNAme");
    setClickedUser(user);
    handleOpen();
  };
  const handleOpen = () => {
    if (selectedUsers.length !== 0) {
      setOpen(true);
    }
  };

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setOpen(false);
    setSelectedUsers([]);
  };

  // const deleteUserFunction = async () => {
  //   console.log("Funtion called")
  //   const deleteUsers = `${DELETE_USER_API}${JSON.stringify({
  //     username: selectedUsers,
  //   })}`
  //   await axios
  //     .post(deleteUsers)
  //     .then((response) => {
  //       console.log("delete user", response.data)
  //       setDeleteConfirmation(response.data)
  //     })
  //     .catch((error) => {
  //       console.log(error, "error")
  //     })
  //   handleClosePopup()
  //   forceUpdate()
  //   setSelectedUsers([])
  // }
  const deleteUserFunction = async () => {
    console.log("Funtion called");

    const data = {
      usernames: selectedUsers,
      time: new Date().toISOString(),
    };

    fetch(DELETE_USER_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        console.log("deleted_users", response.ok);
        setDeleteConfirmation(response.ok);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    handleClosePopup();
    forceUpdate();
    setSelectedUsers([]);
  };

  useEffect(() => {
    if (searchTerm.length === 0) {
      viewUsers();
    }
  }, [searchTerm]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    console.log(e.target.value, "called");
  };

  return (
    <div>
      <Snackbar
        className={`delete-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={deleteConfirmation}
        autoHideDuration={6000}
        onClose={() => setDeleteConfirmation(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {deleteConfirmation === true && (
          <Alert icon={false}>Deleted the selected User</Alert>
        )}
      </Snackbar>
      <div
        className={`manage_users_page ${theme === "dark" ? "dark" : "light"}`}
      >
        <div className="manage-user-top">
          <div className="manage-user-heading">Manage Users</div>
          <div className="manage-user-search">
            <input
              className="manage-user-search-input"
              placeholder="search"
              type="text"
              value={searchTerm}
              onKeyUp={enterAPIHandler}
              onChange={handleSearchChange}
            />
            <img
              className="manage-user-search-icon"
              src={searchIcon}
              alt="Search"
              onClick={() => handleSearch(searchTerm)}
              title="Search"
            />
          </div>
        </div>
      </div>
      <div className="manage-user-lower">
        <div
          className={`manage-user-table-container ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          {details.length === 0 ? (
            <div className="table_empty_message">No Data to Display</div>
          ) : (
            <table className="table">
              <thead className="manage-user-table_head">
                <tr className="manage-user-table_header">
                  <th>S.No</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>License Status</th>
                  <th>Platform</th>
                  <th>Approval Status</th>
                  <th>Role</th>
                  <th>Edit</th>
                  <th>
                    <img
                      style={{ height: "16px" }}
                      onClick={handleOpen}
                      src={deleteuserlogo}
                      alt="Delete"
                      title="Delete"
                    />
                  </th>
                </tr>
              </thead>
              <tbody className="table_body">
                {console.log("currentPosts", currentPosts)}
                {console.log("results", results)}
                {currentPosts.map((item, index) => {
                  return (
                    <>
                      <tr>
                        <td>{indexOfFirstPost + index + 1}</td>
                        <td>{item.username}</td>
                        <td>{item.email_id}</td>
                        <td>
                          {item.status !== null ? item.status : "Not Activated"}
                        </td>
                        <td>
                          {item.platform !== null
                            ? item.platform.join(", ")
                            : "No Platforms"}
                        </td>
                        <td>{item.admin_approval}</td>
                        <td>{item.user_privilege}</td>
                        <td className="edit_delete_logo">
                          {console.log(item, "UserD")}
                          <span>
                            {isOnAboutPage ||
                            isOnAdminPage ||
                            isOnPlatformPage ||
                            isOnEditUserPage ? (
                              <Link
                                to="/platform/adminHomePage/editUser"
                                state={item}
                              >
                                <img
                                  src={edituserlogo}
                                  title="Edit"
                                  alt="Edit"
                                />
                              </Link>
                            ) : platform_data === "Media And Entertainment" ? (
                              <Link
                                to={"/platform/M&E/adminHomePage/editUser"}
                                state={item}
                              >
                                <img
                                  src={edituserlogo}
                                  title="Edit"
                                  alt="Edit"
                                />
                              </Link>
                            ) : (
                              <Link
                                to={
                                  "/platform/" +
                                  platform_data +
                                  "/adminHomePage/editUser"
                                }
                                state={item}
                              >
                                <img
                                  src={edituserlogo}
                                  title="Edit"
                                  alt="Edit"
                                />
                              </Link>
                            )}
                          </span>
                        </td>
                        <td className="manageusers-checkbox">
                          <input
                            type="checkbox"
                            checked={selectedUsers.includes(item.username)}
                            onChange={(event) =>
                              getUserDeletedItem(event, item.username)
                            }
                          />
                        </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <PopupComponent
          open={open}
          text="Are you sure you want to delete ?"
          handleClose={handleClosePopup}
          functionHandle={deleteUserFunction}
        />
        <div className="add_user_logo">
          <div>
            {isOnPlatformPage ||
            isOnAboutPage ||
            isOnViewProfile ||
            isOnChangePasswordPage ||
            isOnAdminMangeUserPage ||
            isOnAdminPage ? (
              <Link to="/platform/adminHomePage/addUser">
                <img src={adduserlogo} alt="Add User" title="Add User" />
              </Link>
            ) : platform_data === "Media And Entertainment" ? (
              <Link to={"/platform/M&E/adminHomePage/addUser"}>
                <img src={adduserlogo} alt="Add User" title="Add User" />
              </Link>
            ) : (
              <Link
                to={"/platform/" + platform_data + "/adminHomePage/addUser"}
              >
                <img src={adduserlogo} alt="Add User" title="Add User" />
              </Link>
            )}
          </div>
        </div>

        <Pagination
          currentPage={currentPage}
          postsPerPage={postsPerPage}
          totalPosts={details.length}
          paginate={paginate}
        />
      </div>
    </div>
  );
};

export default ManageUsers;
