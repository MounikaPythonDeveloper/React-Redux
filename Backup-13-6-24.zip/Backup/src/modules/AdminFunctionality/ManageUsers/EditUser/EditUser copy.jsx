/**
 * Component: EditUser
 * File: EditUser.jsx
 * Description: This file contains the implementation of the EditUser React component.
                To Edit the user credentials(email, userrole).
                Admin can change the 
 *File Used:ManageUsers.jsx
 * Author: B.Jagadeesh, Mounika
 * */

import React, { useState, useEffect } from "react"
import "./EditUser.css"
import { FormHelperText } from "@mui/material"
import Select from "@mui/material/Select"
// import "../../../../components/License/BuyLicense.css"
// import "./BuyLicense/BuyLicense.css"
import Box from "@mui/material/Box"
import TextField from "@mui/material/TextField"
import axios from "axios"
import { useTheme } from "@mui/material/styles"
import { EDIT_USER_API, GET_PLATFORMS_API } from "../../../../services/api"
import { useLocation, useNavigate, Link } from "react-router-dom"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import MenuItem from "@mui/material/MenuItem"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import MultiSelectDropdown from "../../../../components/ReusableComponents/MultiSelectDropdown/MultiSelctDropdown"
import FormControl from "@mui/material/FormControl"
import InputLabel from "@mui/material/InputLabel"
import OutlinedInput from "@mui/material/OutlinedInput"

function EditUser() {
  const theme = useTheme()
  const [email, setEmail] = useState("")
  const [role, setRole] = useState("")
  const [approvalStatus, setApprovalStatus] = useState("")
  const [error, setError] = useState("")
  const navigate = useNavigate()
  const location = useLocation()
  const data = location.state ? location.state : ""
  console.log(data, "PassedData")
  const validationSchema = Yup.object().shape({
    selectedPlatforms: Yup.array()
      .min(1, "Platform is required")
      .required("platform is required"),
    email: Yup.string().required("Email is required"),
    role: Yup.string().required("Select the User role"),
    approvalStatus: Yup.string().required("Select the Approval Status"),
  })
  const formOptions = { resolver: yupResolver(validationSchema) }
  const { register, handleSubmit, reset, formState } = useForm(formOptions)
  const { errors } = formState
  const [selectedPlatforms, setSelectedPlatforms] = useState([])
  const [optionPlatformData, setOptionPlatformData] = useState([])
  const [errorMessagePlatform, setErrorMessagePlatform] = useState("")
  const regex = /^[a-zA-Z0-9_.+-]+@ltts\.com$/

  const handleEmail = (e) => {
    setEmail(e.target.value)
    if (!regex.test(e.target.value)) {
      setError("Invalid email or Invalid domain")
    } else {
      setError("")
      return true
    }
  }
  const ITEM_HEIGHT = 48
  const ITEM_PADDING_TOP = 8
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  }
  const handlePlatform = (event) => {
    const {
      target: { value },
    } = event
    setSelectedPlatforms(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    )
  }
  console.log(email, "Clickeduname")
  console.log(selectedPlatforms, "selected platforms")
  useEffect(() => {
    getPlatforms()
  }, [])
  const getPlatforms = async () => {
    axios
      .post(GET_PLATFORMS_API + JSON.stringify(["platform"]))
      .then((res) => {
        setOptionPlatformData(res.data.platform)
      })
      .catch((er) => console.log(er))
  }

  const handleRole = (event) => {
    setRole(event.target.value)
  }

  const handleApprovalStatus = (event) => {
    setApprovalStatus(event.target.value)
    console.log(event.target.value)
  }

  const submitFuction = async (e) => {
    console.log("Funtion called", selectedPlatforms, selectedPlatforms.length)
    // if (selectedPlatforms.length === 0) {
    //   setErrorMessagePlatform("Please Select Platform")
    //   alert("Please select platform")
    // } else {
    let userName = data.username
    const validationError = {}
    setError(validationError)
    axios
      .post(
        `${EDIT_USER_API}` +
          JSON.stringify({ username: userName }) +
          "&attribute=" +
          JSON.stringify({
            user_privilege: role,
            email_id: email,
            admin_approval: approvalStatus,
          })
      )
      .then((response) => {
        console.log("edit user", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })

    if (
      isOnAboutPage ||
      isOnAdminPage ||
      isOnEditUserPage ||
      isOnPlatformPage
    ) {
      navigate("/platform/adminHomePage")
    } else if (platform_data === "Media And Entertainment") {
      navigate("/platform/M&E/adminHomePage")
    } else {
      navigate("/platform/" + platform_data + "/adminHomePage")
    }
  }
  // }
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const isOnPlatformPage = location.pathname === "/platform"
  const isOnAboutPage = location.pathname === "/about"
  const isOnAdminPage = location.pathname === "/platform/adminHomePage"
  const isOnEditUserPage =
    location.pathname === "/platform/adminHomePage/editUser"

  const preventDragHandler = (e) => {
    e.preventDefault()
  }
  function getStyles(platform, selectedPlatforms, theme) {
    return {
      fontWeight:
        selectedPlatforms.indexOf(platform) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    }
  }

  return (
    <>
      {isOnAboutPage ||
      isOnAdminPage ||
      isOnPlatformPage ||
      isOnEditUserPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/adminHomePage"} onDragStart={preventDragHandler}>
            Admin Home Page
          </Link>
          <Typography color="#0D6EFD">Edit User</Typography>
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            M&E
          </Link>
          <Link
            to={"/platform/M&E/adminHomePage"}
            onDragStart={preventDragHandler}
          >
            Admin Home Page
          </Link>
          <Typography color="#0D6EFD">Edit User</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            {platform_data}
          </Link>
          <Link to={"/platform/" + platform_data + "/adminHomePage"}>
            Admin Home Page
          </Link>
          <Typography color="#0D6EFD">Edit User</Typography>
        </Breadcrumbs>
      )}
      <div className="edit-user-container">
        <div className="edit-user-heading">Edit User</div>
        <div className="edit-user-feilds">
          <form
            onSubmit={handleSubmit(submitFuction)}
            method="post"
            className="ediruser-form"
          >
            <div className="edit-user-username">
              <Box
                component="form"
                sx={{
                  "& > :not(style)": { m: 1, width: "50ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  id="standard-basic"
                  value={data.username}
                  disabled
                  variant="standard"
                />
              </Box>
            </div>
            <div className="edit-user-email">
              <Box
                component="form"
                sx={{
                  "& > :not(style)": { m: 1, width: "50ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  id="standard-basic-mail"
                  label="Email"
                  type="email"
                  variant="standard"
                  {...register("email", {
                    required: "email is required",
                  })}
                  onChange={handleEmail}
                  inputProps={{ maxLength: 28 }}
                  helperText={[email ? error : errors.email?.message]}
                />
                {/* {console.log(error, "errorLength")} */}
              </Box>
            </div>
            <div className="edit-user-role">
              <Box
                component="form"
                sx={{
                  "& > :not(style)": { m: 1, width: "50ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  id="standard-select-role-native"
                  select
                  label="User Role"
                  {...register("role", {
                    required: "User role is required",
                  })}
                  SelectProps={{
                    native: true,
                  }}
                  role
                  value={role}
                  onChange={handleRole}
                  variant="standard"
                  title={role === "" ? "Build" : setRole}
                  helperText={[role ? "" : errors.role?.message]}
                >
                  <option></option>
                  <option value="Admin"> Admin</option>
                  <option value="Tester"> Tester</option>
                </TextField>
              </Box>
            </div>
            {role === "Tester" && (
              <div className="fielddropdown-text">
                <Box sx={{ minWidth: 300, m: 1 }}>
                  <InputLabel
                    style={{
                      color: "#1eb6b6",
                      fontSize: 14,
                      fontFamily: "Open Sans",
                      fontStyle: "normal",
                      fontWeight: 400,
                      lineHeight: "14px",
                    }}
                  >
                    Platforms
                  </InputLabel>
                  {/* <FormControl variant="standard" fullWidth>
                    <MultiSelectDropdown
                      selectedPlatforms={selectedPlatforms}
                      setSelectedPlatforms={setSelectedPlatforms}
                      optionPlatformData={optionPlatformData}
                      title="Platforms"
                      {...register("platforms", {
                        required: "Platforms role is required",
                      })}
                      error={!!errorMessagePlatform}
                      displayEmpty
                    />

                    <FormHelperText error={!!errorMessagePlatform}>
                      {errorMessagePlatform}
                    </FormHelperText>
                  </FormControl> */}
                  <FormControl sx={{ m: 1, width: 300 }}>
                    <InputLabel id="demo-multiple-name-label">
                      Platform
                    </InputLabel>
                    <Select
                      labelId="demo-multiple-name-label"
                      id="demo-multiple-name"
                      multiple
                      SelectProps={{
                        native: true,
                      }}
                      {...register("selectedPlatforms", {
                        required: "Platform is required",
                      })}
                      helperText={[
                        selectedPlatforms.length > 0
                          ? []
                          : errors.selectedPlatforms?.message,
                      ]}
                      selectedPlatforms
                      value={selectedPlatforms}
                      onChange={handlePlatform}
                      input={<OutlinedInput label="selectedPlatforms" />}
                      MenuProps={MenuProps}
                    >
                      {optionPlatformData.map((platform) => (
                        <MenuItem
                          key={platform}
                          value={platform}
                          style={getStyles(platform, selectedPlatforms, theme)}
                        >
                          {platform}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>

                  {errors.selectedPlatforms?.message
                    ? "Platform is Required"
                    : ""}
                </Box>
              </div>
            )}
            <div className="edit-user-approval-status">
              <Box
                component="form"
                sx={{
                  "& > :not(style)": { m: 1, width: "50ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  id="standard-select-approval-status-native"
                  select
                  label="Approval Status"
                  {...register("approvalStatus", {
                    required: "Select the Approval Status",
                  })}
                  SelectProps={{
                    native: true,
                  }}
                  approvalStatus
                  value={approvalStatus}
                  onChange={handleApprovalStatus}
                  variant="standard"
                  title={approvalStatus === "" ? "Build" : setApprovalStatus}
                  helperText={[
                    approvalStatus ? "" : errors.approvalStatus?.message,
                  ]}
                >
                  <option></option>
                  <option value="Approved"> Approve</option>
                  <option value="Declined"> Decline</option>
                </TextField>
              </Box>
            </div>
            {isOnAboutPage ||
            isOnAdminPage ||
            isOnEditUserPage ||
            isOnPlatformPage ? (
              <div className="submit_cancel_button">
                <button
                  onClick={() => navigate("/platform/adminHomePage")}
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="submit_button"
                  disabled={error.length !== 0}
                >
                  Submit
                </button>
              </div>
            ) : platform_data === "Media And Entertainment" ? (
              <div className="submit_cancel_button">
                <button
                  onClick={() => navigate("/platform/M&E/adminHomePage")}
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="submit_button"
                  disabled={error.length !== 0}
                >
                  Submit
                </button>
              </div>
            ) : (
              <div className="submit_cancel_button">
                <button
                  onClick={() =>
                    navigate("/platform/" + platform_data + "/adminHomePage")
                  }
                  id="disable"
                  type="button"
                  className="cancel_button"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="submit_button"
                  disabled={error.length !== 0}
                >
                  Submit
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
    </>
  )
}
export default EditUser
