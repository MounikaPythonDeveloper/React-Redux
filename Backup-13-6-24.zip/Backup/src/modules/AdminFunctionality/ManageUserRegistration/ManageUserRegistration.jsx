/**
 * Component: Context
 * File: ManageUserRegistration.jsx
 * Description: This file contains the implementation of the Manage user registration.
                Wrapping all the components into ManagerUserRegistration.
 *  File Used:App.js
 *  Author: Yuvaraj Dakhane
 * */

import React, { useState, useEffect, useReducer } from "react";
import "./ManageUserRegistration.css";
import axios from "axios";
import searchIcon from "../../../../src/assets/images/img/icon _search_normal.svg";
import { Alert, Snackbar } from "@mui/material";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";

import {
  VIEW_USERS_REGISTRATION_API,
  MANAGE_USER_REGISTRATION_API,
  SEARCH_USER_REGISTRATION_API,
} from "../../../services/api";
import Pagination from "../../Automation/Pagination/Pagination";
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent";

//importing the images from ../../../assets/images/ folder.
import declineLogo from "../../../assets/images/wrong.png";
import acceptLogo from "../../../assets/images/right.png";

const ManageUserRegistration = () => {
  //Defined states and data you want to used
  const [details, setDetails] = useState([]);
  const { theme } = useTheme();
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = details.slice(indexOfFirstPost, indexOfLastPost);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [reducerValue, forceUpdate] = useReducer((x) => x + 1, 0);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [selectedAcceptUser, setSelectedAcceptUser] = useState([]);
  const [selectedAcceptUserEmail, setSelectedAcceptUserEmail] = useState([]);
  const [selectedDeclineUser, setSelectedDeclineUser] = useState([]);
  const [selectedDeclineUserEmail, setSelectedDeclineUserEmail] = useState([]);
  const [acceptConfirmation, setAcceptConfirmation] = useState(false);
  const [acceptOpen, setAcceptOpen] = useState(false);

  //Define a function to get the item that we selected for deletion.
  const getUserDeletedItem = (event, Item) => {
    if (event.target.checked === true) {
      setSelectedDeclineUser([...selectedDeclineUser, Item.username]);
      setSelectedDeclineUserEmail([...selectedDeclineUserEmail, Item.email_id]);
    } else {
      setSelectedDeclineUser(
        selectedDeclineUser.filter((val) => val !== Item.username)
      );
      setSelectedDeclineUserEmail(
        selectedDeclineUserEmail.filter((val) => val !== Item.email_id)
      );
    }
  };

  useEffect(() => {
    viewUsersRegistartion(); // <-- (3) invoke in interval callback
    viewUsersRegistartion();
  }, [reducerValue]);

  //Define a function to get the item that we selected for deletion.
  const viewUsersRegistartion = async () => {
    let viewUsersRegistration = "";
    viewUsersRegistration =
      `${VIEW_USERS_REGISTRATION_API}` +
      JSON.stringify({ admin_approval: "Pending" });
    await axios
      .get(viewUsersRegistration)
      .then((response) => {
        setDetails(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Define a function to get the selected item for accepting.
  const getUserAcceptedItem = (event, item) => {
    if (event.target.checked === true) {
      setSelectedAcceptUser([...selectedAcceptUser, item.username]);
      setSelectedAcceptUserEmail([...selectedAcceptUserEmail, item.email_id]);
    } else {
      setSelectedAcceptUser(
        selectedAcceptUser.filter((val) => val !== item.username)
      );
      setSelectedAcceptUserEmail(
        selectedAcceptUserEmail.filter((val) => val !== item.email_id)
      );
    }
  };

  //Define the function for search the user
  const handleSearch = async (searchTerm) => {
    try {
      const response = await axios.get(
        `${SEARCH_USER_REGISTRATION_API}${searchTerm}&admin_approval=Pending`
      );
      setDetails(response.data);
      setCurrentPage(1);
    } catch (error) {
      console.log(error, "Can't Find");
    }
  };

  const enterAPIHandler = function (event) {
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      event.preventDefault();
      handleSearch(searchTerm);
    }
  };

  //Define the function for checking the selected list is > 0 or not
  const handleDecline = () => {
    if (selectedDeclineUser.length !== 0) {
      setOpen(true);
    }
  };

  const handleAccept = () => {
    if (selectedAcceptUser.length !== 0) {
      setAcceptOpen(true);
    }
  };

  // Defined the function for POPUP CLOSE
  const handleClosePopup = function () {
    setOpen(false);
    setSelectedDeclineUser([]);
    setSelectedDeclineUserEmail([]);
  };

  const handleClosePopupAccept = function () {
    setAcceptOpen(false);
    setSelectedAcceptUser([]);
    setSelectedAcceptUserEmail([]);
  };

  //Defined the function for calling the ACCEPT_USER_REGISTRATION API and to approved the list of selected user.
  const acceptUserFunction = async () => {
    console.log("Funtion called");
    const acceptUsers = `${MANAGE_USER_REGISTRATION_API}${JSON.stringify({
      username: selectedAcceptUser,
      email: selectedAcceptUserEmail,
      status: "Approved",
    })}`;
    setAcceptOpen(false);
    await axios
      .post(acceptUsers)
      .then((response) => {
        console.log(response.data.Message, "kanna");
        if (response.data.Message) {
          setAcceptConfirmation(true);
        }
      })
      .catch((error) => {});
    handleClosePopupAccept();
    forceUpdate();
    setSelectedAcceptUser([]);
  };

  //Defined the function for calling the MANAGE_USER_REGISTRATION_API API and to declined the list of selected user.
  const declinedUserFunction = async () => {
    console.log("Funtion called");
    const deleteUsers = `${MANAGE_USER_REGISTRATION_API}${JSON.stringify({
      username: selectedDeclineUser,
      email: selectedDeclineUserEmail,
      status: "Declined",
    })}`;
    await axios
      .post(deleteUsers)
      .then((response) => {
        if (response.data.Message) {
          console.log(response.data.Message, "kanna2");
          setDeleteConfirmation(true);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
    handleClosePopup();
    forceUpdate();
    setSelectedDeclineUser([]);
  };

  useEffect(() => {
    if (searchTerm.length === 0) {
      viewUsersRegistartion();
    }
  }, [searchTerm]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    console.log(e.target.value + "&admin_approval=Pending", "regSearch");
  };

  const handleAlertClose = () => {
    setDeleteConfirmation(false);
  };

  //It will render the MangerUserRegistration components
  return (
    <div>
      <Snackbar
        className={`delete-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={acceptConfirmation}
        autoHideDuration={6000}
        onClose={() => setAcceptConfirmation(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {acceptConfirmation === true && (
          <Alert icon={false}>Mail Sent to All the Users</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`delete-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={deleteConfirmation}
        autoHideDuration={6000}
        onClose={() => setDeleteConfirmation(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {deleteConfirmation === true && (
          <Alert icon={false}>Decline Mail Sent to All the Users</Alert>
        )}
      </Snackbar>
      {/* Define the Snackbar to return the popup message */}
      {/* {deleteConfirmation && (
                        <div className="alertDiv2">
                          <Alert
                            severity="success"
                            variant="filled"
                            onClose={handleAlertClose}
                            icon={false}
                            className="alertBox"
                          >
                            {deleteConfirmation}
                          </Alert>
                        </div>
                      )}
                      {acceptConfirmation && (
                        <div className="alertDiv2">
                          <Alert
                            severity="success"
                            variant="filled"
                            onClose={() => setAcceptConfirmation(false)}
                            icon={false}
                            className="alertBox"
                          >
                            {acceptConfirmation}
                          </Alert>
                        </div>
                      )} */}

      <div
        className={`manage_users_page ${theme === "dark" ? "dark" : "light"}`}
      >
        <div className="manage-user-top">
          <div className="manage-user-heading">Manage User Registrations</div>
          <div className="manage-user-search">
            <input
              className="manage-user-search-input"
              placeholder="search"
              type="text"
              value={searchTerm}
              onKeyUp={enterAPIHandler}
              onChange={handleSearchChange}
            />
            <img
              className="manage-user-search-icon"
              src={searchIcon}
              onClick={() => handleSearch(searchTerm)}
              alt="manage-user-search-icon"
              title="Search"
            />
          </div>
        </div>
      </div>
      <div className="manage-user-lower">
        <div
          className={`manage-user-table-container ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          {details.length === 0 ? (
            <div className="table_empty_message">No Data to Display</div>
          ) : (
            <table className="table">
              <thead className="manage-user-table_head">
                <tr className="manage-user-table_header">
                  <th style={{ width: "6.25rem" }}>S.No</th>
                  <th style={{ width: "12rem" }}>Username</th>
                  <th style={{ width: "22.375rem" }}>Email</th>
                  <th style={{ width: "9.37s5rem" }}>Role</th>
                  <th style={{ width: "3rem" }}>
                    <img
                      onClick={handleAccept}
                      src={acceptLogo}
                      style={{ height: "20px" }}
                      alt="accept-button"
                      title="Accept"
                    />
                  </th>
                  <th style={{ width: "6.25rem" }}>
                    <img
                      onClick={handleDecline}
                      src={declineLogo}
                      style={{ height: "20px" }}
                      alt="decline-Button"
                      title="Decline"
                    />
                  </th>
                </tr>
              </thead>
              <tbody className="table_body">
                {currentPosts.map((item, index) => {
                  return (
                    <>
                      <tr>
                        <td>{indexOfFirstPost + index + 1}</td>
                        <td>{item.username}</td>
                        <td>{item.email_id}</td>
                        <td>{item.user_privilege}</td>
                        <td className="manageuserregistration-checkbox">
                          <input
                            type="checkbox"
                            checked={selectedAcceptUser.includes(item.username)}
                            onChange={(event) =>
                              getUserAcceptedItem(event, item)
                            }
                            disabled={selectedDeclineUser.includes(
                              item.username
                            )}
                          />
                        </td>
                        <td className="manageuserregistration-checkbox">
                          <input
                            type="checkbox"
                            checked={selectedDeclineUser.includes(
                              item.username
                            )}
                            onChange={(event) =>
                              getUserDeletedItem(event, item)
                            }
                            disabled={selectedAcceptUser.includes(
                              item.username
                            )}
                          />
                        </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <PopupComponent
          open={acceptOpen}
          text="Are you sure you want to accept all users?"
          handleClose={handleClosePopupAccept}
          functionHandle={acceptUserFunction}
        />
        <PopupComponent
          open={open}
          text="Are you sure you want to decline the selected User's?"
          handleClose={handleClosePopup}
          functionHandle={declinedUserFunction}
        />

        <Pagination
          currentPage={currentPage}
          postsPerPage={postsPerPage}
          totalPosts={details.length}
          paginate={paginate}
        />
      </div>
    </div>
  );
};

export default ManageUserRegistration;
