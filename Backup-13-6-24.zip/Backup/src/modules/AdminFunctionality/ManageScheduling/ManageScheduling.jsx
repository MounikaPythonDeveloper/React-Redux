/**
 * Component: Context
 * File: ManageScheduling.jsx
 * Description: This file contains the implementation of the manage scheduling admin functionality.
                Wrapping all the components into  manage scheduling.
 *  File Used:App.js
 *  Author: R Sanjana
 * */

import React, { useEffect, useReducer, useState } from "react";
import axios from "axios";
import "./ManageScheduling.css";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";

import Pagination from "../../Automation/Pagination/Pagination";
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent";
import {
  MANAGE_SCHEDULING_API,
  MANAGE_SCHEDULING_SEARCH_API,
  MANAGE_SCHEDULING_DELETE_API,
} from "../../../services/api";
import { Alert, Snackbar } from "@mui/material";

//importing the images from ../../../assets/images/ folder.
import searchIcon from "../../../assets/images/img/icon _search_normal.svg";
import deleteuserlogo from "../../../assets/images/img/delete_user_icon.svg";

export default function ManageScheduling() {
  //Defined states and data you want to used
  const [open, setOpen] = useState(false);
  const { theme } = useTheme();
  const [searchValue, setSearchValue] = useState("");
  const [schedulingData, setSchedulingData] = useState([]);
  const [reducerValue, forceUpdate] = useReducer((x) => x + 1, 0);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = schedulingData.slice(indexOfFirstPost, indexOfLastPost);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const [deletedConfirmation, setDeletedConfirmation] = useState(false);
  const [checkScheduleItem, SetCheckScheduleItem] = useState([]);

  useEffect(() => {
    if (searchValue.length === 0 || checkScheduleItem.length === 0) {
      ManageSchedulingData();
    }
  }, [reducerValue, searchValue, checkScheduleItem]);

  //Define a api function to fetch the scheduled events through API call & display it in the table
  const ManageSchedulingData = async () => {
    let scheduled_url = "";
    scheduled_url = `${MANAGE_SCHEDULING_API}`;
    await axios
      .get(scheduled_url)
      .then((response) => {
        console.log(response.data, "MANAGE scheduling");
        setSchedulingData(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Define a function to search the required scheduled events in the table
  const searchSchApi = async (searchTerm) => {
    let searchschData = "";
    searchschData = `${MANAGE_SCHEDULING_SEARCH_API}${searchTerm}`;
    await axios
      .post(searchschData)
      .then((response) => {
        setSchedulingData(response.data);
        console.log("Schapidata", response.data);
        setCurrentPage(1);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const enterkeyAPIHandler = (event) => {
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      event.preventDefault();
      searchSchApi(searchValue);
    }
  };

  //Define a api function to delete the selected item.
  const manageSchDeletetHandler = async () => {
    let deleteScheduledItems = "";
    deleteScheduledItems =
      `${MANAGE_SCHEDULING_DELETE_API}` +
      `${JSON.stringify({
        execution_id: checkScheduleItem,
      })}`;
    await axios
      .post(deleteScheduledItems)
      .then((response) => {
        setDeletedConfirmation(response.data);
        console.log("deleted sch item", response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    SetCheckScheduleItem("");
    handleClosePopup();
    forceUpdate();
  };

  //Define a function to get the selected item for deletion.
  const getScheduledItem = function (event, value) {
    console.log(value, "getReservationItem");
    if (event.target.checked === true) {
      SetCheckScheduleItem([...checkScheduleItem, value]);
      console.log(checkScheduleItem, "checkReservationItem");
    } else {
      SetCheckScheduleItem(checkScheduleItem.filter((val) => val !== value));
    }
  };

  // POPUP OPEN FUNCTION
  const handleOpen = function () {
    if (checkScheduleItem.length !== 0) {
      setOpen(true);
      console.log("handle open");
    }
  };

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    SetCheckScheduleItem([]);
    setOpen(false);
  };

  //It will render the ManageScheduling component
  return (
    <>
      {/* Define the Snackbar to return the popup message */}
      <Snackbar
        className={`delete-Scheduled-alert ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={deletedConfirmation}
        autoHideDuration={6000}
        onClose={() => setDeletedConfirmation(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {deletedConfirmation === true && (
          <Alert icon={false}>Deleted the selected Scheduled item</Alert>
        )}
      </Snackbar>
      <div
        className={`manage-sch-container ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div className="manage-sch-top">
          <div className="manage-sch-heading">Manage Scheduling</div>
          <div className="manage-sch-search">
            <input
              className="manage-sch-search-input"
              placeholder="search"
              type="text"
              // value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyUp={enterkeyAPIHandler}
            />
            <img
              className="manage-sch-search-icon"
              src={searchIcon}
              alt="Search"
              onClick={() => searchSchApi(searchValue)}
              title="Search"
            />
          </div>
        </div>
        <div className="manage-sch-lower">
          <div
            className={`manage-sch-table-container ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            {schedulingData.length === 0 ? (
              <div className="table-empty-message">No Data Available</div>
            ) : (
              <table class="table">
                <thead className="manage-sch-table_head ">
                  <tr className="manage-sch-table_header">
                    <th>S.No</th>
                    <th>Device Name</th>
                    <th>Schedule type</th>
                    <th>Start time</th>
                    {/* <th>End time</th> */}
                    <th>Test case</th>
                    <th>Scheduled By</th>
                    <th>
                      <img
                        className="magage-res-icon"
                        onClick={handleOpen}
                        alt="Delete User"
                        src={deleteuserlogo}
                        title="Delete"
                      />
                    </th>
                  </tr>
                </thead>

                <tbody className="table_body">
                  {currentPosts.map((scheduling, index) => {
                    return (
                      <tr>
                        <td>{indexOfFirstPost + index + 1}</td>
                        <td key={scheduling.device_name}>
                          {scheduling.device_name}
                        </td>
                        <td>{scheduling.schedule_type}</td>
                        <td>{scheduling.start_time}</td>
                        {/* <td>{scheduling.end_time}</td> */}
                        <td>{scheduling.test_case}</td>
                        <td>{scheduling.username}</td>
                        <td className="managescheduling-checkbox">
                          <input
                            type="checkbox"
                            checked={checkScheduleItem.includes(
                              scheduling.execution_id
                            )}
                            onChange={(event) =>
                              getScheduledItem(event, scheduling.execution_id)
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
          <PopupComponent
            open={open}
            text="Are you sure you want to delete?"
            handleClose={handleClosePopup}
            functionHandle={manageSchDeletetHandler}
          />
          {schedulingData.length !== 0 && (
            <Pagination
              currentPage={currentPage}
              postsPerPage={postsPerPage}
              totalPosts={schedulingData.length}
              paginate={paginate}
            />
          )}
        </div>
      </div>
    </>
  );
}
