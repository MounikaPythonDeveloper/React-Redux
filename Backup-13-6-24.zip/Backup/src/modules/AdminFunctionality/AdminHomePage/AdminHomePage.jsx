import React, { useState } from "react";
import "./AdminHomePage.css";
import ManageUsers from "../ManageUsers/ManageUsers";
import ManageDevices from "../ManageDevices/ManageDevices";
import ManageReservations from "../ManageReservations/ManageReservations";
import ManageUserRegistration from "../ManageUserRegistration/ManageUserRegistration";
import ManageScheduling from "../ManageScheduling/ManageScheduling";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";
function AdminHomePage() {
  const { theme } = useTheme();
  const [manageComponent, setManageComponent] = useState("ManageUsersActive");
  const manageUsersHandle = function () {
    setManageComponent("ManageUsersActive");
  };
  const manageDevicesHandle = function () {
    setManageComponent("ManageDevicesActive");
  };
  const manageReservationsHandle = function () {
    setManageComponent("ManageReservationsActive");
  };
  const ManageUserRegistartionHandle = () => {
    setManageComponent("ManageUserRegistrationActive");
  };
  const ManageSchedulingHandle = () => {
    setManageComponent("ManageSchedulingActive");
  };
  const location = useLocation();
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnChangePasswordPage =
    location.pathname === "/platform/viewprofile/changepassword";

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  return (
    <>
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnViewProfile ||
      isOnChangePasswordPage ||
      isOnAdminPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Typography color="#0D6EFD">Admin Home Page</Typography>
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          {platform_data === "Media And Entertainment" ? (
            <Link to="/platform" onDragStart={preventDragHandler}>
              M&E
            </Link>
          ) : (
            <Link Link to="/platform">
              {platform_data}
            </Link>
          )}
          <Typography color="#0D6EFD">Admin Home Page</Typography>
        </Breadcrumbs>
      )}
      <div className="admin-home-container">
        <div className="admin-home-left">
          <div className="admin-list">
            <button
              className={`admin-btn ${
                manageComponent === "ManageUsersActive" ? "active" : ""
              } ${theme === "dark" ? "dark" : "light"} `}
              onClick={manageUsersHandle}
            >
              Manage Users
            </button>
            <button
              className={`admin-btn ${
                manageComponent === "ManageDevicesActive" ? "active" : ""
              } ${theme === "dark" ? "dark" : "light"}`}
              onClick={manageDevicesHandle}
            >
              Manage Devices
            </button>
            <button
              className={`admin-btn ${
                manageComponent === "ManageReservationsActive" ? "active" : ""
              } ${theme === "dark" ? "dark" : "light"}`}
              onClick={manageReservationsHandle}
            >
              Manage Reservations
            </button>
            <button
              className={`admin-btn ${
                manageComponent === "ManageUserRegistrationActive"
                  ? "active"
                  : ""
              } ${theme === "dark" ? "dark" : "light"}`}
              onClick={ManageUserRegistartionHandle}
            >
              Manage User Registrations
            </button>
            <button
              className={`admin-btn ${
                manageComponent === "ManageSchedulingActive" ? "active" : ""
              } ${theme === "dark" ? "dark" : "light"}`}
              onClick={ManageSchedulingHandle}
            >
              Manage Scheduling
            </button>
          </div>
        </div>
        <div className="admin-home-right">
          {manageComponent === "ManageUsersActive" && <ManageUsers />}
          {manageComponent === "ManageDevicesActive" && <ManageDevices />}
          {manageComponent === "ManageReservationsActive" && (
            <ManageReservations />
          )}
          {manageComponent === "ManageUserRegistrationActive" && (
            <ManageUserRegistration />
          )}
          {manageComponent === "ManageSchedulingActive" && <ManageScheduling />}
        </div>
      </div>
    </>
  );
}
export default AdminHomePage;
