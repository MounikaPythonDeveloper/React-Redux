/**
 * Component: Context
 * File: AddDevice.jsx
 * Description: This file contains the implementation of the Add device admin functionality.
                Wrapping all the components into Add device.
 *  File Used:App.js
 *  Author: R Sanjana
 * */

import React, { useState, useEffect } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { useNavigate, useLocation, useParams, Link } from "react-router-dom";
import "./AddDevice.css";
import { Form } from "react-bootstrap";
import { Alert, Button, Snackbar } from "@mui/material";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext";
import {
  CHECK_ADD_DEVICE_ATTRIBUTES_API,
  FETCH_ADD_DEVICE_ATTRIBUTES_API,
  FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API,
  SUBMIT_ADD_DEVICE_ATTRIBUTES_API,
  SUBMIT_EDIT_DEVICE_ATTRIBUTES_API,
} from "../../../../services/api";

export default function AddDevice() {
  const { theme } = useTheme();
  let navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const testing = [
    "Manual Testing",
    "Automation Testing",
    "Manual and Automation Testing",
  ];

  //Defined states and data that needs to be used
  const [activeSection, setActiveSection] = useState(0);
  const [addDeviceConfirmation, setAddDeviceConfirmation] = useState("");
  const [editDeviceConfirmation, setEditDeviceConfirmation] = useState("");
  const [deviceValid, setDeviceValid] = useState(true);
  const [agentIdValid, setAgentIdValid] = useState(true);
  const [locationIdValid, setLocationIdValid] = useState(true);
  const [devicePlatforms, setDevicePlatforms] = useState([]);
  const [deviceCategories, setDeviceCategories] = useState([]);
  const [deviceBrands, setDeviceBrands] = useState([]);
  const [deviceModels, setDeviceModels] = useState([]);
  const [deviceCountries, setDeviceCountries] = useState([]);
  const [deviceCities, setDeviceCities] = useState([]);
  const [deviceLabs, setDeviceLabs] = useState([]);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
    trigger,
    reset,
  } = useForm();

  let isEdit = id === undefined ? false : true;
  let watchPlatform = watch("platform");
  let watchCategory = watch("device_category");
  let watchBrand = watch("brand_name");
  let watchModel = watch("model_name");
  let watchCountry = watch("country");
  let watchCity = watch("city");
  let watchLab = watch("lab_name");

  useEffect(() => {
    getDevicePlatforms();
    getDeviceCountries();
  }, []);

  useEffect(() => {
    if (isEdit) {
      getDeviceCategory(location.state.data.platform);
      getDeviceBrand(location.state.data.device_category);
      getDeviceModel(location.state.data.brand_name);
      getDeviceCities(location.state.data.country);
      getDeviceLabs(location.state.data.city);
      setValue("location_id", location.state.data.location_id);
      setValue("device_name", location.state.data.device_name);
      setValue("manufacturer", location.state.data.manufacturer);
      setValue("model_number", location.state.data.model_number);
      setValue("serial_number", location.state.data.serial_number);
      setValue("device_connectivity", location.state.data.device_connectivity);
      setValue("ip_address", location.state.data.ip_address);
      setValue("os_name", location.state.data.os_name);
      setValue("os_version", location.state.data.os_version);
      setValue("imei", location.state.data.imei);
      setValue("phone_number", location.state.data.phone_number);
      setValue("carrier", location.state.data.carrier);
      setValue("agent_id", location.state.data.agent_id);
      setValue("proxy_url", location.state.data.proxy_url);
      setValue("proxy_listen_port", location.state.data.proxy_listen_port);
      setValue("hdmi_port", location.state.data.hdmi_port);
      setValue("ir_port", location.state.data.ir_port);
      setValue("rcu_db", location.state.data.rcu_db);
      setValue(
        "reservation_category",
        location.state.data.reservation_category
      );
    }
  }, []);

  //Defined a function to validate all the user input feilds
  const validationHandler = async () => {
    let isValid = false;
    if (activeSection === 0) {
      isValid = await trigger([
        "device_name",
        "platform",
        "device_category",
        "brand_name",
        "model_name",
        "add_category",
        "add_brand",
        "add_model",
        "country",
        "city",
        "lab_name",
        "location_id",
        "add_country",
        "add_city",
        "add_lab",
      ]);
    } else {
      isValid = await trigger([
        "device_connectivity",
        "ip_address",
        "manufacturer",
        "model_number",
        "os_name",
        "os_version",
        "serial_number",
        "imei",
        "phone_number",
        "carrier",
      ]);
    }
    isValid && deviceValid && setActiveSection(activeSection + 1);
  };

  //Defined a api call function to validate devicename from database
  const checkDevicename = async (e) => {
    console.log("checkdevice", e);
    await axios
      .get(
        `${CHECK_ADD_DEVICE_ATTRIBUTES_API}+${JSON.stringify({
          device_name: e.target.value,
        })}`
      )
      .then((response) => {
        console.log("check device_res", response);
        setDeviceValid(response.data);
      })

      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to validate agentId from database
  const checkAgentId = async (e) => {
    console.log("checkagent", e);
    await axios
      .get(
        `${CHECK_ADD_DEVICE_ATTRIBUTES_API}+${JSON.stringify({
          agent_id: e.target.value,
        })}`
      )
      .then((response) => {
        console.log("check agent_res", response);
        setAgentIdValid(response.data);
      })

      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to validate locationId from database
  const checkLocationId = async (e) => {
    let isLocationValid = await trigger("location_id");
    console.log("isLocationValid", isLocationValid);
    if (isLocationValid) {
      await axios
        .get(
          `${CHECK_ADD_DEVICE_ATTRIBUTES_API}+${JSON.stringify({
            location_id: e.target.value,
          })}`
        )
        .then((response) => {
          console.log("check loc_res", response);
          setLocationIdValid(response.data);
        })
        .catch((error) => {
          console.log(error, "error");
        });
    }
  };
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnViewProfile = location.pathname === "/platform/viewprofile";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnAdminAddDevicePage =
    location.pathname === "/platform/adminHomePage/addDevice";
  const isOnAdminEditDevicePage =
    location.pathname === "/platform/adminHomePage/editDevice/:id";
  const isOnAdminEditDevicePage1 =
    location.pathname ===
    "/platform/" + platform_data + "adminHomePage/editDevice/:id";

  //Defined a api call function to display platforms in the platform dropdown feild
  const getDevicePlatforms = async () => {
    await axios
      .get(`${FETCH_ADD_DEVICE_ATTRIBUTES_API}="platforms"`)
      .then((response) => {
        console.log("check platform", response.data);
        setDevicePlatforms(response.data.platform);
        console.log("check platform", response.data.platform); //array value stored
        if (isEdit) {
          setTimeout(() => {
            setValue("platform", location.state.data.platform);
          }, 50);
        }
      })
      .catch((error) => {
        alert(error);
        console.log(error, "error");
      });
  };

  //Defined a api call function to display device categories in the category dropdown feild
  const getDeviceCategory = async (platform) => {
    reset((formValues) => ({
      ...formValues,
      device_category: "",
      brand_name: "",
      model_name: "",
    }));
    setDeviceBrands([]);
    setDeviceModels([]);
    await axios
      .get(
        `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
          platform: platform,
        })}`
      )
      .then((response) => {
        console.log("check categ", response.data);
        setDeviceCategories(response.data.device_category);
        if (isEdit) {
          setTimeout(() => {
            setValue("device_category", location.state.data.device_category);
          }, 50);
        }
      })

      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to display device brands in the brand dropdown feild
  const getDeviceBrand = async (category) => {
    reset((formValues) => ({
      ...formValues,
      brand_name: "",
      model_name: "",
    }));
    setDeviceModels([]);
    await axios
      .get(
        `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
          platform: isEdit ? location.state.data.platform : watchPlatform,
          device_category: category,
        })}`
      )
      .then((response) => {
        console.log("check brand", response.data);
        setDeviceBrands(response.data.brand_name);
        if (isEdit) {
          setTimeout(() => {
            setValue("brand_name", location.state.data.brand_name);
          }, 50);
        }
      })

      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to display device models in the model dropdown feild
  const getDeviceModel = async (brand) => {
    console.log(watchCategory, "watchCategory");
    await axios
      .get(
        `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
          platform: isEdit ? location.state.data.platform : watchPlatform,
          device_category: isEdit
            ? location.state.data.device_category
            : watchCategory,
          brand_name: brand,
        })}`
      )
      .then((response) => {
        console.log("check models", response.data);
        setDeviceModels(response.data.model_name);
        if (isEdit) {
          setTimeout(() => {
            setValue("model_name", location.state.data.model_name);
          }, 50);
        }
      })

      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to display countries in the country dropdown feild
  const getDeviceCountries = async () => {
    await axios
      .get(`${FETCH_ADD_DEVICE_ATTRIBUTES_API}="country"`)
      .then((response) => {
        console.log("check countries", response.data);
        setDeviceCountries(response.data.country);
        if (isEdit) {
          setTimeout(() => {
            setValue("country", location.state.data.country);
          }, 50);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to display cities in the city dropdown feild
  const getDeviceCities = async (country) => {
    reset((formValues) => ({
      ...formValues,
      city: "",
      lab_name: "",
      location_id: "",
    }));
    setDeviceLabs([]);
    await axios
      .get(
        `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
          country: country,
        })}`
      )
      .then((response) => {
        console.log("check cities", response.data);
        setDeviceCities(response.data.city);
        if (isEdit) {
          setTimeout(() => {
            setValue("city", location.state.data.city);
          }, 50);
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  //Defined a api call function to display labs in the lab dropdown feild
  const getDeviceLabs = async (city) => {
    await axios
      .get(
        `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
          country: isEdit ? location.state.data.country : watchCountry,
          city: city,
        })}`
      )
      .then((response) => {
        console.log("check labs", response.data);
        setDeviceLabs(response.data.lab_name);
        if (isEdit) {
          setTimeout(() => {
            setValue("lab_name", location.state.data.lab_name);
          }, 50);
        }
      });
  };

  //Defined a api call function to display locationId in the locationId dropdown feild
  const getLocationId = async (e) => {
    console.log("aqw", e.target.value);
    console.log("aqwe", watchLab);

    e.target.value !== "Other" &&
      (await axios
        .get(
          `${FETCH_ADD_DEVICE_BASED_ON_ATTRIBUTES_API}${JSON.stringify({
            lab_name: e.target.value,
          })}`
        )
        .then((response) => {
          console.log("loc-id", response);
          setValue("location_id", response.data.location_id[0]);
        })
        .catch((error) => {
          console.log(error, "error");
        }));
  };

  //Defined a api call function to send all the user entered details to backend to complete add device functionality
  const onSubmit = async (data) => {
    console.log("jsondata", data);
    var submitString = {
      device_name: data.device_name,
      platform: data.platform !== "Other" ? data.platform : data.add_platform,
      device_category:
        data.device_category !== "Other"
          ? data.device_category
          : data.add_category,
      brand_name:
        data.brand_name !== "Other" ? data.brand_name : data.add_brand,
      model_name:
        data.model_name !== "Other" ? data.model_name : data.add_model,
      country: data.country !== "Other" ? data.country : data.add_country,
      city: data.city !== "Other" ? data.city : data.add_city,
      lab_name: data.lab_name !== "Other" ? data.lab_name : data.add_lab,
      location_id: data.location_id,
      manufacturer: data.manufacturer,
      model_number: data.model_number,
      serial_number: data.serial_number,
      device_connectivity: data.device_connectivity,
      ip_address: data.ip_address,
      os_name: data.os_name,
      os_version: data.os_version,
      imei: data.imei,
      phone_number: data.phone_number,
      carrier: data.carrier,
      agent_id: data.agent_id,
      hdmi_port: data.hdmi_port === undefined ? "" : data.hdmi_port,
      ir_port: data.ir_port === undefined ? "" : data.ir_port,
      rcu_db: data.rcu_db === undefined ? "" : data.rcu_db,
      proxy_url: data.proxy_url,
      proxy_listen_port: data.proxy_listen_port,
      // build_version: data.build_version,
      reservation_category: data.reservation_category,
    };
    console.log(submitString, "submitstring");
    if (isEdit) {
      await axios
        .post(
          `${SUBMIT_EDIT_DEVICE_ATTRIBUTES_API}${JSON.stringify(submitString)}`
        )
        .then((response) => {
          console.log(response, "EDITDEVICE");
          setEditDeviceConfirmation(response.data.valid);
          if (response.data.valid === "true") {
            setTimeout(() => {
              if (isOnPlatformPage || isOnAboutPage || isOnAdminPage) {
                navigate("/platform/adminHomePage");
              } else if (platform_data === "Media And Entertainment") {
                navigate("/platform/M&E/adminHomePage");
              } else {
                navigate("/platform/" + platform_data + "/adminHomePage");
              }
            }, 2000);
          }
        })
        .catch((error) => {
          alert(error, "Backend error");
          console.log(error, "error");
        });
    } else {
      await axios
        .post(
          `${SUBMIT_ADD_DEVICE_ATTRIBUTES_API}${JSON.stringify(submitString)}`
        )
        .then((response) => {
          console.log(response, "ADDDEVICE");
          setAddDeviceConfirmation(response.data.valid);
          if (response.data.valid === "true") {
            setTimeout(() => {
              if (isOnPlatformPage || isOnAboutPage || isOnAdminPage) {
                navigate("/platform/adminHomePage");
              } else if (platform_data === "Media And Entertainment") {
                navigate("/platform/M&E/adminHomePage");
              } else {
                navigate("/platform/" + platform_data + "/adminHomePage");
              }
            }, 2000);
          }
        })
        .catch((error) => {
          alert(error, "Backend error");
          console.log(error, "error");
        });
    }
  };

  const preventDragHandler = (e) => {
    e.preventDefault();
  };

  //It will render the Add device functionality component
  return (
    <>
      {/* Defined the Snackbar to return the popup message */}
      {isOnPlatformPage ||
      isOnAboutPage ||
      isOnAdminAddDevicePage ||
      isOnAdminPage ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform/adminHomePage"} onDragStart={preventDragHandler}>
            Admin Home Page
          </Link>
          {isOnAdminAddDevicePage ? (
            <Typography color="#0D6EFD">Add Device</Typography>
          ) : (
            <Typography color="#0D6EFD">Edit Device</Typography>
          )}
        </Breadcrumbs>
      ) : platform_data === "Media And Entertainment" ? (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            M&E
          </Link>
          <Link
            to={"/platform/M&E/adminHomePage"}
            onDragStart={preventDragHandler}
          >
            Admin Home Page
          </Link>
          {isEdit === false ? (
            <Typography color="#0D6EFD">Add Device</Typography>
          ) : (
            <Typography color="#0D6EFD">Edit Device</Typography>
          )}
        </Breadcrumbs>
      ) : (
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            Platform
          </Link>
          <Link to={"/platform"} onDragStart={preventDragHandler}>
            {platform_data}
          </Link>
          <Link
            to={"/platform/" + platform_data + "/adminHomePage"}
            onDragStart={preventDragHandler}
          >
            Admin Home Page
          </Link>
          {isEdit === false ? (
            <Typography color="#0D6EFD">Add Device</Typography>
          ) : (
            <Typography color="#0D6EFD">Edit Device</Typography>
          )}
        </Breadcrumbs>
      )}
      <Snackbar
        open={addDeviceConfirmation}
        autoHideDuration={2000}
        className="add-device-confirmation"
        onClose={() => setAddDeviceConfirmation("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {addDeviceConfirmation === "true" ? (
          <Alert severity="success">Device Details added successfully</Alert>
        ) : addDeviceConfirmation === "false" ? (
          <Alert severity="error">
            Server Error, please try again after sometime
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <Snackbar
        open={editDeviceConfirmation}
        autoHideDuration={2000}
        className="add-device-confirmation"
        onClose={() => setEditDeviceConfirmation("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {editDeviceConfirmation === "true" ? (
          <Alert severity="success">Device Details updated successfully</Alert>
        ) : editDeviceConfirmation === "false" ? (
          <Alert severity="error">
            Server Error, please try again after sometime
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <div
        className={`Add-device-page  ${theme === "dark" ? "dark" : "light"}`}
      >
        <h1>{isEdit ? "Edit Device" : "Add Device"}</h1>
        <div className="Add-device-container">
          <form onSubmit={handleSubmit(onSubmit)}>
            {activeSection === 0 && (
              <div className="Add-device-section">
                <div className="Add-device-block">
                  <h2>Device Details</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Device Name*</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Ex:Apple TV"
                          autocomplete="off"
                          {...register("device_name", {
                            required: {
                              value: true,
                              message: "This field is required",
                            },
                            maxLength: {
                              value: 24,
                              message:
                                "Device name cannot exceed 24 characters",
                            },
                            pattern: {
                              value: /^[a-z0-9 ]+$/i,
                              message: "Alpahanumeric characters only",
                            },
                            onChange: async () => {
                              setDeviceValid(true);
                              await trigger("device_name");
                            },
                            onBlur: checkDevicename,
                          })}
                          disabled={isEdit}
                        />
                        {errors.device_name && (
                          <span className="error-msg">
                            {errors.device_name.message}
                          </span>
                        )}

                        {deviceValid === false && (
                          <span className="error-msg">
                            Device name already exists
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Platform*</Form.Label>
                        <Form.Select
                          {...register("platform", {
                            required: true,
                            onChange: (e) => getDeviceCategory(e.target.value),
                          })}
                        >
                          <option value="">Select a Platform</option>
                          {devicePlatforms.length > 0 ? (
                            devicePlatforms.map((platform) => (
                              <option value={platform} key={platform}>
                                {platform}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.platform && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Category*</Form.Label>
                        <Form.Select
                          {...register("device_category", {
                            required: true,
                            onChange: (e) => getDeviceBrand(e.target.value),
                          })}
                        >
                          <option value="">Select a Category</option>
                          {deviceCategories.length > 0 ? (
                            deviceCategories.map((category) => (
                              <option value={category} key={category}>
                                {category}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.device_category && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Brand*</Form.Label>
                        <Form.Select
                          {...register("brand_name", {
                            required: true,
                            onChange: (e) => getDeviceModel(e.target.value),
                          })}
                        >
                          <option value="">Select a brand</option>
                          {deviceBrands.length > 0 ? (
                            deviceBrands.map((brand) => (
                              <option value={brand} key={brand}>
                                {brand}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.brand_name && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Model*</Form.Label>
                        <Form.Select
                          {...register("model_name", { required: true })}
                        >
                          <option value="">Select a model</option>
                          {deviceModels.length > 0 ? (
                            deviceModels.map((model) => (
                              <option value={model} key={model}>
                                {model}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.model_name && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    {watchPlatform === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Platform*</Form.Label>
                          <Form.Control
                            type="text"
                            autocomplete="off"
                            placeholder="Ex:Media & Entertainment"
                            {...register("add_platform", { required: true })}
                          />
                          {errors.add_platform && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {watchCategory === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Category*</Form.Label>
                          <Form.Control
                            type="text"
                            autocomplete="off"
                            placeholder="Ex:Android"
                            {...register("add_category", { required: true })}
                          />
                          {errors.add_category && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {watchBrand === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Brand*</Form.Label>
                          <Form.Control
                            autocomplete="off"
                            type="text"
                            placeholder="Ex:OnePlus"
                            {...register("add_brand", { required: true })}
                          />
                          {errors.add_brand && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {watchModel === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Model*</Form.Label>
                          <Form.Control
                            autocomplete="off"
                            type="text"
                            placeholder="Ex:OnePlus 10R"
                            {...register("add_model", { required: true })}
                          />
                          {errors.add_model && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                  </div>
                </div>
                <div className="Add-device-block">
                  <h2>Location Details</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Country*</Form.Label>
                        <Form.Select
                          {...register("country", {
                            required: true,
                            onChange: (e) => getDeviceCities(e.target.value),
                          })}
                        >
                          <option value="">Select country</option>
                          {deviceCountries.length > 0 ? (
                            deviceCountries.map((country) => (
                              <option value={country} key={country}>
                                {country}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.country && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>City*</Form.Label>
                        <Form.Select
                          {...register("city", {
                            required: true,
                            onChange: (e) => getDeviceLabs(e.target.value),
                          })}
                        >
                          <option value="">Select city</option>
                          {deviceCities.length > 0 ? (
                            deviceCities.map((city) => (
                              <option value={city} key={city}>
                                {city}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.city && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Lab*</Form.Label>
                        <Form.Select
                          {...register("lab_name", {
                            required: true,
                            onChange: getLocationId,
                          })}
                        >
                          <option value="">Select labname</option>
                          {deviceLabs.length > 0 ? (
                            deviceLabs.map((lab) => (
                              <option value={lab} key={lab}>
                                {lab}
                              </option>
                            ))
                          ) : (
                            <option disabled>No data</option>
                          )}
                          <option value="Other">Other</option>
                        </Form.Select>
                        {errors.lab_name && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Location Id*</Form.Label>
                        <Form.Control
                          autocomplete="off"
                          type="text"
                          placeholder="EX:IN_001"
                          {...register("location_id", {
                            required: {
                              value: true,
                              message: "This field is required",
                            },
                            pattern: {
                              value: /^[A-Z]{2,3}_[0-9]{3}$/,
                              message: "Invalid Location Id",
                            },

                            onBlur: checkLocationId,
                          })}
                          disabled={
                            watchCountry !== "Other"
                              ? true
                              : false && watchCity !== "Other"
                              ? true
                              : false && watchLab !== "Other"
                              ? true
                              : false
                          }
                        />
                      </Form.Group>
                      {errors.location_id && (
                        <span className="error-msg">
                          {errors.location_id.message}
                        </span>
                      )}
                      {locationIdValid === false && (
                        <span className="error-msg">
                          Location Id already exists
                        </span>
                      )}
                    </div>

                    {watchCountry === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Country*</Form.Label>
                          <Form.Control
                            autocomplete="off"
                            type="text"
                            placeholder="Ex:India"
                            {...register("add_country", { required: true })}
                          />
                          {errors.add_country && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {watchCity === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add City*</Form.Label>
                          <Form.Control
                            autocomplete="off"
                            type="text"
                            placeholder="Ex:Bengaluru"
                            {...register("add_city", { required: true })}
                          />
                          {errors.add_city && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {watchLab === "Other" && (
                      <div className="col-md-6">
                        <Form.Group>
                          <Form.Label>Add Lab*</Form.Label>
                          <Form.Control
                            type="text"
                            autocomplete="off"
                            placeholder="Ex:Manyata"
                            {...register("add_lab", { required: true })}
                          />
                          {errors.add_lab && (
                            <span className="error-msg">
                              This field is required
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            {activeSection === 1 && (
              <div className="Add-device-section">
                <div className="Add-device-block">
                  <h2>Device Info</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Manufacturer</Form.Label>
                        <Form.Control
                          autocomplete="off"
                          type="text"
                          placeholder="EX:Apple Inc."
                          {...register("manufacturer")}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Model Number</Form.Label>
                        <Form.Control
                          autocomplete="off"
                          type="text"
                          placeholder="Ex:A1625 (32GB)"
                          {...register("model_number")}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Serial Number</Form.Label>
                        <Form.Control
                          autocomplete="off"
                          type="text"
                          placeholder="Ex:YH03G5936"
                          {...register("serial_number", {
                            pattern: {
                              value: /^[a-z0-9]+$/i,
                              message: "Invalid Serial number",
                            },
                          })}
                        />
                        {errors.serial_number && (
                          <span className="error-msg">
                            {errors.serial_number.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Network</Form.Label>
                        <Form.Control
                          autocomplete="off"
                          type="text"
                          placeholder="EX:wifi"
                          {...register("device_connectivity")}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>IP address</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="EX:192.168.1.112"
                          {...register("ip_address", {
                            pattern: {
                              value:
                                /^([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])$/,
                              message: "Invalid IP Address",
                            },
                          })}
                        />
                        {errors.ip_address && (
                          <span className="error-msg">
                            {errors.ip_address.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>OS Name</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="EX:tvOS"
                          {...register("os_name")}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>OS Version</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="EX:16.1(20K71)"
                          {...register("os_version")}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>IMEI</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="Ex:86880305241609"
                          {...register("imei", {
                            pattern: {
                              value: /^[0-9]+$/i,
                              message: "Invalid IMEI",
                            },
                            minLength: {
                              value: 14,
                              message: "Invalid IMEI",
                            },
                            maxLength: {
                              value: 15,
                              message: "Invalid IMEI",
                            },
                          })}
                        />
                        {errors.imei && (
                          <span className="error-msg">
                            {errors.imei.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Phone Number</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="Ex:987654321"
                          {...register("phone_number", {
                            pattern: {
                              value: /^[0-9]+$/i,
                              message: "Invalid Phone number",
                            },
                            minLength: {
                              value: 10,
                              message: "Invalid Phone number",
                            },
                            maxLength: {
                              value: 10,
                              message: "Invalid Phone number",
                            },
                          })}
                        />
                        {errors.phone_number && (
                          <span className="error-msg">
                            {errors.phone_number.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Carrier</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="Ex:Airtel"
                          {...register("carrier")}
                        />
                      </Form.Group>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {activeSection === 2 && (
              <div className="Add-device-section">
                <div className="Add-device-block">
                  <h2>Agent Details</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Test Machine Id*</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="Ex:agent4dut3"
                          {...register("agent_id", {
                            required: {
                              value: true,
                              message: "This field is required",
                            },
                            pattern: {
                              value: /^[a-z0-9]+$/i,
                              message: "Invalid test machine id",
                            },
                            onChange: async () => {
                              setAgentIdValid(true);
                              await trigger("agent_id");
                            },
                            onBlur: checkAgentId,
                          })}
                        />
                        {errors.agent_id && (
                          <span className="error-msg">
                            {errors.agent_id.message}
                          </span>
                        )}
                        {agentIdValid === false && (
                          <span className="error-msg">
                            Test Machine Id already exists
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    {watchCategory !== "Android" &&
                      watchCategory !== "Android Tab" &&
                      watchCategory !== "iOS" && (
                        <div className="col-md-6">
                          <Form.Group>
                            <Form.Label>HDMI PORT</Form.Label>
                            <Form.Control
                              type="text"
                              autocomplete="off"
                              placeholder="Ex:08"
                              {...register("hdmi_port", {
                                pattern: {
                                  value: /^[0-9]+$/i,
                                  message: "Invalid HDMI port number",
                                },
                                maxLength: {
                                  value: 3,
                                  message: "Max-length of port number is three",
                                },
                                onChange: async () => {
                                  await trigger("hdmi_port");
                                },
                              })}
                            />
                            {errors.hdmi_port && (
                              <span className="error-msg">
                                {errors.hdmi_port.message}
                              </span>
                            )}
                          </Form.Group>
                        </div>
                      )}
                    {watchCategory !== "Android" &&
                      watchCategory !== "Android Tab" &&
                      watchCategory !== "iOS" && (
                        <div className="col-md-6">
                          <Form.Group>
                            <Form.Label>IR PORT</Form.Label>
                            <Form.Control
                              type="text"
                              autocomplete="off"
                              placeholder="Ex:16"
                              {...register("ir_port", {
                                pattern: {
                                  value: /^[0-9]+$/i,
                                  message: "Invalid IR port number",
                                },
                                maxLength: {
                                  value: 3,
                                  message: "Max-length of port number is three",
                                },
                                onChange: async () => {
                                  await trigger("ir_port");
                                },
                              })}
                            />
                            {errors.ir_port && (
                              <span className="error-msg">
                                {errors.ir_port.message}
                              </span>
                            )}
                          </Form.Group>
                        </div>
                      )}
                    {watchCategory !== "Android" &&
                      watchCategory !== "Android Tab" &&
                      watchCategory !== "iOS" && (
                        <div className="col-md-6">
                          <Form.Group>
                            <Form.Label>RCU DB</Form.Label>
                            <Form.Control
                              type="text"
                              autocomplete="off"
                              placeholder="Ex:LINUX"
                              {...register("rcu_db", {
                                pattern: {
                                  value: /^[a-z0-9 ]+$/i,
                                  message: "Alpahanumeric characters only",
                                },
                                maxLength: {
                                  value: 30,
                                  message:
                                    "RCU RB value cannot exceed more than 30 characters",
                                },
                                onChange: async () => {
                                  await trigger("rcu_db");
                                },
                              })}
                            />
                            {errors.rcu_db && (
                              <span className="error-msg">
                                {errors.rcu_db.message}
                              </span>
                            )}
                          </Form.Group>
                        </div>
                      )}
                  </div>
                </div>
                <div className="Add-device-block">
                  <h2>Proxy Details</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Proxy URL</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="EX:http://192.168.1.121:3005"
                          {...register("proxy_url", {
                            pattern: {
                              value:
                                /^(https?:\/\/)?((([a-z\d]([a-z\d-]*[a-z\d])*)\.)+[a-z]{2,}|((\d{1,3}\.){3}\d{1,3}))(:(\d+))?((\/[-a-z\d%_.~+]*)+|(\/))+(\?[;&a-z\d%_.~+=-]*)?(\#[-a-z\d_]*)?$/i,
                              message: "Invalid URL format",
                            },
                          })}
                        />
                        {errors.proxy_url && (
                          <span className="error-msg">
                            {errors.proxy_url.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Proxy Listen Port</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          placeholder="EX:50002"
                          {...register("proxy_listen_port")}
                        />
                      </Form.Group>
                    </div>
                  </div>
                </div>
                <div className="Add-device-block">
                  <h2>More Info</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group>
                        <Form.Label>Testing*</Form.Label>
                        <Form.Select
                          {...register("reservation_category", {
                            required: true,
                          })}
                        >
                          <option value="">Select Testing</option>
                          {testing.map((test) => {
                            return (
                              <option value={test} key={test}>
                                {test}
                              </option>
                            );
                          })}
                        </Form.Select>
                        {errors.reservation_category && (
                          <span className="error-msg">
                            This field is required
                          </span>
                        )}
                      </Form.Group>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div className="Add-device-action">
              {activeSection !== 0 && (
                <Button
                  className="Add-device-btn"
                  variant="outlined"
                  onClick={() => setActiveSection(activeSection - 1)}
                >
                  Back
                </Button>
              )}
              {activeSection !== 2 && (
                <Button
                  className="Add-device-btn"
                  variant="outlined"
                  onClick={validationHandler}
                >
                  Next
                </Button>
              )}
              {activeSection === 2 && (
                <Button
                  className="Add-device-btn"
                  variant="outlined"
                  type="submit"
                >
                  Submit
                </Button>
              )}
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
