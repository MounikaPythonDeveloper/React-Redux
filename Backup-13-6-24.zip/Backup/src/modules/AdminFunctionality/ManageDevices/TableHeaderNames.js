const tableHeaderNames = {
  device_name: "Device Name",
  device_category: "Category",
  brand_name: "Brand",
  model_name: "Model",
  country: "Country",
  city: "City",
  lab_name: "Lab",
  device_connectivity: "Network",
  serial_number: "Serial Number",
  imei: "IMEI",
  carrier: "Carrier",
  phone_number: "Phone Number",
  agent_id: "Test Machine Id",
  ip_address: "IP address",
  location_id: "Location Id",
  manufacturer: "Manufacturer",
  model_number: "Model Number",
  os_name: "OS Name",
  os_version: "OS Version",
  proxy_listen_port: "Proxy listen port",
  proxy_url: "Proxy Url",
  reservation_category: "Testing",
  platform: "Platform",
  platform_image_url: "Platform image url",
  hdmi_port: "HDMI PORT",
  ir_port: "IR PORT",
  rcu_db: "RCU DB",
};

export default function TableHeaderNames(Names) {
  return tableHeaderNames[Names] ? tableHeaderNames[Names] : Names;
}
