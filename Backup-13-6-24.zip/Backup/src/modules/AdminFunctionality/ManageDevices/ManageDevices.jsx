/**
 * Component: Context
 * File: ManageDevices.jsx
 * Description: This file contains the implementation of the manage devices admin functionality.
                Wrapping all the components into manage devices.
 *  File Used:App.js
 *  Author: R Sanjana
 * */
import React, { useState, useReducer, useEffect } from "react";
import axios from "axios";
import "./ManageDevices.css";
import searchManageDeviceIcon from "../../../assets/images/img/icon _search_normal.svg";
import AddDeviceIcon from "../../../assets/images/img/adduserbutton.svg";
import ColumnIcon from "../../../assets/images/column.png";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext";
import {
  MANAGE_DEVICES_API,
  DELETE_MANAGE_DEVICES_API,
  MANAGE_DEVICES_SEARCH_API,
} from "../../../services/api";
import DeleteDeviceIcon from "../../../assets/images/DeleteDevice.svg";
import EditDeviceIcon from "../../../assets/images/EditDevices.svg";
import Pagination from "../../Automation/Pagination/Pagination";
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent";
import TableHeaderNames from "./TableHeaderNames";
import { Alert, IconButton, Menu, MenuItem, Snackbar } from "@mui/material";

function ManageDevices() {
  //Defined states and data you want to used
  const { theme } = useTheme();
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const [checkDeleteDeviceItem, setcheckDeleteDeviceItem] = useState([]);
  const [open, setOpen] = useState(false);
  const [deleteDeviceResponse, setDeleteDeviceResponse] = useState(false);
  const [reducerValue, forceUpdate] = useReducer((x) => x + 1, 0);
  const [searchVal, setSearchVal] = useState("");
  const [viewDevicesData, setViewDevicesData] = useState([]);
  const [columnHeaderData, setColumnHeaderData] = useState([]);
  const [filterColumnsData, setFilterColumnsData] = useState([]);
  const defaultTableColumn = [
    "device_name",
    "platform",
    "device_category",
    "brand_name",
    "model_name",
    "country",
  ];
  const [filterColumnsSelectedData, setFilterColumnsSelectedData] =
    useState(defaultTableColumn);
  const [toggleColumnDisplay, setToggleColumnDisplay] = useState(null);

  console.log(searchVal, "searchVal");
  const location = useLocation();
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const isOnPlatformPage = location.pathname === "/platform";
  const isOnAboutPage = location.pathname === "/about";
  const isOnAdminPage = location.pathname === "/platform/adminHomePage";
  const isOnAdminManageDevicePage =
    location.pathname === "/platform/adminHomePage/addDevice";
  const isOnAdminEditDevicePage =
    location.pathname === "/platform/adminHomePage/editDevice/:id";

  useEffect(() => {
    // if (searchVal.length === 0 || checkDeleteDeviceItem.length === 0) {
    //   ManageDevicesData();
    // }
    if (searchVal.length === 0) {
      ManageDevicesData();
    }
  }, [reducerValue, searchVal, checkDeleteDeviceItem]);

  //Define a api function to fetch the devices details through API call & display it in the table
  const ManageDevicesData = async () => {
    let view_devices = "";
    view_devices = `${MANAGE_DEVICES_API}`;
    await axios
      .get(view_devices)
      .then((response) => {
        console.log(response.data, "view all devices");
        setViewDevicesData(response.data);
        const result = Object.keys(Object.assign({}, ...response.data));
        console.log(result, "filtercol");
        setColumnHeaderData(result);
        setFilterColumnsData(result);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  // POPUP OPEN FUNCTION
  const handleOpen = function () {
    if (checkDeleteDeviceItem.length !== 0) {
      setOpen(true);
      console.log("handle open");
    }
  };

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setcheckDeleteDeviceItem([]);
    setOpen(false);
  };

  //Define a function to get the selected item for deletion.
  const getDeleteDeviceItem = function (event, value) {
    console.log(value, "getDeleteDeviceItem");
    if (event.target.checked === true) {
      setcheckDeleteDeviceItem([...checkDeleteDeviceItem, value]);
      console.log(checkDeleteDeviceItem, "checkDeleteDeviceItem");
    } else {
      setcheckDeleteDeviceItem(
        checkDeleteDeviceItem.filter((val) => val !== value)
      );
    }
  };

  //Define a api function to delete the selected item.
  const deleteDeviceHandler = async () => {
    let deleteDeviceItems = "";
    deleteDeviceItems = `${DELETE_MANAGE_DEVICES_API}${JSON.stringify({
      device_name: checkDeleteDeviceItem,
    })}`;
    await axios
      .get(deleteDeviceItems)
      .then((response) => {
        console.log("delete device", response.data);
        setDeleteDeviceResponse(response.data);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    setcheckDeleteDeviceItem("");
    handleClosePopup();
    forceUpdate();
  };

  const searchValHandler = (e) => {
    setSearchVal(e.target.value);
  };

  const onSearchVal = (searchInput) => {
    console.log("searchValue", searchInput);
    searchInputApi(searchInput);
  };

  //Define a function to search the required device details in the table
  const searchInputApi = async (searchInput) => {
    await axios
      .post(`${MANAGE_DEVICES_SEARCH_API}${searchInput}`)
      .then((response) => {
        setViewDevicesData(response.data);
        console.log("search data", response.data);
        setCurrentPage(1);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  };

  const enterKeyAPIHandler = (e) => {
    if (e.code === "Enter" || e.code === "NumpadEnter") {
      console.log("Enter key was pressed. Run your function.", searchVal);
      e.preventDefault();
      searchInputApi(searchVal);
    }
  };

  const toggleColumn = (event) => {
    setToggleColumnDisplay(event.target);
  };

  const toggleColumnClose = (event) => {
    setToggleColumnDisplay(null);
  };

  //Define a function to filter the columns in the table to view the required device details
  const columnFilterHandler = (option) => {
    console.log("colhan", option);
    if (filterColumnsSelectedData.includes(option)) {
      let selectedData = filterColumnsSelectedData.filter((data) => {
        return data !== option;
      });
      setFilterColumnsSelectedData(selectedData);
      console.log("asss", selectedData);
    } else {
      setFilterColumnsSelectedData([...filterColumnsSelectedData, option]);
    }
  };

  console.log("opt", filterColumnsData);
  console.log("dataaa", columnHeaderData);

  //It will render the ManageDevices component
  return (
    <>
      {/* Define the Snackbar to return the popup message */}
      <Snackbar
        className={`delete-device-alert ${theme === "dark" ? "dark" : "light"}`}
        open={deleteDeviceResponse}
        autoHideDuration={3000}
        onClose={() => setDeleteDeviceResponse(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {deleteDeviceResponse === true && (
          <Alert icon={false}>Deleted the selected Device</Alert>
        )}
      </Snackbar>
      <div
        className={`manage-devices-container ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <div className="manage-device-top">
          <div className="manage-devices-left-block-content">
            <div className="manage-devices-heading">Manage Devices</div>
          </div>
          <div className="manage-devices-right-block-content">
            <div className="manage-device-search">
              <input
                className="manage-device-search-input"
                placeholder="search"
                type="text"
                value={searchVal}
                onChange={searchValHandler}
                onKeyUp={enterKeyAPIHandler}
              />
              {searchVal === "" ? (
                <img
                  className="manage-device-search-icon"
                  src={searchManageDeviceIcon}
                  alt="search"
                  title="Search"
                  disabled
                  onClick={() => onSearchVal(searchVal)}
                />
              ) : (
                <img
                  className="manage-device-search-icon"
                  src={searchManageDeviceIcon}
                  alt="search"
                  title="Search"
                  onClick={() => onSearchVal(searchVal)}
                />
              )}
            </div>
            <div
              className={`manage-devices-filter-column ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <div className="Filter-table-columns">
                <span>Filter column:</span>
                <IconButton
                  aria-label="more"
                  id="filter-column-icon"
                  aria-controls={
                    toggleColumnDisplay ? "filter-column" : undefined
                  }
                  aria-expanded={toggleColumnDisplay ? "true" : undefined}
                  aria-haspopup="true"
                  onClick={toggleColumn}
                >
                  <img
                    className="filter-column-icon"
                    src={ColumnIcon}
                    alt="Column-Icon"
                    title="Fliter"
                  />
                </IconButton>
                <Menu
                  className="Filter-table-columns-menu"
                  id="filter-column"
                  MenuListProps={{
                    "aria-labelledby": "filter-column-icon",
                  }}
                  anchorEl={toggleColumnDisplay}
                  open={toggleColumnDisplay !== null ? true : false}
                  onClose={toggleColumnClose}
                  PaperProps={{
                    style: {
                      maxHeight: "230px",
                      width: "230px",
                    },
                  }}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                >
                  {filterColumnsData.map((option) => {
                    return (
                      !defaultTableColumn.includes(option) && (
                        <MenuItem
                          key={option}
                          selected={filterColumnsSelectedData.includes(option)}
                          onClick={() => columnFilterHandler(option)}
                        >
                          {TableHeaderNames(option)}
                        </MenuItem>
                      )
                    );
                  })}
                </Menu>
              </div>
            </div>
          </div>
        </div>
        <div className="manage-devices-table">
          <div
            className={`manage-devices-table-container ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            {viewDevicesData.length === 0 ? (
              <div className="table-empty-message">No Data Available</div>
            ) : (
              <table class="table">
                <thead className="manage-devices-table_head ">
                  <tr className="manage-devices-table_header">
                    <th>S.No</th>
                    {defaultTableColumn.map((thItem, index) => {
                      return <th>{TableHeaderNames(thItem)}</th>;
                    })}
                    {columnHeaderData.map((thItem, index) => {
                      return (
                        filterColumnsSelectedData.includes(thItem) &&
                        !defaultTableColumn.includes(thItem) && (
                          <th>{TableHeaderNames(thItem)}</th>
                        )
                      );
                    })}
                    <th>Edit</th>
                    <th>
                      <img
                        className="manage-delete-icon"
                        alt="Delete device"
                        src={DeleteDeviceIcon}
                        onClick={handleOpen}
                        title="Delete"
                      ></img>
                    </th>
                  </tr>
                </thead>
                <tbody className="table_body">
                  {viewDevicesData
                    .slice(indexOfFirstPost, indexOfLastPost)
                    .map((item, index) => {
                      return (
                        <tr
                          style={{ fontSize: "16px" }}
                          className="text-center"
                          key={index}
                        >
                          <td>{indexOfFirstPost + index + 1}</td>
                          {defaultTableColumn.map((tdItem, index) => {
                            return <td>{item[tdItem]}</td>;
                          })}
                          {columnHeaderData.map((tdItem) => {
                            return (
                              filterColumnsSelectedData.includes(tdItem) &&
                              !defaultTableColumn.includes(tdItem) && (
                                <td>
                                  {/* {item[tdItem]?.length > 1
                                                                    ? item[tdItem]
                                                                    : "-"} */}
                                  {item[tdItem]}
                                </td>
                              )
                            );
                          })}
                          {isOnAboutPage ||
                          isOnAdminPage ||
                          isOnPlatformPage ||
                          isOnAdminEditDevicePage ? (
                            <td className="icon-container">
                              <Link
                                to={`/platform/adminHomePage/editDevice/${item.device_name}`}
                                state={{ data: item }}
                              >
                                <img
                                  className="edit-device"
                                  alt="Edit Device"
                                  src={EditDeviceIcon}
                                  title="Edit Device"
                                ></img>
                              </Link>
                            </td>
                          ) : platform_data === "Media And Entertainment" ? (
                            <td className="icon-container">
                              <Link
                                to={`/platform/M&E/adminHomePage/editDevice/${item.device_name}`}
                                state={{ data: item }}
                              >
                                <img
                                  className="edit-device"
                                  alt="Edit Device"
                                  src={EditDeviceIcon}
                                  title="Edit Device"
                                ></img>
                              </Link>
                            </td>
                          ) : (
                            <td className="icon-container">
                              <Link
                                to={
                                  `/platform/` +
                                  platform_data +
                                  `/adminHomePage/editDevice/${item.device_name}`
                                }
                                state={{ data: item }}
                              >
                                <img
                                  className="edit-device"
                                  alt="Edit Device"
                                  src={EditDeviceIcon}
                                  title="Edit Device"
                                ></img>
                              </Link>
                            </td>
                          )}
                          <td className="managedevices-checkbox">
                            <input
                              type="checkbox"
                              checked={checkDeleteDeviceItem.includes(
                                item.device_name
                              )}
                              onChange={(event) =>
                                getDeleteDeviceItem(event, item.device_name)
                              }
                            />
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            )}
          </div>
        </div>
        <div className="Add-device-icon">
          {isOnAboutPage ||
          isOnAdminManageDevicePage ||
          isOnPlatformPage ||
          isOnAdminPage ? (
            <Link to={"/platform/adminHomePage/addDevice"}>
              <img
                src={AddDeviceIcon}
                title="ADD Device"
                alt="Add Device"
              ></img>
            </Link>
          ) : platform_data === "Media And Entertainment" ? (
            <Link to={"/platform/M&E/adminHomePage/addDevice"}>
              <img
                src={AddDeviceIcon}
                title="ADD Device"
                alt="Add Device"
              ></img>
            </Link>
          ) : (
            <Link
              to={"/platform/" + platform_data + "/adminHomePage/addDevice"}
            >
              <img
                src={AddDeviceIcon}
                title="ADD Device"
                alt="Add Device"
              ></img>
            </Link>
          )}
        </div>
        <PopupComponent
          open={open}
          text="Are you sure you want to delete?"
          handleClose={handleClosePopup}
          functionHandle={deleteDeviceHandler}
        />
        <div style={{ paddingTop: "10px" }}>
          {viewDevicesData.length !== 0 && (
            <Pagination
              currentPage={currentPage}
              postsPerPage={postsPerPage}
              totalPosts={viewDevicesData.length}
              paginate={paginate}
            />
          )}
        </div>
      </div>
    </>
  );
}
export default ManageDevices;
