/** * Component: SampleComponent
    * File: SignUp.jsx
    * Description: This file contents the implementation of Ace Ide Editor.
                   Wrapping all the components into IDEEditor.
                   It Returns the IDE to edit the testcases of the file
    * Author: Yuvaraj Dakhane
    * NOTE: Run the server.js using node server.js to see the file directory and files in the editor
* **/

import React, { useEffect, useState } from 'react';
import AceEditor from 'react-ace';
import 'ace-builds/src-noconflict/mode-text'; // Replace 'text' with the appropriate Ace mode for your file types
import 'ace-builds/src-noconflict/theme-monokai'; // Choose an Ace theme
import "./IDEEditor.css"
import MyButton from '../../components/ReusableComponents/Buttons'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import 'ace-builds/src-noconflict/mode-robot'
import {
    VALIDATE_BUYLICENSE_STATUS,
  } from "../../services/api"
import axios from "axios"

//It returns the ace-editor
function CodeEditor({ fileContent, setEditorContentFuc, readOnly }) {
  return (
    <AceEditor
      mode="robot" 
      theme="monokai" // Choose an Ace theme
      value={fileContent}
      width="100%"
      height="579px"
      fontSize={14}
      showPrintMargin={false}
      showGutter={true}
      highlightActiveLine={true}
      onChange={setEditorContentFuc}
      readOnly={readOnly}
      color="white"
    />
  );
}

//The function is used to return the structure of file directory
function renderStructure(structure, handleFileSelection, handleFolderToggle, openFolders) {
  return (
    <ul>
      {structure.map((item) => (
        <li key={item.name}>
          {item.type === 'directory' ? (
            <div>
              <strong
                onClick={() => handleFolderToggle(item.name)}
                style={{
                  cursor: 'pointer',
                }}
              >
                {openFolders.includes(item.name) ? <KeyboardArrowDownIcon /> : <KeyboardArrowRightIcon/> } {item.name}
              </strong>
              {openFolders.includes(item.name) && item.children ? (
                // Recursive call for nested folders
                renderStructure(item.children, handleFileSelection, handleFolderToggle, openFolders)
              ) : null}
            </div>
          ) : (
            <span onClick={() => handleFileSelection(item.path)}>{item.name}</span>
          )}
        </li>
      ))}
    </ul>
  );
}

function IDEEditor() {
    const [status, setStatus] = useState("")
    const [statusLicense, setStatusLicense] = useState(false)
    const userProfile = JSON.parse(sessionStorage.getItem("userData"))
    const [projectStructure, setProjectStructure] = useState([]);
    const [selectedFileContent, setSelectedFileContent] = useState('');
    const [openFolders, setOpenFolders] = useState([]); // Track open folders
    const [isEditing, setIsEditing] = useState(false);
    const [filePath1, setFilePath] = useState()

    //It used to validate the license status
    const ValidateLicensestatus = async () => {
        axios
          .post(
            VALIDATE_BUYLICENSE_STATUS +
              JSON.stringify({
                licensee: [userProfile.username],
              }) +
              "&attributes=" +
              JSON.stringify(["status"])
          )
          .then((res) => {
            setStatus(Object.values(res.data)[0])
            console.log("apidata status", res.data.status[0] === "Active")
            if (res.data.status[0] === "Active") {
                setStatusLicense(true)
            }
          })
          .catch((er) => console.log(er))
      }  


    //It is fecting the project structure from localhost
    useEffect(() => {
        // Fetch project structure and set it in projectStructure state
        fetch('http://localhost:3007/api/project-structure') // Replace with your API endpoint
        .then((response) => response.json())
        .then((data) => setProjectStructure(data))
        .catch((error) => console.error(error));
    }, []);

    //It return the code content in the edit when user click on any file in the directory
    const handleFileSelection = async (filePath) => {
        setFilePath(filePath);
        try {
        const response = await fetch(
            `http://localhost:3007/api/get-file-content?filePath=${filePath}`
        ); // Replace with your API endpoint
        const content = await response.text();
        setSelectedFileContent(content);
        } catch (error) {
        console.error(error);
        }
    };

    // Function to handle folder open/close toggle
    const handleFolderToggle = (folderName) => {
        if (openFolders.includes(folderName)) {
        setOpenFolders(openFolders.filter((name) => name !== folderName));
        } else {
        setOpenFolders([...openFolders, folderName]);
        }
    };

    //function handle the save function enable/disable functionality
    const handleEditFile = () =>{
        setIsEditing(true)  
    }

    //function save the file in the same location
    const handleSave = async () =>{
        try{
        const response = await fetch(`http://localhost:3007/api/save-file?filePath=${filePath1}`,{
            method: 'POST',
            headers:{
            'Content-Type': 'text/plain'
            },
            body: selectedFileContent,
        });
        if(response.ok){
            console.log('file save')
        }
        else{
            console.error('error saving file')
        }
        }catch(error)
        {
        console.error('save error:', error);
        }
    }

    //function open the file from file picker
    const handleFileOpen = (event) => {
        const file =event.target.files[0];
        const render = new FileReader();
        render.onload = (e) =>{
        setSelectedFileContent(e.target.result);
        };
        render.readAsText(file);
    }
    
    const setEditorContentFuc = (event) =>{
        setSelectedFileContent(event)
    }
    useEffect(() => {
        ValidateLicensestatus();
    },[])

  return (
    <div >
      <div className="editor-header">
        <input type="file" className="file-picker" onChange={handleFileOpen} />
        <MyButton variant="contained" onClick={handleSave} disabled={!isEditing} label="Save" id="editor-save" />
        <MyButton variant="contained" onClick={handleEditFile} disabled={!statusLicense} label="Edit" id="editor-edit" />
      </div>
      <div className="ace-editor">
        <div className='directory'>
          {renderStructure(
            projectStructure,
            handleFileSelection,
            handleFolderToggle,
            openFolders
          )}
        </div>
        <div className='editor'>
          <CodeEditor fileContent={selectedFileContent} setEditorContentFuc={setEditorContentFuc} readOnly={!isEditing}/>
        </div>
      </div>
    </div>
  );
}

 

export default IDEEditor;