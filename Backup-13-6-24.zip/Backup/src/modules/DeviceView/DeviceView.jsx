/**
 * Component: DeviceView
 * File: DeviceView.jsx
 * Description: This file contains the implementation of the Deviceview React component.
              Device  view component in manual testing page will make user to easily view and operate 
              the selected device through remote. the user can view the device screen upon clicking on 
              view button with help of livekit and iframe component.user can view single and multiple devices. 
                
 *File Used:App.js, Calendara.jsx,LiveKitRoom.jsx,Scheduling.jsx,StatusCalendar.jsx,BigCalendar.jsx,DeviceFilter.jsx
 * Author:Supriya Palve, Mounika, Prasanna
 **/

import React, { useRef, useState, useEffect } from "react"
import "./DeviceView.css"
import profanityIcon from "../../assets/images/profanityIcon.png"
import Report from "../../../src/assets/images/Report.png"
import Report_light from "../../../src/assets/images/icons8-reports-58.png"
import "../../components/UniqueID/generateUniqueId"
import { LineChart } from "@mui/x-charts/LineChart"
import CloseIcon from "@mui/icons-material/Close"
import IconButton from "@mui/material/IconButton"
import { Tooltip } from "@mui/material"
import { useLocation, useNavigate, Link } from "react-router-dom"
import axios from "axios"
import Reboot from "../../assets/images/reboot.svg"
import close from "../../assets/images/Close.png"
import RebootRefresh from "../../assets/images/Reboot-Refresh.png"
import Draggable from "react-draggable"
import { Alert, Snackbar } from "@mui/material"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import screenIcon from "../../assets/images/screenshot (2).png"
import videoQualityIcon from "../../assets/images/videoIcon2.png"
import ScreenShotCrop from "../../components/ScreenShotCrop/ScreenShotCrop"
import {
  DEVICE_LOCK_UNLCOK_API,
  HARD_REBOOT_API,
  DEVICE_TRACKING_API,
  BUILD_STATUS_API,
  BUILD_DATA_API,
  EXIST_FROM_LIVEKITROOM,
  LIVEKITROOM_API,
  NETWORK_THROTTLING_API,
  SCREEN_SHOT_IMAGE_API,
  SCREEN_SHOT_IMAGE_ETISILAT,
  VIDEO_METRICS_DEVICES_API,
  GENERATE_REPORT_VQ_API,
  GENERATE_REPORT_VQ_AKSHITHA_API,
  FETCH_REPORT_API,
  PROFANITY_REPORT_GENERATE_API,
  PROFANITY_DETECTION_LIVE_API,
  DELETE_VIDEO_REPORT_API,
  DELETE_PROFANITY_REPORT_API,
} from "../../services/api"
import html2canvas from "html2canvas"
import { ReactSmartScroller } from "react-smart-scroller"
import PopupComponent from "../../components/ReusableComponents/PopupComponent/PopupComponent"
import moment from "moment"
import BuildLoading from "../../components/BuildLoading/BuildLoading"
import "../../components/Livekit/livekit.css"
import LiveKit from "../../components/Livekit/LiveKitRoom"
import DropDownComponent from "../../components/ReusableComponents/DropDownComponent/DropDownComponent"
import Loading from "../../assets/images/icons8-loading-100.png"
import FileUpload from "../../components/FileUpload/FileUpload"
import { msl_ipaddress_trigger } from "../../services/api"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"
import generateUniqueId from "../../components/UniqueID/generateUniqueId"
import ProfanityDetection from "../../components/ProfanityDetection/PDPopup"
import PDDisplay from "../../components/ProfanityDetection/PDDisplay"
// function DeviceView({ PDReport }) {
function DeviceView() {
  const [report, setReport] = useState("")
  const [reportMessage, setReportMessage] = useState("")
  const [videoQualityCheck, setVideoQualityCheck] = useState("")
  const [returnValueCrop, setReturnValueCrop] = useState(false)
  const [returnValueCropFailure, setReturnValueCropFailure] = useState(false)
  const [returnValueMessage, setReturnValueMessage] = useState("")
  const returnValueHandler = (value) => {
    setReturnValueCrop(value)
    console.log("return value", returnValueCrop)
  }
  const divRef = useRef()
  const navigate = useNavigate()
  const location = useLocation()
  const [ReportData, setReportData] = useState("")
  const [open, setOpen] = useState(false)
  const [unlockpopup, setUnlockPopup] = useState(false)
  const [unlockMultiplePopup, setUnlockMultiplePopup] = useState(false)
  const [blur, setBlur] = useState(false)
  const [deviceBlur, setDeviceBlur] = useState(false)
  const [deviceName, SetDeviceName] = useState("")
  const [activeDevice, setActiveDevice] = useState(0)
  const [ProfanityDetectionOpen, setProfanityDetectionOpen] = useState(false)
  const [PDHandlerDisplay, setPDHandlerDisplay] = useState(false)
  const [PDDeviceName, setPDDeviceName] = useState("")
  const [PDReportResponse, setPDReportResponse] = useState("")
  const [PDtriggerId, setPDTriggerID] = useState("")
  const [PDLiveResponseData, setPDLiveResponseData] = useState({})
  const [PDinput, setPDinput] = useState()
  const [buildPopupOpen, setBuildPopupOpen] = useState(false)
  const [buildStatus, setBuildStatus] = useState("")
  const [buildId, setBuildId] = useState([])
  const [buildErrorHandler, setBuildErrorHandler] = useState("")
  const [throattlingCurrentSpeed, setThroattlingCurrentSpeed] = useState([])
  const [networkStatusResponse, setNetworkStausResponse] = useState("")
  const [screenshot, setScreenshot] = useState(null)
  const [buildDeviceName, setBuildDeviceName] = useState(
    location.state ? location.state.DeviceViewInfo[0].device_name : ""
  )
  const id = generateUniqueId()
  const [triggerId, setTriggerID] = useState("")
  const [devicesData, setDeviceData] = useState(
    location.state ? location.state.DeviceViewInfo : ""
  )
  console.log(devicesData, "automation- manual")
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [totalCalls, setTotalCalls] = useState(0)
  const [pdCallCount, setPdCallCount] = useState(0)
  const [starttime, setStartTimeDevice] = useState("")
  const [networkLogs, setNetworkLogs] = useState(false)
  const [showmodal, setShowModal] = useState(false)
  const [toggled, setToggled] = useState("false")
  const [alertMessage, setAlertMessage] = useState(false)
  const [AlertMessageState, setAlertMessageState] = useState(false)
  const [rebootResponse, setRebootResponse] = useState("")
  const [scriptName, setScriptName] = useState("")
  const [errorMessage, setErrorMessage] = useState("")
  const [responseMessage, setResponseMessage] = useState("")
  const [togglebutton, settogglebutton] = useState("false")
  const [tokenData, setTokenData] = useState()
  const [loading, setLoading] = useState(true)
  const [isSelecting, setIsSelecting] = useState(false)
  const [selection, setSelection] = useState({ x1: 0, y1: 0, x2: 0, y2: 0 })
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const [uploadingScript, setUploadingScript] = useState(false)
  const [screenShotDownload, setScreenShotDownload] = useState([])
  const [screenPopup, setScreenPopup] = useState(false)
  const [videoMetricsData, setVideoMetricsData] = useState({})
  const [currentValue, setCurrentValue] = useState(null)
  const [prevValue, setPrevValue] = useState([])
  const [accumulatedFrameCount, setAccumulatedFrameCount] = useState(0)
  const [qualityScore, setQualityScore] = useState([0, 0, 0, 0, 0])
  const [VMAveragePSNRValue, setVMAveragePSNRValue] = useState([0, 0, 0, 0, 0])
  const [xAxisData, setXAxisData] = useState([1, 2, 3, 4, 5])
  const [bandingRate, setBandingRate] = useState([0, 0, 0, 0, 0])
  const [blockingRate, setBlockingRate] = useState([0, 0, 0, 0, 0])
  const [blackFrames, setBlackFrames] = useState([0, 0, 0, 0, 0])
  const [dataVideoMetrics, setDataVideoMetrics] = useState([])
  const handleClick = () => {
    settogglebutton(!togglebutton)
  }
  useEffect(() => {
    if (videoQualityCheck) {
      const videoMetricsData = setInterval(() => {
        getVideoMetrics() // <-- (3) invoke in interval callback
      }, 1000)
      getVideoMetrics()
      return () => clearInterval(videoMetricsData)
    }
  }, [videoQualityCheck])
  console.log("video metrics url", devicesData[activeDevice]?.video_metrics)
  const getVideoMetrics = async () => {
    await axios
      // .get(devicesData[activeDevice]?.video_metrics)
      .get(
        VIDEO_METRICS_DEVICES_API +
          JSON.stringify({
            device_name: devicesData.map((device) => device.device_name)[0],
            trigger_id: triggerId,
          })
      )
      .then((response) => {
        let data = response.data
        console.log(data, "Data..")
        // Update the data array with the new JSON data point
        setDataVideoMetrics((prevData) => [...prevData.slice(-4), data])
        console.log(dataVideoMetrics, "Data Video Metrics")
        setVideoMetricsData(data)
        console.log("acumulate initial", accumulatedFrameCount)
        setCurrentValue(data.Dropped_Frames)
        setPrevValue((prev) => [...prev, data.Dropped_Frames])
        setAccumulatedFrameCount((prevTotal) => prevTotal + data.Dropped_Frames)
        console.log("acumulate final", accumulatedFrameCount)
        setVMAveragePSNRValue((prevData) =>
          [...prevData, data.Avg_PSNR_Value].slice(-5)
        )
        setQualityScore((prevData) =>
          [...prevData, data.Quality_Score].slice(-5)
        )
        setBandingRate((prevData) => [...prevData, data.Banding_Rate].slice(-5))
        console.log(bandingRate, "Banding Rate")
        setBlockingRate((prevData) =>
          [...prevData, data.Blocking_Rate].slice(-5)
        )
        console.log(blockingRate, "Blocking Rate")
        setBlackFrames((prevData) => [...prevData, data.black_frames].slice(-5))
        console.log(VMAveragePSNRValue, "Average PSNR Value")
        // Generate an array of timestamps for the X-axis representing every second
        const xAxis = Array.from(
          { length: VMAveragePSNRValue.length },
          (_, index) => index + 1
        )
        setXAxisData(xAxis)
        console.log(xAxis, "X axis")
      })
      .catch((error) => {
        console.log(error, " video error")
      })
  }

  // POPUP OPEN FUNCTION
  const handleOpen = () => setOpen(true)

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setOpen(false)
    setUnlockPopup(false)
    setUnlockMultiplePopup(false)
  }

  const networkLogsToggle = function () {
    const url = devicesData[activeDevice]?.proxy_url
    if (url !== null) {
      if (videoQualityCheck) {
        setVideoQualityCheck(false)
      }
      setNetworkLogs(true)
    } else {
      setAlertMessageState(true)
      setAlertMessage("Network Logs are not available")
    }
  }
  const networkBlockClose = function () {
    setNetworkLogs(false)
  }

  window.addEventListener("beforeunload", function (e) {
    e.preventDefault()
    e.returnValue = ""
    closeVideoQuality()
    sendDeviceUnlock(devicesData.map((device) => device.device_name))
    removeuserfromlivekitroom(
      devicesData.map((device) => device.device_name.toLowerCase())
    )
  })
  useEffect(() => {
    const networkThrottling = setInterval(() => {
      networkThroattlingCurrentSpeed()
    }, 5000)
    networkThroattlingCurrentSpeed()

    return () => clearInterval(networkThrottling)
  }, [])

  useEffect(() => {
    sendDeviceLock()
    setStartTimeDevice(moment().format("YYYY-DD-MM HH:mm:ss"))
    return () => {
      sendDeviceUnlock(devicesData.map((device) => device.device_name))
      removeuserfromlivekitroom(
        devicesData.map((device) => device.device_name.toLowerCase())
      )
    }
  }, [])

  const signinData = JSON.parse(sessionStorage.getItem("signin_data"))
  const sendDeviceTrackingEnd = async () => {
    let url_device = ""
    url_device = `${DEVICE_TRACKING_API}${JSON.stringify(
      devicesData.map((item, index) => ({
        device_name: item.device_name,
        username: userProfile.username,
        session_id: userProfile.session_id,
        start_time: starttime,
        end_time: moment().format("YYYY-MM-DD HH:mm:ss"),
        category_reservation: "Manual",
      }))
    )}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("tracking", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 3000)

    return () => {
      clearTimeout(timer)
    }
  }, [])
  const sendDeviceLock = async () => {
    let url_device = ""
    url_device = `${DEVICE_LOCK_UNLCOK_API}${JSON.stringify([
      {
        locked_by: userProfile.username,
        device_status: "Locked",
        device_name: devicesData.map((device) => device.device_name),
      },
    ])}`

    if (userProfile.username.length > 1) {
      await axios
        .post(url_device)
        .then((response) => {
          console.log("locked", response.data)
        })
        .catch((error) => {
          console.log(error, "error")
        })
    }
  }

  const sendDeviceUnlock = async (devicesData) => {
    let url_device = ""
    url_device = `${DEVICE_LOCK_UNLCOK_API}${JSON.stringify([
      {
        device_status: "Unlocked",
        device_name: devicesData,
        locked_by: "",
      },
    ])}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("unlocked", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  //remove user from livekitroom-single device
  const removeuserfromlivekitroom = async (devicesData) => {
    let url_device = ""
    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: devicesData[0].toLowerCase(),
    })}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  //remove user from livekitroom-multiple devices
  const removeuserfromlivekitroom1 = async (devicesData) => {
    let url_device = ""
    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: devicesData.toLowerCase(),
    })}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  // NAVIGATE TO DEVICE FILTER PAGE FUNCTION

  const devicesBack = function () {
    sendDeviceUnlock(devicesData)
    sendDeviceTrackingEnd()

    navigate(-1)
  }

  const devicesBack2 = function () {
    navigate(-2)
  }

  // HARDREBOOT FETCHING FUNCTION
  const hardRebootFecth = async () => {
    let hardReboot = ""
    hardReboot = `${HARD_REBOOT_API}${JSON.stringify({
      device_name: deviceName,
    })}`
    await axios
      .post(hardReboot)
      .then((response) => {
        console.log("Hard-Reboot", response.data)
        if (response.data.message === "Device rebooted") {
          setRebootResponse(response.data.message)
          setBlur(false)
        } else {
          setRebootResponse(response.data.Message)
          setBlur(false)
        }
      })
      .catch((error) => {
         if (error.message === "Network Error") {
          setRebootResponse("Device rebooted");
        }
        setBlur(false);
        console.log(error, "error")
      })
  }

  // GETTING DECIVE_NAME

  const hardReboot = async (device_name) => {
    handleOpen()
    SetDeviceName(device_name)
  }

  // BLUR FUNCTION

  const blurFunction = function () {
    setBlur(true)
    setOpen(false)
  }

  const renderDevice = function (data) {
    console.log(data, "data oooo")
    switch (data?.screen_type) {
      case "Tab Screening":
      case "Console Screening":
        return (
          <>
            <div className="device-screen-block lg-screen-device">
              <LiveKit
                devicesData={devicesData}
                activeDevices={activeDevice}
                tokenData2={tokenData}
              />
            </div>
          </>
        )
      case "TV Screening":
        return (
          <>
            <div className="device-screen-block lg-screen-device">
              <LiveKit
                devicesData={devicesData}
                activeDevices={activeDevice}
                tokenData2={tokenData}
              />
            </div>
          </>
        )
      case "Other Screening":
        return (
          <>
            <div className="device-screen-block lg-screen-device">
              <iframe
                class="sm-screen-device-iframe"
                src={data.url_screen}
              ></iframe>
            </div>
          </>
        )
      case "Mobile Screening":
        return loading ? (
          <div className="page-loader1">
            <img src={Loading}></img>{" "}
          </div>
        ) : (
          <div className="device-screen-block sm-screen-device">
            <iframe
              class="sm-screen-device-iframe"
              src={data.url_screen}
            ></iframe>
          </div>
        )
      default:
        return (
          <div className="device-screen-block md-device">
            <LiveKit
              devicesData={devicesData}
              activeDevices={activeDevice}
              tokenData2={tokenData}
            />
          </div>
        )
    }
  }

  // for setting up device remote - toggle remote
  const renderRemote1 = function (data) {
    const remote1 = (
      <iframe
        class="remote-iframe"
        src={data?.url_remote}
        alt="Image1"
      ></iframe>
    )

    return remote1
  }

  const renderRemote2 = function (data) {
    const remote2 = (
      <iframe
        class="remote-iframe"
        src={data?.url_remote_2}
        alt="Image1"
      ></iframe>
    )

    return remote2
  }
  const renderUrl2 = function (data) {
    const remote2 = (
      <iframe
        class="remote-iframe"
        src={data?.url_remote_2}
        alt="Image1"
      ></iframe>
    )
    var url_remote = remote2.props.src
    console.log(url_remote)
    return url_remote
  }

  console.log("iframe device", devicesData[0].device_name)
  //Multiple device view - big screen
  const iframeHandler = async (idx) => {
    setActiveDevice(idx)
    //active device1 removed
    removeuserfromlivekitroom1(devicesData[activeDevice].device_name)
    let url_device = ""
    //active device2 room generated
    url_device = `${LIVEKITROOM_API}${
      devicesData[idx].device_name
    }?data=${JSON.stringify({
      locked_by: userProfile.username,
    })}`
    try {
      const response = await axios.post(url_device)
      console.log("livekit-data deviceview", response.data)
      setTokenData(response.data)
    } catch (error) {
      console.log(error, "error")
    }
  }

  const hardRebootBlur = function () {
    blurFunction()
    hardRebootFecth()
  }

  const buildOpenHandler = function () {
    setBuildPopupOpen(true)
  }
  const buildCloseHandler = function () {
    setBuildPopupOpen(false)
  }
  // Network-Throttling-Current-Time API Function
  const networkThroattlingCurrentSpeed = async () => {
    let currentSpeed = ""
    currentSpeed = `${NETWORK_THROTTLING_API}${JSON.stringify({
      device_name: buildDeviceName,
    })}`
    await axios
      .post(currentSpeed)
      .then((response) => {
        console.log(response.data.Error, "kanna")
        if (response.data.current_throttling) {
          setThroattlingCurrentSpeed(response.data.current_throttling)
        } else {
          setThroattlingCurrentSpeed(response.data.Error)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const buildStatusFetch = async (buildId) => {
    console.log(buildId, "build")
    let statusFetch = ""
    statusFetch = `${BUILD_STATUS_API}${
      JSON.stringify({ build_id: [buildId] }) +
      "&attribute=" +
      JSON.stringify(["status"])
    })}`
    await axios
      .post(statusFetch)
      .then((response) => {
        console.log("build_Fecth11111", response.data[0].status)
        setBuildStatus(response.data[0].status)
        if (response.data[0].status === "In Progress") {
          buildStatusFetch(buildId)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  // BuildDataApi is for sending data to MSL

 const BuildDataApi = (data) => {
    console.log(data, "DATAUSER");
    let buildDataFetch = "";
    buildDataFetch = `${BUILD_DATA_API}${JSON.stringify({
      type: data.type,
      app_name: data.appName,
      source: data.source,
      link: data.sourceLink,
      device_name: buildDeviceName,
      device_category: devicesData[0].device_category,
    })}`;
    axios
      .post(buildDataFetch)
      .then((response) => {
        console.log("build_Fecth", response.data.build_id);
        setBuildId(response.data.build_id);
        buildStatusFetch(response.data.build_id);
      })
      .catch((error) => {
        setBuildId(error.message);
        console.log(error, "error");
      });
  };

  const clearScreenshot = () => {
    setScreenshot(null)
  }
  const [selectedFile, setSelectedFile] = useState(null)
  const [fileUploadOpen, setFileUploadOpen] = useState(null)
  const fileInputRef = useRef(null)

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0])
    setFileUploadOpen(true)
  }

  console.log(selectedFile, "scriptname3")

  const handlePopupClose = () => {
    setSelectedFile(null)
    setErrorMessage("")
    setFileUploadOpen(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  useEffect(() => {
    const handleMouseDown = (event) => {
      if (isSelecting) {
        setIsSelecting(true)
        setSelection({ ...selection, x1: event.clientX, y1: event.clientY })
      }
    }

    const handleMouseUp = () => {
      if (isSelecting) {
        setIsSelecting(false)
        html2canvas(document.body, {
          x: selection.x1,
          y: selection.y1,
          width: selection.x2 - selection.x1,
          height: selection.y2 - selection.y1,
        }).then((canvas) => {
          const imgData = canvas.toDataURL("image/png")
          const link = document.createElement("a")
          link.download = "screenshot.png"
          link.href = imgData
          link.click()
        })
      }
    }

    const handleMouseMove = (event) => {
      if (isSelecting) {
        setSelection({ ...selection, x2: event.clientX, y2: event.clientY })
      }
    }

    document.addEventListener("mousedown", handleMouseDown)
    document.addEventListener("mouseup", handleMouseUp)
    document.addEventListener("mousemove", handleMouseMove)

    return () => {
      document.removeEventListener("mousedown", handleMouseDown)
      document.removeEventListener("mouseup", handleMouseUp)
      document.removeEventListener("mousemove", handleMouseMove)
    }
  }, [isSelecting, selection])

  const toggleSelection = () => {
    setIsSelecting(!isSelecting)
  }

  const cursorStyle = isSelecting ? { cursor: "crosshair" } : { cursor: "auto" }

  //If showAlertFailed is equal to true then alert box will call the handleAlertClose()
  if (responseMessage) {
    setTimeout(() => {
      handleAlertClose()
    }, 2000)
  }

  const handleAlertClose = () => {
    setResponseMessage("")
  }

  const handleFilenameChange = (event) => {
    setScriptName(event)
  }

  const handleUpload = async () => {
    const formData = new FormData()
    console.log("scriptname1", selectedFile)
    formData.append("file", selectedFile)
    formData.append("script_name", scriptName)
    formData.append("device_name", devicesData[activeDevice]?.device_name)
    console.log("formdata", formData, fileUploadOpen)

    try {
      const response = await axios.post(
        msl_ipaddress_trigger + "robo-recorder/msl",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      )
      if (response.status === 200) {
        setResponseMessage(response.data)
        handlePopupClose()
      }
    } catch (error) {
      setErrorMessage("Backend Issue")
      console.error("errormessage", error)
    }
  }

  const screenShotOpenHandler = function () {
    setScreenPopup(true)
  }
  const screenShotCloseHandler = function () {
    setScreenPopup(false)
  }
  const screenShotHandler = async () => {
    screenShotOpenHandler()
    let screenShotUrl = ""
    if (buildDeviceName === "TCH-Android") {
      screenShotUrl = SCREEN_SHOT_IMAGE_ETISILAT
    } else {
      screenShotUrl = SCREEN_SHOT_IMAGE_API
    }
    try {
      const response = await fetch(screenShotUrl)
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      setScreenShotDownload(url)
    } catch (error) {
      console.log(error)
    }
  }

  const videoQuality = () => {
    if (networkLogs) {
      setNetworkLogs(false)
    }
    setTriggerID(generateUniqueId())
    setReportData("")
    setVideoQualityCheck("true")
  }
  useEffect(() => {
    console.log("Trigger ID Updated", triggerId)
  }, [triggerId])

  const handleCloseQuality = () => {
    setVideoQualityCheck("false")
    closeVideoQuality()
  }
  const [isDragging, setDragging] = useState(false)
  const handleDragStart = () => {
    setDragging(true)
  }
  const handleDragEnd = () => {
    setDragging(false)
  }
  const containerStyle = {
    overflowY: isDragging ? "hidden" : "auto",
  }
  const { theme } = useTheme()
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }

  const closeVideoQuality = () => {
    axios
      .get(
        userProfile.username === "akshitha"
          ? GENERATE_REPORT_VQ_AKSHITHA_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: "",
                device_name: devicesData.map((device) => device.device_name)[0],
              })
          : GENERATE_REPORT_VQ_API +
              JSON.stringify({
                trigger_id: triggerId,
                user_name: userProfile.username,
                action: "close",
                url: "",
                device_name: devicesData.map((device) => device.device_name)[0],
              })
      )
      .then((res) => {
        console.log("close video quality", res.data)
      })
      .catch((er) => console.log(er))
  }

  const generateReport = () => {
    setReport("True")
    setVideoQualityCheck(false)
    generateReportMSL()
  }
  const generateReportMSL = () => {
    axios
      .get(
        GENERATE_REPORT_VQ_API +
          JSON.stringify({
            trigger_id: triggerId,
            user_name: userProfile.username,
            action: "generate_report",
            url: "",
            device_name: devicesData.map((device) => device.device_name)[0],
          })
      )
      .then((res) => {
        console.log("generateReport MSL", res.data === "True")
        if (res.data === "True") {
          setAlertMessage("Generating the Report")
        } else {
          // setReportMessage("Report Not Generated")
        }
      })
      .catch((er) => console.log(er))
  }
  const PDOpenHandler = function (pdDevice) {
    setProfanityDetectionOpen(true)
    setPDDeviceName(pdDevice)
    setPDTriggerID(generateUniqueId())
  }
  const PDCloseHandler = function () {
    setProfanityDetectionOpen(false)
  }

  const ProfanityDetectionHandler = (data) => {
    let duration = data
    setPDinput(duration)
    let calls = duration / 5
    if(/^[0-9]*[05]$/.test(data)){
    setTotalCalls(calls)
    PDLiveApiDataDisplay(duration)
  }
    else{
      alert("Please enter the duration ending with 0 or 5")
    }
    setProfanityDetectionOpen(false)
  }

  const PDLiveApiDataDisplay = async (duration) => {
    let PDLiveApiData = ""
    setTotalCalls((prev)=>prev-1)
    console.log("total calls api",totalCalls)
    PDLiveApiData = `${PROFANITY_DETECTION_LIVE_API}${JSON.stringify({
      trigger_id: PDtriggerId,
      duration_limit: duration || PDinput,
    })}`
    await axios
      .post(PDLiveApiData)
      .then((response) => {
        setPDHandlerDisplay(true)
        response.data.contains_profanity = `${response.data.contains_profanity}`
        console.log("Profanity live response", response)
        setPDLiveResponseData(response.data)
        console.log("Profanity live", PDLiveResponseData)
      })
      .catch((error) => {
        alert("Backend Issue")
        setPDinput()
        console.log(error, "pderror")
      })
  }

  useEffect(() => {
    // const [pdCallCount,setPdCallCount]=useState(0)
    if (PDinput && totalCalls) {
      const interval = setInterval(() => {
        if (totalCalls > 0) {
          console.log("Inside Total calls", totalCalls)
          PDLiveApiDataDisplay()
        } else {
          clearInterval(interval)
        }
      }, 5000)

      // Clear interval on unmount or when PDinput changes
      return () => clearInterval(interval)
    }
  }, [PDinput, totalCalls])

  const PDReportApiHandler = async () => {
    console.log("pdtrigger id", triggerId)
    let PDApiData = ""
    PDApiData = `${PROFANITY_REPORT_GENERATE_API}${JSON.stringify({
      device_name: PDDeviceName,
      platform: platform_data,
      locked_by: userProfile.username,
      duration: PDinput,
      trigger_id: PDtriggerId,
    })}`
    await axios
      .post(PDApiData)
      .then((response) => {
        console.log("PDReportApiHandler", response)
        setPDReportResponse(response.data)
        
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const PDReportHandler = function (PDReport) {
    PDReportApiHandler()
  }

  const PDDisplayCloseApi = () => {
     setPDHandlerDisplay(false)
    // await axios
    //   .get(
    //     DELETE_PROFANITY_REPORT_API +
    //       JSON.stringify({ trigger_id: PDtriggerId })
    //   )
    //   .then((res) => {
    //     console.log("generateReport Profanity", res)
    //       setPDHandlerDisplay(false)
        
    //   })
    //   .catch((er) => {
    //     setPDHandlerDisplay(false)
    //     console.log(er)
    //   })
  }

  const PDDisplayCloseHandler = function (PDDisplayClose) {
      PDDisplayCloseApi()
    
  }

  return (
    <div className="device-view" style={cursorStyle}>
      <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
        <Link to={"/platform"}>Platform</Link>

        <Typography color="#0D6EFD">Device View</Typography>
      </Breadcrumbs>
      <Snackbar
        open={reportMessage}
        autoHideDuration={4000}
        className="schedule-confirmation"
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {reportMessage && (
          <Alert severity="error" onClose={() => setReportMessage("")}>
            {reportMessage}
          </Alert>
        )}
      </Snackbar>
   <Snackbar
        open={PDReportResponse}
        autoHideDuration={6000}
        onClose={() => setPDReportResponse("")}
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {PDReportResponse === "True" ? (
          <Alert icon={true}>Generating the Report....</Alert>
        ) : (
          <Alert icon={true}>Server Error, Report not generated..</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        open={returnValueCrop === true}
        autoHideDuration={6000}
        onClose={() => setReturnValueCrop(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {returnValueCrop === true && (
          <Alert icon={true}>Reference icon saved</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        open={alertMessage === "Generating the Report"}
        autoHideDuration={6000}
        onClose={() => setAlertMessage("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {alertMessage === "Generating the Report" && (
          <Alert icon={true}>Generating the Report..</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        open={returnValueCropFailure === true}
        autoHideDuration={6000}
        onClose={() => setReturnValueCropFailure(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {returnValueCrop === true && <Alert icon={true}>Backend Issue</Alert>}
      </Snackbar>
      <Snackbar
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        open={returnValueMessage}
        autoHideDuration={6000}
        onClose={() => setReturnValueMessage("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {returnValueMessage && <Alert icon={true}>{returnValueMessage}</Alert>}
      </Snackbar>
      <Snackbar
        className={`reboot-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={rebootResponse === "Device rebooted"}
        autoHideDuration={6000}
        onClose={() => setRebootResponse("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {rebootResponse === "Device rebooted" && (
          <Alert icon={true}>Device is Rebooted Successfully</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`reboot-alert-message ${
          theme === "dark" ? "dark" : "light"
        }`}
        open={
          rebootResponse === "Server Error, please try again after sometime"
        }
        autoHideDuration={6000}
        onClose={() => setRebootResponse("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {rebootResponse === "Server Error, please try again after sometime" && (
          <Alert icon={true}>
            Server Error, please try again after sometime
          </Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`build-message ${theme === "dark" ? "dark" : "light"}`}
        open={buildErrorHandler === "Network Error"}
        autoHideDuration={6000}
        onClose={() => setBuildErrorHandler("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {buildErrorHandler === "Network Error" && (
          <Alert icon={true}>Network Error</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`build-message ${theme === "dark" ? "dark" : "light"}`}
        open={buildStatus === "Build Loaded"}
        autoHideDuration={6000}
        onClose={() => setBuildStatus("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {buildStatus === "Build Loaded" && (
          <Alert icon={true}>Build Installation is Completed</Alert>
        )}
      </Snackbar>

      <Snackbar
        className={`build-message ${theme === "dark" ? "dark" : "light"}`}
        open={buildStatus === "App Not Found"}
        autoHideDuration={6000}
        onClose={() => setBuildStatus("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {buildStatus === "App Not Found" && (
          <Alert icon={true}>App Not Found</Alert>
        )}
      </Snackbar>
      <Snackbar
        className={`build-message ${theme === "dark" ? "dark" : "light"}`}
        open={buildStatus === "Version already exists"}
        autoHideDuration={6000}
        onClose={() => setBuildStatus("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {buildStatus === "Version already exists" && (
          <Alert icon={true}>Version is Already Exist</Alert>
        )}
      </Snackbar>
      {responseMessage && (
        <div className="alertDiv1">
          <Alert
            severity="success"
            variant="filled"
            onClose={handleAlertClose}
            icon={false}
            className="alertBox1"
          >
            {responseMessage}
          </Alert>
        </div>
      )}
      <PopupComponent
        open={open}
        text="Proceed With Device Hard Reboot ?"
        handleClose={handleClosePopup}
        functionHandle={hardRebootBlur}
      />
      <ProfanityDetection
        open={ProfanityDetectionOpen}
        handleClose={PDCloseHandler}
        functionHandle={ProfanityDetectionHandler}
      />
      <BuildLoading
        open={buildPopupOpen}
        handleClose={buildCloseHandler}
        buildApi={BuildDataApi}
        devicesData={devicesData}
      />

      <ScreenShotCrop
        open={screenPopup}
        screenShotCloseHandler={screenShotCloseHandler}
        screenShotDownloadImg={screenShotDownload}
        buildDeviceName={buildDeviceName}
        returnValueCrop={returnValueHandler}
      />

      {screenshot && (
        <div className="popup-box-deviceview">
          <div className="box-deviceview">
            <button onClick={toggleSelection}>
              {isSelecting ? "Cancel" : "Capture"}
            </button>
            <div>
              <img
                src={screenshot}
                alt="screenshot"
                style={{ pointerEvents: isSelecting ? "none" : "auto" }}
              />
            </div>
            <button onClick={clearScreenshot}>Close</button>
          </div>
        </div>
      )}
      {/* MAIN CONTAINER */}
      <div className="dv-container">
        {/* LEFT CONTAINER */}

        <div className={`dv-left ${theme === "dark" ? "dark" : "light"}`}>
          <div className="dv-screen-container">
            <div className="dv-left-top">
              <div className="device-view-left-top-main-left">
                <h4
                  className={`dv-left-top-heading ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  {devicesData[activeDevice]?.device_name}
                </h4>
                <div className="dv-upload">
                  <Tooltip
                    title={"Select the script file to upload"}
                    className="tooltip-display"
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      className={`upload-btn ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    />
                  </Tooltip>
                </div>
                {fileUploadOpen && (
                  <div>
                    <FileUpload
                      scriptName={handleFilenameChange}
                      handleClose={handlePopupClose}
                      handleUpload={handleUpload}
                      errorMessage={errorMessage}
                    />
                  </div>
                )}
              </div>

              <div className="dv-left-top-main-middle">
                {buildStatus === "In Progress" ? (
                  <button
                    onClick={buildOpenHandler}
                    disabled
                    title="Build Loading Started"
                    className={`dv-btn ${theme === "dark" ? "dark" : "light"}`}
                  >
                    Build
                  </button>
                ) : (
                  <button
                    onClick={buildOpenHandler}
                    className={`dv-btn ${theme === "dark" ? "dark" : "light"}`}
                  >
                    Build
                  </button>
                )}

                <DropDownComponent
                  networkLogsToggle={networkLogsToggle}
                  DeviceName={buildDeviceName}
                  throattlingCurrentSpeed={throattlingCurrentSpeed}
                  networkStatusResponse={networkStatusResponse}
                />
              </div>
              <div className="dv-left-top-main-right">
                <Tooltip
                  title={"Reboot The Device"}
                  className="tooltip-display"
                >
                  <button
                    className={`reboot-btn ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={() =>
                      hardReboot(devicesData[activeDevice]?.device_name)
                    }
                  >
                    <img className="rebootIcon" src={Reboot} alt="Rebbot" />
                  </button>
                </Tooltip>
                <Tooltip
                  title={"Screen Shot The Device"}
                  className="tooltip-display"
                >
                  <button
                    className={`reboot-btn ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={screenShotHandler}
                  >
                    <img
                      id="Capture_Image Button"
                      className="screenIcon"
                      src={screenIcon}
                      alt="screenIcon"
                    />
                  </button>
                </Tooltip>

                <Tooltip title={"Video Quality"} className="tooltip-display">
                  <button
                    className={`reboot-btn ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <img
                      className="uploadIcon"
                      src={videoQualityIcon}
                      alt="Logo"
                      onClick={videoQuality}
                    />
                  </button>
                </Tooltip>
                <Tooltip
                  title={"Profanity Detection"}
                  className="tooltip-display"
                >
                  <button
                    className={`profanity-btn ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    onClick={() =>
                      PDOpenHandler(devicesData[activeDevice]?.device_name)
                    }
                    disabled={PDHandlerDisplay}
                  >
                    <img
                      className="profanityIcon"
                      src={profanityIcon}
                      alt="Profanity Detect"
                    />
                  </button>
                </Tooltip>
                {/* {ReportData && (
                   <Tooltip title={"View Report"} className="tooltip-display">
                     <button
                       className={`reboot-btn ${
                         theme === "dark" ? "dark" : "light"
                       }`}
                     >
                       <img
                         className="uploadIcon"
                         src={ViewReport}
                         alt="Report"
                         onClick={viewReport}
                       />
                     </button>
                   </Tooltip>
                 )} */}
              </div>
            </div>
            <div className={"dv-left-bottom"}>
              {blur ? (
                <div className="reboot-block">
                  <img
                    className="reboot-img"
                    src={RebootRefresh}
                    alt="Reboot"
                  />
                  <div className="reboot-text">Reboot in Progress...</div>
                </div>
              ) : (
                ""
              )}
              {buildStatus === "In Progress" ? (
                <div className="build-status-progress">
                  <div class="spin-container">
                    <div class="spin" id="loader"></div>
                    <div class="spin" id="loader2"></div>
                    <div class="spin" id="loader3"></div>
                    <div class="spin" id="loader4"></div>
                    <span
                      className={`text ${theme === "dark" ? "dark" : "light"}`}
                    >
                      Installation in Progress...
                    </span>
                  </div>
                </div>
              ) : (
                <div
                  className="dv-iframe-container"
                  id="dv-iframe-container"
                  ref={divRef}
                >
                  {renderDevice(devicesData[activeDevice])}
                  {networkLogs ? (
                    <div
                      className={`network-block ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      <img
                        className={`network-block-close ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        onClick={networkBlockClose}
                        src={close}
                        alt="Network Block"
                      />
                      <iframe
                        className="network-block-iframe"
                        src={devicesData[activeDevice]?.proxy_url}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {videoQualityCheck === "true" ? (
                    <Draggable>
                      <div
                        className={`network-video-block ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        <div
                          classname="transparent-block"
                          style={{
                            color: "white",
                          }}
                        >
                          <div className="video-block-top">
                            <div>
                              <h3
                                className={`video-block-heading  ${
                                  theme === "dark" ? "dark" : "light"
                                }`}
                              >
                                Video Insights
                              </h3>
                            </div>
                            <div className="video-icons">
                              {Object.keys(videoMetricsData).length > 0 && (
                                <img
                                  style={{
                                    border: "none",
                                    height: "3vh",
                                    width: "3vh",
                                  }}
                                  src={theme === "dark" ? Report : Report_light}
                                  title="Generate Report"
                                  onClick={() => generateReport()}
                                  alt="Reports"
                                />
                              )}
                              {/* {ReportData && (
                                 <img
                                   style={{
                                     border: "none",
                                     height: "3vh",
                                     width: "3vh",
                                   }}
                                   src={theme === "dark" ? Report : Report_light}
                                   title="View Report"
                                   onClick={() => viewReport()}
                                   alt="Reports"
                                 />
                               )} */}
                              <IconButton
                                aria-label="close"
                                color="inherit"
                                size="small"
                                className={`network-video-block-close ${
                                  theme === "dark" ? "dark" : "light"
                                }`}
                              >
                                <CloseIcon
                                  onClick={handleCloseQuality}
                                  fontSize="inherit"
                                  style={{ color: "white" }}
                                />
                              </IconButton>
                            </div>
                          </div>
                          {Object.keys(videoMetricsData).length > 0 ? (
                            <>
                              <ReactSmartScroller
                                vertical
                                style={{
                                  height: "200px",
                                  overflowX: "hidden",
                                  overflowY: "auto",
                                }}
                                onDragStart={handleDragStart}
                                onDragEnd={handleDragEnd}
                              >
                                <div
                                  style={{
                                    margin: "5px",
                                    padding: "1px",
                                    border: "1px solid #ccc",
                                  }}
                                >
                                  {qualityScore && qualityScore.length > 0 && (
                                    <div>
                                      <div className="custom-y-axis-label">
                                        Quality Score
                                      </div>
                                      <LineChart
                                        xAxis={[
                                          {
                                            data: xAxisData,
                                            label: "Time in Seconds",
                                          },
                                        ]}
                                        yAxis={[
                                          {
                                            data: qualityScore,
                                            label: "Quality Score",
                                            max: 100, // Set the maximum value of the y-axis to 100
                                            min: 0, // Set the minimum value of the y-axis to 0
                                            axisLabel: {
                                              interval: 20,
                                              formatter: (value) =>
                                                `${value.toFixed(2)}`, // Formats the numeric value to show as currency with 2 decimal places
                                            },
                                          },
                                        ]}
                                        series={[
                                          {
                                            data: qualityScore,
                                          },
                                        ]}
                                        width={400}
                                        height={200}
                                      />
                                    </div>
                                  )}
                                </div>
                                <div
                                  style={{
                                    margin: "5px",
                                    padding: "1px",
                                    border: "1px solid #ccc",
                                  }}
                                >
                                  {VMAveragePSNRValue &&
                                    VMAveragePSNRValue.length > 0 && (
                                      <div>
                                        <div className="custom-y-axis-label">
                                          Average PSNR Values
                                        </div>
                                        <LineChart
                                          xAxis={[
                                            {
                                              data: xAxisData,
                                              label: "Time in Seconds",
                                            },
                                          ]}
                                          yAxis={[
                                            {
                                              data: VMAveragePSNRValue,
                                              label: "Average PSNR",
                                            },
                                          ]}
                                          series={[
                                            {
                                              data: VMAveragePSNRValue,
                                            },
                                          ]}
                                          width={400}
                                          height={200}
                                        />
                                      </div>
                                    )}
                                </div>
                                <div
                                  style={{
                                    margin: "5px",
                                    padding: "1px",
                                    border: "1px solid #ccc",
                                  }}
                                >
                                  {blockingRate && blockingRate.length > 0 && (
                                    <div>
                                      <div className="custom-y-axis-label">
                                        Blocking Rate
                                      </div>
                                      <LineChart
                                        xAxis={[
                                          {
                                            data: xAxisData,
                                            label: "Time in Seconds",
                                          },
                                        ]}
                                        yAxis={[
                                          {
                                            label: "Blocking Rate",
                                          },
                                        ]}
                                        series={[
                                          {
                                            data: blockingRate,
                                          },
                                        ]}
                                        width={400}
                                        height={200}
                                      />
                                    </div>
                                  )}
                                </div>
                                <div
                                  style={{
                                    margin: "5px",
                                    padding: "1px",
                                    border: "1px solid #ccc",
                                  }}
                                >
                                  {bandingRate && bandingRate.length > 0 && (
                                    <div>
                                      <div className="custom-y-axis-label">
                                        Banding Rate
                                      </div>
                                      <LineChart
                                        xAxis={[
                                          {
                                            data: xAxisData,
                                            label: "Time in Seconds",
                                          },
                                        ]}
                                        yAxis={[
                                          {
                                            label: "Banding Rate",
                                          },
                                        ]}
                                        series={[
                                          {
                                            data: bandingRate,
                                          },
                                        ]}
                                        width={400}
                                        height={200}
                                      />
                                    </div>
                                  )}
                                </div>
                              </ReactSmartScroller>

                              <table
                                className={`video-quilty-data  ${
                                  theme === "dark" ? "dark" : "light"
                                }`}
                              >
                                <div className="video-quilty-data-A">
                                  <tr>
                                    <th>Quality Score</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.Quality_Score}</td>
                                  </tr>
                                  <tr>
                                    <th>FPS</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.FPS}</td>
                                  </tr>
                                  <tr>
                                    <th>Dropped Frames</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.Dropped_Frames}</td>
                                  </tr>
                                  <tr>
                                    <th>Total Frames</th>
                                    <td>:</td>
                                    <td>{accumulatedFrameCount}</td>
                                  </tr>
                                  <tr>
                                    <th>Resolution</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.Resolution}</td>
                                  </tr>
                                  <tr>
                                    <th>Blur Detected</th>
                                    <td>:</td>
                                    <td>
                                      {videoMetricsData.Blur_Detected === null
                                        ? videoMetricsData.Blur_Detected
                                            .length + "Frames"
                                        : "0 Frames"}
                                    </td>
                                  </tr>
                                  <tr>
                                    <th>Blur Score</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.Blur_Score}</td>
                                  </tr>
                                  <tr>
                                    <th>Macro Blocking</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.macro_blocking}</td>
                                  </tr>
                                </div>
                                <div className="video-quilty-data-B">
                                  <tr>
                                    <th>Black Frames</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.black_frames}</td>
                                  </tr>
                                  <tr>
                                    <th>Average PSNR</th>
                                    <td>:</td>
                                    <td>
                                      {Number(
                                        videoMetricsData.Avg_PSNR_Value
                                      ).toFixed(2)}
                                    </td>
                                  </tr>
                                  <tr>
                                    <th>SSIM Score</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.ssim_score}</td>
                                  </tr>
                                  <tr>
                                    <th>Banding Rate</th>
                                    <td>:</td>
                                    <td>
                                      {Number(
                                        videoMetricsData.Banding_Rate
                                      ).toFixed(2)}
                                    </td>
                                  </tr>
                                  <tr>
                                    <th>Blocking Rate</th>
                                    <td>:</td>
                                    <td>
                                      {Number(
                                        videoMetricsData.Blocking_Rate
                                      ).toFixed(2)}
                                    </td>
                                  </tr>
                                  <tr>
                                    <th>Connection Speed</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.connection_speed}</td>
                                  </tr>
                                  <tr>
                                    <th>Data Used</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.network_activity}</td>
                                  </tr>
                                  <tr>
                                    <th>Timestamp</th>
                                    <td>:</td>
                                    <td>{videoMetricsData.time_stamp}</td>
                                  </tr>
                                </div>
                              </table>
                            </>
                          ) : (
                            <div className="video-quality-nodata">
                              No Data Available
                            </div>
                          )}
                        </div>
                      </div>
                    </Draggable>
                  ) : (
                    ""
                  )}
                  {PDHandlerDisplay && (
                    <div>
                      <PDDisplay
                        PDLiveDataDisplay={PDLiveResponseData}
                        PDReportData={PDReportHandler}
                        PDDisplayCloseData={PDDisplayCloseHandler}
                      ></PDDisplay>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
        {renderUrl2(devicesData[activeDevice]) !== null ? (
          <div className="dv-right">
            <div onClick={handleClick} className="toggle">
              {togglebutton ? (
                <div className="toggle-left"></div>
              ) : (
                <div className="toggle-right"></div>
              )}
            </div>
            <br />
            <br />

            {togglebutton && renderRemote1(devicesData[activeDevice])}
            {!togglebutton && renderRemote2(devicesData[activeDevice])}
          </div>
        ) : (
          <div className="dv-right">
            <div onClick={handleClick} className="toggle-disable">
              {togglebutton ? (
                <div className="toggle-left"></div>
              ) : (
                <div className="toggle-right"></div>
              )}
            </div>
            <br />
            <br />

            {togglebutton && renderRemote1(devicesData[activeDevice])}
            {!togglebutton && renderRemote2(devicesData[activeDevice])}
          </div>
        )}
      </div>
      {/* for multidevice view */}
      {devicesData.length > 1 && (
        <div className="multi-device-list">
          {devicesData.map((Data, index) => {
            if (Data.device_name !== devicesData[activeDevice]?.device_name) {
              return (
                <div
                  className={`multi-device-item ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  onClick={() => iframeHandler(index)}
                >
                  <div className="device-item-header">
                    <h3>{Data?.device_name}</h3>
                  </div>
                  <div className="remote-iframe-block">
                    <iframe
                      className="remote-iframe"
                      src={Data?.thumbnail_url}
                      title="iframe"
                    ></iframe>
                  </div>
                </div>
              )
            }
          })}
        </div>
      )}
    </div>
  )
}

export default DeviceView
//
