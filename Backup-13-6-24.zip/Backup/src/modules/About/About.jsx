/** * Component: About
 * File: About.jsx
 * Description: This file contents the implementation of about page.
 * Author: Mounika, Harine
 * **/
import React from "react"
import "../About/About.css"
import usermanual from "../../assets/documents/EvQUAL_User_Manual_V.2.1.7.docx"
import { Link } from "react-router-dom"
import { Breadcrumbs } from "@mui/material"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"
const About = () => {
  const { theme } = useTheme()
  return (
    <React.Fragment>
      <div className="about">
        <Breadcrumbs aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
        </Breadcrumbs>
        <div class="force-overflow">
          <div className="manual">
            <span>
              <a
                href={usermanual}
                target="_blank"
                download="User_Manual.docx"
                data-testid="about-link"
                className={`userManual ${theme === "dark" ? "dark" : "light"}`}
                rel="noreferrer"
              >
                User Manual
              </a>
            </span>
          </div>
          <h1
            data-testid="about-heading1"
            className={`about-heading  ${theme === "dark" ? "dark" : "light"}`}
          >
            EvQUAL-V.3.4
          </h1>
          <div className="first">
            <p
              data-testid="about-sh1txt1"
              className={`about-paragraph  ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Company Overview:
              </h4>
              L&T Technology Services Limited (LTTS) is a global leader in
              Engineering and R&D (ER&D) services. With 1033 patents filed for
              57 of the Global Top 100 ER&D spenders, LTTS lives and breathes
              engineering. Our innovations speak for themselves – World’s 1st
              Autonomous Welding Robot, Solar ‘Connectivity’ Drone, and the
              Smartest Campus in the World, to name a few. LTTS’ expertise in
              engineering design, product development, smart manufacturing, and
              digitalization touches every area of human lives - from the moment
              one wakes up till the time one goes to bed. With 110 Innovation
              and R&D design centers globally, we specialize in disruptive
              technology spaces such as 5G, Artificial Intelligence,
              Collaborative Robots, Digital Factory, and Autonomous Transport.
              LTTS is a publicly listed subsidiary of Larsen & Toubro Limited,
              the $21 billion Indian conglomerate operating in over 30
              countries.
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Tool Description:
              </h4>
              EvQUAL is a Cloud enabled Remote Test Orchestration Platform that
              integrates automated and manual testing of apps, players, devices,
              streams & networks.For organizations, across Consumer Electronics,
              Telecom, Media & Entertainment, Automotive, Industrial, Medical
              and other verticals, who are looking at faster time-to-market &
              enhanced quality for their products, EvQUAL is the Next-Gen Test
              Solution of preference.
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                EvQUAL Snapshot:
              </h4>
              <li>
                Intelligent, in-house developed Test Automation suite from L&T
                Technology Services (LTTS).
              </li>
              <li>Developed for multiplatform and multidevice automation</li>
              <li>
                Integrates various test components, based on the unique device
                and platform conﬁgurations.
              </li>
              <li>
                Support for End-to-End testing with available interfaces for
                measuring instruments, robotic arms.
              </li>
              <li>
                In-build support for functional & stability testing; available
                integrations for performance, security & accessibility testing.
              </li>
              <li>
                Anytime, Anywhere, Any-device access to Dashboard with Live
                Results Updates, Analytics, Visualization.
              </li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                {" "}
                Benefits:
              </h4>
              <li>
                Test Infra Utilization: Cloud-mediated Remote testing enables
                higher test asset utilization
              </li>
              <li>
                Cost Savings: Leverage of reusable components, flexible
                licensing models provide cost reduction
              </li>
              <li>
                Time Savings: Scalable Parallel testing over distributed test
                infra enables faster time to market
              </li>
              <li>
                Reduced Rework: ML-driven defect classification & triage saves
                developer effort to fix issues
              </li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Top Use Cases:
              </h4>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Media & Entertainment:
              </h4>
              <li>OTT App & Player Testing on all Media platforms</li>
              <li>Set Top Box Testing</li>
              <li>Quality of Experience Validation</li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Automotive:
              </h4>
              <li>Infotainment Systems Testing</li>
              <li>Cluster Testing</li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Telecom & Consumer Electronics:
              </h4>
              <li>5G RAN and End-to-end system Testing</li>
              <li>
                Handsets & Wearables Testing as per Telco Carrier standards
              </li>
              <li>Broadband Device Testing: Routers & Gateways</li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Other verticals:
              </h4>
              <li>Mobile, Web, Desktop Apps and HMI Testing</li>
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Support and Training:
              </h4>
              We are committed to providing exceptional support and training to
              our customers. Our dedicated support team is available via email,
              and phone to assist with any inquiries or technical issues.
              Additionally, we offer comprehensive documentation and video
              tutorials to ensure you get the most out of EvQUAL.
              <h4
                className={`header-style  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Contact Information:
              </h4>
              For more information about EvQUAL or to schedule a demo, please
              contact our sales team.
            </p>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default About
