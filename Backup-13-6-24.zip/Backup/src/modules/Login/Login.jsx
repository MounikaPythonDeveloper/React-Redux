import React, { useState, useEffect, useRef } from "react"
import MyButton from "../../components/ReusableComponents/Buttons"
import MyLink from "../../components/ReusableComponents/Links"
import "../Login/Login.css"
import { useNavigate } from "react-router-dom"
import { Link } from "react-router-dom"
import axios from "axios"
import { useLocation } from "react-router-dom"
import { IconButton, InputAdornment, TextField } from "@mui/material"
import { Visibility, VisibilityOff } from "@mui/icons-material"
import { makeStyles } from "@material-ui/core"
import EvQuallogo from "../../assets/images/EvQuallogo.svg"
import PopupComponent from "../../components/ReusableComponents/PopupComponent/PopupComponent"
import { Alert, Snackbar } from "@mui/material"
import CloseIcon from "@mui/icons-material/Close"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"
import {
  SIGNIN_API,
  VALIDATE_USERNAME_SIGNIN_API,
  RELOGIN_API,
} from "../../services/api"

var CryptoJS = require("crypto-js")

const useStyles = makeStyles({
  underline: {
    "&&&:before": { borderBottom: "1px solid grey" },
    "&&:after": { borderBottom: "none" },
  },
  inputAdornment: {
    fontSize: "30px",
    marginLeft: "-5px",
  },
}) //mui

const Login = () => {
  const { theme } = useTheme()
  const [isLoading, setIsLoading] = useState(false)
  const [usernameExists, setUsernameExists] = useState(true)
  const [open, setOpen] = useState(false)
  const [loginAttemptsMap, setLoginAttemptsMap] = useState({}) //for 5 login attepmts block user
  const classes = useStyles() //mui
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [timeoutId, setTimeoutId] = useState("null") //alert pop up
  const [error, setError] = useState("")
  const [resetMes, setResetMes] = useState("Your Password is  reseted")
  const [passwordMes, setPasswordMes] = useState("")
  const location = useLocation()
  const [loginMes, setLoginMes] = useState("")
  var message = location.state ? location.state.message : ""
  const [stateAuth, setStateAuth] = useState()
  const [dataBaseData, setDataBaseData] = useState([])
  const [mslData, setMslData] = useState([])
  const [mslDataTrigger, setMslDataTrigger] = useState([])
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const usernameInputRef = useRef()
  const passwordInputRef = useRef()
  const [sessionId, setSessionId] = useState("")
  const [showUsernameErrorMessage, setShowUsernameErrorMessage] =
    useState(false)
  const [isFocused, setIsFocused] = useState(false)

  let navigate = useNavigate()

  const handleUsernameChange = (event) => {
    const enteredUsername = event.target.value

    setShowUsernameErrorMessage(false)

    // Retrieve the stored credentials from local storage
    const storedCredentials =
      JSON.parse(sessionStorage.getItem("userCredentials")) || []

    // Find the stored credentials for the entered username
    const matchedCredentials = storedCredentials.find(
      (cred) => cred.username === enteredUsername
    )

    setUsername(enteredUsername)
  }
  const handleUsernameFocus = () => {
    setIsFocused(true)
  }
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }
  const preventDragHandler = (e) => {
    e.preventDefault()
  }
  const handleClosePopup = function () {
    setOpen(false)
  }
  const debounce = (func, delay) => {
    let timerId
    return (...args) => {
      clearTimeout(timerId)
      timerId = setTimeout(() => {
        func(...args)
      }, delay)
    }
  }
  const { state } = useLocation()
  const [logoutAlert, setLogoutAlert] = useState(
    state ? state.autoLogout : false
  )
  console.log(logoutAlert, "logoutAlertlogoutAlert")

  useEffect(() => {
    // Push a new history state, which will replace the current one
    window.history.pushState(null, "", window.location.href)

    // Add a listener for the 'popstate' event (when user tries to navigate back)
    window.addEventListener("popstate", handlePopstate)

    // Cleanup the event listener when the component unmounts
    return () => {
      window.removeEventListener("popstate", handlePopstate)
    }
  }, [])

  const handlePopstate = () => {
    // Navigate forward again and push another history state
    window.history.forward()
    window.history.pushState(null, "", window.location.href)
  }

  useEffect(() => {
    let cancelRequest = false
    const checkUsernameExists = async () => {
      try {
        setIsLoading(true)
        const response = await axios.get(
          VALIDATE_USERNAME_SIGNIN_API + JSON.stringify({ username: username })
        )
        const exists = response.data
        if (!cancelRequest) {
          setUsernameExists(exists)
          setShowUsernameErrorMessage(!exists)
        }
      } catch (error) {
        console.error(error)
        if (!cancelRequest) {
          setUsernameExists(false)

          setShowUsernameErrorMessage(true)
        }
      } finally {
        setIsLoading(false)
      }
    }
    if (username && showUsernameErrorMessage) {
      checkUsernameExists()
    } else {
      setUsernameExists(true)
      setShowUsernameErrorMessage(false)
    }
    const debouncedCheckUsername = debounce(checkUsernameExists, 300)

    if (username && showUsernameErrorMessage) {
      debouncedCheckUsername()
    } else {
      setUsernameExists(true)
      setShowUsernameErrorMessage(false)
    }

    return () => {
      cancelRequest = true
    }
  }, [username, showUsernameErrorMessage])

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  const handleRelogin = () => {
    //relogin
    setOpen(false)
    const relogin_data = {
      username: username,
      logout_time: new Date().toISOString(),
      session_id: sessionId,
    }
    axios
      .post(RELOGIN_API + JSON.stringify(relogin_data))
      .then((response) => {
        navigate("/")
      })

      .catch((error) => {
        console.log(error, "error")
      })
  }

  const loginusers = (e) => {
    e.preventDefault()

    clearTimeout(timeoutId) //alert pop up
    if (username.trim() === "" && password.trim() === "") {
      setError("Username & Password cannot be empty")
      return
    }
    if (username.trim() === "") {
      setError("Username cannot be empty")
      return
    }
    if (password.trim() === "") {
      setError("Password cannot be empty")
      return
    }

    const email = usernameInputRef.current.value
    const message = passwordInputRef.current.value
    var key = "AAAAAAAAAAAAAAAA"
    key = CryptoJS.enc.Utf8.parse(key)

    var encrypted = CryptoJS.AES.encrypt(password, key, {
      mode: CryptoJS.mode.ECB,
    })
    encrypted = encrypted.toString()

    const signin_data = {
      username: email.toLowerCase(),
      password: encrypted,
      flag: false,
      login_status: false,
      login_time: new Date().toISOString(),
    }
    console.log("signin data", signin_data)
    axios
      .post(SIGNIN_API + JSON.stringify(signin_data))
      .then((response) => {
        if (response.data.valid === "true") {
          signin_data.login_status = true
          signin_data.valid = true

          sessionStorage.setItem("userData", JSON.stringify(response.data))
          sessionStorage.setItem(
            "userSessionData",
            JSON.stringify(response.data)
          )
          sessionStorage.setItem("signin_data", JSON.stringify(signin_data))
          navigate("/platform")
        } else if (response.data.error === "Your are already logged in") {
          setOpen(true)
        } else {
          setLoginAttemptsMap((prevMap) => ({
            ...prevMap,
            [email]: signin_data.login_attempts,
          }))
          setError(response.data.message)

          if (response.data.message === "Invalid password or username") {
            setOpen(false)
          } else {
            setOpen(true)
          }
          if (response.data.session_id) {
            setSessionId(response.data.session_id)
          }
        }
      })

      .catch((error) => {
        console.log(error, "error")
        if (error.response && error.response.status === 500) {
          setError("Server Down")
        }
      })
  }

  const handleChange = (event) => {
    const enteredPassword = event.target.value
    if (enteredPassword.length <= 18) {
      setPassword(enteredPassword)
    }

    setPassword(enteredPassword)
  }
    const lightThemeStyles = {
    background: "linear-gradient(to right, #034e88, #40a7f6)",
    color: "white",
    borderRadius: "5px",
  }

  const texfieldInputStyle = {
    borderBottom: "1px solid grey !important",
    color: "white",
    opacity: 1,
    fontSize: 18,
    outline: "none",
    fontFamily: "Open Sans",
    paddingTop: 3,
    bottom: 5,
    lineHeight: "30px",
    background: theme === "light" ? lightThemeStyles.background : "none",
    borderRadius: theme === "light" ? lightThemeStyles.borderRadius : "none",
    caretColor: "white",
  }

  // const texfieldInputStyle = {
  //   borderBottom: "1px solid grey !important",
  //   color: "white",
  //   opacity: 1,
  //   fontSize: 18,
  //   outline: "none",
  //   fontFamily: "Open Sans",
  //   paddingTop: 3,
  //   bottom: 5,
  //   lineHeight: "30px",
  //   background: "transparent",
  //   caretColor: "white",
  // }
      const lightLabelStyles = {
    color: "#004a8",
    borderRadius: "5px",
  }

  const texfieldLabelStyle = {
    borderBottom: "1px solid grey !important",
    color: theme==="light"?"#004a8":"white",
    opacity: 1,
    fontSize: 18,
    outline: "none",
    fontFamily: "Open Sans",
    paddingTop: 0,
    bottom: 12,
    lineHeight: "30px",
    background: "transparent",
    caretColor: "white",
  }

  const closePopup = () => {
    setLogoutAlert(false)
    sessionStorage.setItem("mystate", false)
  }

  console.log(logoutAlert, "statusOfState")

  const action = (
    <React.Fragment>
      <IconButton
        size="small"
        aria-label="close"
        color="inherit"
        onClick={closePopup}
      >
        <CloseIcon fontSize="small" />
      </IconButton>
    </React.Fragment>
  )

  return (
    <React.Fragment>
      <div className="BackgroundImg">
        <Snackbar
          className={`logout-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          open={logoutAlert}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          action={action}
        >
          {logoutAlert && (
            <div>
              <Alert icon={false}>
                Your session has been timed out.Please login again.
                <IconButton
                  size="small"
                  aria-label="close"
                  color="inherit"
                  onClick={closePopup}
                >
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Alert>
              ,
            </div>
          )}
        </Snackbar>
        <div className={`Login-Page ${theme === "dark" ? "dark" : "light"}`}>
          <div className="logo-container">
            <img
              src={EvQuallogo}
              alt="Logo"
              className="logo"
              onDragStart={preventDragHandler}
            />
          </div>

          <div class="row">
            <div class="col-md-6 register-left">
              <div className="account sign-in">
                Create an account?&#160;
                <br />
                <MyLink to="/Register" id="SignUpLink" className="signupBtn">
                  Sign Up
                </MyLink>
              </div>
            </div>

            <div class="col-md-5 register-right">
              <form onSubmit={loginusers} className="newform">
                {error && (
                  <span
                    style={{
                      color: "white",
                      paddingLeft: "10px",
                      fontfamily: "Roboto Serif",
                      fontStyle: "Open Sans",
                    }}
                  ></span>
                )}

                <div className="input-text ">
                  <h3 className="reg_title"> Sign In</h3>
                  <TextField
                    id="standard-basic-username"
                    label="Username"
                    variant="standard"
                    className="texfield"
                    autoComplete="off"
                    type=""
                    inputRef={usernameInputRef}
                    value={username}
                    onChange={handleUsernameChange}
                    onFocus={handleUsernameFocus}
                    onBlur={() => setShowUsernameErrorMessage(true)}
                    InputProps={{
                      style: texfieldInputStyle,
                      classes: { underline: classes.underline },
                      startAdornment: (
                        <InputAdornment
                          position="start"
                          className={classes.inputAdornment}
                        ></InputAdornment>
                      ),
                    }}
                    InputLabelProps={{ style: texfieldLabelStyle }}
                    //autoFocus // bydefault cursor on username textfield
                  />
                  <span className="formlineNew"></span>
                  {!usernameExists && setShowUsernameErrorMessage && (
                    <p className="username-message">Username Doesn't Exist</p>
                  )}
                </div>
                <div className="input-text ">
                  <TextField
                    id="standard-basic-password"
                    label="Password"
                    variant="standard"
                    className="texfield"
                    autoComplete="off"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={handleChange}
                    InputLabelProps={{ style: texfieldLabelStyle }}
                    inputRef={passwordInputRef}
                    InputProps={{
                      classes: { underline: classes.underline }, //mui
                      startAdornment: (
                        <InputAdornment
                          position="start"
                          className={classes.inputAdornment}
                        ></InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle password visibility"
                            onClick={togglePasswordVisibility}
                            edge="end"
                            style={{
                              position: "absolute",
                              right: "10px",
                              transform: "translateY(-15%)",
                            }}
                          >
                            {showPassword ? <Visibility /> : <VisibilityOff />}
                          </IconButton>
                        </InputAdornment>
                      ),
                      style: texfieldInputStyle,
                    }}
                    //for password upto 18 characters
                    inputProps={{
                      maxLength: 18,
                    }}
                  />
                  {password.length === 18 && (
                    <p
                      className="error-message"
                      style={{
                        color: "red",
                        fontSize: "16px",
                        marginLeft: "32px",
                        fontFamily: "Open Sans",
                      }}
                    >
                      Maximum Limit 18 characters
                    </p>
                  )}
                </div>

                <div className="remember">
                  <span style={{ paddingLeft: 250 }}>
                    <Link
                      style={{
                        textAlign: "right",
                        width: "100%",
                        color: "#07F265",
                        fontWeight: 600,
                        fontSize: 16,
                        fontfamily: "Open Sans",
                      }}
                      state={{ message: resetMes }}
                      to="/forgotpassword"
                      id="ForgotpasswordLink"
                    >
                      {" "}
                      Forgot password ?{" "}
                    </Link>
                  </span>
                </div>

                <div className="input_css1 reset-align">
                  <MyButton
                    type="submit"
                    variant="contained"
                    label="Sign in"
                  ></MyButton>

                  {error && error !== "Your are already logged in" ? (
                    <p className="message">{error}</p>
                  ) : null}

                  {setOpen && error === "Your are already logged in" && (
                    <PopupComponent
                      open={open}
                      text="To login, first logout from another Device ?"
                      handleClose={handleClosePopup}
                      functionHandle={handleRelogin}
                    />
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default Login
