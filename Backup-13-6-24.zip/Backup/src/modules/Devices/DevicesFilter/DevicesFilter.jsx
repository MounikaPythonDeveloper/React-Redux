import React, { useState, useEffect } from "react"
import "./DevicesFilter.css"
import axios from "axios"
import { tooltipClasses } from "@mui/material/Tooltip"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { Form } from "react-bootstrap"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import SearchIcon from "../../../assets/images/Search.svg"
import LockIcon from "../../../assets/images/Lock.svg"
import UnlockIcon from "../../../assets/images/Unlock.svg"
import OfflineIcon from "../../../assets/images/Offline.svg"
import FilterIcon from "../../../assets/images/Filter.svg"
import ReserveIcon from "../../../assets/images/Reserve.svg"
import DeviceLockedErrorIcon from "../../../assets/images/DeviceLockedError.svg"
import OutOfNetworkIcon from "../../../assets/images/OutOfNetwork.svg"
import EditRegionIcon from "../../../assets/images/EditDevices.svg"
import Indiaflagicon from "../../../assets/images/indiaflagicon.png"
import UKIcon from "../../../assets/images/united-kingdom.png"
import USIcon from "../../../assets/images/united-states-of-america.png"
import Arrow from "../../../assets/images/Arrow 2.svg"
import {
  REMOTE_API,
  DEVICES_FILTER_SEARCH_API,
  VALIDATE_BUYLICENSE_STATUS,
  DEVICES_FILTER_NETWORK_REGION_API,
  GEO_LOCATION_STATUS_API,
} from "../../../services/api"
import Loader from "../../../components/ReusableComponents/Loader/Loader"
import {
  Alert,
  Autocomplete,
  Button,
  Checkbox,
  Container,
  FormControl,
  FormControlLabel,
  FormGroup,
  IconButton,
  Input,
  InputAdornment,
  Popover,
  Snackbar,
  TextField,
  Tooltip,
} from "@mui/material"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))

export default function DevicesFilter() {
  const [isChecked, setIsChecked] = useState(false)
  const [checkDevices, setCheckDevices] = useState([])
  const location = useLocation()
  const [deviceModel, setDeviceModel] = useState([])
  const [deviceInfo, setDeviceInfo] = useState(null)
  const [filterDropdown, setFilterDropdown] = useState(null)
  const [activeDeviceModel, setActiveDeviceModel] = useState("")
  const [devicesBasedOnModel, setDevicesBasedOnModel] = useState([])
  const [filterDropdownData, setFilterDropdownData] = useState([])
  const [activeCol, setActiveCol] = useState(1)
  const [filterDropdownSelectedData, setFilterDropdownSelectedData] = useState({
    deviceStatus: [],
    deviceList: [],
  })
  const [messageDisplay, setMessageDisplay] = useState("")
  const [loader, setLoader] = useState(false)
  const [showDeviceInfoCol, setShowDeviceInfoCol] = useState(false)
  const navigate = useNavigate()
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const statusData = ["Locked", "Unlocked", "Out of Network"]
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const userSessionData = JSON.parse(sessionStorage.getItem("userSessionData"))
  const [Status, setStatus] = useState("")
  const [selectedRegion, setSelectedRegion] = useState("")
  const [regionConfirmation, setRegionConfirmation] = useState("")
  const [editRegion, setEditRegion] = useState(true)
  const [networkRegionStatus, setNetworkRegionStatus] = useState("")
  const [regionLoader, setRegionLoader] = useState(false)
  const countryData = ["UK", "US"]
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }

  const filterHandler = () => {
    handleClose()
    let url_device = ""
    url_device = `${REMOTE_API}${JSON.stringify({
      model_name: [activeDeviceModel],
      device_category: [location.state.data.device_category],
      ...(filterDropdownSelectedData.deviceStatus.length > 0
        ? { device_status: filterDropdownSelectedData.deviceStatus }
        : ""),
      ...(filterDropdownSelectedData.deviceList.length > 0
        ? { device_name: filterDropdownSelectedData.deviceList }
        : ""),
    })}`
    axios
      .get(url_device)
      .then((response) => {
        console.log("devicesbasedonmodel", response.data)
        if (deviceInfo !== null) {
          let isExist = response.data.find(function (data) {
            return data.device_name === deviceInfo.device_name
          })
          console.log(isExist, "kkkkk")
          if (isExist === undefined) {
            setDeviceInfo(null)
          }
        }
        setDevicesBasedOnModel(response.data)
      })
      .catch((error) => {
        console.log(error, "deviceerror")
      })
  }
  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )
      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }
  const devicestatusicon = (
    device_status,
    LockedBy,
    reserved_by,
    reservation_status
  ) => {
    if (reservation_status === true) {
      if (device_status === "Out of Network") {
        return (
          <img className="status-icon" alt="OutOfNetwork" src={OfflineIcon} />
        )
      }
      if (reserved_by !== userSessionData.username) {
        console.log("reserved by1", reserved_by, userSessionData.username)
        return (
          <TooltipComponent
            title={`Reserved by ${reserved_by}`}
            className="tooltip-display"
          >
            <div className="status-icon-container">
              <img className="status-icon" alt="LockIcon" src={LockIcon} />
            </div>
          </TooltipComponent>
        )
      } else {
        console.log("reserved by2", reserved_by, userSessionData.username)
        return (
          <img className="status-icon" alt="UnlockedIcon" src={UnlockIcon} />
        )
      }
    } else {
      switch (device_status) {
        case "Unlocked":
          return (
            <img className="status-icon" alt="UnlockedIcon" src={UnlockIcon} />
          )
        case "Locked":
          if (LockedBy !== userSessionData.username) {
            return (
              <Tooltip
                title={`Locked by ${LockedBy}`}
                className="tooltip-display"
              >
                <div className="status-icon-container">
                  <img className="status-icon" alt="LockIcon" src={LockIcon} />
                </div>
              </Tooltip>
            )
          } else {
            return (
              <img
                className="status-icon"
                alt="UnlockedIcon"
                src={UnlockIcon}
              />
            )
          }
        case "Out of Network":
          return (
            <img className="status-icon" alt="OutOfNetwork" src={OfflineIcon} />
          )
        default:
          return (
            <img className="status-icon" alt="OutOfNetwork" src={OfflineIcon} />
          )
      }
    }
  }

  const devicestatusinfo = (status, reservation_status) => {
    console.log(status, reservation_status)
    switch (status) {
      case (reservation_status = true):
        return <span style={{ color: "red" }}>Reserved</span>
      case (status = "Unlocked"):
        return <span style={{ color: "green" }}>Unlocked</span>
      case (status = "Locked"):
        return <span style={{ color: "red" }}>Locked</span>
      case (status = "Out of Network"):
        return <span style={{ color: "#969696" }}>Out Of Network</span>
      default:
        return <span style={{ color: "#969696" }}>Out Of Network</span>
    }
  }

  const preventDragHandler = (e) => {
    e.preventDefault()
  }

  const handleClick = (event) => {
    setFilterDropdown(event.currentTarget)
  }

  const handleClose = () => {
    setFilterDropdown(null)
  }

  const DeviceModalHandler = (ModelName) => {
    setCheckDevices([])
    console.log("sss", ModelName)
    setActiveCol(2)
    setDeviceInfo(null)
    setFilterDropdownSelectedData({ deviceStatus: [], deviceList: [] })
    getDevicesBasedOnModel(ModelName)
  }

  const DeviceListHandler = (DeviceInformation) => {
    console.log("deviceinfo", DeviceInformation)
    sessionStorage.setItem(
      "deviceinformationinfo",
      JSON.stringify(DeviceInformation)
    )
    setActiveCol(3)
    setDeviceInfo(DeviceInformation)
    setEditRegion(true)
    setSelectedRegion("")
    console.log(deviceInfo, "getdevicedata")
  }

  const DeviceViewHandler = (DeviceViewInfo) => {
    if (Status === "Expired" || Status === "Inactive") {
      setMessageDisplay(Status)
    } else {
      const unique = [
        ...new Map(
          checkDevices.map((item) => [item["device_name"], item])
        ).values(),
      ]
      console.log(unique, "unique")
      if (DeviceViewInfo === null && checkDevices.length <= 0) {
        alert("Please Select The Device")
      } else if (checkDevices.length > 0) {
        if (platform_data === "Media And Entertainment") {
          navigate("/platform/M&E/DeviceFilter/deviceView", {
            state: { DeviceViewInfo: unique },
          })
        } else {
          navigate("/platform/" + platform_data + "/DeviceFilter/deviceView", {
            state: { DeviceViewInfo: unique },
          })
        }
      } else if (
        (DeviceViewInfo.device_status === "Unlocked" &&
          DeviceViewInfo.reservation_status === false) ||
        (DeviceViewInfo.reservation_status === true &&
          DeviceViewInfo.reserved_by === userSessionData.username) ||
        (DeviceViewInfo.device_status === "Locked" &&
          DeviceViewInfo.reservation_status === false &&
          DeviceViewInfo.locked_by === userSessionData.username)
      ) {
        if (platform_data === "Media And Entertainment") {
          navigate("/platform/M&E/DeviceFilter/deviceView", {
            state: { DeviceViewInfo: [DeviceViewInfo] },
          })
        } else {
          navigate("/platform/" + platform_data + "/DeviceFilter/deviceView", {
            state: { DeviceViewInfo: [DeviceViewInfo] },
          })
        }
      }
      setMessageDisplay(DeviceViewInfo?.device_status)
    }
  }

  const handleSearch = async (event) => {
    const trim_string = event.target.value.trim()
    await axios
      .get(
        `${DEVICES_FILTER_SEARCH_API}search=${trim_string}&device_category=${location.state.data.device_category}&model_name=${activeDeviceModel}`
      )
      .then((response) => {
        setDevicesBasedOnModel(response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const getDeviceModels = async (deviceCategory) => {
    await axios
      .get(
        `${REMOTE_API}+${JSON.stringify({
          device_category: [deviceCategory],
        })}`
      )
      .then((response) => {
        const unique = [
          ...new Map(
            response.data.map((item) => [item["model_name"], item])
          ).values(),
        ]
        console.log("devicemodal", unique)
        setDeviceModel(unique)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const getDevicesBasedOnModel = async (model_name) => {
    setActiveDeviceModel(model_name)
    setLoader(true)
    await axios
      .get(
        `${REMOTE_API}+${JSON.stringify({
          model_name: [model_name],
          device_category: [location.state.data.device_category],
        })}`
      )
      .then((response) => {
        console.log("devicesbasedonmodel", response.data)
        setFilterDropdownData(response.data)
        sortDevicesData(response.data)
        setLoader(false)
        setShowDeviceInfoCol(true)
        if (deviceInfo) {
          for (let i = 0; i < response.data.length; i++) {
            if (response.data[i].device_name === deviceInfo.device_name)
              setDeviceInfo(response.data[i])
          }
        }
      })
      .catch((error) => {
        console.log(error, "deviceerror")
      })
  }
  const sortDevicesData = (data) => {
    let LockedData = [],
      UnlockedData = [],
      OutOfNetworkData = []
    data.map((obj) => {
      switch (obj.device_status) {
        case "Unlocked":
          UnlockedData.push(obj)
          break
        case "Locked":
          LockedData.push(obj)
          break
        case "Out of Network":
          OutOfNetworkData.push(obj)
          break
        default:
          UnlockedData.push(obj)
          break
      }
    })
    setDevicesBasedOnModel([
      ...UnlockedData,
      ...LockedData,
      ...OutOfNetworkData,
    ])
  }

  useEffect(() => {
    getDeviceModels(location.state.data.device_category)
    ValidateLicensestatus()
  }, [])
  const MultipleViewHandler = () => {
    setIsChecked(!isChecked)
  }

  const handleMultipleDevice = (event, item) => {
    if (event.target.checked === true) {
      setCheckDevices([...checkDevices, item])
    } else {
      setCheckDevices(checkDevices.filter((val) => val !== item))
    }
  }
  const deviceFilterBack = function () {
    navigate(-1)
  }

  const renderCountryFlag = (country) => {
    switch (country) {
      case "UK":
        return UKIcon
      case "US":
        return USIcon
      default:
        return Indiaflagicon
    }
  }

  const handleNetworkRegion = () => {
    setEditRegion(false)
    setSelectedRegion("")
  }

  const handleOptionChange = (e) => {
    setSelectedRegion(e.target.value)
  }

  const handleRegionSubmit = async (dname) => {
    setRegionLoader(true)
    console.log("Selected Option:", selectedRegion)
    let regionDetails = ""
    regionDetails = `${DEVICES_FILTER_NETWORK_REGION_API}${JSON.stringify({
      device_name: dname,
      region: selectedRegion,
    })}`
    console.log(regionDetails, "regionDetails")
    await axios
      .post(regionDetails)
      .then((response) => {
        console.log(response.data, "EDITRegion")
        setRegionConfirmation(response.data.valid)
        handleRegionCancel(dname)
        if (response.data.valid === "true") {
          setRegionLoader(true)
          handleGeoLocationStatus(dname)
        } else {
          setRegionLoader(false)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const handleGeoLocationStatus = async (devicename) => {
    await axios
      .get(
        `${GEO_LOCATION_STATUS_API}${JSON.stringify({
          device_name: [devicename],
        })}` +
          "&attributes=" +
          JSON.stringify(["network_region", "network_status"])
      )
      .then((response) => {
        console.log(response.data, "locationStatus")
        setNetworkRegionStatus(response.data[0].network_status)
        console.log(networkRegionStatus, "setNetworkRegionStatus")

        if (response.data[0].network_status === "In Progress") {
          handleGeoLocationStatus(devicename)
        } else {
          setRegionLoader(false)
          getDevicesBasedOnModel(deviceInfo.model_name)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const handleRegionCancel = () => {
    setEditRegion(true)
  }

  return deviceModel.length > 0 ? (
    <div className="FilterDevice ">
      <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
        <Link to={"/platform"} onDragStart={preventDragHandler}>
          Platform
        </Link>
        {platform_data === "Media And Entertainment" ? (
          <Link onClick={deviceFilterBack} onDragStart={preventDragHandler}>
            M&E
          </Link>
        ) : (
          <Link onClick={deviceFilterBack}>{platform_data}</Link>
        )}
        <Typography color="#0D6EFD">Device Filter</Typography>
      </Breadcrumbs>

      <Container
        maxWidth="xl"
        style={{
          flex: "1",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Snackbar
          className="device-filter-alert-message"
          open={messageDisplay}
          autoHideDuration={5000}
          onClose={() => setMessageDisplay("")}
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
        >
          {messageDisplay === "Locked" ? (
            <Alert icon={false}>
              <img
                className="error-icon"
                alt="DeviceLockedErrorIcon"
                src={DeviceLockedErrorIcon}
              />
              Device Locked
            </Alert>
          ) : messageDisplay === "Out of Network" ? (
            <Alert icon={false}>
              <img
                className="OutOfNetwork-icon"
                alt="OutOfNetworkIcon"
                src={OutOfNetworkIcon}
              />
              Device Out of Network
            </Alert>
          ) : messageDisplay === Status ? (
            <Alert icon={false}>
              <img
                className="OutOfNetwork-icon"
                alt="DeviceLockedErrorIcon"
                src={DeviceLockedErrorIcon}
              />
              License {Status}
            </Alert>
          ) : messageDisplay === "Reserved" ? (
            <Alert icon={false}>
              <img
                className="Reserve-icon"
                title="ReserveIcon"
                alt="ReserveIcon"
                src={LockIcon}
              />
              Device Reserved
            </Alert>
          ) : (
            <div></div>
          )}
        </Snackbar>
        <Snackbar
          open={regionConfirmation}
          autoHideDuration={3000}
          className="region-confirmation"
          onClose={() => setRegionConfirmation("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          {regionConfirmation === "true" ? (
            <Alert severity="success">Changing Network Geo Location</Alert>
          ) : regionConfirmation === "false" ? (
            <Alert severity="error">
              Server Error, please try again after sometime
            </Alert>
          ) : (
            <div></div>
          )}
        </Snackbar>
        <Snackbar
          open={networkRegionStatus}
          autoHideDuration={5000}
          className="region-confirmation"
          onClose={() => setNetworkRegionStatus("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          {networkRegionStatus === "Pass" ? (
            <Alert severity="success">Updated Network Geo Location</Alert>
          ) : networkRegionStatus === "Fail" ? (
            <Alert severity="error">
              Failed to update the Network Geo Location
            </Alert>
          ) : (
            <div></div>
          )}
        </Snackbar>
        {regionLoader && <Loader />}

        <div className="filter-device-header">
          {activeCol !== 1 && (
            <div
              className="filter-device-back-navigation"
              onClick={() => setActiveCol(activeCol === 3 ? 2 : 1)}
            >
              <img src={Arrow} alt="Arrow" />
            </div>
          )}

          <h2
            className={`filter-device-heading ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Devices
          </h2>
          <p
            className={`filter-device-subheading ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Devices under{" "}
            {location.state ? location.state.data.device_category : ""}
          </p>
        </div>
        <div className="filter-device-body">
          <div className={`device-container active-col-${activeCol}`}>
            <div className="device-col device-col-1">
              <div className="device-list">
                <ul>
                  {deviceModel.map((item) => {
                    return (
                      <li
                        onClick={() => DeviceModalHandler(item.model_name)}
                        key={item.model_name}
                      >
                        <div
                          className={`device-list-item ${
                            activeDeviceModel === item.model_name
                              ? "active"
                              : ""
                          } ${theme === "dark" ? "dark" : "light"} `}
                        >
                          <label>{item.model_name}</label>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              </div>
            </div>
            {showDeviceInfoCol === true ? (
              <div className="device-modal-container">
                <div className="device-col device-col-2">
                  <div className="device-filter-block">
                    <FormControl
                      className={`search-field ${
                        theme === "dark" ? "dark" : "light"
                      } `}
                      variant="standard"
                      color="secondary"
                    >
                      <Input
                        autoComplete="off"
                        id="search-devices"
                        type="text"
                        onChange={handleSearch}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton>
                              <img
                                className="devicepage-search-icon"
                                alt="SearchIcon"
                                title="SearchIcon"
                                src={SearchIcon}
                              />
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                    <div className="filter-devices-dropdown">
                      <IconButton
                        id="filter-icon-button"
                        aria-controls={
                          filterDropdown ? "filter-menu" : undefined
                        }
                        aria-haspopup="true"
                        aria-expanded={filterDropdown ? "true" : undefined}
                        onClick={handleClick}
                      >
                        <img
                          className={`filter-devices-icon ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          alt="FilterIcon"
                          src={FilterIcon}
                          title="FilterIcon"
                        />
                      </IconButton>
                      <Popover
                        className={`filter-devices-dropdown-menu ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        id="filter-menu"
                        anchorEl={filterDropdown}
                        open={filterDropdown}
                        onClose={handleClose}
                        MenuListProps={{
                          "aria-labelledby": "filter-icon-button",
                        }}
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "right",
                        }}
                        transformOrigin={{
                          vertical: "top",
                          horizontal: "right",
                        }}
                      >
                        <h4>Filter Devices</h4>
                        <div
                          className={`filter-dropdown-search ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <Autocomplete
                            multiple
                            onChange={(event, item) => {
                              setFilterDropdownSelectedData({
                                ...filterDropdownSelectedData,
                                deviceList: item,
                              })
                            }}
                            id="search-filter"
                            className={`search-list-container ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                            options={filterDropdownData.map(function (el) {
                              return el.device_name
                            })}
                            getOptionLabel={(option) => option}
                            defaultValue={filterDropdownSelectedData.deviceList}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                size="small"
                                color="secondary"
                                placeholder="Devices"
                              />
                            )}
                          />
                        </div>
                        <FormGroup
                          className={`filter-dropdown-checkbox  ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          row
                        >
                          {statusData.map((item) => (
                            <FormControlLabel
                              key={item}
                              label={item}
                              control={
                                <Checkbox
                                  style={
                                    theme === "light"
                                      ? {
                                          color: "#3a9fec",
                                        }
                                      : {}
                                  }
                                  value={item}
                                  sx={{
                                    "& .MuiSvgIcon-root": { fontSize: 28 },
                                  }}
                                  checked={filterDropdownSelectedData.deviceStatus.includes(
                                    item
                                  )}
                                  onChange={(e) => {
                                    const { checked, value } = e.target
                                    if (checked) {
                                      setFilterDropdownSelectedData({
                                        ...filterDropdownSelectedData,
                                        deviceStatus: [
                                          ...filterDropdownSelectedData.deviceStatus,
                                          value,
                                        ],
                                      })
                                    } else {
                                      setFilterDropdownSelectedData({
                                        ...filterDropdownSelectedData,
                                        deviceStatus:
                                          filterDropdownSelectedData.deviceStatus.filter(
                                            (val) => val !== value
                                          ),
                                      })
                                    }
                                  }}
                                />
                              }
                            />
                          ))}
                        </FormGroup>
                        <div
                          className={`filter-dropdown-action ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <Button onClick={filterHandler} variant="contained">
                            Filter
                          </Button>
                        </div>
                      </Popover>
                    </div>
                  </div>
                  {devicesBasedOnModel.length > 0 ? (
                    <>
                      <div className="device-list">
                        <ul>
                          {devicesBasedOnModel.map((item) => {
                            return (
                              <li key={item.device_name}>
                                {isChecked && (
                                  <Checkbox
                                    // style={
                                    //   theme === "light"
                                    //     ? {
                                    //         color: "#3a9fec",
                                    //       }
                                    //     : {}
                                    // }  
                                     style={
                                      theme === "light"
                                        ? {
                                            color:
                                              item?.device_status === "Out of Network" ||
                                              (item?.reservation_status === true &&
                                                item?.reserved_by !== userSessionData.username)
                                                ? "#a8a8a8" // Disabled color for light theme
                                                : "#3a9fec", // Default color for light theme
                                          }
                                        : {
                                            // Dark theme styles
                                          }
                                    }

                                    value={item}
                                    disabled={
                                      item?.device_status ===
                                        "Out of Network" ||
                                      (item?.reservation_status === true &&
                                        item?.reserved_by !==
                                          userSessionData.username)
                                    }
                                    onChange={(event) =>
                                      handleMultipleDevice(event, item)
                                    }
                                    className="mr-2"
                                  />
                                )}
                                <div
                                  onClick={() => DeviceListHandler(item)}
                                  onDoubleClick={() => DeviceViewHandler(item)}
                                  className={`device-list-item ${
                                    deviceInfo?.device_name === item.device_name
                                      ? "active"
                                      : ""
                                  } ${theme === "dark" ? "dark" : "light"}
                                 `}
                                >
                                  <div className="device-list-left-col">
                                    <label>{item.device_name}</label>
                                  </div>
                                  <div className="device-list-right-col">
                                    {platform_data ===
                                    "Media And Entertainment" ? (
                                      Status === "Active" ? (
                                        <Link
                                          to={
                                            "/platform/M&E/DeviceFilter/bigcalendar"
                                          }
                                          state={{ DeviceData: [item] }}
                                          className="link"
                                        >
                                          <img
                                            className={`reserve-icon ${
                                              theme === "dark"
                                                ? "dark"
                                                : "light"
                                            }`}
                                            alt="ReserveIcon"
                                            src={ReserveIcon}
                                            title="ReserveIcon"
                                          />
                                        </Link>
                                      ) : (
                                        <Tooltip
                                          title={<td>License {Status}</td>}
                                          className="tooltip-display"
                                        >
                                          <img
                                            className={`reserve-icon ${
                                              theme === "dark"
                                                ? "dark"
                                                : "light"
                                            }`}
                                            alt="ReserveIcon"
                                            src={ReserveIcon}
                                            title="ReserveIcon"
                                            style={{
                                              cursor: "not-allowed",
                                              opacity: "0.5",
                                            }}
                                          />
                                        </Tooltip>
                                      )
                                    ) : Status === "Active" ? (
                                      <Link
                                        to={
                                          "/platform/" +
                                          platform_data +
                                          "/DeviceFilter/bigcalendar"
                                        }
                                        state={{ DeviceData: [item] }}
                                        className="link"
                                      >
                                        <img
                                          className={`reserve-icon ${
                                            theme === "dark" ? "dark" : "light"
                                          }`}
                                          alt="ReserveIcon"
                                          src={ReserveIcon}
                                          title="ReserveIcon"
                                        />
                                      </Link>
                                    ) : (
                                      <Tooltip
                                        title={<td>License {Status}</td>}
                                        className="tooltip-display"
                                      >
                                        <img
                                          className={`reserve-icon ${
                                            theme === "dark" ? "dark" : "light"
                                          }`}
                                          alt="ReserveIcon"
                                          src={ReserveIcon}
                                          title="ReserveIcon"
                                          style={{
                                            cursor: "not-allowed",
                                            opacity: "0.5",
                                          }}
                                        />
                                      </Tooltip>
                                    )}
                                    {devicestatusicon(
                                      item.device_status,
                                      item.locked_by,
                                      item.reserved_by,
                                      item.reservation_status
                                    )}
                                  </div>
                                </div>
                              </li>
                            )
                          })}
                        </ul>
                      </div>
                      <div className="device-info-action">
                        <Button
                          className={`multiple-select-btn ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          variant="outlined"
                          onClick={() => {
                            MultipleViewHandler()
                          }}
                        >
                          Select Multiple
                        </Button>
                        <Button
                          className={`device-view-btn ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          variant="outlined"
                          onClick={() => {
                            DeviceViewHandler(deviceInfo)
                            setMessageDisplay("")
                          }}
                        >
                          View
                        </Button>
                      </div>
                    </>
                  ) : (
                    <p
                      className={`no-data ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      {" "}
                      No Data
                    </p>
                  )}
                </div>
                <div className="device-col device-info device-col-3">
                  <div
                    className={`device-info-list ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    {deviceInfo !== null ? (
                      <div>
                        <div
                          className={`device-info-region-edit ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          <h3
                            className={`filter-device-info-heading ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            {deviceInfo.model_name} : {deviceInfo.device_name}
                          </h3>
                           {(editRegion &&
                            deviceInfo.device_status === "Unlocked" &&
                            !regionLoader &&
                            deviceInfo.reservation_status === true &&
                            deviceInfo.reserved_by ===
                              userSessionData.username) ||
                          deviceInfo.reservation_status === false ? (
                            <Tooltip
                              title="Configure devices"
                              className="tooltip-display"
                            >
                              <img
                                alt="Edit Region"
                                src={EditRegionIcon}
                                onClick={handleNetworkRegion}
                              />
                            </Tooltip>
                          ) : (
                            ""
                          )}
                        </div>
                        <ul>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Devicename
                            </label>
                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {deviceInfo.device_name}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Category
                            </label>
                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {deviceInfo.device_category}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Model
                            </label>
                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {deviceInfo.model_name}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Status
                            </label>
                            {devicestatusinfo(
                              deviceInfo.device_status,
                              deviceInfo.reservation_status
                            )}
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Reservation
                            </label>
                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {deviceInfo.reservation_status === false
                                ? "Not Reserved"
                                : "Reserved"}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              OS Version
                            </label>
                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {deviceInfo.os_version}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Device Location
                            </label>
                            <span>
                              {deviceInfo.country === "India" ? (
                                <img
                                  className="country-flag"
                                  src={Indiaflagicon}
                                  alt="Country Flag"
                                />
                              ) : (
                                deviceInfo.country
                              )}
                            </span>
                          </li>
                          <li>
                            <label
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              Network Region
                            </label>

                            <span
                              className={`filter-device-list-info-heading ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                            >
                              {editRegion &&
                              (deviceInfo.device_name === "Apple TV" ||
                                deviceInfo.device_name === "Oneplus 8") ? (
                                <img
                                  className="country-flag"
                                  src={renderCountryFlag(
                                    deviceInfo.network_region
                                  )}
                                />
                              ) : (
                                <Form.Select
                                  className={`region-dropdown ${
                                    theme === "dark" ? "dark" : "light"
                                  }`}
                                  onChange={handleOptionChange}
                                >
                                  <option value="">Select Region</option>
                                  {countryData.map((country) => (
                                    <option value={country}>{country}</option>
                                  ))}
                                </Form.Select>
                              )}
                            </span>
                          </li>
                        </ul>
                      </div>
                    ) : (
                      <p
                        className={`device-info-para ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                      >
                        Select a device to get its info
                      </p>
                    )}
                  </div>

                  {editRegion ? (
                    <div
                      className={`device-info-action ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      {Status !== "Active" && (
                        <Tooltip
                          title={<td>License {Status}</td>}
                          className="tooltip-display"
                        >
                          <Button
                            className={`multiple-select-btn ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                            variant="outlined"
                            style={{ cursor: "not-allowed" }}
                          >
                            Select Multiple
                          </Button>
                        </Tooltip>
                      )}
                      {Status === "Active" && (
                        <Button
                          className={`multiple-select-btn ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          variant="outlined"
                          onClick={() => {
                            MultipleViewHandler()
                          }}
                        >
                          Select Multiple
                        </Button>
                      )}
                      {Status !== "Active" && (
                        <Tooltip
                          title={<td>License {Status}</td>}
                          className="tooltip-display"
                        >
                          <Button
                            className={`device-view-btn ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                            variant="outlined"
                            style={{ cursor: "not-allowed" }}
                          >
                            View
                          </Button>
                        </Tooltip>
                      )}
                      {Status === "Active" && (
                        <Button
                          className={`device-view-btn ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                          variant="outlined"
                          onClick={() => {
                            DeviceViewHandler(deviceInfo)
                          }}
                        >
                          View
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div
                      className={`device-info-action ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      <Button
                        className={`multiple-select-btn ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        variant="outlined"
                        onClick={() =>
                          handleRegionSubmit(deviceInfo.device_name)
                        }
                      >
                        Submit
                      </Button>
                      <Button
                        className={`device-view-btn ${
                          theme === "dark" ? "dark" : "light"
                        }`}
                        variant="outlined"
                        onClick={handleRegionCancel}
                      >
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ) : loader === true ? (
              <Loader />
            ) : (
              <p
                className={`no-data device-no-data ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Select a model name to get the list of devices
              </p>
            )}
          </div>
        </div>
      </Container>
    </div>
  ) : (
    <div>
      <Loader />
    </div>
  )
}
