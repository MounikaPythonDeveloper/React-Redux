import React from "react"
import "../ModelPopup/Popup_Abort.css"
const PopupAbort = (props) => {
  return (
    <div className={"popup-box-abort"}>
      <div className="box-abort">
        <div>
          <img
            src={"Stop"}
            onClick={props.handleClose}
            className="icon-close"
            alt="Close Icon"
          />
        </div>
        {props.content}
      </div>
    </div>
  )
}

export default PopupAbort
