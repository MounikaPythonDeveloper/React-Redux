import React from "react"
import "./SoapApi.css"

function SoapApi() {
  return "hello"
  // <div className="soap-api">
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Test Reference</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input
  //         type="text"
  //         className="test_input"
  //         placeholder="EX: Test_01"
  //       ></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Base Url</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder="Url"></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>End Point</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Expected Code</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Parameter</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Base Url</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder="Url"></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>End Point</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Expected Code</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  //   <div className="selected_inputs">
  //     <div className="selected_inputs_title">
  //       <label>Parameter</label>
  //     </div>
  //     <div className="input_feilds">
  //       <input type="text" className="test_input" placeholder=""></input>
  //     </div>
  //   </div>
  // </div>
}
export default SoapApi
