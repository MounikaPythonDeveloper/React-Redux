import React, { useState, useEffect } from "react";
import "./RestApi.css";
import { Form } from "react-bootstrap";
import axios from "axios";
import { API_TESTING_REST_API } from "../../../../../services/api";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import { useTheme } from "../../../../../components/ThemeToggle/ThemeContext";

function RestApi(props) {
  const { theme } = useTheme();
  useEffect(() => {
    setAlertMsg(false);
  }, []);

  const [allValues, setAllValues] = useState({
    testReference: "",
    url: "",
    endPoint: "",
    parameter: "",
  });
  const [mode, setMode] = useState("");
  const [alertMsg, setAlertMsg] = useState(false);
  const [successAlertMsg, setSuccessAlertMsg] = useState(false);
  const [restRes, setRestRes] = useState([]);
  const date = new Date().toISOString();
  const userData = JSON.parse(sessionStorage.getItem("userSessionData"));
  const [gettingValidateValue, setGettingValidateValue] = useState(true);
  const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;

  function validateURL(url) {
    return urlRegex.test(url);
  }

  const changeHandler = (e) => {
    setAlertMsg(false);
    setAllValues({ ...allValues, [e.target.name]: e.target.value });
    const validateValue = validateURL(allValues.url);
    setGettingValidateValue(validateValue);
  };
  const modeHandler = function (e) {
    setMode(e.target.value);
  };
  // const modeClear = function (e) {
  //   setMode("");
  // };

  const restApiFun = async () => {
    // modeClear();
    if (
      mode.length === 0 ||
      allValues.testReference.length === 0 ||
      allValues.endPoint.length === 0 ||
      allValues.url.length === 0
    ) {
      setAlertMsg(true);
    } else {
      // setSuccessAlertMsg(true);
      toast.success("Executing Testcase", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
    let restApi = "";
    restApi = `${API_TESTING_REST_API}${JSON.stringify({
      category: props.Value,
      mode: mode,
      base_url: allValues.url,
      end_point: allValues.endPoint,
      parameter: mode === "GET" ? "NA" : allValues.parameter,
      reference: allValues.testReference,
      date: date,
      session_id: userData.session_id,
      user_privilege: userData.user_privilege,
      username: userData.username,
      email_id: userData.email_id,
    })}`;
    await axios
      .post(restApi)
      .then((response) => {
        setRestRes(response.data.Message);
        console.log("RestApi", response.data);
      })
      .catch((error) => {
        toast.error(
          "Please enter Test Fields",

          { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
        );
        console.log(error, "error");
      });
  };

  const restHandler = function (params) {
    setAllValues({ testReference: "", url: "", endPoint: "", parameter: "" });
    setMode("");
    if (
      mode.length > 0 &&
      allValues.testReference.length > 0 &&
      allValues.endPoint.length > 0 &&
      allValues.url.length > 0 &&
      gettingValidateValue
    ) {
      restApiFun();
    } else {
      toast.error(
        gettingValidateValue
          ? "Please Enter The Fields "
          : "Please Enter Vaild Url",
        {
          position: toast.POSITION.TOP_CENTER,
          className: "toast-message",
        }
      );
    }
  };

  const restResetHandler = function () {
    setAllValues({ testReference: "", url: "", endPoint: "", parameter: "" });
    setMode("");
  };
  return (
    <>
      <div className="rest-api">
        {/* <pre>{JSON.stringify(gettingValidateValue)}</pre> */}
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Test Reference</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={allValues.testReference}
              className="test_input"
              name="testReference"
              onChange={changeHandler}
              placeholder="EX: Test_01"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Mode</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              value={mode}
              onChange={modeHandler}
              className={`mode-value-drop-down ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <option>Select mode</option>
              <option>GET</option>
              <option>POST</option>
              {/* <option>UPDATE</option>
              <option>DELETE</option> */}
            </Form.Select>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Base Url</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={allValues.url}
              name="url"
              onChange={changeHandler}
              className="test_input"
              placeholder="Ex:https://youtube.com"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>End Point</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={allValues.endPoint}
              className="test_input"
              name="endPoint"
              onChange={changeHandler}
              placeholder="Ex:/test"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Parameter</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={allValues.parameter}
              className="test_input"
              placeholder="Ex:Parameter"
              name="parameter"
              onChange={changeHandler}
            ></input>
          </div>
        </div>
      </div>

      <div className="getdatabtn">
        {/* <button className="TestButton triggerbtn m-2">TC MAP</button> */}

        <button
          onClick={restHandler}
          className={`TestButton triggerbtn m-2 ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          Submit
        </button>
        {/* 
        <button className="TestButton triggerbtn  m-2">Schedule</button> */}

        <button
          className={`TestButton triggerbtn m-2 ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClick={restResetHandler}
          type="reset"
        >
          Reset
        </button>
      </div>
    </>
  );
}
export default RestApi;
