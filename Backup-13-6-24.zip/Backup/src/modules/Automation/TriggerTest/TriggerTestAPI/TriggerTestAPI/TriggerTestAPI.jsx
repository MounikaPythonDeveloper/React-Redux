import React from "react"
import RestApi from "../RestApi/RestApi"
import SoapApi from "../SoapApi/SoapApi"
import WebSocketApi from "../WebSocketApi/WebSocketApi"

function TriggerTestAPI(props) {
  return (
    <div className="trigger_page">
      {props.apiTestValue === "Rest API" ? (
        <RestApi Value={props.apiTestValue} />
      ) : props.apiTestValue === "Web Socket API" ? (
        <WebSocketApi Value={props.apiTestValue} />
      ) : (
        <SoapApi Value={props.apiTestValue} />
      )}
    </div>
  )
}
export default TriggerTestAPI
