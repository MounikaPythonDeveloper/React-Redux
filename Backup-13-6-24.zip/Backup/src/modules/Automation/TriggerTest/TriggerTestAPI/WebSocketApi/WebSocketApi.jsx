import React, { useState, useEffect } from "react";
import "./WebSocketApi.css";
import { Form } from "react-bootstrap";
import { useTheme } from "../../../../../components/ThemeToggle/ThemeContext";

function WebSocketApi() {
  const { theme } = useTheme();
  const [webAllValues, setWebAllValues] = useState({
    testReference: "",
    url: "",
    endPoint: "",
    parameter: "",
  });
  const [mode, setMode] = useState("");
  const webChangeHandler = (e) => {
    setWebAllValues({ ...webAllValues, [e.target.name]: e.target.value });
  };
  const webResetHandler = function () {
    setWebAllValues({
      testReference: "",
      url: "",
      endPoint: "",
      parameter: "",
    });
    setMode("");
  };
  const modeHandler = function (e) {
    setMode(e.target.value);
  };
  return (
    <>
      <div className="web-socket-api">
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Test Reference</label>
          </div>
          <div className="input_feilds">
            <input
              value={webAllValues.testReference}
              type="text"
              name="testReference"
              onChange={webChangeHandler}
              className="test_input"
              placeholder="EX: Test_01"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Mode</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              value={mode}
              onChange={modeHandler}
              className="mode-value-drop-down"
            >
              <option>Select mode</option>
              <option>GET</option>
              <option>POST</option>
              {/* <option>UPDATE</option>
              <option>DELETE</option> */}
            </Form.Select>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Base Url</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              className="test_input"
              value={webAllValues.url}
              name="url"
              onChange={webChangeHandler}
              placeholder="Url"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>End Point</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              name="endPoint"
              value={webAllValues.endPoint}
              onChange={webChangeHandler}
              className="test_input"
              placeholder="End Point"
            ></input>
          </div>
        </div>

        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Parameter</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={webAllValues.parameter}
              className="test_input"
              placeholder="Parameter"
              name="parameter"
              onChange={webChangeHandler}
            ></input>
          </div>
        </div>
      </div>
      <div className="getdatabtn">
        {/* <button className="TestButton triggerbtn m-2">TC MAP</button> */}

        <button
          className={`TestButton triggerbtn m-2 ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          Submit
        </button>

        {/* <button className="TestButton triggerbtn  m-2">Schedule</button>*/}

        <button
          onClick={webResetHandler}
          className={`TestButton triggerbtn m-2 ${
            theme === "dark" ? "dark" : "light"
          }`}
          type="reset"
        >
          Reset
        </button>
      </div>
    </>
  );
}
export default WebSocketApi;
