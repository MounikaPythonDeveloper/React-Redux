import React, { useEffect, useRef, useState } from "react";
import "../TestManager/TestManager.css";
import "./TriggerTest.css";
import "../ModelPopup/Model.css";
import "../Table/TableData.css";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import Scheduling from "../../../components/Scheduling/Scheduling.jsx";
import axios from "axios";
import moment from "moment";
import { Alert, Snackbar, Tooltip } from "@mui/material";
import {
  TESTCASES_API,
  SUPPORT_API_DEVICES,
  TESTSUITES_DEVICES_API,
  FETCH_DEVICES_BY_DEVICE_STATUS_API,
  TRIGGER_TEST_API,
  SCHEDULE_SUBMIT_ATTRIBUTES_API,
  VALIDATE_BUYLICENSE_STATUS,
} from "../../../services/api.js";
import TestRefreshIcon from "../../../assets/images/TestRefreshIcon1.png";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext.jsx";
import Switch from "@mui/material/Switch";
// import { msl_ipaddress_trigger } from "../../services/api";
import { msl_ipaddress_trigger } from "../../../services/api.js";
import FileUpload from "../../../components/FileUpload/FileUpload";

const TriggertestME = () => {
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const [toggleDropdown, setToggleDropdown] = useState(0);
  const [devicesData, setDeviceData] = useState([]);
  const [devicesData1, setDeviceData1] = useState([]);
  const [testcasesData, setTestcasesData] = useState([]);
  const [testsuiteData, setTestsuiteData] = useState([]);
  const [checkdevices, setCheckDevices] = useState([]);
  const [checkdevices1, setCheckDevices1] = useState([]);
  const [selectAllDevice, setSelectAllDevice] = useState(false);
  const [checktestcase, setCheckTestcases] = useState([]);
  const [selectAllTestcases, setSelectAllTestcases] = useState(false);
  const [checktestsuites, setCheckTestsuites] = useState([]);
  const [selectAllTestsuite, setSelectAllTestsuite] = useState(false);
  const [scheduleConfirmation, setScheduleConfirmation] = useState("");
  const [splitval, setSplitval] = useState("No");
  const [refervalue, setReferValue] = useState("");
  const [notification, setNotification] = useState();
  const [date, setDate] = useState(new Date().toLocaleTimeString());
  const currentDate = new Date();
  const deviceRef = useRef(null);
  const testcasesRef = useRef(null);
  const testsuiteRef = useRef(null);
  const [schedulingPopup, setSchedulingPopup] = useState(false);
  const [Status, setStatus] = useState("");
  const [nIterations, setNIterations] = useState(1);
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileUploadOpen, setFileUploadOpen] = useState(null);
  const [scriptName, setScriptName] = useState("");
  const [responseMessage, setResponseMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [activeDeviceValue, setActiveDeviceValue] = useState("");
  const [TestCaseMessage, setTestCaseMessage] = useState("");
  const [failTestMessage, setFailTestMessage] = useState("");

  const [TCchecked, setTCChecked] = React.useState(false);

  useEffect(() => {
    ValidateLicensestatus();
    console.log(activeDeviceValue, "activeDeviceValue");
  });

  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )
      .then((res) => {
        setStatus(Object.values(res.data)[0]);
        console.log("apidata status", res.data.status[0] === "Active");
        if (res.data.status.length === 0) {
          setStatus("Not Activated");
        } else {
          setStatus(res.data.status[0]);
        }
      })
      .catch((er) => console.log(er));
  };
  useEffect(() => {
    const id = setInterval(() => {
      devices_apis();
    }, 5000);
    devices_apis();

    return () => clearInterval(id);
  }, []);
  const { theme } = useTheme();
  const handleScheduling = () => {
    ValidateLicensestatus();
    if (nIterations > 100 || nIterations <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    } else if (
      checkdevices.length >= 1 &&
      !refervalue == "" &&
      (checktestcase.length >= 1 || checktestsuites.length >= 1)
    ) {
      setSchedulingPopup(true);
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };
  const handleSchedulingClose = () => {
    setSchedulingPopup(false);
  };
  const handleSchedulingOnSubmit = (data) => {
    ValidateLicensestatus();
    handleReset();
    console.log(data, "submit");
    setSplitval("No");
    if (nIterations > 100 || nIterations <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    } else if (
      (checkdevices.length >= 1 &&
        !refervalue == "" &&
        (checktestcase.length >= 1 || checktestsuites.length >= 1),
      "check scheduling")
    ) {
      const schduleString = {
        ...data,
        Date: new Date(),
        Devices: checkdevices,
        TestSuite: checktestsuites,
        TestCase: checktestcase,
        Reference: String(refervalue).trim(),
        // Split: splitval != "" ? String(splitval) : String("No"),
        Split: TCchecked ? "Yes" : "No",
        reservation_category: String("Automation"),
        locked_by: userProfile.username,
        session_id: userProfile.session_id,
        user_privilege: userProfile.user_privilege,
        username: userProfile.username,
        email_id: userProfile.email_id,
        iteration: nIterations,
      };
      console.log("schduleString", schduleString);
      axios
        .post(
          SCHEDULE_SUBMIT_ATTRIBUTES_API + `${JSON.stringify(schduleString)}`
        )
        .then((response) => {
          console.log(response, "schedule");
          setScheduleConfirmation(response.data.valid);
        })
        .catch((error) => {
          alert(error, "Backend error");
          console.log(error, "error");
        });
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };

  const devices_apis = () => {
    axios
      .post(
        FETCH_DEVICES_BY_DEVICE_STATUS_API +
          JSON.stringify({
            username: userProfile.username,
            platform: platform_data,
            device_category: [
              "STB",
              "Smart TV",
              "OTT",
              "iOS",
              "Android",
              "Gaming",
              "iOS Tab",
              "Android Tab",

            ],
            current_date: moment().format("YYYY-MM-D"),
            current_time:
              currentDate.getHours() +
              ":" +
              currentDate.getMinutes() +
              ":" +
              currentDate.getSeconds(),
          })
      )
      .then((res) => {
        console.log("devicesdata", res.data);

        setDeviceData(res.data);
        if (res.data !== null) {
          devices_apis1(res.data);
        }
      })

      .catch((er) => console.log(er));
  };

  const devices_apis1 = (devicedata) => {
    axios
      .post(
        SUPPORT_API_DEVICES +
          JSON.stringify({
            device_name: devicedata,
          }) +
          "&attributes=" +
          JSON.stringify(["support_device"])
      )
      .then((res) => {
        console.log("devicesdata1", res.data);
        const result_data = Object.values(res.data);

        result_data.map((item, index) => {
          if (item.length > 1) {
            setDeviceData1(item);
          }
        });
      })
      .catch((er) => console.log(er));
  };

  const testcases_api = (checked_devices) => {
    console.log("testcases2", checked_devices);
    axios
      .get(TESTCASES_API + `?device_list=${JSON.stringify(checked_devices)}`)
      .then((res) => {
        console.log("testcasesdata", res.data);
        setTestcasesData(res.data[0].test_case_name);
      })
      .catch((er) => console.log(er));
  };

  const testsuites_api = (checked_devices) => {
    axios
      .get(
        TESTSUITES_DEVICES_API +
          `${JSON.stringify({ device_name: checked_devices })}`
      )
      .then((res) => {
        let testsuites = res.data;
        if (Array.isArray(testsuites) && testsuites.length === 0) {
          setTestsuiteData("No Testcases");
        } else {
          setTestsuiteData(testsuites);
        }
      })
      .catch((er) => console.log(er));
  };

  const setspecialval = () => {
    setSplitval("Yes");
  };

  const handleReset = (e) => {
    setReferValue("");
    setSplitval("");
    setTCChecked(false);
    setNIterations(1);
    setCheckDevices([]);
    setCheckDevices1([]);
    setCheckTestsuites([]);
    setCheckTestcases([]);
  };

  const today = new Date(),
    day =
      today.getFullYear() +
      "-" +
      (today.getMonth() + 1) +
      "-" +
      today.getDate();

  let handleCheckboxChange = (event) => {
    setCheckTestcases([]);
    setCheckTestsuites([]);
    setSelectAllTestsuite(false);
    setSelectAllTestcases(false);

    const { value, checked } = event.target;
    let total_devices = checkdevices;
    console.log(value, "value");
    setActiveDeviceValue(value);
    if (!checked) {
      total_devices = checkdevices.filter((val) => val !== value);
    } else {
      total_devices = [...checkdevices, value];
    }
    setCheckDevices(total_devices);
    testcases_api(total_devices);
    console.log(total_devices, "total_devices");
    testsuites_api(total_devices);
  };

  let handleCheckboxChangetestcase = (event) => {
    const { value, checked } = event.target;
    setCheckTestcases([...checktestcase, value]);
    !checked && setCheckTestcases(checktestcase.filter((val) => val !== value));
  };

  let handleCheckboxChangetestsuite = (event) => {
    const { value, checked } = event.target;
    setCheckTestsuites([...checktestsuites, value]);
    !checked &&
      setCheckTestsuites(checktestsuites.filter((val) => val !== value));
  };

  let onChangeHandler = (e) => {
    setReferValue(e.target.value);
  };

  const getdataTable = () => {
    ValidateLicensestatus();
    setSplitval("No");
    if (nIterations > 100 || nIterations <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    } else if (
      checkdevices.length >= 1 &&
      !refervalue == "" &&
      (checktestcase.length >= 1 || checktestsuites.length >= 1)
    ) {
      var requestString = {
        Devices: checkdevices,
        TestSuite: checktestsuites,
        TestCase: checktestcase,
        Date: new Date(),
        Reference: String(refervalue).trim(),
        // Split: splitval != "" ? String(splitval) : String("No"),
        Split: TCchecked ? "Yes" : "No",
        reservation_category: String("Automation"),
        locked_by: userProfile.username,
        session_id: userProfile.session_id,
        user_privilege: userProfile.user_privilege,
        username: userProfile.username,
        email_id: userProfile.email_id,
        iteration: nIterations,
      };

      console.log("triggertest", requestString);
      axios
        .post(TRIGGER_TEST_API + `${JSON.stringify(requestString)}`)
        .then((response) => {
          console.log(response.data.Message, "success");
          setNotification(response.data.Message);
          toast.success("Executing Testcase", {
            position: toast.POSITION.TOP_CENTER,
          });
        })
        .catch((error) => {
          console.log(error, "error");
        });
      // setReferValue("");
      // setNIterations(1);
      // setTCChecked(false);
      // setCheckDevices([]);
      // setCheckTestsuites([]);
      // setCheckTestcases([]);
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };

  const deviceSelectAllHandler = (e) => {
    setSelectAllDevice(e.target.checked);
    if (e.target.checked === true) {
      setCheckDevices(devicesData);
    } else {
      setCheckDevices([]);
    }
  };

  const testcasesSelectAllHandler = (e) => {
    setSelectAllTestcases(e.target.checked);
    if (e.target.checked === true) {
      setCheckTestcases(testcasesData);
    } else {
      setCheckTestcases([]);
    }
  };

  const testsuiteSelectAllHandler = (e) => {
    setSelectAllTestsuite(e.target.checked);
    if (e.target.checked === true) {
      setCheckTestsuites(testsuiteData);
    } else {
      setCheckTestsuites([]);
    }
  };
  const handleEditIDE = (event) => {
    console.log("Ide Call", event);
    const newTab = window.open("/ide", "_blank");
    if (newTab) {
      newTab.opener = null;
    }
  };
  const handleBlurIterations = (e) => {
    if (e.target.value > 100 || e.target.value <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    }
  };
  const handleChangeIterations = (e) => {
    setNIterations(Number(e.target.value));
  };
  const TChandleChange = (event) => {
    setTCChecked(event.target.checked);
    console.log(event.target.checked, "TCMAP");
  };
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    setFileUploadOpen(true);
  };
  const handleUpload = async () => {
    const formData = new FormData();
    console.log("scriptname1", selectedFile);
    formData.append("file", selectedFile);
    formData.append("script_name", scriptName);
    formData.append("device_name", activeDeviceValue);
    console.log("formdata", formData, fileUploadOpen);

    try {
      const response = await axios.post(
        msl_ipaddress_trigger + "robo-recorder/msl",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      if (response.status === 200) {
        setTestCaseMessage(true);
        // setResponseMessage(response.data);
        handlePopupClose();
      }
    } catch (error) {
      setFailTestMessage(true);
      // setErrorMessage("Backend Issue");
      console.error("errormessage", error);
    }
  };
  const handleFilenameChange = (event) => {
    setScriptName(event);
  };

  const handlePopupClose = () => {
    setSelectedFile(null);
    setErrorMessage("");
    setFileUploadOpen(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setActiveDeviceValue("");
  };
  const testRefresh = function () {
    testcases_api(["Apple TV"]);
    // window.location.reload();
  };

  return (
    <>
      <Snackbar
        open={scheduleConfirmation}
        autoHideDuration={5000}
        className="schedule-confirmation"
        onClose={() => setScheduleConfirmation("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {scheduleConfirmation === "true" ? (
          <Alert severity="success">Scheduled successfully</Alert>
        ) : scheduleConfirmation === "false" ? (
          <Alert severity="error">
            Server Error, please try again after sometime
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <Snackbar
        open={TestCaseMessage}
        autoHideDuration={5000}
        onClose={() => setTestCaseMessage(false)}
        className={`crop-alert-message ${theme === "dark" ? "dark" : "light"}`}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {TestCaseMessage && (
          <Alert icon={true} onClose={() => setTestCaseMessage("")}>
            {" "}
            Test Case Is Uploaded
          </Alert>
        )}
      </Snackbar>
      <Snackbar
        open={failTestMessage}
        autoHideDuration={2000}
        className="schedule-confirmation"
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {failTestMessage && (
          <Alert severity="error" onClose={() => setFailTestMessage("")}>
            Backend Issue
          </Alert>
        )}
      </Snackbar>
      <div className={`trigger_page ${theme === "dark" ? "dark" : "light"}`}>
        <div className="me">
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="TestReferenceMain">
              <div
                className="IterationsMain"
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "10px",
                }}
              >
                <label>Iterations:</label>
                <input
                  type="number"
                  value={nIterations}
                  onChange={handleChangeIterations}
                  onBlur={handleBlurIterations}
                  className={`test_input_iterations ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                />
                <label>TC Map:</label>
                <Switch
                  checked={TCchecked}
                  onChange={TChandleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              </div>
            </div>
            <div className="TestRerenceLable">
              <label>Test Reference</label>
            </div>
            <div className="input_feilds">
              {" "}
              <input
                type="text"
                className="test_input"
                value={refervalue}
                onChange={onChangeHandler}
                placeholder="EX: Test_01"
              ></input>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="selected_inputs_title">
              <label>Target Devices</label>
            </div>
            <div className="input_feilds">
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 1 ? 0 : 1))
                  }
                >
                  <span title={checkdevices.join(",")}>
                    {checkdevices.length > 0
                      ? checkdevices.join(", ")
                      : "Dropdown to select device"}
                  </span>
                </div>
                {toggleDropdown === 1 && (
                  <div className="filter-dropdown-menu">
                    <button
                      onClick={() =>
                        setToggleDropdown((prevState) =>
                          prevState === 1 ? 0 : 1
                        )
                      }
                      className={`TestButton triggerbtn m-2 ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Submit
                    </button>

                    {devicesData ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              onChange={deviceSelectAllHandler}
                              type="checkbox"
                              checked={selectAllDevice}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {devicesData.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  onChange={handleCheckboxChange}
                                  type="checkbox"
                                  checked={checkdevices.includes(item)}
                                  ref={deviceRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p>No Devices</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="selected_inputs_title">
              <label>Test cases</label>
            </div>
            <div className="input_feilds">
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 2 ? 0 : 2))
                  }
                >
                  <span title={checktestcase.join(",")}>
                    {checktestcase.length > 0
                      ? checktestcase.join(", ")
                      : "Dropdown to select test cases"}
                  </span>
                </div>
                {toggleDropdown === 2 && (
                  <div className="filter-dropdown-menu">
                    <div className="flex-dropdown">
                      <div className="button-container-left">
                        <button
                          disabled={checktestsuites.length !== 0}
                          onClick={() =>
                            setToggleDropdown((prevState) =>
                              prevState === 2 ? 0 : 2
                            )
                          }
                          className={`TestButton triggerbtn m-2 ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          Submit
                        </button>
                        <div className="button-container-right">
                          <div className="button-container-right-A">
                            <label className="test-case-lable" for="script">
                              Add Test Case
                            </label>
                            <input
                              id="script"
                              type="file"
                              ref={fileInputRef}
                              onChange={handleFileChange}
                              className={`upload-btn ${
                                theme === "dark" ? "dark" : "light"
                              }`}
                              style={{ display: "none" }}
                            />
                          </div>
                          {fileUploadOpen && (
                            <div>
                              <FileUpload
                                scriptName={handleFilenameChange}
                                handleClose={handlePopupClose}
                                handleUpload={handleUpload}
                                // errorMessage={errorMessage}
                              />
                            </div>
                          )}
                          <div className="test-script-refresh">
                            <img src={TestRefreshIcon} onClick={testRefresh} />
                          </div>
                        </div>
                      </div>
                      {/* <div className="button-container-right">
                        {checktestcase.length !== 0 &&
                        checktestcase.length < 2 ? (
                          <button
                            onClick={handleEditIDE}
                            className={`TestButton triggerbtn m-2 ${
                              theme === "dark" ? "dark" : "light"
                            }`}
                          >
                            Edit
                          </button>
                        ) : (
                          ""
                        )}
                      </div> */}
                    </div>

                    {testcasesData ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              disabled={checktestsuites.length !== 0}
                              onChange={testcasesSelectAllHandler}
                              type="checkbox"
                              checked={selectAllTestcases}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {testcasesData.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  disabled={checktestsuites.length !== 0}
                                  onChange={handleCheckboxChangetestcase}
                                  type="checkbox"
                                  checked={checktestcase.includes(item)}
                                  ref={testcasesRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p>No Testcases</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="selected_inputs_title">
              <label>Test suite</label>
            </div>
            <div className="input_feilds">
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 3 ? 0 : 3))
                  }
                >
                  <span title={checktestsuites.join(",")}>
                    {checktestsuites.length > 0
                      ? checktestsuites.join(", ")
                      : "Dropdown to select test suite"}
                  </span>
                </div>
                {toggleDropdown === 3 && (
                  <div className="filter-dropdown-menu">
                    {testsuiteData.length >= 1 ? (
                      <>
                        <button
                          disabled={checktestcase.length !== 0}
                          onClick={() =>
                            setToggleDropdown((prevState) =>
                              prevState === 3 ? 0 : 3
                            )
                          }
                          className={`TestButton triggerbtn m-2 ${
                            theme === "dark" ? "dark" : "light"
                          }`}
                        >
                          Submit
                        </button>

                        <ul>
                          <li>
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                value="All"
                                id="All"
                                onChange={testsuiteSelectAllHandler}
                                disabled={checktestcase.length !== 0}
                                type="checkbox"
                                checked={selectAllTestsuite}
                              />
                              <label className="form-check-label" htmlFor="All">
                                Select All
                              </label>
                            </div>
                          </li>

                          {Array.isArray(testsuiteData) ? (
                            testsuiteData.map((item, index) => (
                              <li key={index}>
                                <div className="form-check">
                                  <input
                                    className="form-check-input"
                                    value={item}
                                    id={item}
                                    onChange={handleCheckboxChangetestsuite}
                                    type="checkbox"
                                    disabled={checktestcase.length !== 0}
                                    checked={checktestsuites.includes(item)}
                                    ref={testsuiteRef}
                                  />
                                  <label
                                    className="form-check-label"
                                    htmlFor={item}
                                  >
                                    {item}
                                  </label>
                                </div>
                              </li>
                            ))
                          ) : (
                            <p className="NoData">No test suite</p>
                          )}
                        </ul>
                      </>
                    ) : (
                      <p className="NoData">No test suite</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className={`getdatabtn ${theme === "dark" ? "dark" : "light"}`}>
            {/* {splitval === "Yes" && (
              <button disabled title="Disabled Right Now">
                TC MAP
              </button>
            )}
            {splitval === "No" && Status === "Active" && (
              <button
                onClick={setspecialval}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                TC MAP
              </button>
            )} */}
            {/* {splitval === "No" && Status !== "Active" && (
            <Tooltip
              title={<td>License {Status}</td>}
              className="tooltip-display"
            >
              <button
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
                disabled={Status !== "Active"}
              >
                TC MAP
              </button>
            </Tooltip>
          )} */}
            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Submit
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                onClick={getdataTable}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Submit
              </button>
            ) : (
              <div></div>
            )}

            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Schedule
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                onClick={handleScheduling}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Schedule
              </button>
            ) : (
              <div></div>
            )}

            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  type="reset"
                >
                  Reset
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
                type="reset"
                onClick={handleReset}
              >
                Reset
              </button>
            ) : (
              <div></div>
            )}
          </div>
          {schedulingPopup && (
            <Scheduling
              onSubmit={handleSchedulingOnSubmit}
              handleClose={handleSchedulingClose}
            />
          )}
        </div>
      </div>
    </>
  );
};
export default TriggertestME;
