import React, { useEffect, useRef, useState } from "react";
import "../TestManager/TestManager.css";
import "./TriggerTest.css";
import "../ModelPopup/Model.css";
import "../Table/TableData.css";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import Scheduling from "../../../components/Scheduling/Scheduling.jsx";
import axios from "axios";
import moment from "moment";
import { useLocation } from "react-router-dom";
import { Alert, Snackbar, Tooltip } from "@mui/material";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext.jsx";
import {
  TESTCASES_API,
  SUPPORT_API_DEVICES,
  TESTSUITES_DEVICES_API,
  FETCH_DEVICES_BY_DEVICE_STATUS_API,
  TRIGGER_TEST_API_IVI,
  SCHEDULE_SUBMIT_ATTRIBUTES_API,
  VALIDATE_BUYLICENSE_STATUS,
} from "../../../services/api.js";
import Switch from "@mui/material/Switch";

const TriggerTestMedicalDomain = () => {
  const { theme } = useTheme();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const [toggleDropdown, setToggleDropdown] = useState(0);
  const [devicesData, setDeviceData] = useState([]);
  const [devicesData1, setDeviceData1] = useState([]);
  const [nIterations, setNIterations] = useState(1);
  const [testcasesData, setTestcasesData] = useState([]);
  const [testsuiteData, setTestsuiteData] = useState([]);
  const [checkdevices, setCheckDevices] = useState([]);
  const [checkdevices1, setCheckDevices1] = useState([]);
  const [selectAllDevice, setSelectAllDevice] = useState(false);
  const [selectAllDevice1, setSelectAllDevice1] = useState(false);
  const [checktestcase, setCheckTestcases] = useState([]);
  const [selectAllTestcases, setSelectAllTestcases] = useState(false);
  const [checktestsuites, setCheckTestsuites] = useState([]);
  const [selectAllTestsuite, setSelectAllTestsuite] = useState(false);
  const [scheduleConfirmation, setScheduleConfirmation] = useState("");
  const [splitval, setSplitval] = useState("No");
  const [refervalue, setReferValue] = useState("");
  const [Status, setStatus] = useState("");
  const [notification, setNotification] = useState();
  const currentDate = new Date();
  const deviceRef = useRef(null);
  const testcasesRef = useRef(null);
  const testsuiteRef = useRef(null);
  const [schedulingPopup, setSchedulingPopup] = useState(false);
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const [TCchecked, setTCChecked] = React.useState(false);

  useEffect(() => {
    ValidateLicensestatus();
  });

  useEffect(() => {
    const id = setInterval(() => {
      devices_apis(); // <--  invoke in interval callback
    }, 5000);
    devices_apis();
    return () => clearInterval(id);
  }, []);

  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )
      .then((res) => {
        setStatus(Object.values(res.data)[0]);
        console.log("apidata status", res.data.status[0] === "Active");
        if (res.data.status.length === 0) {
          setStatus("Not Activated");
        } else {
          setStatus(res.data.status[0]);
        }
      })
      .catch((er) => console.log(er));
  };

  const handleScheduling = () => {
    if (
      checkdevices.length >= 1 &&
      !refervalue == "" &&
      (checktestcase.length >= 1 || checktestsuites.length >= 1)
    ) {
      setSchedulingPopup(true);
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };
  const handleSchedulingClose = () => {
    setSchedulingPopup(false);
  };
  const handleSchedulingOnSubmit = (data) => {
    handleReset();
    console.log(data, "submit");
    setSplitval("No");
    console.log(
      checkdevices.length >= 1,
      checktestcase.length >= 1,
      !refervalue == "",
      "check"
    );
    if (nIterations > 100 || nIterations <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    } else if (
      checkdevices.length >= 1 &&
      !refervalue == "" &&
      (checktestcase.length >= 1 || checktestsuites.length >= 1)
    ) {
      const schduleString = {
        ...data,
        Date: new Date(),
        Devices: checkdevices,
        TestSuite: checktestsuites,
        TestCase: checktestcase,
        Reference: String(refervalue).trim(),
        // Split: splitval != "" ? String(splitval) : String("No"),
        Split: TCchecked ? "Yes" : "No",
        reservation_category: String("Automation"),
        locked_by: userProfile.username,
        session_id: userProfile.session_id,
        user_privilege: userProfile.user_privilege,
        username: userProfile.username,
        email_id: userProfile.email_id,
        iteration: nIterations,
      };
      console.log("schduleString", schduleString);
      axios
        .post(
          SCHEDULE_SUBMIT_ATTRIBUTES_API + `${JSON.stringify(schduleString)}`
        )
        .then((response) => {
          console.log(response, "schedule");
          setScheduleConfirmation(response.data.valid);
        })
        .catch((error) => {
          alert(error, "Backend error");
          console.log(error, "error");
        });
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };

  const devices_apis = () => {
    axios
      .post(
        FETCH_DEVICES_BY_DEVICE_STATUS_API +
          JSON.stringify({
            username: userProfile.username,
            platform: platform_data,
            device_category: ["Medical"],
            current_date: moment().format("YYYY-MM-D"),
            current_time:
              currentDate.getHours() +
              ":" +
              currentDate.getMinutes() +
              ":" +
              currentDate.getSeconds(),
          })
      )
      .then((res) => {
        console.log("devicesdata", res.data);

        setDeviceData(res.data);
      })

      .catch((er) => console.log(er));
  };

  const devices_apis1 = (devicedata) => {
    axios
      .post(
        SUPPORT_API_DEVICES +
          JSON.stringify({
            device_name: devicedata,
          }) +
          "&attributes=" +
          JSON.stringify(["support_device"])
      )
      .then((res) => {
        const result_data = Object.values(res.data);
        console.log("devicesdata1", result_data);
        result_data.map((item, index) => {
          if (item !== null) {
            setDeviceData1(item);
          }
        });
      })
      .catch((er) => console.log(er));
  };

  const testcases_api = (checked_devices) => {
    console.log("testcases2", TESTCASES_API);
    axios
      .get(TESTCASES_API + `?device_list=${JSON.stringify(checked_devices)}`)
      .then((res) => {
        console.log("testcasesdata", res.data);
        setTestcasesData(res.data[0].test_case_name);
      })
      .catch((er) => console.log(er));
  };

  const testsuites_api = (devicename) => {
    axios
      .get(
        TESTSUITES_DEVICES_API +
          `${JSON.stringify({ device_name: devicename })}`
      )
      .then((res) => {
        let testsuites = res.data;
        if (Array.isArray(testsuites) && testsuites.length === 0) {
          setTestsuiteData("No Testcases");
        } else {
          setTestsuiteData(testsuites);
        }
      })
      .catch((er) => console.log(er));
  };

  const handleReset = (e) => {
    setReferValue("");
    setSplitval("");
    setTCChecked(false);
    setNIterations(1);
    setCheckDevices([]);
    setCheckDevices1([]);
    setCheckTestsuites([]);
    setCheckTestcases([]);
  };

  const today = new Date(),
    day =
      today.getFullYear() +
      "-" +
      (today.getMonth() + 1) +
      "-" +
      today.getDate();

  let handleCheckboxChange = (event) => {
    setCheckTestcases([]);
    setCheckTestsuites([]);
    setCheckDevices1([]);
    setSelectAllTestsuite(false);
    setSelectAllTestcases(false);
    setSelectAllDevice1(false);
    const { value, checked } = event.target;
    let total_devices = checkdevices;
    if (!checked) {
      total_devices = checkdevices.filter((val) => val !== value);
    } else {
      total_devices = [...checkdevices, value];
    }
    setCheckDevices(total_devices);

    console.log(total_devices, "devicesivi");
    devices_apis1(total_devices);
    testcases_api(total_devices);
    testsuites_api(total_devices);
  };
  let handleCheckboxChange1 = (event) => {
    const { value, checked } = event.target;
    let total_devices = checkdevices1;
    if (!checked) {
      total_devices = checkdevices1.filter((val) => val !== value);
    } else {
      total_devices = [...checkdevices1, value];
    }
    setCheckDevices1(total_devices);
  };

  let handleCheckboxChangetestcase = (event) => {
    const { value, checked } = event.target;
    setCheckTestcases([...checktestcase, value]);
    !checked && setCheckTestcases(checktestcase.filter((val) => val !== value));
  };

  let handleCheckboxChangetestsuite = (event) => {
    const { value, checked } = event.target;
    setCheckTestsuites([...checktestsuites, value]);
    !checked &&
      setCheckTestsuites(checktestsuites.filter((val) => val !== value));
  };

  let onChangeHandler = (e) => {
    setReferValue(e.target.value);
  };

  const getdataTable1 = () => {
    setSplitval("No");
    console.log(
      checkdevices.length >= 1,
      checkdevices1.length >= 1,
      checktestcase.length >= 1,
      !refervalue == "",
      "check"
    );
    if (nIterations > 100 || nIterations <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    } else if (
      checkdevices.length >= 1 &&
      !refervalue == "" &&
      (checktestcase.length >= 1 || checktestsuites.length >= 1)
    ) {
      var requestString = {
        Devices: checkdevices1,
        TestSuite: checktestsuites,
        TestCase: checktestcase,
        Date: new Date(),
        Reference: String(refervalue).trim(),
        // Split: splitval != "" ? String(splitval) : String("No"),
        Split: TCchecked ? "Yes" : "No",
        reservation_category: String("Automation"),
        locked_by: userProfile.username,
        session_id: userProfile.session_id,
        user_privilege: userProfile.user_privilege,
        username: userProfile.username,
        email_id: userProfile.email_id,
        iteration: nIterations,
      };

      console.log("triggertestivi", requestString);
      axios
        .post(TRIGGER_TEST_API_IVI + `${JSON.stringify(requestString)}`)
        .then((response) => {
          console.log(response.data.Message, "success");
          setNotification(response.data.Message);
          toast.success("Executing Testcase", {
            position: toast.POSITION.TOP_CENTER,
          });
        })
        .catch((error) => {
          console.log(error, "error");
        });
      // setReferValue("");
      // setNIterations(1);
      // setTCChecked(false);
      // setCheckDevices([]);
      // setCheckTestsuites([]);
      // setCheckTestcases([]);
    } else {
      toast.error(
        "Please enter Test Reference and select Devices and Testcases",
        { position: toast.POSITION.TOP_CENTER, className: "toast-message" }
      );
    }
  };

  const deviceSelectAllHandler = (e) => {
    setSelectAllDevice(e.target.checked);
    if (e.target.checked === true) {
      setCheckDevices(devicesData);
    } else {
      setCheckDevices([]);
    }
  };

  const deviceSelectAllHandler1 = (e) => {
    setSelectAllDevice1(e.target.checked);
    if (e.target.checked === true) {
      setCheckDevices1(devicesData1);
    } else {
      setCheckDevices1([]);
    }
  };
  console.log(checkdevices, "device");

  const testcasesSelectAllHandler = (e) => {
    setSelectAllTestcases(e.target.checked);
    console.log("fggg", testcasesData);
    if (e.target.checked === true) {
      setCheckTestcases(testcasesData);
    } else {
      setCheckTestcases([]);
    }
  };
  console.log(checktestcase, "testcasesivi");

  const testsuiteSelectAllHandler = (e) => {
    setSelectAllTestsuite(e.target.checked);

    if (e.target.checked === true) {
      setCheckTestsuites(testsuiteData);
    } else {
      setCheckTestsuites([]);
    }
  };
  console.log(checktestsuites, "testsuite");

  const handleBlurIterations = (e) => {
    if (e.target.value > 100 || e.target.value <= 0) {
      toast.error("Iteration value between 1 and 100", {
        position: toast.POSITION.TOP_CENTER,
        className: "toast-message",
      });
    }
  };
  const handleChangeIterations = (e) => {
    setNIterations(Number(e.target.value));
  };
  const TChandleChange = (event) => {
    setTCChecked(event.target.checked);
    console.log(event.target.checked, "TCMAP");
  };

  return (
    <>
      <Snackbar
        open={scheduleConfirmation}
        autoHideDuration={5000}
        className="schedule-confirmation"
        onClose={() => setScheduleConfirmation("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {scheduleConfirmation === "true" ? (
          <Alert severity="success">Scheduled successfully</Alert>
        ) : scheduleConfirmation === "false" ? (
          <Alert severity="error">
            Server Error, please try again after sometime
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>

      <div className={`trigger_page ${theme === "dark" ? "dark" : "light"}`}>
        <div className={`HMI_TC_map ${theme === "dark" ? "dark" : "light"}`}>
          <label>TC Map:</label>
          <Switch
            checked={TCchecked}
            onChange={TChandleChange}
            inputProps={{ "aria-label": "controlled" }}
          />
        </div>
        <div className="ivi">
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Iterations</label>

              <input
                type="number"
                value={nIterations}
                onChange={handleChangeIterations}
                onBlur={handleBlurIterations}
                className={`test_input_iterations ${
                  theme === "dark" ? "dark" : "light"
                }`}
              ></input>
            </div>
          </div>

          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Test Reference</label>

              <input
                type="text"
                className="test_input"
                value={refervalue}
                onChange={onChangeHandler}
                placeholder="EX: Test_01"
              ></input>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Target Devices</label>
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 1 ? 0 : 1))
                  }
                >
                  <span title={checkdevices.join(",")}>
                    {checkdevices.length > 0
                      ? checkdevices.join(", ")
                      : "Dropdown to select device"}
                  </span>
                </div>
                {toggleDropdown === 1 && (
                  <div className="filter-dropdown-menu">
                    <button
                      onClick={() =>
                        setToggleDropdown((prevState) =>
                          prevState === 1 ? 0 : 1
                        )
                      }
                      className={`TestButton triggerbtn m-2 ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Submit
                    </button>

                    {devicesData ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              onChange={deviceSelectAllHandler}
                              type="checkbox"
                              checked={selectAllDevice}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {devicesData.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  onChange={handleCheckboxChange}
                                  type="checkbox"
                                  checked={checkdevices.includes(item)}
                                  ref={deviceRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p>No Devices</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Support Devices</label>
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 2 ? 0 : 2))
                  }
                >
                  <span title={checkdevices1.join(",")}>
                    {checkdevices1.length > 0
                      ? checkdevices1.join(", ")
                      : "Dropdown to select device"}
                  </span>
                </div>
                {toggleDropdown === 2 && (
                  <div className="filter-dropdown-menu">
                    <button
                      onClick={() =>
                        setToggleDropdown((prevState) =>
                          prevState === 2 ? 0 : 2
                        )
                      }
                      className={`TestButton triggerbtn m-2 ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Submit
                    </button>

                    {devicesData1 ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              onChange={deviceSelectAllHandler1}
                              type="checkbox"
                              checked={selectAllDevice1}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {devicesData1.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  onChange={handleCheckboxChange1}
                                  type="checkbox"
                                  checked={checkdevices1.includes(item)}
                                  ref={deviceRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p>No Devices</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Test cases</label>
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 3 ? 0 : 3))
                  }
                >
                  <span title={checktestcase.join(",")}>
                    {checktestcase.length > 0
                      ? checktestcase.join(", ")
                      : "Test cases dropdown"}
                  </span>
                </div>
                {toggleDropdown === 3 && (
                  <div className="filter-dropdown-menu">
                    <button
                      disabled={checktestsuites.length !== 0}
                      onClick={() =>
                        setToggleDropdown((prevState) =>
                          prevState === 3 ? 0 : 3
                        )
                      }
                      className={`TestButton triggerbtn m-2 ${
                        theme === "dark" ? "dark" : "light"
                      }`}
                    >
                      Submit
                    </button>

                    {testcasesData ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              disabled={checktestsuites.length !== 0}
                              onChange={testcasesSelectAllHandler}
                              type="checkbox"
                              checked={selectAllTestcases}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {testcasesData.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  disabled={checktestsuites.length !== 0}
                                  onChange={handleCheckboxChangetestcase}
                                  type="checkbox"
                                  checked={checktestcase.includes(item)}
                                  ref={testcasesRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p>No Testcases</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* <div className="sub-heading-text">HMI Validation-CAN</div> */}
          {/* <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Detect camera device</label>

              <div classname="button">
                <button
                  style={{
                    backgroundColor: "rgba(255, 0, 0, 0)",
                    color: "white",
                    border: "2px solid #1eb6b6",
                    width: "30%",
                  }}
                >
                  Detect Devices
                </button>
              </div>
            </div>
          </div>
          <div
            className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
          >
            <div className="input_feilds">
              <label>Launch CANDOISO interface</label>

              <div classname="buttontt">
                <button
                  style={{
                    backgroundColor: "rgba(255, 0, 0, 0)",
                    color: "white",
                    border: "2px solid #1eb6b6",
                    width: "30%",
                  }}
                >
                  Start
                </button>
              </div>
            </div>
          </div> */}
          {/* <div className="getdatabtn">
            {/* {splitval === "Yes" ? (
                <button disabled title="Disabled Right Now">
                  Test Now
                </button>
              ) : (
                <button
                  onClick={setspecialval}
                  className="TestButton triggerbtn m-2"
                >
                  Test Now
                </button>
              )} */}
          {/* <button
              onClick={getdataTable1}
              className="TestButton triggerbtn  m-2"
            >
              Submit
            </button>
            <button
              onClick={handleScheduling}
              className="TestButton triggerbtn  m-2"
            >
              Schedule
            </button>
            {schedulingPopup && (
              <Scheduling
                handleClose={handleSchedulingClose}
                onSubmit={handleSchedulingOnSubmit}
              />
            )}
            <button
              className="TestButton m-2"
              type="reset"
              onClick={handleReset}
            >
              Reset
            </button>
          </div> */}

          <div className="getdatabtn">
            {/* {splitval === "Yes" && (
              <button disabled title="Disabled Right Now">
                TC MAP
              </button>
            )}
            {splitval === "No" && Status[0] === "Active" && (
              <button
                onClick={setspecialval}
                className="TestButton triggerbtn m-2"
              >
                TC MAP
              </button>
            )}
            {splitval === "No" && Status[0] !== "Active" && (
              <Tooltip
                title={<td>License {Status[0]}</td>}
                className="tooltip-display"
              >
                <button
                  onClick={setspecialval}
                  className="TestButton triggerbtn m-2"
                  disabled={Status[0] !== "Active"}
                >
                  TC MAP
                </button>
              </Tooltip>
            )} */}
            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Submit
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                onClick={getdataTable1}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Submit
              </button>
            ) : (
              <div></div>
            )}

            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  Schedule
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                onClick={handleScheduling}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                Schedule
              </button>
            ) : (
              <div></div>
            )}
            {schedulingPopup && (
              <Scheduling
                handleClose={handleSchedulingClose}
                onSubmit={handleSchedulingOnSubmit}
              />
            )}
            {Status !== "Active" ? (
              <Tooltip
                title={<td>License {Status}</td>}
                className="tooltip-display"
              >
                <button
                  disabled={Status !== "Active"}
                  className={`TestButton triggerbtn m-2 ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  type="reset"
                >
                  Reset
                </button>
              </Tooltip>
            ) : Status === "Active" ? (
              <button
                disabled={Status !== "Active"}
                className={`TestButton triggerbtn m-2 ${
                  theme === "dark" ? "dark" : "light"
                }`}
                type="reset"
                onClick={handleReset}
              >
                Reset
              </button>
            ) : (
              <div></div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
export default TriggerTestMedicalDomain;
