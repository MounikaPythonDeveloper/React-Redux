import React, { useState, useEffect } from "react";
import { Form } from "react-bootstrap";
import axios from "axios";
import "../../TriggerTest.css";
import "../TriggerTestPerformanceTesting/TriggerTestPerformanceTesting.css";
import { LOCUST_API } from "../../../../../services/api";
import { Alert, Snackbar } from "@mui/material";
import { useTheme } from "../../../../../components/ThemeToggle/ThemeContext";

export default function Locust(props) {
  const { theme } = useTheme();

  const [locustAllValues, setLocustAllValues] = useState({
    testReference: "",
    user: "",
    spawn_rate: "",
    duration: "",
    method: "",
    host: "",
    get_path: "",
    post_data: "",
    host_url: "",
  });
  const [mode, setMode] = useState("");
  const [locustRes, setLocustRes] = useState("");
  const date = new Date().toISOString();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));

  const changeHandlerLocust = (e) => {
    setLocustAllValues({ ...locustAllValues, [e.target.name]: e.target.value });
  };

  const methodHandler = (e) => {
    setMode(e.target.value);
  };

  const ResetHandler = () => {
    console.log("RESET");
    setLocustAllValues({
      testReference: "",
      user: "",
      spawn_rate: "",
      duration: "",
      method: "",
      host: "",
      get_path: "",
      post_data: "",
      host_url: "",
    });
    setMode("");
  };

  const LocustApiHandler = async () => {
    let LocustApi = "";
    LocustApi = `${LOCUST_API}${JSON.stringify({
      device_name: props.Value,
      test_reference: locustAllValues.testReference,
      user: locustAllValues.user,
      spawn_rate: locustAllValues.spawn_rate,
      duration: locustAllValues.duration,
      host: mode !== "POST" ? locustAllValues.host : "",
      get_path: mode !== "POST" ? locustAllValues.get_path : "",
      post_path:
        mode !== "GET"
          ? `${locustAllValues.host_url}:${locustAllValues.post_data}`
          : "",
      date: date,
      username: userProfile.username,
      session_id: userProfile.session_id,
      user_privilege: userProfile.user_privilege,
    })}`;
    console.log(LocustApi, "LocustApi");
    await axios
      .post(LocustApi)
      .then((response) => {
        setLocustRes(response.data);
        console.log("LocustApires", response);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    // ResetHandler();
  };

  return (
    <>
      <Snackbar
        open={locustRes}
        autoHideDuration={6000}
        className="add-device-confirmation"
        onClose={() => setLocustRes("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {locustRes === "API testing in Jmeter triggered successfully" ? (
          <Alert severity="success">
            API testing in Jmeter triggered successfully
          </Alert>
        ) : locustRes === "Failed to trigger test due to backend issue" ? (
          <Alert severity="error">
            Failed to trigger test due to backend issue
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <div className="locust">
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Test Reference</label>
          </div>
          <div className="input_feilds">
            <input
              value={locustAllValues.testReference}
              type="text"
              className="test_input"
              name="testReference"
              onChange={changeHandlerLocust}
              placeholder="EX: Test_01"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Number of user (peak concurrency)</label>
          </div>
          <div className="input_feilds">
            <input
              value={locustAllValues.user}
              type="text"
              className="test_input"
              name="user"
              onChange={changeHandlerLocust}
              placeholder="EX: 5"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Spawn rate (seconds)</label>
          </div>
          <div className="input_feilds">
            <input
              value={locustAllValues.spawn_rate}
              type="text"
              className="test_input"
              name="spawn_rate"
              onChange={changeHandlerLocust}
              placeholder="EX: 10"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Duration (in mins)</label>
          </div>
          <div className="input_feilds">
            <input
              value={locustAllValues.duration}
              type="text"
              className="test_input"
              name="duration"
              onChange={changeHandlerLocust}
              placeholder="EX: 5"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>HTTP Request</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              value={mode}
              onChange={methodHandler}
              className="mode-value-drop-down"
            >
              <option value="">Select a method</option>
              <option>GET</option>
              <option>POST</option>
              <option>GET, POST</option>
            </Form.Select>
          </div>
        </div>
        {(mode === "GET" || mode === "GET, POST") && (
          <div>
            <div
              className={`selected_inputs ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <div className="selected_inputs_title">
                <label>Host (hostname with port)</label>
              </div>
              <div className="input_feilds">
                <input
                  value={locustAllValues.host}
                  type="text"
                  className="test_input"
                  name="host"
                  onChange={changeHandlerLocust}
                  placeholder="EX: http://172.31.31.203:5003"
                ></input>
              </div>
            </div>
            <div
              className={`selected_inputs ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <div className="selected_inputs_title">
                <label>GET Path (Endpoints)</label>
              </div>
              <div className="input_feilds">
                <input
                  value={locustAllValues.get_path}
                  type="text"
                  className="test_input"
                  name="get_path"
                  onChange={changeHandlerLocust}
                  placeholder="EX: '/,/triggerDEVJC5,/triggerJC5,/agenttriggerJC5'"
                ></input>
              </div>
            </div>
          </div>
        )}
        {(mode === "POST" || mode === "GET, POST") && (
          <div>
            <div
              className={`selected_inputs ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <div className="selected_inputs_title">
                <label>Host (URL)</label>
              </div>
              <div className="input_feilds">
                <input
                  value={locustAllValues.host_url}
                  type="text"
                  className="test_input"
                  name="host_url"
                  onChange={changeHandlerLocust}
                  placeholder="EX: http://3.7.28.3:5000/update_master_status?master_details="
                ></input>
              </div>
            </div>
            <div
              className={`selected_inputs ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <div className="selected_inputs_title">
                <label>POST data (List of data)</label>
              </div>
              <div className="input_feilds">
                <input
                  value={locustAllValues.post_data}
                  type="text"
                  className="test_input"
                  name="post_data"
                  onChange={changeHandlerLocust}
                  placeholder="EX: [{'master_id':'Jenkins_Controller-1','master_status':'Online'}]"
                ></input>
              </div>
            </div>
          </div>
        )}
        <div className="getdatabtn">
          <button
            onClick={ResetHandler}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Reset
          </button>
          <button
            onClick={LocustApiHandler}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Submit
          </button>
        </div>
      </div>
    </>
  );
}
