import JMeter from "../Jmeter/Jmeter";
import LoadRunner from "../LoadRunner/LoadRunner";
import Locust from "../Locust/Locust";

export default function TriggerTestPerformanceTesting(props) {
  return (
    <div className="trigger_page">
      {props.performanceTestValue === "Locust" ? (
        <Locust Value={props.performanceTestValue} />
      ) : props.performanceTestValue === "Load Runner" ? (
        <LoadRunner Value={props.performanceTestValue} />
      ) : (
        <JMeter Value={props.performanceTestValue} />
      )}
    </div>
  );
}
