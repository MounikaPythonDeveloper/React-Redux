import React, { useState, useEffect } from "react";
import { Form } from "react-bootstrap";
import axios from "axios";
import "../../TriggerTest.css";
import "../TriggerTestPerformanceTesting/TriggerTestPerformanceTesting.css";
import { JMETER_API } from "../../../../../services/api";
import { Alert, Snackbar } from "@mui/material";
import { useTheme } from "../../../../../components/ThemeToggle/ThemeContext";

export default function JMeter(props) {
  const { theme } = useTheme();
  const [jmeterAllValues, setJmeterAllValues] = useState({
    testReference: "",
    protocol: "",
    domain: "",
    path: "",
    method: "",
    user: "",
    time: "",
  });
  const [mode, setMode] = useState("");
  const [jmeterRes, setJmeterRes] = useState("");
  const date = new Date().toISOString();
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const changeHandlerJmeter = (e) => {
    setJmeterAllValues({ ...jmeterAllValues, [e.target.name]: e.target.value });
  };

  const methodHandler = (e) => {
    setMode(e.target.value);
  };

  const ResetHandler = () => {
    setJmeterAllValues({
      testReference: "",
      protocol: "",
      domain: "",
      path: "",
      method: "",
      user: "",
      time: "",
    });
    setMode("");
  };

  const JmeterApiHandler = async () => {
    let JMeterApi = "";
    JMeterApi = `${JMETER_API}${JSON.stringify({
      device_name: props.Value,
      test_reference: jmeterAllValues.testReference,
      method: mode,
      protocol: jmeterAllValues.protocol,
      domain: jmeterAllValues.domain,
      path: jmeterAllValues.path,
      user: jmeterAllValues.user,
      time: jmeterAllValues.time,
      date: date,
      username: userProfile.username,
      session_id: userProfile.session_id,
      user_privilege: userProfile.user_privilege,
    })}`;
    console.log(JMeterApi, "JMeterApi");
    await axios
      .post(JMeterApi)
      .then((response) => {
        setJmeterRes(response.data);
        console.log("jmeterApires", response);
      })
      .catch((error) => {
        console.log(error, "error");
      });
    // ResetHandler();
  };

  return (
    <>
      <Snackbar
        open={jmeterRes}
        autoHideDuration={6000}
        className="add-device-confirmation"
        onClose={() => setJmeterRes("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {jmeterRes === "API testing in Jmeter triggered successfully" ? (
          <Alert severity="success">
            API testing in Jmeter triggered successfully
          </Alert>
        ) : jmeterRes === "Failed to trigger test due to backend issue" ? (
          <Alert severity="error">
            Failed to trigger test due to backend issue
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <div className="j-meter">
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Test Reference</label>
          </div>
          <div className="input_feilds">
            <input
              value={jmeterAllValues.testReference}
              type="text"
              className="test_input"
              name="testReference"
              onChange={changeHandlerJmeter}
              placeholder="EX: Test_01"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Protocol</label>
          </div>
          <div className="input_feilds">
            <input
              value={jmeterAllValues.protocol}
              type="text"
              className="test_input"
              name="protocol"
              onChange={changeHandlerJmeter}
              placeholder="EX: http"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Domain</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              className="test_input"
              name="domain"
              value={jmeterAllValues.domain}
              onChange={changeHandlerJmeter}
              placeholder="EX: www.amazon.in"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Path</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              className="test_input"
              name="path"
              value={jmeterAllValues.path}
              onChange={changeHandlerJmeter}
              placeholder="EX: -/hi/gp/bestsellers/?ref_=nav_cs_bestsellers"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>HTTP Request</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              value={mode}
              onChange={methodHandler}
              className="mode-value-drop-down"
            >
              <option value="">Select a method</option>
              <option>GET</option>
              <option>POST</option>
            </Form.Select>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Number of threads (users)</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              value={jmeterAllValues.user}
              className="test_input"
              name="user"
              onChange={changeHandlerJmeter}
              placeholder="EX: 10"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Ramp-up Period(seconds)</label>
          </div>
          <div className="input_feilds">
            <input
              type="text"
              className="test_input"
              name="time"
              value={jmeterAllValues.time}
              onChange={changeHandlerJmeter}
              placeholder="EX: 30"
            ></input>
          </div>
        </div>
        <div className="getdatabtn">
          <button
            onClick={ResetHandler}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Reset
          </button>
          <button
            onClick={JmeterApiHandler}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Submit
          </button>
        </div>
      </div>
    </>
  );
}
