import React, { useState } from "react";
import { LOAD_RUNNER_API } from "../../../../../services/api";
import axios from "axios";
import { Form } from "react-bootstrap";
import "./LoadRunner.css";
import "../TriggerTestPerformanceTesting/TriggerTestPerformanceTesting.css";
import { Alert, Snackbar } from "@mui/material";
import { useTheme } from "../../../../../components/ThemeToggle/ThemeContext";

export default function LoadRunner() {
  const { theme } = useTheme();
  const [testreference, setTestReference] = useState("");
  const [devicename, setDeviceName] = useState("");
  const [method, setMethod] = useState("");
  const [url, setUrl] = useState("");
  const [iter, setIter] = useState("");
  const [loadRunnerRes, setLoadRunnerRes] = useState("");
  const userProfile = JSON.parse(sessionStorage.getItem("userData"));
  const currentDate = new Date();
  const ResetHandler = () => {
    setTestReference("");
    setDeviceName("");
    setMethod("");
    setUrl("");
    setIter("");
    setLoadRunnerRes("");
  };
  const load_runner_api = () => {
    axios
      .post(
        LOAD_RUNNER_API +
          JSON.stringify({
            test_reference: testreference,
            username: userProfile.username,
            date: currentDate,
            device_name: devicename,
            method: method,
            URL: url,
            iterations: iter,
            session_id: userProfile.session_id,
            user_privilege: userProfile.user_privilege,
          })
      )
      .then((res) => {
        setLoadRunnerRes(res.data);
        console.log(res.data, "success");
      })

      .catch((er) => console.log(er));
    // ResetHandler();
  };
  let onChangeHandlerTestRef = (e) => {
    setTestReference(e.target.value);
  };

  let onChangeHandlerDeviceName = (e) => {
    setDeviceName(e.target.value);
    console.log("devicename", e.target.value);
  };

  const getMethod = (e) => {
    setMethod(e);
  };
  let onChangeHandlerURL = (e) => {
    setUrl(e.target.value);
  };
  let onChangeHandlerIteration = (e) => {
    setIter(e.target.value);
  };

  return (
    <>
      <Snackbar
        open={loadRunnerRes}
        autoHideDuration={6000}
        className="add-device-confirmation"
        onClose={() => setLoadRunnerRes("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {loadRunnerRes ===
        "API testing in Load Runner triggered successfully" ? (
          <Alert severity="success">
            API testing in Load Runner triggered successfully
          </Alert>
        ) : loadRunnerRes === "Failed to trigger test due to backend issue" ? (
          <Alert severity="error">
            Failed to trigger test due to backend issue
          </Alert>
        ) : (
          <div></div>
        )}
      </Snackbar>
      <div className="load_ruuner">
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="input_feilds">
            <div className="selected_inputs_title">
              <label>Test Reference</label>
            </div>
            <input
              type="text"
              // className="test_input_lr"
              className="test_input"
              value={testreference}
              onChange={onChangeHandlerTestRef}
              placeholder="EX: Test_01"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Testing Tool</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              onChange={onChangeHandlerDeviceName}
              className="mode-value-drop-down"
            >
              <option value="">Select Tool</option>
              <option value="LoadRunner">LoadRunner</option>
            </Form.Select>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="selected_inputs_title">
            <label>Method</label>
          </div>
          <div className="mode-drop-down">
            <Form.Select
              onChange={(e) => getMethod(e.target.value)}
              className="mode-value-drop-down"
            >
              <option>Method</option>
              <option value="POST">POST</option>
              <option value="GET">GET</option>
            </Form.Select>
          </div>
        </div>

        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="input_feilds">
            <div className="selected_inputs_title">
              <label>URL</label>
            </div>

            <input
              type="text"
              // className="test_input_lr"
              className="test_input"
              value={url}
              onChange={onChangeHandlerURL}
              placeholder="EX: 43.205.56.231:5000/fetch_all_details_user_search_for_user_accounts?search=A"
            ></input>
          </div>
        </div>
        <div
          className={`selected_inputs ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="input_feilds">
            <div className="selected_inputs_title">
              <label>Iteration</label>
            </div>

            <input
              type="text"
              // className="test_input_lr"
              className="test_input"
              value={iter}
              onChange={onChangeHandlerIteration}
              placeholder="EX: 2"
            ></input>
          </div>
          {/* <button
            onClick={load_runner_api}
            className="TestButton triggerbtn  m-2"
          >
            Submit
          </button> */}
        </div>
        <div className="getdatabtn">
          <button
            onClick={ResetHandler}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Reset
          </button>
          <button
            onClick={load_runner_api}
            className={`TestButton triggerbtn m-2 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Submit
          </button>
        </div>
      </div>
    </>
  );
}
