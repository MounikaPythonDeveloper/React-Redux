import React, { useEffect, useState } from "react"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"
import FormControl from "@mui/material/FormControl"
import { FormHelperText } from "@mui/material"
import { Select, MenuItem, InputLabel } from "@mui/material"
import TextField from "@mui/material/TextField"
import "./TriggerTestABR.css"
import axios from "axios"
import moment from "moment"
import { Alert, Snackbar, Tooltip } from "@mui/material"
import {
  TESTCASES_API,
  TESTSUITES_DEVICES_API,
  TRIGGER_TEST_ABR_API,
} from "../../../../services/api"
import MultiSelectDropdown from "../../../../components/ReusableComponents/MultiSelectDropdown/MultiSelctDropdown"

export default function TriggerTestABR() {
  const { theme } = useTheme()
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [errorMessage, setErrorMessage] = useState("")
  const [testReference, setTestReference] = useState("")
  const [selectedTestcases, setSelectedTestcases] = useState([])
  const [testsuiteData, setTestsuiteData] = useState([])
  const [testsuite, setTestsuite] = useState("")
  const [optionPlatformData, setOptionPlatformData] = useState([])
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  useEffect(() => {
    testcases_api()
  }, [selectedTestcases])
  useEffect(() => {
    testsuites_api()
  }, [selectedTestcases])

  const testcases_api = () => {
    axios
      .get(TESTCASES_API + `?device_list=${JSON.stringify(["ABR"])}`)
      .then((res) => {
        setOptionPlatformData(res.data[0].test_case_name)
      })
      .catch((er) => console.log(er))
  }

  const testsuites_api = () => {
    axios
      .get(
        TESTSUITES_DEVICES_API + `${JSON.stringify({ device_name: ["ABR"] })}`
      )
      .then((res) => {
        console.log(res.data !== "", "testsuite check", res.data)
        res.data.length >= 1
          ? setTestsuiteData(res.data)
          : setTestsuiteData(["No Testcases"])
      })
      .catch((er) => console.log(er))
  }
  const getABRAutomation = () => {
    if (
      (selectedTestcases.length === 0 && testsuite === "") ||
      !testReference
    ) {
      setErrorMessage("Please Select Data")
    } else {
      setErrorMessage("")
      // Prepare data to send to API
      const requestData = {
        Reference: testReference,
        Split: "No",
        TestSuite: testsuite === "" ? [] : [testsuite],
        Devices: ["ABR"],
        TestCase: selectedTestcases,
        Date: moment().format("YYYY-MM-D"),
        reservation_category: "Automation",
        locked_by: userProfile.username,
        session_id: userProfile.session_id,
        user_privilege: userProfile.user_privilege,
        username: userProfile.username,
        email_id: userProfile.email_id,
        iteration: 1,
      }

      // Send data to API using fetch or any other API client
      axios
        .post(TRIGGER_TEST_ABR_API + JSON.stringify(requestData))
        .then((response) => {
          setSnackBarMessage(response.data.Message)
          setSnackBarSeverity("success")
        })
        .catch((error) => {
          setSnackBarMessage("Backend Issue")
          setSnackBarSeverity("error")
        })

      // setSelectedTestcases([])
      // setTestReference("")
      // setTestsuite("")
    }
  }
  return (
    <div className="TriggerTestABR">
      <div class="row">
        <div class="col-md-6 offset-md-3">
          <h3 className={`ABR-title ${theme === "dark" ? "dark" : "light"}`}>
            Trigger Test
          </h3>
        </div>
        <div className="Triggertest-head">
          <div class="row">
            <TextField
              id="ABR-TestReference"
              label="Test Reference"
              variant="standard"
              className={`Testrefernce-ABR ${
                theme === "dark" ? "dark" : "light"
              }`}
              value={testReference}
              onChange={(e) => setTestReference(e.target.value)}
            />
          </div>
          <div class="row">
            <FormControl
              variant="standard"
              fullWidth
              className={`DropdownSelect ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <MultiSelectDropdown
                selectedPlatforms={selectedTestcases}
                setSelectedPlatforms={setSelectedTestcases}
                optionPlatformData={optionPlatformData}
                title="Test Case"
                testsuite={testsuite}
                displayEmpty
                onClick={testcases_api}
              />
            </FormControl>
          </div>
          <div class="row">
            <FormControl
              variant="standard"
              sx={{ m: 1, minWidth: 120 }}
              className={`DropdownSelect ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <InputLabel id="demo-simple-select-standard-label">
                Test Suite
              </InputLabel>
              <Select
                labelId="demo-simple-select-standard-label"
                id="demo-simple-select-standard"
                value={testsuite}
                disabled={selectedTestcases.length !== 0}
                onChange={(e) => setTestsuite(e.target.value)}
                label="Testsuite"
                MenuProps={{
                  PaperProps: {
                    style: {
                      background:
                        theme === "light"
                          ? "linear-gradient(to right, #034e88, #40a7f6)"
                          : "",
                    },
                  },
                }}
              >
                <MenuItem value={""}>Test Suite</MenuItem>
                {testsuiteData.length >= 1 ? (
                  testsuiteData.map((item, index) => {
                    return <MenuItem value={item}>{item}</MenuItem>
                  })
                ) : (
                  <MenuItem value="">No Data</MenuItem>
                )}
              </Select>
            </FormControl>
          </div>
          {errorMessage && (
            <div>
              <FormHelperText error={!!errorMessage}>
                {errorMessage}
              </FormHelperText>
            </div>
          )}
          <div className="ABR-Button">
            <button
              type="submit"
              onClick={getABRAutomation}
              className={`ABRSubmit ${theme === "dark" ? "dark" : "light"}`}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
      <>
        <Snackbar
          open={snackBarMessage}
          autoHideDuration={10000}
          className={`crop-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          onClose={() => setSnackBarMessage("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            severity={snackBarSeverity}
            onClose={() => setSnackBarMessage("")}
          >
            {snackBarMessage}
          </Alert>
        </Snackbar>
      </>
    </div>
  )
}
