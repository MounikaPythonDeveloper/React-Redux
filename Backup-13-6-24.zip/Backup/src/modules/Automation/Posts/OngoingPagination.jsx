import axios from "axios"
import React, { useState, useEffect } from "react"
import Posts from "../Table/OngoingTestTableData"
import Pagination from "../Pagination/Pagination"
import { ONGOINGTEST_API } from "../../../services/api"

const Tabledata = (platformCategory) => {
  const platform = JSON.parse(sessionStorage.getItem("platform"))
  const otherData = {
    "M&E-Devices": ["STB", "Smart TV", "OTT", "iOS", "Android", "Gaming","iOS Tab",
      "Android Tab",],
    "Select M&E Categories": [
      "STB",
      "Smart TV",
      "OTT",
      "iOS",
      "Android",
      "Gaming",
      "iOS Tab",
      "Android Tab",
    ],
    "Media And Entertainment": [
      "STB",
      "Smart TV",
      "OTT",
      "iOS",
      "Android",
      "Gaming",
      "iOS Tab",
      "Android Tab",
    ],
    "Telecom-Devices": ["Router"],
    "Select Telecom Devices": ["Router"],
    Telecom: ["Router"],
    "Healthcare-Devices": ["iOS", "Android"],
    "Select Healthcare Devices": ["iOS", "Android"],
    Healthcare: ["iOS", "Android"],
    "IndustrialProducts-Devices": ["Embedded"],
    "Select IndustrialProducts Devices": ["Embedded"],
    IndustrialProducts: ["Embedded"],
    "Transportation - Devices": ["IVI", "ECU"],
    Transportation: ["IVI", "ECU"],
  }
  const platformCategoryName = platformCategory.platformCategory
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [testdata, setTestData] = useState([])
  console.log("testdata", testdata)
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [postsPerPage, setPostsPerPage] = useState(5)
  useEffect(() => {
    const id = setInterval(() => {
      ongoingtest() // <-- (3) invoke in interval callback
    }, 5000)
    ongoingtest()
    return () => clearInterval(id)
  }, [platformCategory])

  const ongoingtest = () => {
    axios
      .get(
        `${ONGOINGTEST_API}${JSON.stringify({
          count: 100,
          locked_by: userProfile.username,
          user_privilege: userProfile.user_privilege,
        })}&condition=${JSON.stringify({
          platform: platform,
          device_category: otherData.hasOwnProperty(platformCategoryName)
            ? otherData[platformCategoryName]
            : [platformCategoryName],
        })}`
      )
      .then((res) => {
        console.log("ongoing", res.data)
        setTestData(res.data)
      })
      .catch((er) => console.log(er))
  }

  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = testdata.slice(indexOfFirstPost, indexOfLastPost)

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber)

  return (
    <React.Fragment>
      <Posts
        testdata={currentPosts}
        indexOfFirstPost={indexOfFirstPost}
        loading={loading}
      />
      <Pagination
        currentPage={currentPage}
        postsPerPage={postsPerPage}
        totalPosts={testdata.length}
        paginate={paginate}
      />
    </React.Fragment>
  )
}
export default Tabledata
