import axios from "axios"
import React, { useState, useEffect } from "react"
import Pagination from "../Pagination/Pagination"
import TestHistoryTabledata from "../Table/TestHistoryTabledata"
import "../Posts/Test_history.css"
import { TESTHISTORY_API } from "../API/apis"

const Tabledata = (props) => {
  const [testhistorydata, setTestHistoryData] = useState([])

  useEffect(() => {
    const id = setInterval(() => {
      testhistorydataapi() // <-- (3) invoke in interval callback
    }, 5000)
    testhistorydataapi()
    return () => clearInterval(id)
  }, [])

  const testhistorydataapi = () => {
    axios
      .get(TESTHISTORY_API)
      .then((res) => {
        console.log("testhistorydata", res.data)
        setTestHistoryData(res.data)
      })
      .catch((er) => console.log(er))
  }

  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [postsPerPage, setPostsPerPage] = useState(10)

  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = testhistorydata.slice(indexOfFirstPost, indexOfLastPost)

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber)
  useEffect(() => {}, [])

  const openInNewTab = (url) => {
    window.open(url, "_blank", "noreferrer")
  }
  return (
    <React.Fragment>
      <div className="dashboard-reports">
        <div>
          <h3 className="table_mainhead">Test History</h3>
        </div>
        <div className="dashboard-actions">
          <button
            className="dashboard-btn"
            role="link"
            onClick={() => openInNewTab("http://3.7.48.156/TMO")}
          >
            Analytics Dashboard1
          </button>
          <button
            className="dashboard-btn"
            role="link"
            onClick={() => openInNewTab("http://3.7.48.156/ATT")}
          >
            Analytics Dashboard2
          </button>
          <button
            className="dashboard-btn"
            role="link"
            onClick={() => openInNewTab("http://3.7.48.156/VZW")}
          >
            Analytics Dashboard3
          </button>
        </div>
      </div>
      <TestHistoryTabledata testhistorydata={currentPosts} loading={loading} />
      <Pagination
        currentPage={currentPage}
        postsPerPage={postsPerPage}
        totalPosts={testhistorydata.length}
        paginate={paginate}
      />
    </React.Fragment>
  )
}
export default Tabledata
