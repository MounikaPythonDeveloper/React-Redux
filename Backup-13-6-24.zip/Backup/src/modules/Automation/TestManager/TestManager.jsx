import React, { useState } from "react";
import "../TestManager/TestManager.css";
import axios from "axios";
import Tabledata from "../Posts/OngoingPagination";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from "react-router-dom";
import { Breadcrumbs, Typography } from "@mui/material";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import { Form } from "react-bootstrap";
import JiraIcon from "../../../assets/images/JiraLogo.svg";
import ConnectToJira from "./JiraIntegration/ConnectToJira";
import { DEVICE_STATUS_API } from "../../../services/api.js";
import { useTheme } from "../../../components/ThemeToggle/ThemeContext.jsx";
import StatusMonitoring from "../StatusMonitoring/StatusMonitoring.jsx";
import TriggertestME from "../TriggerTest/TriggerTestME";
import TriggertestWeb from "../TriggerTest/TriggerTestWeb";
import TriggertestDesktop from "../TriggerTest/TriggerTestDesktop";
import TriggertestHMI from "../TriggerTest/TriggerTestHMI";
import TriggerTestMedicalDomain from "../TriggerTest/TriggerTestMedicalDomain";
import TriggerTestIVI from "../TriggerTest/TriggerTestIVI";
import TriggerTestTelecom from "../TriggerTest/TriggerTestTelecom";
import TriggerTestAPI from "../TriggerTest/TriggerTestAPI/TriggerTestAPI/TriggerTestAPI.jsx";
import TriggerTestPerformanceTesting from "../TriggerTest/TriggerTestPerformanceTesting/TriggerTestPerformanceTesting/TriggerTestPerformanceTesting";

export default function TestManager() {
  const { theme } = useTheme();
  const [tab, setTab] = useState(1);
  const platform_data = JSON.parse(sessionStorage.getItem("platform"));
  const [dev_status, SetDev_status] = useState([]);
  const [platformCategory, setPlatformCategory] = useState(platform_data);
  const [onPlatformChange, setOnPlatformChange] = useState(false);
  const [apiTestValue, setApiTestValue] = useState("Rest API");
  const [modalOpen, setModalOpen] = useState(false);

  const [performanceTestValue, setPerformanceTestValue] = useState("Jmeter");

  const getPlatformCategory = (e) => {
    let newvalue = e;
    setPlatformCategory(newvalue);
    setOnPlatformChange(true);
  };
  const apiTestDropDownFunction = function (e) {
    setApiTestValue(e);
  };

  const performanceTestDropDownFunction = (e) => {
    setPerformanceTestValue(e);
  };

  const openJiraPopUp = () => {
    setModalOpen(true);
  };

  // POPUP CLOSE FUNCTION
  const handleClosePopup = function () {
    setModalOpen(false);
  };

  return (
    <>
      <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
        <Link to={"/platform"}>Platform</Link>
        {platform_data === "Telecom" ? (
          <Link to="/platform">Telecom</Link>
        ) : (
          <Link Link to="/platform">
            {platform_data}
          </Link>
        )}
        <Typography color="#0D6EFD">Automation</Typography>
      </Breadcrumbs>

      <div
        className={`test-manager-page ${theme === "dark" ? "dark" : "light"}`}
      >
        <Form.Group>
          {platform_data === "Media And Entertainment" && (
            <Form.Select
              className={`deviceFilterForm ${
                theme === "dark" ? "dark" : "light"
              }`}
              onChange={(e) => getPlatformCategory(e.target.value)}
            >
              <option value="M&E-Devices">Select M&E Categories</option>
              <option>Web</option>
              <option>HMI</option>
              <option>Desktop</option>
              <option>API Testing</option>
              <option>Performance Testing</option>
              <option>M&E-Devices</option>
            </Form.Select>
          )}

          {platform_data === "Transportation" && (
            <Form.Select
              className={`deviceFilterForm ${
                theme === "dark" ? "dark" : "light"
              }`}
              onChange={(e) => getPlatformCategory(e.target.value)}
            >
              <option value="Transportation-Devices">
                Select Transportation Categories
              </option>
              <option>IVI</option>
              <option>HMI</option>
            </Form.Select>
          )}
          {platform_data === "Healthcare" && (
            <Form.Select
              className={`deviceFilterForm ${
                theme === "dark" ? "dark" : "light"
              }`}
              onChange={(e) => getPlatformCategory(e.target.value)}
            >
              <option value="Healthcare-Devices">
                Select Healthcare Categories
              </option>
              <option>Medical</option>
              <option>HMI</option>
              <option>web</option>
              <option>Desktop</option>
              <option>API Testing</option>
              <option>Healthcare-Devices</option>
            </Form.Select>
          )}
          {platform_data === "Industrial Products" && (
            <Form.Select
              className={`deviceFilterForm ${
                theme === "dark" ? "dark" : "light"
              }`}
              onChange={(e) => getPlatformCategory(e.target.value)}
            >
              <option value="IndustrialProducts-Devices">
                Select Industrial Products Categories
              </option>
              <option>Embedded</option>
              <option>web</option>
              <option>Desktop</option>
              <option>API Testing</option>
            </Form.Select>
          )}
          {platform_data === "Telecom" && (
            <Form.Select
              className={`deviceFilterForm ${
                theme === "dark" ? "dark" : "light"
              }`}
              onChange={(e) => getPlatformCategory(e.target.value)}
            >
              <option value="Telecom-Devices">Select Telecom Categories</option>
              <option>API Testing</option>
              <option>Telecom-Devices</option>
            </Form.Select>
          )}
        </Form.Group>
        <ToastContainer />
        <br />
        <br />
        {platform_data !== "Web" ? (
          <div
            className={`heading-text ${theme === "dark" ? "dark" : "light"}`}
          >
            Automation Hub
          </div>
        ) : (
          <div
            className={`heading-text ${theme === "dark" ? "dark" : "light"}`}
          >
            Web Automation{" "}
          </div>
        )}
        <div className="test-manager-sub-heading">
          <div className="Trigger-Test-container">
            <div
              className={`Trigger-Test-text ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              Trigger Test
            </div>
            <ConnectToJira open={modalOpen} handleClose={handleClosePopup} />
            <div className="jira-logo">
              <img src={JiraIcon} onClick={openJiraPopUp} alt="Jira icon" />
            </div>
            {platformCategory === "API Testing" && (
              <div className="trigger-test-drop-down">
                <Form.Select
                  onChange={(e) => apiTestDropDownFunction(e.target.value)}
                  className={`deviceFilterForm ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  <option>Rest API</option>
                  <option>Web Socket API</option>
                </Form.Select>
              </div>
            )}
            {platformCategory === "Performance Testing" && (
              <div>
                <Form.Select
                  className={`deviceFilterForm ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  onChange={(e) =>
                    performanceTestDropDownFunction(e.target.value)
                  }
                >
                  <option
                    value={"Load Runner"}
                    selected={performanceTestValue === "Load Runner"}
                  >
                    Load Runner
                  </option>
                  <option
                    value={"Jmeter"}
                    selected={performanceTestValue === "Jmeter"}
                  >
                    Jmeter
                  </option>
                  <option
                    value={"Locust"}
                    selected={performanceTestValue === "Locust"}
                  >
                    Locust
                  </option>
                </Form.Select>
              </div>
            )}
          </div>
          <div className="Trigger-Test-container-left">
            {platformCategory === "API Testing" ||
            platformCategory === "Web" ||
            platformCategory === "Performance Testing" ? (
              ""
            ) : (
              <div
                className={`sub-heading-text ${
                  theme === "dark" ? "dark" : "light"
                }`}
                // style={{ paddingRight: "18%" }}
              >
                Status Monitoring
              </div>
            )}
          </div>
        </div>

        <div className="test_main">
          <div className="trigger_content">
            {tab === 1 && platformCategory === "Transportation" ? (
              <TriggerTestIVI />
            ) : platformCategory === "Transportation-Devices" ? (
              <TriggerTestIVI />
            ) : platformCategory === "Web" ? (
              <TriggertestWeb />
            ) : platformCategory === "Desktop" ? (
              <TriggertestDesktop />
            ) : platformCategory === "IVI" ? (
              <TriggerTestIVI />
            ) : platformCategory === "HMI" ? (
              <TriggertestHMI />
            ) : platformCategory === "Medical" ? (
              <TriggerTestMedicalDomain />
            ) : platformCategory === "API Testing" ? (
              <TriggerTestAPI apiTestValue={apiTestValue} />
            ) : platformCategory === "M&E-Devices" ? (
              <TriggertestME />
            ) : platformCategory === "Telecom-Devices" ? (
              <TriggerTestTelecom />
            ) : platformCategory === "Healthcare-Devices" ? (
              <TriggertestME />
            ) : platformCategory === "Performance Testing" ? (
              <TriggerTestPerformanceTesting
                performanceTestValue={performanceTestValue}
              />
            ) : (
              <TriggertestME />
            )}

            {platformCategory === "API Testing" ||
            platformCategory === "Web" ||
            platformCategory === "Performance Testing" ? (
              ""
            ) : (
              <div className="dev_status">
                <StatusMonitoring
                  platformCategory={
                    platformCategory.length > 1
                      ? platformCategory
                      : platform_data
                  }
                />
              </div>
            )}
          </div>

          <div className="table_data Ontable">
            <Tabledata
              platformCategory={
                platformCategory.length > 1 ? platformCategory : platform_data
              }
            />
          </div>
        </div>
      </div>
    </>
  );
}
