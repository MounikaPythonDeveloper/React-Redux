import React, { useState } from "react"
import "./SelectJiraProject.css"
import SelectJiraFunction from "./SelectJiraFunction"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { Form } from "react-bootstrap"
import { useForm } from "react-hook-form"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Select Function",
  "Update Changes",
]

const SelectJiraProject = (props) => {
  const { theme } = useTheme()
  const [modalOpenSelectFunction, setModalOpenSelectFunction] = useState(false)
  const [error, setError] = useState("")
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const submitFuction = (data) => {
    console.log("jira_project", data)
    const validationError = {}
    setError(validationError)
    sessionStorage.setItem("jira_project_key", data.project_key)
    openSelectFunctionPopup()
  }

  const openSelectFunctionPopup = () => {
    setModalOpenSelectFunction(true)
  }
  const closeSelectFunctionPopup = () => {
    setModalOpenSelectFunction(false)
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`jira-popup-box ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`license-modal-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={1} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="project-key-page-contents">
            <div className="project-key-title">
              <h3>Enter Project Key</h3>
            </div>
            <div className="project-key-field">
              <div className="col-md-5">
                <form onSubmit={handleSubmit(submitFuction)}>
                  <div
                    className={`text-fields-connect-jira ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <Form.Group>
                      <Form.Control
                        type="text"
                        placeholder="Ex:PJI"
                        autocomplete="off"
                        {...register("project_key", {
                          required: {
                            value: true,
                            message: "This field is required",
                          },
                        })}
                      />
                      {errors.project_key && (
                        <span className="error-msg">
                          {errors.project_key.message}
                        </span>
                      )}
                    </Form.Group>
                  </div>
                  <div
                    className={`project-key-submit-cancel-buttons ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <button onClick={props.handleClose} className="button-back">
                      Back
                    </button>
                    <SelectJiraFunction
                      open={modalOpenSelectFunction}
                      handleClose={closeSelectFunctionPopup}
                    />
                    <button>Submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default SelectJiraProject
