import React, { useState } from "react"
import "./SelectJiraProject.css"
import SelectJiraFunction from "./SelectJiraFunction"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { Form } from "react-bootstrap"
import { Alert, Snackbar } from "@mui/material"
import { useForm } from "react-hook-form"
import { JIRA_ATTACH_FILE_API } from "../../../../services/api"
import axios from "axios"
import UpdateChanges from "./UpdateChanges"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Attach File",
  "Update Changes",
]

const AttachFileJira = (props) => {
  const { theme } = useTheme()
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const [modalOpenSelectProject, setModalOpenSelectProject] = useState(false)
  const [filename, setFileName] = useState("")
  const [modalOpenSelectFunction, setModalOpenSelectFunction] = useState(false)
  const [modalOpenUpdateChanges, setModalOpenUpdateChanges] = useState(false)
  const [responseMessage, setResponseMessage] = useState("")
  const [error, setError] = useState("")
  const jira_credentials = JSON.parse(
    sessionStorage.getItem("jira_credentials")
  )
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const submitFuction = async (data) => {
    console.log("jira_project", data)
    const validationError = {}
    setError(validationError)
    sessionStorage.setItem("jira_project_key", data.project_key)
    const formData = new FormData()
    let filenameData = data.file[0]
    setFileName(filenameData)
    console.log("filename1", data.file[0].File)
    formData.append("file", filenameData)
    formData.append("jira_password", jira_credentials.API_token)
    formData.append("jira_username", jira_credentials.email_id)
    formData.append("issue_key", data.project_key)
    formData.append("project_name", jira_credentials.jira_URL)

    try {
      const response = await axios.post(JIRA_ATTACH_FILE_API, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      if (response.status === 200) {
        setResponseMessage(response.data)
        if (response.data == "Successfully attached file to Jira issue") {
          setResponseMessage("Successfully Attached File To Jira")
          setModalOpenUpdateChanges(true)
        } else {
          setSnackBarMessage(response.data)
          setSnackBarSeverity("error")
        }
      }
    } catch (error) {
      setSnackBarMessage("Backend Issue to Attach File")
      setSnackBarSeverity("error")
    }
  }
  const closeSelectFunctionPopup = () => {
    setModalOpenSelectFunction(false)
  }

  const openSelectJiraFunctionPopup = () => {
    setModalOpenSelectProject(true)
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`jira-popup-box ${theme === "dark" ? "dark" : "light"}`}
        >
          <Snackbar
            open={snackBarMessage}
            autoHideDuration={10000}
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            onClose={() => setSnackBarMessage("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            <Alert
              severity={snackBarSeverity}
              onClose={() => setSnackBarMessage("")}
            >
              {snackBarMessage}
            </Alert>
          </Snackbar>
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className="license-modal-close-icon"
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={2} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="project-key-page-contents">
            <div className="project-key-title">
              <h3>Attach File</h3>
            </div>
            <div className="project-key-field">
              <div className="col-md-5">
                <form onSubmit={handleSubmit(submitFuction)}>
                  <div
                    className={`text-fields-connect-jira ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <Form.Group>
                      <Form.Label>Issue Key*</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="PM-1999"
                        autocomplete="off"
                        {...register("project_key", {
                          required: {
                            value: true,
                            message: "This field is required",
                          },
                        })}
                      />
                      {errors.project_key && (
                        <span className="error-msg">
                          {errors.project_key.message}
                        </span>
                      )}
                    </Form.Group>
                  </div>
                  <div
                    className={`text-fields-connect-jira ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <Form.Group>
                      <Form.Label>Choose a File*</Form.Label>
                      <Form.Control
                        type="file"
                        autocomplete="off"
                        {...register("file", {
                          required: {
                            value: true,
                            message: "This field is required",
                          },
                        })}
                      />
                      {errors.file && (
                        <span className="error-msg">{errors.file.message}</span>
                      )}
                    </Form.Group>
                  </div>
                  <div
                    className={`project-key-submit-cancel-buttons ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <button onClick={openSelectJiraFunctionPopup}>Back</button>
                    <UpdateChanges
                      open={modalOpenUpdateChanges}
                      message={responseMessage}
                      handleClose={props.handleClose}
                    />
                    <SelectJiraFunction
                      open={modalOpenSelectProject}
                      handleClose={props.handleClose}
                    />
                    <SelectJiraFunction
                      open={modalOpenSelectFunction}
                      handleClose={closeSelectFunctionPopup}
                    />
                    <button>Submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default AttachFileJira
