import React, { useState } from "react"
import axios from "axios"
import "./ConnectToJira.css"
import SelectJiraProject from "./SelectJiraProject"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { Form } from "react-bootstrap"
import { useForm } from "react-hook-form"
import { Alert, Snackbar } from "@mui/material"
import { CONNECT_JIRA_API } from "../../../../services/api"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Select Function",
  "Update Changes",
]

const ConnectToJira = (props) => {
  const { theme } = useTheme()
  const [modalOpenSelectProject, setModalOpenSelectProject] = useState(false)
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const [error, setError] = useState("")
  const openSelectJiraProjectPopup = () => {}
  const closeSelectJiraProjectPopup = () => {
    setModalOpenSelectProject(false)
  }

  const submitFuction = async (data) => {
    const validationError = {}
    setError(validationError)
    axios
      .post(
        CONNECT_JIRA_API +
          JSON.stringify({
            api_url: `https://${data.jira_URL}.atlassian.net/rest/api/2/myself`,
            username: data.email_id,
            password: data.API_token,
          })
      )
      .then((response) => {
        console.log("connect_jira_response", response.data)
        if (response.data === true) {
          openSelectJiraProjectPopup()
          setModalOpenSelectProject(true)
        } else {
          setSnackBarMessage(response.data)
          setSnackBarSeverity("error")
        }
        sessionStorage.setItem("jira_credentials", JSON.stringify(data))
        sessionStorage.setItem(
          "jira_url",
          JSON.stringify(`https://${data.jira_URL}.atlassian.net/rest/api/2/`)
        )
      })
      .catch((error) => {
        setSnackBarMessage("Backend Issue to Connect Jira")
        setSnackBarSeverity("error")
      })
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`jira-popup-box ${theme === "dark" ? "dark" : "light"}`}
        >
          <Snackbar
            open={snackBarMessage}
            autoHideDuration={10000}
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            onClose={() => setSnackBarMessage("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            <Alert
              severity={snackBarSeverity}
              onClose={() => setSnackBarMessage("")}
            >
              {snackBarMessage}
            </Alert>
          </Snackbar>
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              {/* <pre className="pre">{JSON.stringify(props.open)}</pre> */}
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`license-modal-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={0} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="text-lines">
            <h3>Connect to Jira</h3>
            <p>Enter your Jira credentials</p>
          </div>
          <div
            className={`connecting-fields ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            <div className="connect-jira-field-title">
              <p>Project Name</p>
              <p>Email Id</p>
              <p>API Token</p>
            </div>
            <div className="col-md-6">
              <form onSubmit={handleSubmit(submitFuction)} autoComplete="off">
                <div
                  className={`text-fields-connect-jira ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  <Form.Group>
                    <Form.Control
                      type="text"
                      // autoComplete="off"
                      autocomplete="autocomplete_off_randString"
                      // placeholder="Project name"

                      // autocomplete="false"
                      {...register("jira_URL", {
                        required: {
                          value: true,
                          message: "This field is required",
                        },
                      })}
                    />
                    {errors.jira_URL && (
                      <span className="error-msg">
                        {errors.jira_URL.message}
                      </span>
                    )}
                  </Form.Group>
                  <Form.Group>
                    <Form.Control
                      // autoComplete="off"
                      autocomplete="autocomplete_off_randString"
                      type="text"
                      // autocomplete="false"
                      {...register("email_id", {
                        required: {
                          value: true,
                          message: "This field is required",
                        },
                        pattern: {
                          value: /^[a-zA-Z0-9_.+-]+@ltts\.com$/,
                          message: "Invalid Email Id",
                        },
                      })}
                    />
                    {errors.email_id && (
                      <span className="error-msg">
                        {errors.email_id.message}
                      </span>
                    )}
                  </Form.Group>
                  <Form.Group>
                    <Form.Control
                      // autoComplete="off"
                      autocomplete="autocomplete_off_randString"
                      // inputProps={{
                      //   autoComplete: "new-password",
                      // }}
                      type="password"
                      {...register("API_token", {
                        required: {
                          value: true,
                          message: "This field is required",
                        },
                      })}
                    />
                    {errors.API_token && (
                      <span className="error-msg">
                        {errors.API_token.message}
                      </span>
                    )}
                  </Form.Group>
                </div>
                <div className="connect-jira-buttons">
                  <button
                    onClick={props.handleClose}
                    className={`button-back ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Close
                  </button>
                  <SelectJiraProject
                    open={modalOpenSelectProject}
                    handleClose={closeSelectJiraProjectPopup}
                  />
                  {/* <button onClick={openSelectJiraProjectPopup}>Connect</button> */}

                  <button
                    className={`button-back ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    Connect
                  </button>
                </div>
              </form>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default ConnectToJira
