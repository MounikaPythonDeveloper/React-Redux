import React, { useEffect, useState } from "react"
import "./CreateJiraIssue.css"
import SelectJiraFunction from "./SelectJiraFunction"
import { Alert, Snackbar } from "@mui/material"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { Form } from "react-bootstrap"
import { useForm } from "react-hook-form"
import UpdateChanges from "./UpdateChanges"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"
import {
  FETCH_JIRA_ACCOUNT_ID,
  JIRA_SPRINTS_API,
  CREATE_ISSUE_JIRA_API,
} from "../../../../services/api"
import axios from "axios"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Create Issue",
  "Update Changes",
]

const CreateJiraIssue = (props) => {
  const { theme } = useTheme()
  const [snackBarMessage, setSnackBarMessage] = useState("")
  const [snackBarSeverity, setSnackBarSeverity] = useState("")
  const [modalOpenUpdateChanges, setModalOpenUpdateChanges] = useState(false)
  const [responseMessage, setResponseMessage] = useState("")
  const [modalOpenSelectProject, setModalOpenSelectProject] = useState(false)
  const [selectedFunction, setSelectedFunction] = useState(0)
  const [modalOpenCreateIssue, setModalOpenCreateIssue] = useState(false)
  const [issueType, setIssueType] = useState("")
  const [selectedIssueType, setSelectedIssueType] = useState("Story")
  const [error, setError] = useState("")
  const [assigneeName, setAssigneeName] = useState("")
  const [assigneeAccountId, setAssigneeAccountId] = useState({})
  const [storyPoints, setStoryPoints] = useState(0)
  const [storyLabels, setStoryLabels] = useState([])
  const [sprints, setSprints] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedSprint, setSelectedSprint] = useState("None")
  const [environment, setEnvironment] = useState("")
  const [component, setComponent] = useState([])
  const jiraCredentials = JSON.parse(sessionStorage.getItem("jira_credentials"))
  const projectKey = sessionStorage.getItem("jira_project_key")
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  console.log(selectedFunction, "selectedFunction")

  const openSelectJiraFunctionPopup = () => {
    setModalOpenSelectProject(true)
  }

  const fetchAccoundId = (e) => {
    const assignee = e.target.value
    setAssigneeName(e.target.value)
    axios
      .post(
        FETCH_JIRA_ACCOUNT_ID +
          `${JSON.stringify({
            username: assignee,
          })}&"attributes"+"="+["account_id"] })`
      )
      .then((response) => {
        console.log(
          "FETCH_JIRA_ACCOUNT_ID_response",
          `{"id":"${response.data[0].account_id}"}`
        )
        setAssigneeAccountId({ id: `${response.data[0].account_id}` })
      })
      .catch((error) => {
        console.log(error, "error")
        // setAssigneeAccountId(null)
        // setSnackBarMessage("Invalid Project Key")
        // setSnackBarSeverity("error")
      })
  }

  const userStoryPointsFunction = (e) => {
    const selectedStoryPionts = e.target.value
    console.log(selectedStoryPionts, "storyPionts")
    if (selectedStoryPionts !== 0) {
      setStoryPoints(selectedStoryPionts)
    }
  }

  const issueLabelFunction = (e) => {
    const labels = e.target.value
    const labelArray = labels.split(",").map((value) => value.trim())
    setStoryLabels(labelArray)
  }

  const selectIssueType = (e) => {
    console.log(e.target.value, "selectIssueType")
    setIssueType(e.target.value)
    setSelectedIssueType(e.target.value)
  }

  useEffect(() => {
    const issueSprintFunction = async () => {
      try {
        const response = await fetch(
          JIRA_SPRINTS_API + JSON.stringify({ sprint_status: "Active" })
        )
        const data = await response.json()
        setSprints(data)
      } catch (error) {
        setSnackBarMessage("Backend Issue Error In Fetching Sprints")
        setSnackBarSeverity("error")
      } finally {
        setLoading(false)
      }
    }
    issueSprintFunction()
  }, [])
  console.log(sprints, "Jira_sprints")

  const handleDropdownChange = (e) => {
    const selectedSprint = sprints.map((option) => option.sprint_id)
    setSelectedSprint(selectedSprint ? selectedSprint[0] : "None")
  }

  const issueEnvironmentFunction = (e) => {
    const environment = e.target.value
    console.log(environment, "bug_environment")
    setEnvironment(environment)
  }

  const issueComponentFunction = (e) => {
    const component = e.target.value
    const componentArray = component.split(",").map((value) => value.trim())
    setComponent(componentArray)
  }

  const createIssueSubmitFuction = async (data) => {
    const validationError = {}
    setError(validationError)
    axios
      .post(
        CREATE_ISSUE_JIRA_API +
          JSON.stringify({
            project_name: jiraCredentials.jira_URL,
            email: jiraCredentials.email_id,
            api_token: jiraCredentials.API_token,
            project_key: projectKey,
            summary: data.summary,
            description: data.description,
            labels: storyLabels,
            assignee: assigneeAccountId,
            issue_type: selectedIssueType,
            story_points: Number(storyPoints),
            sprint_id: selectedSprint,
            environment: environment,
            component: component,
          })
      )
      .then((response) => {
        if (response.data.includes("Issue ID")) {
          setResponseMessage("Successfully Created")
          setModalOpenUpdateChanges(true)
        } else {
          setSnackBarMessage(response.data)
          setSnackBarSeverity("error")
        }
      })
      .catch((error) => {
        setSnackBarMessage("Backend Issue to Create Jira Issue")
        setSnackBarSeverity("error")
      })
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`create-issue-popup-box ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          <Snackbar
            open={snackBarMessage}
            autoHideDuration={10000}
            className={`crop-alert-message ${
              theme === "dark" ? "dark" : "light"
            }`}
            onClose={() => setSnackBarMessage("")}
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
          >
            <Alert
              severity={snackBarSeverity}
              onClose={() => setSnackBarMessage("")}
            >
              {snackBarMessage}
            </Alert>
          </Snackbar>
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              {/* <pre>{JSON.stringify(assigneeAccountId)}</pre> */}
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className="license-modal-close-icon"
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={2} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="project-function-page-contents">
            <div className="create-issue-title">
              <h3>Create Issue</h3>
            </div>
            <div className="create-issue-form">
              <form onSubmit={handleSubmit(createIssueSubmitFuction)}>
                <div className="create-issue-columns">
                  <div
                    className={`create-issue-col1 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Assignee</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Assignee name"
                          autocomplete="off"
                          onChange={fetchAccoundId}
                        />
                        {assigneeAccountId === null &&
                        assigneeName.length > 0 ? (
                          <p className="error-msg">Invalid Assignee</p>
                        ) : (
                          ""
                        )}
                        {/* {errors.assignee &&(<span className="error-msg">{errors.assignee.message}</span>)} */}
                      </Form.Group>
                    </div>
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Summary*</Form.Label>
                        <Form.Control
                          type="text"
                          // placeholder="account Id"
                          autocomplete="off"
                          {...register("summary", {
                            required: {
                              value: true,
                              message: "This field is required",
                            },
                          })}
                        />
                        {errors.summary && (
                          <span className="error-msg">
                            {errors.summary.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Description*</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          {...register("description", {
                            required: {
                              value: true,
                              message: "This field is required",
                            },
                          })}
                        />
                        {errors.description && (
                          <span className="error-msg">
                            {errors.description.message}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Story point estimate</Form.Label>
                        <Form.Control
                          type="number"
                          min="0"
                          max="8"
                          step="1"
                          id="amountInput"
                          autocomplete="off"
                          onChange={userStoryPointsFunction}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Labels</Form.Label>
                        <Form.Control
                          type="text"
                          autocomplete="off"
                          value={storyLabels.join(",")}
                          onChange={issueLabelFunction}
                        />
                      </Form.Group>
                    </div>
                  </div>
                  <div
                    className={`create-issue-col2 ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Sprint</Form.Label>
                        <Form.Select
                          onChange={handleDropdownChange}
                          value={selectedSprint || "None"}
                        >
                          <option>Select Sprint</option>
                          {loading ? (
                            <option>Loading...</option>
                          ) : (
                            sprints.map((option) => (
                              <option
                                key={option.sprint_name}
                                value={option.sprint_id}
                              >
                                {option.sprint_name}
                              </option>
                            ))
                          )}
                        </Form.Select>
                      </Form.Group>
                    </div>
                    <div className="col-md-10">
                      <Form.Group>
                        <Form.Label>Issue type*</Form.Label>
                        <Form.Select onChange={selectIssueType}>
                          <option>Story</option>
                          <option>Task</option>
                          <option>Bug</option>
                          <option>Epic</option>
                        </Form.Select>
                      </Form.Group>
                    </div>
                    {selectedIssueType === "Bug" && (
                      <div className="col-md-10">
                        <Form.Group>
                          <Form.Label>Environment*</Form.Label>
                          <Form.Control
                            type="text"
                            autocomplete="off"
                            {...register("environmemt", {
                              required: {
                                value: true,
                                message: "This field is required",
                              },
                            })}
                            onChange={issueEnvironmentFunction}
                          />
                          {errors.environmemt && (
                            <span className="error-msg">
                              {errors.environmemt.message}
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                    {selectedIssueType === "Bug" && (
                      <div className="col-md-10">
                        <Form.Group>
                          <Form.Label>Component*</Form.Label>
                          <Form.Control
                            type="text"
                            autocomplete="off"
                            {...register("component", {
                              required: {
                                value: true,
                                message: "This field is required",
                              },
                            })}
                            onChange={issueComponentFunction}
                          />
                          {errors.component && (
                            <span className="error-msg">
                              {errors.component.message}
                            </span>
                          )}
                        </Form.Group>
                      </div>
                    )}
                  </div>
                </div>
                <div
                  className={`create-isuue-submit-buttons ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                >
                  <button onClick={openSelectJiraFunctionPopup}>Back</button>
                  <SelectJiraFunction
                    open={modalOpenSelectProject}
                    handleClose={props.handleClose}
                  />
                  <UpdateChanges
                    open={modalOpenUpdateChanges}
                    message={responseMessage}
                    handleClose={props.handleClose}
                  />
                  <CreateJiraIssue
                    open={modalOpenCreateIssue}
                    handleClose={props.handleClose}
                  />
                  <button>Submit</button>
                </div>
              </form>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default CreateJiraIssue
