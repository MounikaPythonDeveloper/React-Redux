import React, { useState } from "react"
import "./SelectJiraFunction.css"
import SelectJiraProject from "./SelectJiraProject"
import CreateJiraIssue from "./CreateJiraIssue"
import UpdateJiraIssue from "./UpdateJiraIssue"
import AttachFileJira from "./AttachFileJira"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { useForm } from "react-hook-form"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Select Function",
  "Update Changes",
]

const SelectJiraFunction = (props) => {
  const { theme } = useTheme()
  const [modalOpenSelectProject, setModalOpenSelectProject] = useState(false)
  const [selectedFunction, setSelectedFunction] = useState(0)
  const [modalOpenCreateIssue, setModalOpenCreateIssue] = useState(false)
  const [modalOpenUpdateIssue, setModalOpenUpdateIssue] = useState(false)
  const [modalOpenAttachFile, setModalOpenAttachFile] = useState(false)

  const {
    formState: { errors },
  } = useForm()

  const handleFunction = (e) => {
    setSelectedFunction(e.target.value)
  }

  const openSelectJiraProjectPopup = () => {
    setModalOpenSelectProject(true)
  }

  const openFunctionPopup = () => {
    if (selectedFunction === "Create Issue") {
      setModalOpenCreateIssue(true)
    } else if (selectedFunction === "Update Issue") {
      setModalOpenUpdateIssue(true)
    } else if (selectedFunction === "Attach File") {
      setModalOpenAttachFile(true)
    }
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`jira-popup-box ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`license-modal-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={2} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="project-function-page-contents">
            <div className="project-key-title">
              <h3>Select Function</h3>
            </div>
            <div className="select-function-fields">
              <div className="select-function-buttons-group">
                <button
                  className={`select-function-buttons ${
                    selectedFunction === "Create Issue" ? "active" : ""
                  } ${theme === "dark" ? "dark" : "light"}`}
                  onClick={handleFunction}
                  value="Create Issue"
                >
                  Create Issue
                </button>
                <button
                  className={`select-function-buttons ${
                    selectedFunction === "Update Issue" ? "active" : ""
                  } ${theme === "dark" ? "dark" : "light"}`}
                  onClick={handleFunction}
                  value="Update Issue"
                >
                  Update Issue
                </button>
                <button
                  className={`select-function-buttons ${
                    selectedFunction === "Attach File" ? "active" : ""
                  } ${theme === "dark" ? "dark" : "light"}`}
                  onClick={handleFunction}
                  value="Attach File"
                >
                  Attach File
                </button>
              </div>
              <div
                className={`select-function-submit-buttons  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <button onClick={openSelectJiraProjectPopup}>Back</button>
                <SelectJiraProject
                  open={modalOpenSelectProject}
                  handleClose={props.handleClose}
                />
                <CreateJiraIssue
                  open={modalOpenCreateIssue}
                  handleClose={props.handleClose}
                />
                <UpdateJiraIssue
                  open={modalOpenUpdateIssue}
                  handleClose={props.handleClose}
                />
                <AttachFileJira
                  open={modalOpenAttachFile}
                  handleClose={props.handleClose}
                />
                <button onClick={openFunctionPopup}>Submit</button>
              </div>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default SelectJiraFunction
