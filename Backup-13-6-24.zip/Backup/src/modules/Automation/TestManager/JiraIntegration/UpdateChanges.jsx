import React, { useState } from "react"
import "./SelectJiraFunction.css"
import SelectJiraFunction from "./SelectJiraFunction"
import CreateJiraIssue from "./CreateJiraIssue"
import UpdateJiraIssue from "./UpdateJiraIssue"
import AttachFileJira from "./AttachFileJira"
import Box from "@mui/material/Box"
import Modal from "@mui/material/Modal"
import EvQuallogo from "../../../../assets/images/EvQuallogo.svg"
import JiraLogo from "../../../../assets/images/JiraLogo.svg"
import IconButton from "@mui/material/IconButton"
import CloseIcon from "@mui/icons-material/Close"
import Stepper from "@mui/material/Stepper"
import Step from "@mui/material/Step"
import StepLabel from "@mui/material/StepLabel"
import { useForm } from "react-hook-form"
import doneIcon from "../../../../assets/images/done-icon.png"
import { useTheme } from "../../../../components/ThemeToggle/ThemeContext"

const steps = [
  "Connect to Jira",
  "Select a Jira Project",
  "Select Function",
  "Update Changes",
]

const UpdateChanges = (props) => {
  const { theme } = useTheme()
  const [modalOpenSelectProject, setModalOpenSelectProject] = useState(false)
  const [selectedFunction, setSelectedFunction] = useState(0)
  const [modalOpenCreateIssue, setModalOpenCreateIssue] = useState(false)
  const [modalOpenUpdateIssue, setModalOpenUpdateIssue] = useState(false)
  const [modalOpenAttachFile, setModalOpenAttachFile] = useState(false)
  const {
    formState: { errors },
  } = useForm()
  const openSelectJiraFunctionPopup = () => {
    setModalOpenSelectProject(true)
  }

  return (
    <div>
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          className={`jira-popup-box ${theme === "dark" ? "dark" : "light"}`}
        >
          <div className="evqual-jira-logo">
            <div
              className={`evqual-jira-EvQuallogo ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img src={EvQuallogo} alt="" />
            </div>
            <div>
              <img className="jira-logo-properties" src={JiraLogo} alt="" />
            </div>
            <div>
              <IconButton
                className="license-modal-icon"
                aria-label="close"
                color="inherit"
                size="small"
                onClick={props.handleClose}
              >
                <CloseIcon
                  fontSize="inherit"
                  className={`license-modal-close-icon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  style={{ top: "2%" }}
                />
              </IconButton>
            </div>
          </div>
          <div
            className={`page-steppers ${theme === "dark" ? "dark" : "light"}`}
          >
            <Stepper activeStep={3} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </div>
          <div className="project-function-page-contents">
            <div className="project-key-title">
              <img
                alt="Done Icon"
                src={doneIcon}
                width="50"
                height="50"
                style={{ marginTop: "10px" }}
              ></img>
              <h6 style={{ paddingTop: "10px" }}>{props.message}</h6>
            </div>
            <div></div>
            <div className="select-function-fields">
              <div
                className={`select-function-submit-buttons ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                <button onClick={openSelectJiraFunctionPopup}>Back</button>
                <SelectJiraFunction
                  open={modalOpenSelectProject}
                  handleClose={props.handleClose}
                />
                <CreateJiraIssue
                  open={modalOpenCreateIssue}
                  handleClose={props.handleClose}
                />
                <UpdateJiraIssue
                  open={modalOpenUpdateIssue}
                  handleClose={props.handleClose}
                />
                <AttachFileJira
                  open={modalOpenAttachFile}
                  handleClose={props.handleClose}
                />
              </div>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  )
}

export default UpdateChanges
