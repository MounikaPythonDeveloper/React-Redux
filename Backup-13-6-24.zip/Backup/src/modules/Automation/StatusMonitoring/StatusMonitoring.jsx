import React, { useEffect, useState, useRef } from "react"
import { useNavigate } from "react-router-dom"
import axios from "axios"
import { tooltipClasses } from "@mui/material/Tooltip"
import "./StatusMonitoring.css"
import SearchIcon from "../../../assets/images/Search.svg"
import ReserveIcon from "../../../assets/images/Reserve.svg"
import ViewData from "../../../assets/images/ViewProfile.svg"
import GetDeviceView from "../../../components/DeviceView/DeviceViewAutomationLiveKit.jsx"
import GetCalendar from "../../../components/StatusCalender/StatusCalendar.jsx"
import Modal from "react-bootstrap/Modal"
import { Tooltip } from "@mui/material"
import {
  Button,
  FormControl,
  IconButton,
  Input,
  InputAdornment,
  InputLabel,
} from "@mui/material"
import {
  TESTMANAGER_API,
  TESTMANAGER_SEARCH_API,
  EXIST_FROM_LIVEKITROOM,
  VALIDATE_BUYLICENSE_STATUS,
} from "../../../services/api.js"
import DeviceRack from "./DeviceRack.jsx"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext.jsx"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))

const Devicemonitor = (platformCategory) => {
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  // const SearchInput=theme==="dark">Input:LightInput
  console.log(platformCategory.platformCategory, "Platform category")
  const otherData = {
    "M&E-Devices": ["STB", "Smart TV", "OTT", "iOS", "Android", "Gaming","iOS Tab",
      "Android Tab",],
    "Select M&E Categories": [
      "STB",
      "Smart TV",
      "OTT",
      "iOS",
      "Android",
      "Gaming",
      "iOS Tab",
      "Android Tab",
    ],
    "Media And Entertainment": [
      "STB",
      "Smart TV",
      "OTT",
      "iOS",
      "Android",
      "Gaming",
      "iOS Tab",
      "Android Tab",
    ],
    "Telecom-Devices": ["Router"],
    "Select Telecom Devices": ["Router"],
    Telecom: ["Router"],
    "Healthcare-Devices": ["iOS", "Android"],
    "Select Healthcare Devices": ["iOS", "Android"],
    Healthcare: ["iOS", "Android"],
    "IndustrialProducts-Devices": ["Embedded"],
    "Select IndustrialProducts Devices": ["Embedded"],
    IndustrialProducts: ["Embedded"],
    "Transportation - Devices": ["IVI", "ECU"],
    Transportation: ["IVI", "ECU"],
    "Select Transportation Devices": ["IVI", "ECU"],
  }
  const platformCategoryName = platformCategory.platformCategory
  const navigate = useNavigate()

  const [Presentdevice, setPresentdevice] = useState()
  const [deviceconfrimreserve, setDeviceconfrimreserve] = useState()
  const [Popups, setPopups] = useState(false)
  const [devicerack, setDeviceRack] = useState([])
  const [isOpen, setIsOpen] = useState(false)
  const [selectedDevices, setSelectedDevices] = useState([])
  const [deviceViewPresent, setDeviceViewPresent] = useState()
  const [isChecked, setIsChecked] = useState(false)
  const [deviceViewPopups, setDeviceViewPopups] = useState(false)
  const platform = JSON.parse(sessionStorage.getItem("platform"))
  const [searchAutoValue, SetSearchAutoValue] = useState("")
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [Status, setStatus] = useState("")
  const togglePopup = () => {
    setIsOpen(!isOpen)
  }
  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }
  useEffect(() => {
    ValidateLicensestatus()
  })
   useEffect(() => {
    const interval = setInterval(() => {
      devicestatus_api();
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const devicestatus_api = () => {
    axios
      .get(
        TESTMANAGER_API +
          `${JSON.stringify({
            platform: [platform],
            device_category: otherData.hasOwnProperty(platformCategoryName)
              ? otherData[platformCategoryName]
              : [platformCategoryName],
            device_status: ["Locked", "Unlocked"],
          })}`
      )
      .then((res) => {
        const result = res.data
        const sortedDevices = result.sort((a, b) =>
          a.device_status === "Locked" ? -1 : 1
        )
        setDeviceRack(sortedDevices)
        console.log("M&E devices", res.data)
      })
      .catch((er) => console.log(er))
  }

  useEffect(() => {
    if (searchAutoValue.length === 0) {
      devicestatus_api()
    }
  }, [searchAutoValue, platformCategory])

  //seraching devices

  const searchAutoApi = async (searchAutoTerm) => {
    console.log("searchAutoTerm", searchAutoTerm)
    await axios
      .get(
        `${TESTMANAGER_SEARCH_API}search=${searchAutoTerm}&platform=${platform}`
      )
      .then((response) => {
        setDeviceRack(response.data)
        console.log(response, "auto search")
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const enterkeyAPIHandler = (event) => {
    const trim_string = event.target.value.trim()
    SetSearchAutoValue(trim_string)
    console.log("SearchAutoValue", searchAutoValue)
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      event.preventDefault()
      searchAutoApi(searchAutoValue)
    }
  }

  const removeuserfromlivekitroom = async () => {
    let url_device = ""

    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: selectedDevices.map((item) => item.device_name),
    })}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const handlepopupclose = () => {
    removeuserfromlivekitroom(selectedDevices.map((item) => item.device_name))
    setPopups(false)
    setSelectedDevices([])
  }

  const handlepopupcloseDeviceView = () => {
    removeuserfromlivekitroom(selectedDevices.map((item) => item.device_name))
    setSelectedDevices([])
    setDeviceViewPopups(false)
  }

  const renderedItems = []
  selectedDevices.map((item, index) => {
    renderedItems.push(item.device_name)
    return null
  })

  const reservebutton = (val, status) => {
    console.log(renderedItems, "www1")
    const unique_items = renderedItems.filter(
      (item, index) =>
        renderedItems.indexOf(item) === index && renderedItems !== undefined
    )
    setPopups(true)
    setPresentdevice(unique_items)
    setIsChecked(false)
  }

  const deviceButton = (val, status) => {
    const unique = [
      ...new Map(
        selectedDevices.map((item) => [item["device_name"], item])
      ).values(),
    ]
    setDeviceViewPresent(unique)
    setIsChecked(false)
    setDeviceViewPopups(true)
  }
  const Remotetoast = (msg) => {
    setDeviceconfrimreserve(msg)
  }

  const handleReset = (msg) => {
    setSelectedDevices([])
  }

  const deviceHanlder = (e) => {
    console.log(e, "countc1", selectedDevices, "count")
    const { checked, name } = e.target
    let total_devices = selectedDevices
    if (!checked) {
      total_devices = selectedDevices.filter((val) => val !== name)
    } else {
      total_devices = [...selectedDevices, name]
    }
    setSelectedDevices(total_devices)
    console.log(e, "countc2", selectedDevices, "count3")
  }

  const MultipleViewHandler = () => {
    setIsChecked(!isChecked)
  }

  return (
    <React.Fragment>
      <div class="status-monitor-container">
        <div className="span_rackstitle">
          <div
            className={`status-filter-block1 ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            <FormControl
              className={`search-field-status-monitor ${
                theme === "dark" ? "dark" : "light"
              }`}
              variant="standard"
              color="secondary"
            >
              {/* <InputLabel htmlFor="search-devices" style={{ color: "white" }}>
                Search
              </InputLabel> */}
              <Input
                autoComplete="off"
                id="search-devices"
                type="text"
                onKeyUp={enterkeyAPIHandler}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton>
                      <img
                        className="search-icon"
                        alt="SearchIcon"
                        src={SearchIcon}
                        title="SearchIcon"
                        onClick={() => searchAutoApi(searchAutoValue)}
                      />
                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl>

            <IconButton
              className={`reserve-button ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              {Status !== "Active" ? (
                <TooltipComponent
                  title={<td>License {Status}</td>}
                  className="tooltip-display"
                >
                  <img
                    className="reserve-icon"
                    alt="ReserveIcon"
                    src={ReserveIcon}
                    title="ReserveIcon"
                    style={{ cursor: "not-allowed", opacity: "0.5" }}
                  />
                </TooltipComponent>
              ) : Status === "Active" ? (
                <img
                  className="reserve-icon"
                  alt="ReserveIcon"
                  src={ReserveIcon}
                  title="ReserveIcon"
                  onClick={
                    selectedDevices.length <= 0
                      ? () => {
                          MultipleViewHandler()
                        }
                      : reservebutton
                  }
                />
              ) : (
                <div></div>
              )}
            </IconButton>
            <IconButton
              className={`reserve-button ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              {Status !== "Active" ? (
                <TooltipComponent
                  title={<td>License {Status}</td>}
                  className="tooltip-display"
                >
                  <img
                    className="view-icon"
                    title="viewIcon"
                    alt="viewData"
                    src={ViewData}
                    style={{ cursor: "not-allowed", opacity: "0.5" }}
                  />
                </TooltipComponent>
              ) : Status === "Active" ? (
                <img
                  className="view-icon"
                  title="viewIcon"
                  alt="viewData"
                  src={ViewData}
                  onClick={
                    selectedDevices.length <= 0
                      ? () => {
                          MultipleViewHandler()
                        }
                      : deviceButton
                  }
                />
              ) : (
                <div></div>
              )}
            </IconButton>
          </div>

          <span>
            <Modal show={isOpen} onHide={togglePopup} centered>
              <Modal.Header closeButton></Modal.Header>
              <Modal.Body>Please Select a Device</Modal.Body>
              <Modal.Footer>
                <Button variant="primary" onClick={togglePopup}>
                  {" "}
                  Ok{" "}
                </Button>
              </Modal.Footer>
            </Modal>
          </span>
        </div>
        <div className="racks-main">
          {devicerack.length > 0 &&
            devicerack.map((data) => {
              return (
                <div className="abc">
                  <div className="racks">
                    <DeviceRack
                      data={data}
                      onChange={deviceHanlder}
                      values={selectedDevices}
                      chekboxvalue={isChecked}
                    />
                  </div>
                </div>
              )
            })}
        </div>

        {Popups && (
          <div>
            <div className="remote_content">
              <GetCalendar
                device={renderedItems}
                Popups={Popups}
                Remotetoast={Remotetoast}
                resetDevice={handleReset}
                handleClose={handlepopupclose}
              />
            </div>
          </div>
        )}
        {deviceViewPopups && (
          <GetDeviceView
            devicesauto={deviceViewPresent}
            handleCloseButton={handlepopupcloseDeviceView}
          />
        )}
      </div>
    </React.Fragment>
  )
}
export default Devicemonitor
