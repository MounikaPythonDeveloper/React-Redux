import React, { useState, useEffect } from "react"
import "./StatusMonitoring.css"
import LockIcon from "../../../assets/images/Lock.svg"
import UnlockIcon from "../../../assets/images/Unlock.svg"
import OfflineIcon from "../../../assets/images/Offline.svg"
import ViewData from "../../../assets/images/ViewProfile.svg"
import ReserveIcon from "../../../assets/images/Reserve.svg"
import { Alert, Checkbox, Tooltip } from "@mui/material"
import GetDeviceView from "../../../components/DeviceView/DeviceViewAutomationLiveKit"
import axios from "axios"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import { tooltipClasses } from "@mui/material/Tooltip"
import {
  EXIST_FROM_LIVEKITROOM,
  VALIDATE_BUYLICENSE_STATUS,
} from "../../../services/api"
import { useNavigate, useLocation } from "react-router-dom"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))
export default function DeviceRack({
  name,
  data = {},
  onChange,
  values = [],
  chekboxvalue,
}) {
  const navigate = useNavigate()
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  const [showCheckbox, setShowCheckbox] = useState(false)
  const [alertBoxEnable, setAlertBoxEnable] = useState(false)
  const [deviceViewPopup, setDeviceViewPopup] = useState(false)
  const [Status, setStatus] = useState("")
  const [itemContent, setItemContent] = useState([])
  const [checkDevices, setCheckDevices] = useState([])
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const room_name = JSON.parse(localStorage.getItem("room_name"))
  const location = useLocation()
  const isOnAutomationPage = location.pathname === "/platform/automation"
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))

  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }
  useEffect(() => {
    ValidateLicensestatus()
  })

  useEffect(() => {
    localStorage.getItem("room_name", JSON.stringify(room_name))
  })
  const clickImage = () => {
    setShowCheckbox(!showCheckbox)
  }

  const devicestatusicon = (status, LockedBy) => {
    switch (status) {
      case "Unlocked":
        return (
          <img className="status-icon" alt="UnlockedIcon" src={UnlockIcon} />
        )
      case "Locked":
        return (
          <Tooltip title={`Locked by ${LockedBy}`} className="tooltip-display">
            <div className="status-icon-container">
              <img className="status-icon" alt="LockIcon" src={LockIcon} />
            </div>
          </Tooltip>
        )
      case "Out of Network":
        return (
          <Tooltip title={"Device Out of Network"} className="tooltip-display">
            <img className="status-icon" alt="OutOfNetwork" src={OfflineIcon} />
          </Tooltip>
        )

      default:
        return (
          <img className="status-icon" alt="OutOfNetwork" src={OfflineIcon} />
        )
    }
  }

  const removeuserfromlivekitroom = async (room_name) => {
    let url_device = ""
    url_device = `${EXIST_FROM_LIVEKITROOM}${JSON.stringify({
      username: userProfile.username,
      room_name: room_name,
    })}`
    await axios
      .post(url_device)
      .then((response) => {
        console.log("removed", response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  const handleMultipleDevice = (event, item) => {
    if (event.target.checked === true) {
      setCheckDevices([...checkDevices, item])
      values.push(item)
    } else {
      values.pop(values.filter((val) => val !== item))
      setCheckDevices(checkDevices.filter((value) => value !== item))
    }
  }
  values.map((chad) => {
    if (chad === "") {
      values.pop(values.filter((val) => val !== chad))
    }
  })

  const reverseDevice = (e) => {
    console.log("cooldevice1", e)
    if (isOnAutomationPage) {
      navigate("/platform/automation/bigCalendar", {
        state: { DeviceData: [e] },
      })
    } else if (platform_data === "Media And Entertainment") {
      navigate("/platform/M&E/automation/bigCalendar", {
        state: { DeviceData: [e] },
      })
    } else {
      navigate("/platform/" + platform_data + "/automation/bigCalendar", {
        state: { DeviceData: [e] },
      })
    }
  }

  const getDeviceView = (e) => {
    console.log(e, "getDeviceview")
    setDeviceViewPopup(true)
    setItemContent(e)
  }

  const handlepopupcloseDeviceView = () => {
    removeuserfromlivekitroom(room_name)
    setDeviceViewPopup(false)
    setItemContent([])
  }

  const handleDragStart = (e) => {
    e.preventDefault()
  }

  const onClickOON = () => {
    setAlertBoxEnable(true)
  }

  if (alertBoxEnable) {
    setTimeout(() => {
      handleAlertClose()
    }, 2000)
  }

  const handleAlertClose = () => {
    setAlertBoxEnable(false)
  }

  return (
    <div className={`racks  ${theme === "dark" ? "dark" : "light"}`}>
      <div className="status-list1">
        {alertBoxEnable && (
          <Alert
            severity="success"
            variant="filled"
            onClose={handleAlertClose}
            icon={false}
            className="alertBox1"
          >
            Device Out of Network
          </Alert>
        )}
        <TooltipComponent
          classes={{}}
          title={
            <div>
              <table>
                <tr>
                  <td>Device Category</td>
                  <td>:</td>
                  <td>{data.device_category}</td>
                </tr>
                <tr>
                  <td>Device Name</td>
                  <td>:</td>
                  <td>{data.device_name}</td>
                </tr>

                <tr>
                  <td>Model Name</td>
                  <td>:</td>
                  <td>{data.model_name}</td>
                </tr>
                <tr>
                  <td>OS Name</td>
                  <td>:</td>
                  <td>{data.os_name}</td>
                </tr>
                <tr>
                  <td>Serial Number</td>
                  <td>:</td>
                  <td>{data.serial_number}</td>
                </tr>
                <tr>
                  <td>IP Address</td>
                  <td>:</td>
                  <td>{data.ip_address}</td>
                </tr>
                <tr>
                  <td>Lab Name</td>
                  <td>:</td>
                  <td>{data.lab_name}</td>
                </tr>
                <tr>
                  <td>Manufacturer</td>
                  <td>:</td>
                  <td>{data.manufacturer === "-" ? "-" : data.manufacturer}</td>
                </tr>
                <tr>
                  <td>Master ID</td>
                  <td>:</td>
                  <td>{data.master_id}</td>
                </tr>
              </table>
            </div>
          }
          placement="left"
        >
          <li key={data.device_name}>
            <div
              className={
                data.reservation_status === true
                  ? "disableddevices"
                  : "racks_align"
              }
            >
              {chekboxvalue && (
                <div className="checkbox_enabled">
                  <Checkbox
                    value={data}
                    disabled={data?.device_status === "Out of Network"}
                    onChange={(event) => handleMultipleDevice(event, data)}
                    className="mr-2"
                  />
                </div>
              )}
            </div>

            <img
              src={data.status_icon_path}
              className="mobile-icon"
              style={{ width: "40px", height: "45px" }}
              onClick={clickImage}
              alt={data.device_name}
              onDragStart={handleDragStart}
            />

            <div className="racks-label">
              <label>{data.device_name} </label>
            </div>

            <div
              className={`status-list-right-col ${
                Status !== "Active" ? "disabled" : ""
              }`}
              style={{
                opacity: Status === "Active" ? 1 : 0.5,
                cursor: Status === "Active" ? "auto" : "not-allowed",
              }}
            >
              {Status !== "Active" ? (
                <Tooltip
                  title={<td>License {Status}</td>}
                  className="tooltip-display"
                >
                  <img
                    className="view-icon"
                    alt="viewCalendar"
                    src={ReserveIcon}
                    title="viewIcon"
                  />
                </Tooltip>
              ) : Status === "Active" ? (
                <img
                  className="view-icon"
                  alt="viewCalendar"
                  src={ReserveIcon}
                  title="viewIcon"
                  onClick={() => reverseDevice(data)}
                />
              ) : (
                <div></div>
              )}

              {Status !== "Active" ? (
                <Tooltip
                  title={<td>License {Status}</td>}
                  className="tooltip-display"
                >
                  <img
                    className="view-icon"
                    alt="viewData"
                    title="viewIcon"
                    src={ViewData}
                  />
                </Tooltip>
              ) : Status === "Active" ? (
                <img
                  className="view-icon"
                  alt="viewData"
                  title="viewIcon"
                  src={ViewData}
                  onClick={() =>
                    data?.device_status === "Out of Network"
                      ? onClickOON()
                      : getDeviceView(data)
                  }
                />
              ) : (
                <div></div>
              )}
              {devicestatusicon(data.device_status, data.locked_by)}
            </div>
          </li>
        </TooltipComponent>
      </div>

      {deviceViewPopup && (
        <GetDeviceView
          devicesauto={[itemContent]}
          handleCloseButton={handlepopupcloseDeviceView}
        />
      )}
    </div>
  )
}
