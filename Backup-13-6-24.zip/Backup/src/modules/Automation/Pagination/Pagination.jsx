import React from "react"
import "../Pagination/Pagination.css"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"

const Pagination = ({ postsPerPage, totalPosts, currentPage, paginate }) => {
  const pageNumbers = []

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i)
  }
  console.log(pageNumbers)

  const renderPageNumbers = () => {
    const isMobile = window.innerWidth < 768 // Example breakpoint for mobile screen
    const firstPageNumbers = pageNumbers.slice(0, 5)
    const lastPageNumbers = pageNumbers.slice(-5)

    const ellipsis = (
      <li key="ellipsis" className="ellipsis">
        ...
      </li>
    )
    if (pageNumbers.length <= 10) {
      // Display all page numbers if there are 10 or fewer pages
      return pageNumbers.map((number) => (
        <li
          key={number}
          className={`num ${currentPage === number ? "active" : ""}`}
          onClick={() => paginate(number)}
        >
          {number}
        </li>
      ))
    } else {
      if (currentPage <= 5) {
        // Display first 5 pages, ellipsis, and last 5 pages
        return [
          ...firstPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
          ellipsis,
          ...lastPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
        ]
      } else if (currentPage >= pageNumbers.length - 4) {
        // Display first 5 pages, ellipsis, and last 5 pages
        return [
          ...firstPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
          ellipsis,
          ...lastPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
        ]
      } else {
        // Display first 5 pages, ellipsis before current, current page, ellipsis after current, last 5 pages
        return [
          ...firstPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
          ellipsis,
          <li
            key={currentPage}
            className={`num ${currentPage === currentPage ? "active" : ""}`}
            onClick={() => paginate(currentPage)}
          >
            {currentPage}
          </li>,
          ellipsis,
          ...lastPageNumbers.map((number) => (
            <li
              key={number}
              className={`num ${currentPage === number ? "active" : ""}`}
              onClick={() => paginate(number)}
            >
              {number}
            </li>
          )),
        ]
      }
    }
  }
  const { theme } = useTheme()

  return (
    <div className={`pagination ${theme === "dark" ? "dark" : "light"}`}>
      <ul class="pagination flex-wrap ml-7">
        <li
          className={`${currentPage === 1 && "disabled"}`}
          onClick={() => {
            if (currentPage > 1) {
              paginate(currentPage - 1)
            }
          }}
        >
          Prev
        </li>
        {renderPageNumbers()}
        <li
          className={`${currentPage === pageNumbers.length && "disabled"}`}
          onClick={() => {
            if (currentPage < pageNumbers.length) {
              paginate(currentPage + 1)
            }
          }}
        >
          Next
        </li>
      </ul>
    </div>
  )
}

export default Pagination
