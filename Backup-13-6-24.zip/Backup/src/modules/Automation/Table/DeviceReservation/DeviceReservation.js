import React, { useEffect, useRef, useState } from "react"
import "react-toastify/dist/ReactToastify.css"
import DatePicker from "react-datepicker"
import "./DeviceReservation.css"
import Button from "react-bootstrap/Button"
import Modal from "react-bootstrap/Modal"

import axios from "axios"
import { DEVICES_API, DEVICE_RESERVATION_API } from "../API/apis"
const DeviceReservation = ({
  device = null,
  Popups,
  Remotetoast,
  toggletab,
  reservationcategory,
}) => {
  const [startDate, setStartDate] = useState(new Date())
  const filterPassedTime = (time) => {
    const currentDate = new Date()
    const selectedDate = new Date(time)
    return currentDate.getTime() < selectedDate.getTime()
  }
  const [endDate, setEndDate] = useState(null)
  console.log("startdate", endDate)
  const maxDate = new Date(startDate)
  maxDate.setDate(maxDate.getDate() + 14)
  const ref = useRef(null)
  const [customreserve, setCustomReservation] = useState("False")
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [toggleDropdown, setToggleDropdown] = useState(0)
  const [devicesData, setDeviceData] = useState([])
  const [checkdevices, setCheckDevices] = useState([])
  const [selectAllDevice, setSelectAllDevice] = useState(false)
  const deviceRef = useRef(null)
  const [startvalue, setStartValue] = useState("")
  const [endvalue, setEndValue] = useState("")
  const [customselect, setCustomSelect] = useState("")
  const [reserveMessage, setReserveMessage] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [adhocChecked, setAdhocChecked] = React.useState(false)

  const togglePopup = () => {
    setIsOpen(!isOpen)
  }

  //Adhoc Reservation
  const handleChange = (e) => {
    setAdhocChecked(!adhocChecked)
    if (e.target.checked) {
      const adhoc = new Date(startDate)
      adhoc.setHours(adhoc.getHours() + 4)
      setEndDate(adhoc)
    } else {
      setEndDate(null)
    }
  }

  useEffect(() => {
    if (device == null) {
      const id = setInterval(() => {
        devices_api() // <-- (3) invoke in interval callback
      }, 5000)
      devices_api()

      return () => clearInterval(id)
    }
  }, [])

  const devices_api = () => {
    axios
      .get(DEVICES_API)
      .then((res) => {
        console.log("devicesdata", res.data)
        setDeviceData(res.data[0].device_name)
      })
      .catch((er) => console.log(er))
  }
  const setCustomReserve = (e) => {
    if (ref.current.checked) {
      setCustomReservation("True")
    } else {
      setCustomReservation("False")
    }
  }

  let handleCheckboxChange = (event) => {
    const { value, checked } = event.target
    setCheckDevices([...checkdevices, value])
    !checked && setCheckDevices(checkdevices.filter((val) => val !== value))
  }

  const deviceSelectAllHandler = (e) => {
    setSelectAllDevice(e.target.checked)
    if (e.target.checked === true) {
      setCheckDevices(devicesData)
    } else {
      setCheckDevices([])
    }
  }
  console.log(checkdevices, "device")

  const sendData = () => {
    console.log(startvalue, endvalue, "checkstart")

    console.log(startDate, endDate, "dates")

    const adhoc = new Date(startDate)

    console.log(adhoc, "san")
    var requestString = {
      device_name: device === null ? checkdevices : device,
      reservation_start_time: startDate,
      reservation_end_time: endDate,
      reserved_by: userProfile.username,
      reservation_duration: customselect,
      category_reservation: reservationcategory,
    }
    console.log("manual", requestString)

    axios
      .post(DEVICE_RESERVATION_API + `${JSON.stringify(requestString)}`)
      .then((response) => {
        console.log(response.data.Message, "success")

        setReserveMessage(response.data.Message)
        togglePopup()
      })
      .catch((error) => {
        console.log(error, "error")
      })

    setCheckDevices([])
  }

  return (
    <React.Fragment>
      <div className="trigger_page">
        <h1 className="device_font">Device Reservation</h1>
        <div className="selected_inputs">
          {device == null ? (
            <div className="input_feilds">
              <label>Devices</label>
              <div className="device-filter-dropdown">
                <div
                  className="dropdown-toggle"
                  onClick={() =>
                    setToggleDropdown((prevState) => (prevState === 1 ? 0 : 1))
                  }
                >
                  <span title={checkdevices.join(",")}>
                    {checkdevices.length > 0
                      ? checkdevices.join(", ")
                      : "Dropdown to select device"}
                  </span>
                </div>
                {toggleDropdown === 1 && (
                  <div className="filter-dropdown-menu">
                    {devicesData ? (
                      <ul>
                        <li>
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              value="All"
                              id="All"
                              onChange={deviceSelectAllHandler}
                              type="checkbox"
                              checked={selectAllDevice}
                            />
                            <label className="form-check-label" htmlFor="All">
                              Select All
                            </label>
                          </div>
                        </li>
                        {devicesData.map((item, index) => {
                          return (
                            <li key={index}>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  value={item}
                                  id={item}
                                  onChange={handleCheckboxChange}
                                  type="checkbox"
                                  checked={checkdevices.includes(item)}
                                  ref={deviceRef}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={item}
                                >
                                  {item}
                                </label>
                              </div>
                            </li>
                          )
                        })}
                      </ul>
                    ) : (
                      <p>No Devices</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="selected_inputs">
              <label>Current Device Name</label>
              <div className="input_feilds">
                {" "}
                <input
                  type="text"
                  className="test_input"
                  value={device}
                  readOnly
                ></input>
              </div>
            </div>
          )}
        </div>

        <div className="selected_inputs1">
          <label>Select Start Date & Time</label>
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            showTimeSelect
            timeFormat="h:mm aa"
            timeIntervals={15}
            minDate={new Date()}
            filterTime={filterPassedTime}
            dateFormat="MMMM d, yyyy h:mm aa"
            timeCaption="time"
            className="react-datepicker-ignore-onclickoutside"
          />
        </div>
        <div className="selected_inputs1">
          <label>Select End Date & Time</label>

          <DatePicker
            selected={endDate}
            disabled={adhocChecked}
            onChange={(date) => setEndDate(date)}
            showTimeSelect
            timeFormat="h:mm aa"
            timeIntervals={15}
            minDate={startDate}
            maxDate={maxDate}
            filterTime={(time) => {
              const selectedTime = new Date(time)

              const startDateTime = new Date(startDate)

              return selectedTime > startDateTime
            }}
            dateFormat="MMMM d, yyyy h:mm aa"
            timeCaption="time"
            className="react-datepicker-ignore-onclickoutside"
          />
        </div>
        <div className="selected_inputs">
          <label>
            <input
              type="checkbox"
              checked={adhocChecked}
              onChange={handleChange}
            />
            Adhoc Reservation
          </label>
        </div>

        <div className="getdatabtn">
          <span>
            <div className="buttongrp">
              <button
                className="TestButtonCancel triggerbtn m-2"
                onClick={() => {
                  setEndDate(null)
                  setAdhocChecked(false)
                }}
              >
                Cancel
              </button>
              <button
                onClick={endDate !== null && sendData}
                className={
                  endDate === null
                    ? "TestButtonConfirm triggerbtn m-2"
                    : "TestButton triggerbtn bg-info m-2"
                }
              >
                Confirm
              </button>
            </div>
          </span>
        </div>
      </div>
      <Modal show={isOpen} onHide={togglePopup} centered>
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body>{reserveMessage}</Modal.Body>
        <Modal.Footer>
          <Button
            variant="primary"
            onClick={() => {
              toggletab(2)
            }}
          >
            View all reservations
          </Button>
        </Modal.Footer>
      </Modal>
    </React.Fragment>
  )
}

export default DeviceReservation
