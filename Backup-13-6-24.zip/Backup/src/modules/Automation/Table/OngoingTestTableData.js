import React, { useState, useEffect } from "react"
import "../Pagination/Pagination.css"
import "./OngoingTestTableData.css"
import axios from "axios"
import { toast } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import "reactjs-popup/dist/index.css"
import { ABORT_API, VALIDATE_BUYLICENSE_STATUS } from "../../../services/api"
import { Tooltip } from "@mui/material"
import PopupComponent from "../../../components/ReusableComponents/PopupComponent/PopupComponent"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import { tooltipClasses } from "@mui/material/Tooltip"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))

const Posts = ({ testdata, loading, indexOfFirstPost }) => {
  const [read, setRead] = useState(false)
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  const [isOpen, setIsOpen] = useState(false)
  const [Status, setStatus] = useState("")
  const [abortData, setAbortData] = useState()
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))

  useEffect(() => {
    ValidateLicensestatus()
  }, [])
  if (loading) {
    return <h2>Loading...</h2>
  }
  const togglePopup = (data) => {
    setAbortData(data)
    setIsOpen(!isOpen)
  }
  const cancelAbort = () => {
    setIsOpen(!isOpen)
  }
  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }

  const sendAbort = () => {
    console.log("test", abortData)
    setIsOpen(!isOpen)
    axios
      .post(ABORT_API + `${JSON.stringify(abortData)}`)
      .then((response) => {
        console.log("user message", response.data)
        toast.success("Aborted", {
          position: toast.POSITION.TOP_CENTER,
        })
      })
      .catch((error) => console.log(error))
  }

  const handleOngoingTestCases = (item) => {
    const testData = item.test_case_name
      .slice(0, 5)
      .map((ongoingTest) => <li>{ongoingTest}</li>)
    return testData
  }
  return (
    <div
      className={`table-container table table-responsive  ${
        theme === "dark" ? "dark" : "light"
      }`}
    >
      <h3 className={`table_mainhead ${theme === "dark" ? "dark" : "light"}`}>
        Ongoing Test
      </h3>
      <table class="table">
        <thead className="table_head ">
          <tr className="table_header text-center">
            <th scope="col">SI_No</th>
            <th scope="col">Test ID</th>
            <th scope="col">Device</th>
            <th scope="col">Test Case</th>
            <th scope="col">Test Suite</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody className="table_body text-left">
          {testdata.map((item, index) => {
            return (
              <tr
                style={{ fontSize: "14px" }}
                className="text-center"
                key={index}
              >
                <td>{indexOfFirstPost + index + 1}</td>
                <td>{item.test_reference}</td>
                <td>{item.device_name}</td>
                <TooltipComponent
                  multiline={true}
                  title={
                    item.test_case_name.length > 1 &&
                    handleOngoingTestCases(item)
                  }
                  placement="bottom-end"
                >
                  <td>{item.test_case_name[0]}</td>
                </TooltipComponent>
                <td>{item.test_suite === "" ? "Null" : item.test_suite}</td>
                <td>
                  {Status !== "Active" ? (
                    <Tooltip
                      title={<td>License {Status}</td>}
                      className="tooltip-display"
                    >
                      <button
                        disabled={Status !== "Active"}
                        className="TestButton"
                      >
                        Abort
                      </button>
                    </Tooltip>
                  ) : Status === "Active" ? (
                    <button
                      disabled={Status !== "Active"}
                      onClick={() => togglePopup(item)}
                      className="TestButton"
                    >
                      Abort
                    </button>
                  ) : (
                    <div></div>
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <PopupComponent
        open={isOpen}
        text=" Are you Sure? Do you like to Abort?"
        handleClose={togglePopup}
        functionHandle={sendAbort}
      />
    </div>
  )
}

export default Posts
