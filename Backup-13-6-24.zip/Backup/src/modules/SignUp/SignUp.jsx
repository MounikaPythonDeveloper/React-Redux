/** * Component: SampleComponent
    * File: SignUp.jsx
    * Description: This file contents the implementation of user registration page.
                   Wrapping all the components into ManagerUserRegistration.
                   Calling OTP.jsx after filling the registration data
                   It will register the user.
    * Author: Yuvaraj Dakhane
* **/

import React, { useState, useEffect } from "react"

import { useLocation } from "react-router-dom"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import "../SignUp/SignUp.css"
import MyButton from "../../components/ReusableComponents/Buttons"
import MyLink from "../../components/ReusableComponents/Links"
import { IconButton, InputAdornment } from "@mui/material"
import axios from "axios"
import {
  SIGNUP_API,
  VALIDATE_EMAIL_API,
  VERIFY_USER_API,
  RESEND_OTP_API,
} from "../../services/api"
import { Visibility, VisibilityOff } from "@mui/icons-material"
import Otp from "../../components/OTP/OTP"
import TextField from "@material-ui/core/TextField"
import Tooltip from "@mui/material/Tooltip"
import { tooltipClasses } from "@mui/material/Tooltip"
import { styled } from "@mui/material/styles"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"

import { Typography, makeStyles, useMediaQuery } from "@material-ui/core"
import Alert from "@mui/material/Alert"

import EvQuallogo from "../../assets/images/EvQuallogo.svg"
var CryptoJS = require("crypto-js")
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))

//Styles for Mui components
const useStyles = makeStyles({
  underline: {
    "&&&:before": {
      borderBottom: "none",
    },
    "&&:after": {
      borderBottom: "none",
    },
  },
})

const texfieldInputStyle = {
  borderBottom: "1px solid grey",
  color: "#fff",
  fontFamily: "Open Sans",
  fontSize: 18,
  fontStyle: "normal",
  fontWeight: 400,
  lineHeight: "30px",
  background: "transparent",
}

const texfieldLabelStyle = {
  color: "#fff",
  opacity: 1.0,
  fontSize: 16,
  fontFamily: "Open Sans",
  fontStyle: "normal",
  fontWeight: 400,
  paddingTop: 1,
  lineHeight: "30px",
  background: "transparent",
}

const SignUp = () => {
  //Defined states and data
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  const location = useLocation()
  const [active, setActive] = useState(0)
  const [username, setUsername] = useState("")
  const [otpVerify,setOtpVerify]=useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState({ username: "", email_id: "" })
  const [errorEmail, setErrorEmail] = useState({ username: "", email_id: "" })
  const [usernameValid, setUsernameValid] = useState("")
  const [emailValid, setEmailValid] = useState("")
  const [errorUsername, setUsernameError] = useState("")
  const [usernameEmpty, setUsernameEmpty] = useState(true)
  const [emailEmpty, setEmailEmpty] = useState(true)
  const [passwordEmpty, setPasswordEmpty] = useState(true)
  const [otperror, setOtpError] = useState("")
  const [showAlert, setShowAlert] = useState(false)
  const [showAlertFailed, setShowAlertFailed] = useState(false)
  const [msg, setMsg] = useState()
  const [userDataOtp, setUserDataOtp] = useState({})
  const [showPassword, setShowPassword] = useState(false)
  const [onSubmitButton, setOnSubmitButton] = useState(false)
  const classes = useStyles()
  const isMobile = useMediaQuery("(max-width: 480px)") //using MediaQuery to change the style when it will be in below 480px

  // Style for below 480px alert box
  const alertStyle = {
    fontSize: isMobile ? "15px" : "24px",
    color: "#fff",
  }

  // useEffect will be used to get the message from otp.jsx
  useEffect(() => {
    let msg1 = location.state?.data
    setMsg(msg1)
  }, [active === 0])

  // form validation rules

  //Regular Expression for password validation
  const regexPass1 =
    /^[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~](?=.*[a-zA-Z0-9])[a-zA-Z0-9]{8,14}[a-zA-Z0-9]{0,6}$/
  const regexPass2 =
    /^(?=.*[a-zA-Z0-9])[a-zA-Z0-9]{8,14}[a-zA-Z0-9]{0,6}[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~]$/
  const regexPass3 =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~])[A-Za-z\d!@#$%^&*()-=_+[\]{}\\|;:',.<>?`~]{10,18}$/

  //Define the function to validate the fields of form
  const validationSchema = Yup.object().shape({
    password: Yup.string()
      .required("Password is required")
      .matches(regexPass2 && regexPass1 && regexPass3, "Invalid Password"),
    confirmPassword: Yup.string()
      .required("Confirm Password is required")
      .oneOf([Yup.ref("password")], "Passwords must match"),
    uname: Yup.string().required("User name is required"),
    email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
  })

  const formOptions = { resolver: yupResolver(validationSchema) }
  if (theme === "dark") {
    document.documentElement.classList.remove("light")
    document.documentElement.classList.add("dark")
  } else {
    document.documentElement.classList.remove("dark")
    document.documentElement.classList.add("light")
  }
  // get functions to build form with useForm() hook
  const { register, handleSubmit, formState } = useForm(formOptions)
  const { errors } = formState //error if it doent match with formvalidation

  //Define the function to submit the data and call SIGN_UP_API
  function onSubmit(data) {
    var key = "AAAAAAAAAAAAAAAA"
    key = CryptoJS.enc.Utf8.parse(key)
    setShowAlert(true)

    var encrypted = CryptoJS.AES.encrypt(data.password, key, {
      mode: CryptoJS.mode.ECB,
    })
    encrypted = encrypted.toString()
    const signup_data = {
      username: data.uname.toLowerCase(),
      email: data.email.toLowerCase(),
      password: encrypted,
    }
    setOnSubmitButton(true)

    axios
      .post(SIGNUP_API + JSON.stringify(signup_data))
      .then((response) => {
        if (response.data.valid === "true") {
          setUsername(response.data.username)
          setEmail(response.data.email_id)
          setActive(1)
          setOnSubmitButton(false)
        } else {
          setError(response.data)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  console.log("onsubmit", onSubmitButton)
  //If showAlertFailed is equal to true then alert box will call the handleAlertClose()
  if (showAlert) {
    setTimeout(() => {
      handleAlertClose()
    }, 2000)
  }

  //If showAlertFailed is equal to true then alert box will call the handleAlertCloseFailed()
  if (showAlertFailed) {
    setTimeout(() => {
      handleAlertCloseFailed()
    }, 2000)
  }

  //define function to close the alert box
  const handleAlertCloseFailed = () => {
    setShowAlertFailed(false)
  }

  const handleAlertClose = () => {
    setShowAlert(false)
  }

  //Check username is already exist or not
  const checkUsername = (uname) => {
    axios
      .post(VERIFY_USER_API + JSON.stringify({ username: uname }))
      .then((response) => {
        setOtpVerify("")
        if (response.data.message === "OTP is not Verified") {
          let value = response.data.message
          setOtpVerify(value)
          setUsernameValid(value)
          setUserDataOtp(response.data)
          setUsernameError("")
        }
        if (response.data.message === "Username already exists.") {
          let value = response.data.message
          setUsernameValid(value)
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  //Check email is already exist or not
  const checkEmail = (email_id) => {
    axios
      .post(VALIDATE_EMAIL_API + JSON.stringify({ email_id: email_id }))
      .then((response) => {
        if (response.data === true) {
          let value = "true"
          setEmailValid(value)
          setErrorEmail("")
        }
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  //Define the function to handle the onChange event on textfield of username
  const handleUsernameBlur = (e) => {
    e.preventDefault()
    setUsernameValid("")
    const regex = /^[a-z0-9_]{4,}$/
    if (!regex.test(e.target.value)) {
      setUsernameError(
        // "Atleast 4+ Characters, lowercase & Special characters not allowed."
        "Username must be 4+ characters, lowercase, and numbers only"
      )
      setUsername(true)
      setUsernameEmpty(true)
    } else {
      checkUsername(e.target.value)
      setUsername(false)
      setUsernameEmpty(false)
    }

    if (e.target.value.includes(" ")) {
      setUsernameError("Space is not allowed")
      setUsername(true)
      setUsernameEmpty(true)
    }
  }

  //Define the function to handle the onChange event on textfield of email
  const handEmailBlur = (e) => {
    setEmailValid("")
    const regex = /^[a-z0-9][a-z0-9._%+-]*@ltts\.com$/
    if (!regex.test(e.target.value)) {
      setErrorEmail("Invalid email or domain. Supports only lowercase.")
      setEmail(true)
      setEmailEmpty(true)
    } else if (e.target.value.includes("+") || e.target.value.includes("_")) {
      setErrorEmail("Special characters '+' and '-' are not allowed")
      setEmail(true)
      setEmailEmpty(true)
    } else {
      setEmailEmpty(false)
      setErrorEmail("")
      setEmail(false)
      checkEmail(e.target.value)
    }
  }

  //Define the function to handle the onChange event on textfield of password
  const handlePasswordBlur = (e) => {
    setPassword("")
    const regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{}|;:'",.<>?`~\\\/])[A-Za-z\d!@#$%^&*()_+\-=[\]{}|;:'",.<>?`~\\\/]{10,18}$/

    if (!regex.test(e.target.value)) {
      setPassword(true)
      setPasswordEmpty(true)
    } else {
      setPasswordEmpty(false)
      setPassword(false)
    }
  }

  //Define the function to handle the onChange event on textfield of  confirm password
  const handleConfirmPasswordBlur = (e) => {
    setConfirmPassword("")
    if (e.target.value === "") {
      setConfirmPassword(true)
    } else {
      setConfirmPassword(false)
    }
  }

  //Define the function call RESEND_OTP_API when user is already registered and It will set the setActive with respective the response.
  const handleOTP = () => {
    axios
      .post(
        RESEND_OTP_API +
          JSON.stringify({
            username: userDataOtp.username,
            email: userDataOtp.email_id,
          })
      )
      .then((response) => {
        setActive(1)
        setUsername(userDataOtp.username)
        setEmail(userDataOtp.email_id)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }

  //Define the function to check the password visibility
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  useEffect(() => {
    // Read the theme state from sessionStorage

    const savedTheme = sessionStorage.getItem("theme")
    console.log("theme", savedTheme)
    const isDarkTheme = savedTheme === "dark"

    if (isDarkTheme) {
      document.documentElement.classList.add("dark")

      document.documentElement.classList.remove("light")
    } else {
      document.documentElement.classList.add("light")

      document.documentElement.classList.remove("dark")
    }
  }, [])

  const preventDragHandler = (e) => {
    e.preventDefault()
  }

  return (
    <React.Fragment>
      <div className="background-div">
        <div className={`Registration  ${theme === "dark" ? "dark" : "light"}`}>
          <div className="logo-container">
            <img
              src={EvQuallogo}
              alt="Logo"
              className="logo"
              onDragStart={preventDragHandler}
            />
          </div>
          <div class="row">
            {/* If showAlertFailed will "true" this alert box will display*/}
            {showAlertFailed && (
              <div className="alertDiv">
                <Alert
                  severity="success"
                  variant="filled"
                  onClose={handleAlertCloseFailed}
                  icon={false}
                  className="alertBox1"
                  sx={alertStyle}
                >
                  {msg}
                </Alert>
              </div>
            )}
            <div class="col-md-6 register-left">
              <div className="account sign-in">
                Already have an Account?&#160;
                <br />
                <MyLink to="/login" className="signupBtn">
                  Sign In
                </MyLink>
              </div>
            </div>
            <div class="col-md-5 register-right">
              {otperror && otperror}
              {active === 0 && (
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  method="post"
                  className="registration-form"
                  style={{ marginTop: "-15%" }}
                >
                  <div>
                    <h3 className="reg_title-signup">User Sign Up</h3>
                    <div className="text-input-signup">
                      <TextField
                        label="Username"
                        className="text-field"
                        id="standard-basic-uname"
                        {...register("uname", {
                          required: "uname is required",
                        })}
                        onBlur={handleUsernameBlur}
                        error={username}
                        helperText={[
                          username ? errorUsername : errors.uname?.message,
                          (usernameValid === "Username already exists." &&
                            "Username already exists.") ||
                            (otpVerify=== "OTP is not Verified" &&
                              "OTP is not Verified"),

                          error.username && error.username,
                        ]}
                        InputProps={{
                          style: texfieldInputStyle,
                          classes: { underline: classes.underline },
                        }}
                        InputLabelProps={{
                          style: texfieldLabelStyle,
                        }}
                        FormHelperTextProps={{ className: "my-helper-text" }}
                        autoComplete="off"
                      />
                      <br />
                    </div>
                    {otpVerify !== "OTP is not Verified" && (
                      <div className="text-input-signup">
                        <TextField
                          id="standard-basic-email"
                          className="text-field"
                          label="Email"
                          variant="standard"
                          {...register("email", {
                            required: "email is required",
                          })}
                          onBlur={handEmailBlur}
                          error={email}
                          helperText={[
                            email ? errorEmail : errors.email?.message,
                            emailValid === "true" &&
                              "Email already exist, please try other email-id",
                            // error.email_id && error.email_id,
                          ]}
                          InputProps={{
                            style: texfieldInputStyle,
                            classes: { underline: classes.underline },
                          }}
                          InputLabelProps={{
                            style: texfieldLabelStyle,
                          }}
                          FormHelperTextProps={{ className: "my-helper-text" }}
                          autoComplete="off"
                        />
                        <br />
                      </div>
                    )}
                    {otpVerify!== "OTP is not Verified" && (
                      <div className="text-input-signup">
                        <TooltipComponent
                          classes={{ tooltip: classes.tooltip }}
                          className="tooltip-signup"
                          title={
                            <>
                              <Typography
                                color="inherit"
                                style={{ fontSize: "11px" }}
                              >
                                Password Should contain:
                              </Typography>
                              <Typography
                                color="inherit"
                                component="div"
                                style={{ fontSize: "11px" }}
                              >
                                <ul className="unordered-list-tooltip">
                                  <li>10+ characters </li>
                                  <li>Atleast 1 number </li>
                                  <li>
                                    Atleast one special character($,%,@, etc.){" "}
                                  </li>
                                  <li>
                                    Have mixture of uppercase and lowercase
                                    letters{" "}
                                  </li>
                                </ul>
                              </Typography>
                            </>
                          }
                          placement="bottom"
                        >
                          <TextField
                            id="standard-basic-pass"
                            label="Password"
                            className="text-field"
                            variant="standard"
                            type={showPassword ? "text" : "password"}
                            {...register("password", {
                              required: "Password is required",
                            })}
                            onBlur={handlePasswordBlur}
                            error={password}
                            helperText={[
                              password
                                ? "Invalid password"
                                : errors.password?.message,
                            ]}
                            InputProps={{
                              style: texfieldInputStyle,
                              classes: { underline: classes.underline },
                              endAdornment: (
                                <InputAdornment position="end">
                                  <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={togglePasswordVisibility}
                                    edge="end"
                                    style={{
                                      position: "absolute",
                                      right: "10px",
                                      transform: "translateY(-15%)",
                                    }}
                                  >
                                    {showPassword ? (
                                      <Visibility />
                                    ) : (
                                      <VisibilityOff />
                                    )}
                                  </IconButton>
                                </InputAdornment>
                              ),
                            }}
                            InputLabelProps={{
                              style: texfieldLabelStyle,
                            }}
                            FormHelperTextProps={{
                              className: "my-helper-text",
                            }}
                            autoComplete="off"
                          />
                        </TooltipComponent>
                      </div>
                    )}
                    {otpVerify!== "OTP is not Verified" && (
                      <div className="text-input-signup">
                        <TextField
                          id="standard-basic-confirm"
                          label="Confirm Password"
                          variant="standard"
                          className="text-field"
                          type="password"
                          {...register("confirmPassword", {
                            required: " Confirm Password is required",
                          })}
                          onBlur={handleConfirmPasswordBlur}
                          error={confirmPassword}
                          helperText={[
                            confirmPassword
                              ? "Password Mismatch"
                              : errors.confirmPassword?.message,
                          ]}
                          InputProps={{
                            style: texfieldInputStyle,
                            classes: { underline: classes.underline },
                          }}
                          InputLabelProps={{
                            style: texfieldLabelStyle,
                          }}
                          FormHelperTextProps={{ className: "my-helper-text" }}
                          autoComplete="off"
                        />
                        <br />
                      </div>
                    )}
                    {otpVerify!== "OTP is not Verified" && (
                      <div className="submit-signup">
                        <MyButton
                          type="submit"
                          variant="contained"
                          disabled={
                            !!usernameValid ||
                            !!emailValid ||
                            !!usernameEmpty ||
                            !!emailEmpty ||
                            !!passwordEmpty ||
                            !!confirmPassword ||
                            onSubmitButton
                          }
                          label="Submit"
                        ></MyButton>
                      </div>
                    )}
                    {otpVerify === "OTP is not Verified" && (
                      <div className="submit-signup">
                        <MyButton
                          type="submit"
                          variant="contained"
                          onClick={handleOTP}
                          label="Verify OTP"
                        ></MyButton>
                      </div>
                    )}
                  </div>
                </form>
              )}
              {/* If active = 1 then it will call OTP.jsx*/}
              {active === 1 && (
                <Otp
                  username={username}
                  email_id={email}
                  handleactiveblock={setActive}
                />
              )}
              <br />
            </div>
          </div>

          {showAlert && (
            <div className="alertDiv1">
              <Alert
                severity="success"
                variant="filled"
                onClose={handleAlertClose}
                icon={false}
                className="alertBox1"
                sx={alertStyle}
              >
                A confirmation link is send to your email
              </Alert>
            </div>
          )}
        </div>
      </div>
    </React.Fragment>
  )
}
export default SignUp
