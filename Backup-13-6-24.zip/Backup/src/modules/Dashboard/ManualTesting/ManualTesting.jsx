/** * Component: Dashboard
 * File: ManualTesting.jsx
 * Description: This file contents the implementation of Manual Test History Table Data and Pagination.
 * Author: Mounika,Prasanna
 * **/
import "./ManualTesting.css"
import axios from "axios"
import { Tooltip } from "@mui/material"
import { Alert, Snackbar } from "@mui/material"
import { FormControl, IconButton, Input, InputAdornment } from "@mui/material"
import SearchIcon from "../../../assets/images/Search.svg"
import Report from "../../../assets/images/Report.png"
import Report_light from "../../../assets/images/icons8-reports-58.png"
import React, { useState, useEffect } from "react"
import mailreport from "../../../assets/images/email_logo.png"
import Mail_light from "../../../assets/images/icons8-mail-48.png"
import Pagination from "../../Automation/Pagination/Pagination"
import {
  VIDEO_QUALITY_HISTORY_API,
  MAIL_REPORT_API,
  VALIDATE_BUYLICENSE_STATUS,
  VIDEO_DASHBOARD_SEARCH_API,
} from "../../../services/api"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"

function ManualTesting(props) {
  const [manualTestData, setManualTestData] = useState([])
  const [searchManualValue, SetSearchManualValue] = useState("")
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const platform = JSON.parse(sessionStorage.getItem("platform"))
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [postsPerPage, setPostsPerPage] = useState(5)
  const [mailConfirmation, setMailConfirmation] = useState(false)
  const [Status, setStatus] = useState("")
  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = manualTestData.slice(indexOfFirstPost, indexOfLastPost)
  const paginate = (pageNumber) => setCurrentPage(pageNumber)
  const { theme } = useTheme()
  const [reportError, setReportError] = useState("")
  useEffect(() => {
    const id = setInterval(() => {
      if (!searchManualValue) {
        manualTestdataapi()
      }
    }, 5000)
    manualTestdataapi()
    return () => clearInterval(id)
  }, [searchManualValue])

  useEffect(() => {
    ValidateLicensestatus()
  })
  const sendmaildata = (report) => {
    axios
      .post(
        MAIL_REPORT_API +
          JSON.stringify({ email: userProfile.email_id, report_link: report })
      )
      .then((response) => {
        console.log(response.data, "sendreport")
        setMailConfirmation(response.data.valid)
      })
  }
  const reportaction = (report) => {
    if (report.includes("http")) {
      window.open(report, "_blank")
    } else {
      setReportError("URL Not found")
    }
  }
  const manualTestdataapi = () => {
    axios
      .post(
        `${VIDEO_QUALITY_HISTORY_API}${JSON.stringify({
          count: 100,
          locked_by: userProfile.username,
          user_privilege: userProfile.user_privilege,
        })}&condition=${JSON.stringify({ platform: platform })}`
      )
      .then((res) => {
        console.log(" manualTestdataapi", res.data)
        setManualTestData(res.data)
      })
      .catch((er) => console.log(er))
  }
  const handleSearchManual = async () => {
    // const selectedFields = [
    //   "trigger_id",
    //   "video_details",
    //   "date_and_time",
    //   "status",
    // ]
    // const results = []
    // manualTestData.forEach((item) => {
    //   let found = false
    //   for (let key in item) {
    //     if (
    //       selectedFields.includes(key) &&
    //       item[key] &&
    //       item[key].toString().includes(searchManualValue)
    //     ) {
    //       found = true
    //       break
    //     }
    //   }
    //   if (found) {
    //     results.push(item)
    //   }
    // })
    // console.log("video quality search", results)
    // // Assuming setManualTestData is a function to update the state
    // setManualTestData(results)
    await axios
      .get(`${VIDEO_DASHBOARD_SEARCH_API}search=${searchManualValue}`)
      .then((response) => {
        console.log(response.data, "Manual testing")
        setManualTestData(response.data)
      })
      .catch((error) => {
        console.log(error, "error")
      })
  }
  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }
  const handleTestCases = (item) => {
    const data = item.test_case_name
      .slice(0, 5)
      .map((itestcases) => <li>{itestcases}</li>)
    return data
  }
  const enterkeyAPIHandler = (event) => {
    const trim_string = event.target.value.trim()
    SetSearchManualValue(trim_string)
    console.log("SearchManualValue", searchManualValue)
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      event.preventDefault()
      handleSearchManual()
    }
  }
  console.log(currentPosts, "manual testing:")

  return (
    <div className="ManualTestingContainer">
      <Snackbar
        className="delete-alert-message"
        open={reportError}
        autoHideDuration={6000}
        onClose={() => setReportError("")}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert icon={false}>{reportError}</Alert>
      </Snackbar>
      <Snackbar
        className="delete-alert-message"
        open={mailConfirmation}
        autoHideDuration={6000}
        onClose={() => setMailConfirmation(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        {mailConfirmation === "true" && (
          <Alert icon={false}>Report has sent to your Mail Id</Alert>
        )}
      </Snackbar>
      <div
        className={`ManualTestingHeading ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        Video Quality Dashboard
      </div>
      <div className="searchDashboard">
        <FormControl
          className={`search-field-status-monitor ${
            theme === "dark" ? "dark" : "light"
          }`}
          variant="standard"
          color="secondary"
        >
          <Input
            autoComplete="off"
            id="search-devices"
            placeholder="Search"
            type="text"
            onKeyUp={enterkeyAPIHandler}
            onChange={(e) => SetSearchManualValue(e.target.value)}
            endAdornment={
              <InputAdornment position="end">
                <IconButton>
                  <img
                    className="search-icon"
                    alt="SearchIcon"
                    src={SearchIcon}
                    title="SearchIcon"
                    onClick={() => handleSearchManual(searchManualValue)}
                  />
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
      </div>
      <div
        className={`table-container table table-responsive  ${
          theme === "dark" ? "dark" : "light"
        }`}
      >
        <table class="table">
          <thead className="table_head ">
            <tr className="table_header text-center">
              <th scope="col">SI_No</th>
              <th scope="col">Test ID</th>
              {/* <th scope="col">Test Reference</th> */}
              <th scope="col">Video Details</th>
              <th scope="col"> Start Time</th>
              {/* <th scope="col">Test Case</th> */}

              {/* <th scope="col">End time</th> */}
              {/* <th scope="col">Result</th> */}
              <th scope="col">Status</th>
              {/* <th scope="col">Result</th> */}
              <th scope="col">Report</th>
              <th scope="col">Mail</th>
            </tr>
          </thead>
          {currentPosts.length === 0 ? (
            <div
              className={`table-empty-message  ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              No Data Available
            </div>
          ) : (
            <tbody className="table_body text-left">
              {currentPosts.map((item, index) => {
                return (
                  <tr style={{ fontSize: "14px" }} className="text-center">
                    <td data-label="SI_NO">{indexOfFirstPost + index + 1}</td>
                    <td data-label="Test ID">{item.trigger_id}</td>
                    <td data-label="Video Details">
                      {item.video_details.length > 30
                        ? item.video_details.substring(0, 30) + "..."
                        : item.video_details}
                    </td>
                    <td data-label="Start Time">{item.date_and_time}</td>
                    <td data-label="Status">{item.status}</td>
                    {Status !== "Active" ? (
                      <Tooltip
                        title={<td>License is {Status}</td>}
                        className="tooltip-display"
                      >
                        <td data-label="Report">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                              cursor: "not-allowed",
                            }}
                            src={theme === "dark" ? Report : Report_light}
                            disabled={Status !== "Active"}
                            title="Reports"
                            alt="Reports"
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                          />
                        </td>
                      </Tooltip>
                    ) : Status === "Active" ? (
                      <td data-label="Report">
                        <img
                          style={{
                            border: "none",
                            height: "6vh",
                            width: "6vh",
                          }}
                          src={theme === "dark" ? Report : Report_light}
                          title="Reports"
                          disabled={Status !== "Active"}
                          alt="Reports"
                          className={
                            // item.status === "Completed"
                            item.status === "Completed" && item.report !== null
                              ? "btn btn-md p-2"
                              : "btn disabled p-2 "
                          }
                          onClick={() => {
                            reportaction(item.report)
                          }}
                        />
                      </td>
                    ) : (
                      <div></div>
                    )}
                    {Status !== "Active" ? (
                      <Tooltip
                        title={<td>License is {Status}</td>}
                        className="tooltip-display"
                      >
                        <td data-label="Mail">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                              cursor: "not-allowed",
                            }}
                            src={theme === "dark" ? mailreport : Mail_light}
                            alt="Mail"
                            title="Mail"
                            disabled={Status !== "Active"}
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                          />
                        </td>
                      </Tooltip>
                    ) : Status === "Active" ? (
                      <td data-label="Mail">
                        <img
                          style={{
                            border: "none",
                            height: "6vh",
                            width: "6vh",
                          }}
                          src={theme === "dark" ? mailreport : Mail_light}
                          alt="Mail"
                          title="Mail"
                          disabled={Status !== "Active"}
                          className={
                            item.status === "Completed"
                              ? "btn btn-md p-2"
                              : "btn disabled p-2 "
                          }
                          onClick={() => {
                            sendmaildata(item.report)
                          }}
                        />
                      </td>
                    ) : (
                      <div></div>
                    )}
                  </tr>
                )
              })}
            </tbody>
          )}
        </table>
        {currentPosts.length > 0 && (
          <Pagination
            currentPage={currentPage}
            postsPerPage={postsPerPage}
            totalPosts={manualTestData.length}
            paginate={paginate}
            indexOfFirstPost={indexOfFirstPost}
          />
        )}
      </div>
    </div>
  )
}
export default ManualTesting
