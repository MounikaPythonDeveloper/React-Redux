import axios from "axios"
import React, { useState, useEffect } from "react"
import Posts from "../Dashboard/TestHistoryTabledata"
import Pagination from "../Automation/Pagination/Pagination"
import TestHistoryTabledata from "../Dashboard/TestHistoryTabledata"
import { test, TESTHISTORY_API } from "../../services/api"

const Tabledata = (props) => {
  const [testhistorydata, setTestHistoryData] = useState([])
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const platform = JSON.parse(sessionStorage.getItem("platform"))
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [postsPerPage, setPostsPerPage] = useState(6)
  const [powerBIAction, setPowerBIAction] = useState(false)
  useEffect(() => {
    const id = setInterval(() => {
      testhistorydataapi() // <-- (3) invoke in interval callback
    }, 5000)
    testhistorydataapi()
    return () => clearInterval(id)
  }, [])

  const testhistorydataapi = () => {
    axios
      .post(
        `${TESTHISTORY_API}${JSON.stringify({
          count: 100,
          locked_by: userProfile.username,
          user_privilege: userProfile.user_privilege,
        })}&condition=${JSON.stringify({ platform: platform })}`
      )
      .then((res) => {
        console.log("testhistorydata", res.data)
        setTestHistoryData(res.data)
      })
      .catch((er) => console.log(er))
  }

  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = testhistorydata.slice(indexOfFirstPost, indexOfLastPost)

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber)

  const handlechildValue = (value) => {
    setPowerBIAction(value)
  }

  return (
    <React.Fragment>
      <Posts
        testhistorydata={currentPosts}
        indexOfFirstPost={indexOfFirstPost}
        loading={loading}
        valuetosend={handlechildValue}
      />

      {testhistorydata.length > 0 && !powerBIAction && (
        <Pagination
          currentPage={currentPage}
          postsPerPage={postsPerPage}
          totalPosts={testhistorydata.length}
          paginate={paginate}
          indexOfFirstPost={indexOfFirstPost}
        />
      )}
    </React.Fragment>
  )
}
export default Tabledata
