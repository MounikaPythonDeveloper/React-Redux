import React from "react"
import "./Pagination.css"
const Pagination = ({ postsPerPage, totalPosts, currentPage, paginate }) => {
  const pageNumbers = []

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i)
  }

  console.log(pageNumbers)
  return (
    <div className="pagination">
      <ul>
        {
          <li
            style={{ backgroundColor: "white", border: "none" }}
            className={`${pageNumbers[0] === currentPage && "disabled"}`}
            onClick={() => {
              paginate(currentPage - 1)
            }}
          >
            <svg
              data-testid="ArrowLeftIcon"
              fontSize="small"
              style={{ color: "skyblue", fontSize: 10 }}
            ></svg>
            Prev
          </li>
        }

        {pageNumbers.map((Number) => (
          <li
            className={`num ${currentPage === Number ? "page_highlight" : ""}`}
            onClick={() => paginate(Number)}
          >
            {Number}
          </li>
        ))}
        {
          <li
            style={{ backgroundColor: "#04B1B1", border: "none" }}
            className={`${
              pageNumbers.reverse()[0] === currentPage && "disabled"
            }`}
            onClick={() => {
              paginate(currentPage + 1)
            }}
          >
            <svg
              data-testid="ArrowLeftIcon"
              style={{ color: "skyblue", fontSize: 10 }}
            ></svg>
            Next
          </li>
        }
      </ul>
    </div>
  )
}

export default Pagination
