/** * Component: Dashboard
    * File: Dashboard.jsx
    * Description: This file contents the implementation of Dashboard page with manual, automation 
    and analytics Dashboard.
    * Author: Yuvaraj Dakhane,Mounika,Prasanna
* **/
import React, { useState } from "react"
import TestHistory from "./AutomationTesting/AutomationTestHistory"
import "../Dashboard/Dashboard.css"
import { Link } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import ManualIcon from "../../assets/images/MTI.png"
import AutomationTestingIcon from "../../assets/images/testing.png"
import ManualTestingIcon from "../../assets/images/manual-test.png"
import AutomationIcon from "../../assets/images/ATI.png"
import ManualTesting from "./ManualTesting/ManualTesting"
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))
const Dashboard = () => {
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  console.log("dashboard theme", theme)
  const [manualRender, setManualRender] = useState(false)
  const [automationRender, setAutomationRender] = useState(true)
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const manualHandler = function () {
    setAutomationRender(false)
    setManualRender(true)
  }
  const automationHandler = function () {
    setManualRender(false)
    setAutomationRender(true)
  }

  return (
    <React.Fragment>
      <div className="dashboard-sub">
        <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
          <Link to={"/platform"}>Platform</Link>
          {platform_data === "Media And Entertainment" ? (
            <Link to="/platform">M&E</Link>
          ) : (
            <Link Link to="/platform">
              {platform_data}
            </Link>
          )}
          <Typography color="#0D6EFD">Dashboard</Typography>
        </Breadcrumbs>
        <div className="dashboard-icons">
          <div className="ManualIconDiv">
            {automationRender && (
              <TooltipComponent title="Video Quality">
                <img
                  src={theme === "dark" ? ManualIcon : ManualTestingIcon}
                  onClick={manualHandler}
                  title="Video Quality"
                  className={`ManualIcon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  alt="ManualIcon"
                />
              </TooltipComponent>
            )}
          </div>
          <div className="AutomationIconDiv">
            {manualRender && (
              <TooltipComponent title="Automation Testing">
                <img
                  src={
                    theme === "dark" ? AutomationIcon : AutomationTestingIcon
                  }
                  className={`AutomationIcon ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  alt="AutomationIcon"
                  onClick={automationHandler}
                />
              </TooltipComponent>
            )}
          </div>
        </div>
      </div>
      {automationRender && (
        <div className="automation">
          <TestHistory />
        </div>
      )}
      {manualRender && (
        <div className="manual">
          <ManualTesting />
        </div>
      )}
    </React.Fragment>
  )
}
export default Dashboard
