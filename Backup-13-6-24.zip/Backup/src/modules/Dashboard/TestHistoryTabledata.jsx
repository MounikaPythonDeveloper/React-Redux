// Video icon-https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Video_Quality/EvQUAL_Video_Quality_Report.pdf
//inside dropdown Test Record
//Quality Report

// 1.multiple screens powerbi record and play
import React, { useState, useEffect } from "react"
import "./Test_history.css"
import Log from "../../assets/images/logs.png"
import Report from "../../assets/images/Report.png"
import mailreport from "../../assets/images/email_logo.png"
import Video from "../../assets/images/video_plus_icon1.svg"
import powerbi from "../../assets/images/power-bi.svg"
import axios from "axios"
import { MAIL_REPORT_API, VALIDATE_BUYLICENSE_STATUS } from "../../services/api"
import Arrow from "../../assets/images/Arrow 2.svg"
import { Alert, Snackbar } from "@mui/material"
import { Tooltip } from "@mui/material"
import "../Automation/Pagination/Pagination.css"
import "../Automation/Table/OngoingTestTableData.css"
import { toast } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"

const TestHistoryTabledata = ({
  testhistorydata,
  loading,
  indexOfFirstPost,
  valuetosend,
}) => {
  // console.log(testhistorydata === [], "one");
  console.log("hello supriya")

  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const [Status, setStatus] = useState("")
  const [mailConfirmation, setMailConfirmation] = useState(false)
  const [read, setRead] = useState(false)
  const [powerBIAction, setPowerBIAction] = useState(false)
  const [powerBiUrl, setPowerBiUrl] = useState("")
  useEffect(() => {
    ValidateLicensestatus()
  }, [])

  if (loading) {
    return <h2>Loading...</h2>
  }

  const sendmaildata = (report) => {
    axios
      .post(
        MAIL_REPORT_API +
          JSON.stringify({ email: userProfile.email_id, report_link: report })
      )
      .then((response) => {
        console.log(response.data, "sendreport")
        setMailConfirmation(response.data.valid)
      })
  }
  const reportaction = (report) => {
    window.open(report, "_blank")
  }
  const reportactionPowerBI = (report) => {
    setPowerBIAction(true)
    setPowerBiUrl(
      "https://app.powerbi.com/reportEmbed?reportId=bc6ef75d-9648-4f50-9b58-4f68125262db&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
    )
    valuetosend(true)
  }

  const displayDashboard = () => {
    setPowerBIAction(false)
    valuetosend(false)
    // setPowerBiUrl("")
  }

  const handleTestCases = (item) => {
    const data = item.test_case_name
      .slice(0, 5)
      .map((itestcases) => <li>{itestcases}</li>)
    return data
  }

  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }

  return (
    <div className="table-container table table-responsive">
      <div>
        <Snackbar
          className="delete-alert-message"
          open={mailConfirmation}
          autoHideDuration={6000}
          onClose={() => setMailConfirmation(false)}
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
        >
          {mailConfirmation === "true" && (
            <Alert icon={false}>Report has sent to your Mail Id</Alert>
          )}
        </Snackbar>
      </div>
      {!powerBIAction && (
        <h3 className="table_mainhead_dashboard">Dashboard</h3>
      )}
      {powerBIAction && (
        <h2 className="table_mainhead_dashboard">Analytics Dashboard</h2>
      )}
      {!powerBIAction && (
        <>
          <table class="table">
            <thead className="table_head ">
              <tr className="table_header text-center">
                <th scope="col">SI_No</th>
                <th scope="col">Test ID</th>
                <th scope="col"> Device Name</th>
                <th scope="col">Start Time</th>
                <th scope="col">Test Case</th>
                <th scope="col">Status</th>
                <th scope="col">Result</th>
                <th scope="col">Logs</th>
                <th scope="col">Reports</th>
                <th scope="col">Mail</th>
                <th scope="col">PowerBI</th>
              </tr>
            </thead>
            {testhistorydata.length === 0 ? (
              <div className="table-empty-message">No Data Available</div>
            ) : (
              // <tbody className={`table_body text-left ${Status[0] !== "Active" ? 'disabled' : ''}`}
              //   style={{opacity: Status[0] === 'Active' ? 1 : 0.5,cursor: Status[0] === 'Active' ? 'auto' : 'not-allowed'}}>
              <tbody className="table_body text-left">
                {testhistorydata.map((item, index) => {
                  return (
                    <tr
                      style={{ fontSize: "14px" }}
                      className="text-center"
                      key={index}
                    >
                      <td>{indexOfFirstPost + index + 1}</td>
                      <td>{item.test_reference}</td>
                      <td>{item.device_name}</td>
                      <td>{item.date_and_time}</td>
                      <Tooltip
                        multiline={true}
                        title={
                          item.test_case_name.length > 1 &&
                          handleTestCases(item)
                        }
                        placement="bottom-end"
                      >
                        <td>{item.test_case_name[0]}</td>
                      </Tooltip>
                      <td>{item.status}</td>
                      <td>{item.result}</td>
                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td>
                            <img
                              style={{
                                border: "none",
                                height: "5vh",
                                width: "5vh",
                                cursor: "not-allowed",
                              }}
                              src={Log}
                              alt="Logs"
                              disabled={Status !== "Active"}
                              className={
                                item.status == "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td>
                          <img
                            style={{
                              border: "none",
                              height: "5vh",
                              width: "5vh",
                            }}
                            src={Log}
                            alt="Logs"
                            disabled={Status !== "Active"}
                            //className={
                            //item.status == "Completed"
                            // ? "btn btn-md p-2"
                            // : "btn disabled p-2 "
                            //}
                            className="btn btn-md p-2"
                            onClick={() => {
                              reportaction(item.dev_logs)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}
                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td>
                            <img
                              style={{
                                border: "none",
                                height: "5vh",
                                width: "5vh",
                                cursor: "not-allowed",
                              }}
                              src={Report}
                              disabled={Status !== "Active"}
                              alt="Reports"
                              className={
                                item.status == "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td>
                          <img
                            style={{
                              border: "none",
                              height: "5vh",
                              width: "5vh",
                            }}
                            src={Report}
                            disabled={Status !== "Active"}
                            alt="Reports"
                            className={
                              item.status == "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              reportaction(item.exec_reports)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}

                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td>
                            <img
                              style={{
                                border: "none",
                                height: "5.5vh",
                                width: "5.5vh",
                                cursor: "not-allowed",
                              }}
                              src={mailreport}
                              alt="Mail"
                              disabled={Status !== "Active"}
                              className={
                                item.status == "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td>
                          <img
                            style={{
                              border: "none",
                              height: "5.5vh",
                              width: "5.5vh",
                            }}
                            src={mailreport}
                            alt="Mail"
                            disabled={Status !== "Active"}
                            className={
                              item.status == "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              sendmaildata(item.exec_reports)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}

                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td>
                            <img
                              style={{
                                border: "none",
                                height: "5vh",
                                width: "5vh",
                                cursor: "not-allowed",
                              }}
                              src={powerbi}
                              disabled={Status !== "Active"}
                              alt="PowerBI"
                              className={
                                item.status == "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td>
                          <img
                            style={{
                              border: "none",
                              height: "5vh",
                              width: "5vh",
                            }}
                            src={powerbi}
                            disabled={Status !== "Active"}
                            alt="PowerBI"
                            className={
                              item.status == "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              reportactionPowerBI(item.power_bi)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}
                    </tr>
                  )
                })}
              </tbody>
            )}
          </table>
        </>
      )}
      {powerBIAction && (
        <>
          <div class="powerBi-main">
            <button onClick={displayDashboard} className="Dashboard-Back">
              <img src={Arrow}></img>Dashboard
            </button>
            <div
              class="btn-group"
              role="group"
              aria-label="Basic outlined example"
            >
              <button
                className="Dashboard-Back-buttons"
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=bc6ef75d-9648-4f50-9b58-4f68125262db&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Report Summary
              </button>
              <button
                className="Dashboard-Back-buttons"
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=0efe0f96-72b9-4a4d-9c1a-bb07ff5503c7&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Detailed Report
              </button>
              <button
                className="Dashboard-Back-buttons"
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=44457f87-5cee-433e-b0ad-ef00d82c2e1b&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Failure Analysis
              </button>
              <div class="dropdown">
                <button
                  class="btn btn-secondary dropdown-toggle"
                  type="button"
                  id="dropdownMenu2"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <img src={Video}></img>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                  <button
                    class="dropdown-item"
                    type="button"
                    onClick={() =>
                      setPowerBiUrl(
                        "https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Etisalat/Test_Record/2023-09-1221_23_captured_video.webm"
                      )
                    }
                  >
                    Test Record
                  </button>
                  <button
                    class="dropdown-item"
                    type="button"
                    onClick={() =>
                      setPowerBiUrl(
                        "https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Video_Quality/EvQUAL_Video_Quality_Report.pdf"
                      )
                    }
                  >
                    Quality Report
                  </button>
                  {/* <button class="dropdown-item" type="button">
                  Something else here
                </button> */}
                </div>
              </div>
            </div>
          </div>
          <div
          // className="iframe-container"
          >
            <iframe
              //
              width="100%"
              height="600px"
              frameborder="0"
              // allowFullScreen
              // height="400px"
              // src={powerBiUrl}
              src={powerBiUrl}
            ></iframe>
          </div>
        </>
      )}
    </div>
  )
}

export default TestHistoryTabledata
