/** * Component: Dashboard
 * File: AutomationTestHistoryTableData.jsx
 * Description: This file contents the implementation of Automation Test History Table Data and Analytics Data.
 * Author: Yuvaraj Dakhane,Mounika,Prasanna
 * **/
import React, { useState, useEffect } from "react"
import ModalPopup from "../../../components/ReusableComponents/Modal/Modal"
import Modal from "../../../components/RerunTestcases/RerunModelPopup"
import "../AutomationTesting/AutomationTestHistory"
import Log from "../../../assets/images/logs.png"
import SearchIcon from "../../../assets/images/Search.svg"
import log_light from "../../../assets/images/icons8-log-58.png"
import Report from "../../../assets/images/Report.png"
import Report_light from "../../../assets/images/icons8-reports-58.png"
import mailreport from "../../../assets/images/email_logo.png"
import Mail_light from "../../../assets/images/icons8-mail-48.png"
import Video from "../../../assets/images/video_plus_icon1.svg"
import Video_light from "../../../assets/images/icons8-video-64.png"
import powerbi from "../../../assets/images/power-bi.svg"
import powerbi_light from "../../../assets/images/icons8-power-bi.svg"
import axios from "axios"
import {
  Button,
  FormControl,
  IconButton,
  Input,
  InputAdornment,
  InputLabel,
} from "@mui/material"
import {
  MAIL_REPORT_API,
  VALIDATE_BUYLICENSE_STATUS,
  TRIGGER_TEST_API,
  RERUN_TESTCASES_API,
} from "../../../services/api"
import Arrow from "../../../assets/images/Arrow 2.svg"
import Rerun from "../../../assets/images/undo-dark.png"
import Arrow_light from "../../../assets/images/icons8-back-arrow-96.png"
import { Alert, Snackbar } from "@mui/material"
import { Tooltip } from "@mui/material"
import "../../Automation/Table/OngoingTestTableData.css"
import "react-toastify/dist/ReactToastify.css"
import { useTheme } from "../../../components/ThemeToggle/ThemeContext"
import { tooltipClasses } from "@mui/material/Tooltip"
import { styled } from "@mui/material/styles"
const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(to right, #034e88, #40a7f6) !important",
    color: "white !important",
    boxShadow: theme.shadows[1],
  },
}))
const TestHistoryTabledata = ({
  testhistorydata,
  loading,
  indexOfFirstPost,
  valuetosend,
  valuetosendSearch,
}) => {
  const { theme } = useTheme()
  const TooltipComponent = theme === "dark" ? Tooltip : LightTooltip
  const userProfile = JSON.parse(sessionStorage.getItem("userData"))
  const platform_data = JSON.parse(sessionStorage.getItem("platform"))
  const [searchAutomationValue, SetSearchAutomationValue] = useState("")
  const [Status, setStatus] = useState("")
  const [reportError, setReportError] = useState("")
  const [confirmation, setConfirmation] = useState("")
  const [mailConfirmation, setMailConfirmation] = useState(false)
  const [powerBIAction, setPowerBIAction] = useState(false)
  const [powerBiUrl, setPowerBiUrl] = useState("")
  const [alertRerun, setAlertRerun] = useState(false)
  const [testcasesItem, setTestcasesItem] = useState({})
  useEffect(() => {
    ValidateLicensestatus()
  })

  if (loading) {
    return <h2>Loading...</h2>
  }

  const sendmaildata = (report) => {
    axios
      .post(
        MAIL_REPORT_API +
          JSON.stringify({ email: userProfile.email_id, report_link: report })
      )
      .then((response) => {
        console.log(response.data, "sendreport")
        setMailConfirmation(response.data.valid)
      })
  }


  const reportaction = (report) => {
    if (report.includes("http") && platform_data !== "Transportation") {
      window.open(report, "_blank");
    } else if (
      report.includes("http") &&
      platform_data === "Transportation" &&
      userProfile.username === "suhas"
    ) {
      downloadFile(report);
    } else if (report.includes("http") && platform_data === "Transportation") {
      window.open(report, "_blank");
    } else {
      setReportError("URL Not found");
    }
  };
  const downloadFile = (report) => {
    // Create a Blob containing the file data
    const fileData = new Blob(["Your file content here"], {
      type: "text/plain",
    })

    // Create a temporary URL for the file
    const fileUrl = report

    // Create an anchor tag with download attribute and simulate a click event
    const a = document.createElement("a")
    a.href = fileUrl
    a.download = "example.txt" // specify the filename
    document.body.appendChild(a)
    a.click()
    // Clean up by removing the temporary URL and anchor tag
    // URL.revokeObjectURL(fileUrl)
    document.body.removeChild(a)
  }
  const reportactionPowerBI = (report) => {
    setPowerBIAction(true)
    setPowerBiUrl(
      "https://app.powerbi.com/reportEmbed?reportId=bc6ef75d-9648-4f50-9b58-4f68125262db&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
    )
    valuetosend(true)
  }

  const displayDashboard = () => {
    setPowerBIAction(false)
    valuetosend(false)
  }

  const handleTestCases = (item) => {
    const data = item.test_case_name
      .slice(0, 5)
      .map((itestcases) => <li>{itestcases}</li>)
    return data
  }

  const ValidateLicensestatus = async () => {
    axios
      .post(
        VALIDATE_BUYLICENSE_STATUS +
          JSON.stringify({
            licensee: [userProfile.username],
          }) +
          "&attributes=" +
          JSON.stringify(["status"])
      )

      .then((res) => {
        setStatus(Object.values(res.data)[0])
        console.log("apidata status", res.data.status[0] === "Active")
        if (res.data.status.length === 0) {
          setStatus("Not Activated")
        } else {
          setStatus(res.data.status[0])
        }
      })
      .catch((er) => console.log(er))
  }

  const enterkeyAPIHandler = (event) => {
    const trim_string = event.target.value.trim()
    SetSearchAutomationValue(trim_string)
    console.log("SearchAutoValue", searchAutomationValue)
    if (event.code === "Enter" || event.code === "NumpadEnter") {
      event.preventDefault()
      valuetosendSearch(searchAutomationValue)
    }
  }
  const getRerunDetails = (item) => {
    console.log(item, "rerun")
    setAlertRerun(true)
    setTestcasesItem(item)
  }
  const handleCloseRerun = () => {
    setAlertRerun(false)
    setTestcasesItem({})
  }
  const handleYesRerun = () => {
    setAlertRerun(false)
    reRunData()
  }
  const reRunData = () => {
    var requestString = {
      locked_by: userProfile.username,
      trigger_id: testcasesItem.trigger_id,
      TestSuite:
        testcasesItem.test_suite === "NA" ? "NA" : testcasesItem.test_suite,
      TestCase:
        testcasesItem.test_case_name === "NA"
          ? []
          : testcasesItem.test_case_name,
      device_name: testcasesItem.device_name,
      agent_id: testcasesItem.agent_id,
      Report:
        "EVQUAL" +
        (testcasesItem.exec_reports.split("EvQUAL")[1]).replace("report", "log"),
      execution_id: [testcasesItem.execution_id],
    }

    console.log("triggertest rerun", requestString)
    axios
      .post(RERUN_TESTCASES_API + `${JSON.stringify(requestString)}`)
      .then((response) => {
        setTestcasesItem({})
        console.log(response.data.message, "success")
        if (
          response.data.message ===
          "Backend Server Error, please try again after sometime"
        ) {
          setReportError(response.data.message)
        } else if (response.data === "sent data to jc") {
          setConfirmation("Sent Data to JC")
        } else {
          setConfirmation(response.data)
        }

        // setNotification(response.data.Message)
        // toast.success("Executing Testcase", {
        //   position: toast.POSITION.TOP_CENTER,
        // })
      })
      .catch((error) => {
        setTestcasesItem({})
        setReportError(error)
        console.log(error, "error")
      })
  }
  return (
    <div
      className={`table-container table table-responsive  ${
        theme === "dark" ? "dark" : "light"
      }`}
    >
      <div>
        {alertRerun && (
          <Modal
            model_title="Rerun Confirmation"
            canShow={"yes"}
            // model_body={[testcasesItem.test_case_name, testcasesItem.status]}
            model_body="Would you like to Rerun this test - 'Test Reference'"
            handleClose={handleCloseRerun}
            handleYes={handleYesRerun}
          ></Modal>
        )}
        <Snackbar
          className={`delete-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          open={mailConfirmation}
          autoHideDuration={6000}
          onClose={() => setMailConfirmation(false)}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          {mailConfirmation === "true" && (
            <Alert icon={false}>Report has sent to your Mail Id</Alert>
          )}
        </Snackbar>
        <Snackbar
           className={`delete-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          open={confirmation}
          autoHideDuration={6000}
          onClose={() => setConfirmation("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          {confirmation && <Alert icon={false}>{confirmation}</Alert>}
        </Snackbar>
        <Snackbar
           className={`delete-alert-message ${
            theme === "dark" ? "dark" : "light"
          }`}
          open={reportError}
          autoHideDuration={6000}
          onClose={() => setReportError("")}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert icon={false}>{reportError}</Alert>
        </Snackbar>
      </div>
      {!powerBIAction && (
        <h3
          className={`table_mainhead_dashboard ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          Automation Dashboard
        </h3>
      )}
      {powerBIAction && (
        <h2
          className={`table_mainhead_dashboard ${
            theme === "dark" ? "dark" : "light"
          }`}
        >
          Analytics Dashboard
        </h2>
      )}
      {!powerBIAction && (
        <div className="searchDashboard">
          <FormControl
            className={`search-field-status-monitor ${
              theme === "dark" ? "dark" : "light"
            }`}
            variant="standard"
            color="secondary"
          >
            <Input
              autoComplete="off"
              id="search-devices"
              placeholder="Search"
              type="text"
              onKeyUp={enterkeyAPIHandler}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton>
                    <img
                      className="search-icon"
                      alt="SearchIcon"
                      src={SearchIcon}
                      title="SearchIcon"
                      onClick={() => valuetosendSearch(searchAutomationValue)}
                    />
                  </IconButton>
                </InputAdornment>
              }
            />
          </FormControl>
        </div>
      )}
      {!powerBIAction && (
        <>
          <table class="table">
            <thead className="table_head ">
              <tr className="table_header text-center">
                <th scope="col">SI_No</th>
                <th scope="col">Test Reference</th>
                <th scope="col"> Device Name</th>
                <th scope="col">Start Time</th>
                <th scope="col">Test Case</th>
                <th scope="col">Status</th>
                <th scope="col">Result</th>
                <th scope="col">Logs</th>
                <th scope="col">Reports</th>
                <th scope="col">Mail</th>
                <th scope="col">Rerun</th>
                {platform_data !== "Transportation" && (
                  <th scope="col">PowerBI</th>
                )}
              </tr>
            </thead>
            {testhistorydata.length === 0 ? (
              <div
                className={`table-empty-message  ${
                  theme === "dark" ? "dark" : "light"
                }`}
              >
                No Data Available
              </div>
            ) : (
              <tbody className="table_body text-left">
                {testhistorydata.map((item, index) => {
                  return (
                    <tr
                      style={{ fontSize: "14px" }}
                      className="text-center"
                      key={index}
                    >
                      <td data-label="SI_NO">{indexOfFirstPost + index + 1}</td>
                      <td data-label="Test Reference">{item.test_reference}</td>
                      <td data-label="Device Name">{item.device_name}</td>
                      <td data-label="Start Time">{item.date_and_time}</td>
                      {/* <td>{item.date_and_time}</td> */}
                      {/* <td>
                        {new Date(item.date_and_time).toLocaleString("en-US", {
                          timeZone: "UTC",
                        })}
                      </td> */}
                      {/* <td>
                        {item.date_and_time.split(" ")[0]}{" "}
                        {item.date_and_time.split(" ")[1]}
                      </td> */}
                      <TooltipComponent
                        multiline={true}
                        title={
                          item.test_case_name.length > 1 &&
                          handleTestCases(item)
                        }
                        placement="bottom-end"
                      >
                        <td data-label="Test Case">
                          {item.test_case_name[0].length > 30
                            ? item.test_case_name[0].substring(0, 30) + "..."
                            : item.test_case_name[0]}
                        </td>
                      </TooltipComponent>
                      <td data-label="Status">{item.status}</td>
                      <td data-label="Result">{item.result}</td>
                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td data-label="Logs">
                            <img
                              style={{
                                border: "none",
                                height: "6vh",
                                width: "6vh",
                                cursor: "not-allowed",
                              }}
                              src={theme === "dark" ? Log : log_light}
                              alt="Logs"
                              title="Logs"
                              disabled={Status !== "Active"}
                              className={
                                item.status === "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td data-label="Logs">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                            }}
                            src={theme === "dark" ? Log : log_light}
                            alt="Logs"
                            title="Logs"
                            disabled={Status !== "Active"}
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              reportaction(item.dev_logs)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}
                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td data-label="Report">
                            <img
                              style={{
                                border: "none",
                                height: "6vh",
                                width: "6vh",
                                cursor: "not-allowed",
                              }}
                              src={theme === "dark" ? Report : Report_light}
                              disabled={Status !== "Active"}
                              title="Reports"
                              alt="Reports"
                              className={
                                item.status === "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td data-label="Report">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                            }}
                            src={theme === "dark" ? Report : Report_light}
                            title="Reports"
                            disabled={Status !== "Active"}
                            alt="Reports"
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              reportaction(item.exec_reports)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}

                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td data-label="Mail">
                            <img
                              style={{
                                border: "none",
                                height: "6vh",
                                width: "6vh",
                                cursor: "not-allowed",
                              }}
                              src={theme === "dark" ? mailreport : Mail_light}
                              alt="Mail"
                              title="Mail"
                              disabled={Status !== "Active"}
                              className={
                                item.status === "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td data-label="Mail">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                            }}
                            src={theme === "dark" ? mailreport : Mail_light}
                            alt="Mail"
                            title="Mail"
                            disabled={Status !== "Active"}
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              sendmaildata(item.exec_reports)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}
                      {Status !== "Active" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td data-label="Rerun">
                            <img
                              style={{
                                border: "none",
                                height: "6vh",
                                width: "6vh",
                                cursor: "not-allowed",
                              }}
                              src={theme === "dark" ? Rerun : Rerun}
                              alt="Rerun"
                              title="Rerun"
                              disabled={Status !== "Active"}
                              className={
                                item.status === "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" ? (
                        <td data-label="Rerun">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                            }}
                            src={theme === "dark" ? Rerun : Rerun}
                            alt="Rerun"
                            title="Rerun"
                            disabled={Status !== "Active"}
                            className={
                              item.status === "Completed" &&
                              item.result === "Fail" &&
                              item.report !== "undefined"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              getRerunDetails(item)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}

                      {Status !== "Active" &&
                      platform_data !== "Transportation" ? (
                        <Tooltip
                          title={<td>License is {Status}</td>}
                          className="tooltip-display"
                        >
                          <td data-label="PowerBI">
                            <img
                              style={{
                                border: "none",
                                height: "6vh",
                                width: "6vh",
                                cursor: "not-allowed",
                              }}
                              src={theme === "dark" ? powerbi : powerbi_light}
                              disabled={Status !== "Active"}
                              alt="PowerBI"
                              title="PowerBI"
                              className={
                                item.status === "Completed"
                                  ? "btn btn-md p-2"
                                  : "btn disabled p-2 "
                              }
                            />
                          </td>
                        </Tooltip>
                      ) : Status === "Active" &&
                        platform_data !== "Transportation" ? (
                        <td data-label="PowerBI">
                          <img
                            style={{
                              border: "none",
                              height: "6vh",
                              width: "6vh",
                            }}
                            src={theme === "dark" ? powerbi : powerbi_light}
                            title="PowerBI"
                            disabled={Status !== "Active"}
                            alt="PowerBI"
                            className={
                              item.status === "Completed"
                                ? "btn btn-md p-2"
                                : "btn disabled p-2 "
                            }
                            onClick={() => {
                              reportactionPowerBI(item.power_bi)
                            }}
                          />
                        </td>
                      ) : (
                        <div></div>
                      )}
                    </tr>
                  )
                })}
              </tbody>
            )}
          </table>
        </>
      )}
      {powerBIAction && (
        <>
          <div class="powerBi-main">
            <button
              onClick={displayDashboard}
              className={`Dashboard-Back ${
                theme === "dark" ? "dark" : "light"
              }`}
            >
              <img
                src={theme === "dark" ? Arrow : Arrow_light}
                alt="Arrow"
                className={`Arrow ${theme === "dark" ? "dark" : "light"}`}
              ></img>
              Dashboard
            </button>
            <div
              class="btn-group"
              role="group"
              aria-label="Basic outlined example"
            >
              <button
                className={`Dashboard-Back-buttons ${
                  theme === "dark" ? "dark" : "light"
                }`}
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=bc6ef75d-9648-4f50-9b58-4f68125262db&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Report Summary
              </button>
              <button
                className={`Dashboard-Back-buttons ${
                  theme === "dark" ? "dark" : "light"
                }`}
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=0efe0f96-72b9-4a4d-9c1a-bb07ff5503c7&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Detailed Report
              </button>
              <button
                className={`Dashboard-Back-buttons ${
                  theme === "dark" ? "dark" : "light"
                }`}
                onClick={() =>
                  setPowerBiUrl(
                    "https://app.powerbi.com/reportEmbed?reportId=44457f87-5cee-433e-b0ad-ef00d82c2e1b&autoAuth=true&ctid=311b3378-8e8a-4b5e-a33f-e80a3d8ba60a"
                  )
                }
              >
                Failure Analysis
              </button>
              <div class="dropdown">
                <button
                  class={`btn btn-secondary dropdown-toggle ${
                    theme === "dark" ? "dark" : "light"
                  }`}
                  type="button"
                  id="dropdownMenu2"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <img
                    src={theme === "dark" ? Video : Video_light}
                    alt="Video"
                    className={`Video-icon ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  ></img>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                  <button
                    class={`dropdown-item ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    type="button"
                    onClick={() =>
                      setPowerBiUrl(
                        "https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Etisalat/Test_Record/2023-09-1221_23_captured_video.webm"
                      )
                    }
                  >
                    Test Record
                  </button>
                  <button
                    class={`dropdown-item ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                    type="button"
                    onClick={() =>
                      setPowerBiUrl(
                        "https://elasticbeanstalk-ap-south-1-509040541908.s3.ap-south-1.amazonaws.com/EvQUAL/Video_Quality/EvQUAL_Video_Quality_Report.pdf"
                      )
                    }
                  >
                    Quality Report
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <iframe
              width="100%"
              height="600px"
              frameborder="0"
              src={powerBiUrl}
              title="PowerBI"
            ></iframe>
          </div>
        </>
      )}
    </div>
  )
}

export default TestHistoryTabledata
