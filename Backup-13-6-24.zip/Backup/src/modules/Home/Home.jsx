import React, { useEffect } from "react"
import "./Home.css"
import { useState } from "react"
import Loader from "../../components/ReusableComponents/Loader/Loader"
import { HomeData } from "../../services/ApiFunction"
import Arrow from "../../../src/assets/images/Arrow 2.svg"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { Breadcrumbs, Typography } from "@mui/material"
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft"
import { useTheme } from "../../components/ThemeToggle/ThemeContext"

function Home() {
  const { theme } = useTheme()
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const [platformData, setplatformData] = useState(
    location.state?.data.platform ?? ""
  )
  // if (theme === "dark") {
  //   document.documentElement.classList.remove("light")
  //   document.documentElement.classList.add("dark")
  // } else {
  //   document.documentElement.classList.remove("dark")
  //   document.documentElement.classList.add("light")
  // }
  useEffect(() => {
    if (platformData) {
      sessionStorage.setItem("platform", JSON.stringify(platformData))
    }
  }, [platformData])
  // const home_data = JSON.parse(sessionStorage.getItem("platform"))
  // console.log(platformData, "platformData")
  // const navigate = useNavigate()
  const [remotePageData, setRemotePageData] = useState([])
  const [uniqueRemotePageData, SetUniqueRemotePageData] = useState([])

  let size
  if (remotePageData.length >= 5) {
    size = 4
  } else {
    size = 3
  }
  useEffect(() => {
    getRemoteDevices()
    console.log(platformData, "platformData2")
  }, [platformData])

  const getRemoteDevices = async function () {
    try {
      setLoading(true)
      let response = await HomeData.HomePageData(location.state?.data.platform)
      setRemotePageData(response.data)
      console.log(response.data, "data-Media")
      const unique = [
        ...new Map(
          response.data.map((item) => [item["device_category"], item])
        ).values(),
      ]
      SetUniqueRemotePageData(unique)
      setLoading(false)
    } catch (error) {
      console.log(error)
    }
  }

  const preventDragHandler = (e) => {
    e.preventDefault()
  }

  return (
    <>
      <Breadcrumbs separator={<KeyboardArrowLeft />} aria-label="breadcrumb">
        <Link to={"/platform"} onDragStart={preventDragHandler}>
          Platform
        </Link>
        {platformData === "Media And Entertainment" ? (
          <Typography>M&E</Typography>
        ) : (
          <Typography>{platformData}</Typography>
        )}
      </Breadcrumbs>
      {loading === false ? (
        <div className={`home_remote ${theme === "dark" ? "dark" : "light"}`}>
          <div
            className={`home_re-category  ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Category
          </div>
          <div
            className={`home_re-sub-heading ${
              theme === "dark" ? "dark" : "light"
            }`}
          >
            Select a category to get Started
          </div>
          <div
            className="re-category-container"
            style={{
              display: "grid",
              "grid-template-columns": "repeat(" + size + ", 1fr)",
            }}
          >
            {uniqueRemotePageData.map((remoteItems) => {
              return remoteItems.device_category === "5G" ? (
                <div className="remote-items hover">
                  <Link
                    to="https://reviewltts.azurewebsites.net/"
                    state={{ data: remoteItems }}
                  >
                    <img
                      className="remote-item-img"
                      src={remoteItems.light_theme_image_url}
                      alt="Remote Item"
                      onDragStart={preventDragHandler}
                    />
                  </Link>
                  <h3
                    className={`home_remote-item-title ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    {remoteItems.device_category}
                  </h3>
                </div>
              ) : remoteItems.device_category === "AV" ? (
                <div className="remote-items hover">
                  <Link to={"/platform/M&E/AV"} state={{ data: remoteItems }}>
                    <img
                      className="remote-item-img"
                      src={remoteItems.thumbnail_url}
                      alt="Remote Item"
                      onDragStart={preventDragHandler}
                    />
                  </Link>
                  <h3
                    className={`home_remote-item-title ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    {remoteItems.device_category}
                  </h3>
                </div>
              ) : (
                <div className="remote-items hover">
                  {platformData === "Media And Entertainment" ? (
                    <Link
                      to={"/platform/M&E/DeviceFilter"}
                      state={{ data: remoteItems }}
                    >
                      <img
                        className="remote-item-img"
                        src={remoteItems.thumbnail_url}
                        alt="Remote Item"
                        onDragStart={preventDragHandler}
                      />
                    </Link>
                  ) : (
                    <Link
                      to={"/platform/" + platformData + "/DeviceFilter"}
                      state={{ data: remoteItems }}
                    >
                      <img
                        className="remote-item-img"
                        src={remoteItems.thumbnail_url}
                        alt="Remote Item"
                        onDragStart={preventDragHandler}
                      />
                    </Link>
                  )}
                  <h3
                    className={`home_remote-item-title ${
                      theme === "dark" ? "dark" : "light"
                    }`}
                  >
                    {remoteItems.device_category}
                  </h3>
                </div>
              )
            })}
          </div>
        </div>
      ) : (
        <div>
          <Loader />
        </div>
      )}
    </>
  )
}
export default Home
