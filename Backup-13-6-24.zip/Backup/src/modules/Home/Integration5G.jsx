import React, { useEffect } from "react"
//import "./Home.css"
import { useState } from "react"
import Loader from "../../components/ReusableComponents/Loader/Loader"
import { HomeData } from "../../services/ApiFunction"
import Arrow from "../../../src/assets/images/Arrow 2.svg"
import { Link, useLocation, useNavigate } from "react-router-dom"


function Home() {
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const [platformData, setplatformData] = useState(
    location.state?.data.platform ?? ""
  )
  useEffect(() => {
    if (platformData) {
      sessionStorage.setItem("platform", JSON.stringify(platformData))
    }
  }, [platformData])
  const home_data = JSON.parse(sessionStorage.getItem("platform"))
  console.log(platformData, "platformData")
  const navigate = useNavigate()
  const [remotePageData, setRemotePageData] = useState([])
  const [uniqueRemotePageData, SetUniqueRemotePageData] = useState([])

  let size
  if (remotePageData.length >= 5) {
    size = 4
  } else {
    size = 3
  }
  useEffect(() => {
    getRemoteDevices()
    console.log(platformData, "platformData2")
  }, [platformData])

  const getRemoteDevices = async function () {
    try {
      setLoading(true)
      let response = await HomeData.HomePageData(location.state?.data.platform)
      setRemotePageData(response.data)
      console.log(response.data, "data-Media")
      const unique = [
        ...new Map(
          response.data.map((item) => [item["device_category"], item])
        ).values(),
      ]
      SetUniqueRemotePageData(unique)
      setLoading(false)
    } catch (error) {
      console.log(error)
    }
  }
  const homeBack = function () {
    navigate(-1)
  }

  return (
    <>
      {loading === false ? (
        <div className="remote">
          <div className="DevicesView">
            <div className="home-back-navigation">
              <img src={Arrow} onClick={homeBack} alt="Arrow" />
              <div className="device-txt" onClick={homeBack}>
                Platform
              </div>
            </div>
          </div>
          <div className="re-category">5G</div>
         
          <div>
            <iframe src="https://reviewltts.azurewebsites.net/" 
            style={{alignItems:"center",width:"100%",height:"400px"}}></iframe>
          </div>
        </div>
      ) : (
        <div>
          <Loader />
        </div>
      )}
    </>
  )
}

export default Home
