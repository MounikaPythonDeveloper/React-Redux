const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser')
const app = express();

app.use(bodyParser.text())
app.use(cors())

async function getProjectStructure(dir) {
    const items = await fs.readdir(dir);
    const structure = await Promise.all(
      items.map(async item => {
        const itemPath = path.join(dir, item);
        const stats = await fs.stat(itemPath);
        if (stats.isDirectory()) {
          return {  
            name: item,
              type: 'directory',
              children: await getProjectStructure(itemPath), // Recursively fetch subdirectories
            };
          } else {
            return {
              name: item,
              type: 'file',
              path: itemPath, // Include the file path
            };
          }
        })
      );
     
      return structure;
    }
    
    app.get('/api/project-structure', async (req, res) => {
      try {
        const projectDirectory = '/home/ubuntu/Paramount-Sandbox/PL/Current PL Server/S29-demo-latest/'; // Replace with your actual directory path
        const projectStructure = await getProjectStructure(projectDirectory);
        res.json(projectStructure);
      } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Unable to retrieve project structure' });
      }
    });
    
    app.get('/api/get-file-content', async (req, res) => {
        try {
            const filePath = req.query.filePath; // Get the file path from the request query
            const fileContent = await fs.readFile(filePath, 'utf-8'); // Read the file content
            res.send(fileContent);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Unable to retrieve file content' });
        }
    });

    app.post('/api/save-file', async (req, res) => {
        try{
            const content = req.body;
            const filePath = req.query.filePath;
            await fs.writeFile(filePath, content, 'utf-8')
            res.status(200).send('File Save Successfully');
        } catch(error){
            const content = req.body;
            const filePath = req.query.filePath;
            console.log(content, filePath)
            console.error('Error saving file')
            res.status(500).send('Error saving file');
        }
    });
app.listen(3007, () => {
  console.log('Server is running on port "3007"');
});