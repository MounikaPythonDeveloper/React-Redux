module.exports = {
  testEnvironment: "jsdom",

  setupFilesAfterEnv: ["<rootDir>/setupTests.js"],

  roots: ["<rootDir>/src"],

  testMatch: ["**/__tests__/**/*js?(x)", "**/?(*.)+(spec|test).js?(x)"],
}
