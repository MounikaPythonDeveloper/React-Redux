from flask import Flask, request, jsonify
import Video_metrics_function
from flask_cors import CORS, cross_origin
import json
import csv_to_pdf
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'


# @cross_origin()
# @app.route('/video_metrics/<int:port>', methods=['GET'])
# def video_metrics(port):
#     result = Video_metrics_function.video_metrics(port, 1)
#     get_device_name = lambda \
#         port: "AppleTV" if port == 0 else "Roku TV" if port == 1 else "FireStick" if port == 2 else "XBOX" if port == 3 else "Unknown Device"
#     device_name = get_device_name(port)
#     result["device_name"] = device_name
#     print(jsonify(result))
#     return jsonify(result)
@app.route("/")
@cross_origin()
def hello_world():
    return "APIs in Master Service Layer"

@cross_origin()
@app.route('/video_metrics_url_etisalat', methods=['GET'])
def video_metrics_url():
    attributes = request.args.get('data')
    json1_data = json.loads(attributes)
    keys = json1_data.keys()
    for i in keys:
        print(json1_data[i])
    print(json1_data["url"])
    url = json1_data["url"]
    trigger_id = json1_data["trigger_id"]
    result = Video_metrics_function.video_metrics(url,1, trigger_id)

    print(jsonify(result))
    return jsonify(result)


@cross_origin()
@app.route('/generate_pdf_video_quality_etisalat', methods=['GET'])
def generate_pdf_video_quality():
    # attributes = request.args.get('data')
    # json1_data = json.loads(attributes)
    # keys = json1_data.keys()
    # for i in keys:
    #     print(json1_data[i])
    # # print(json1_data["url"])
    # # url = json1_data["url"]
    # trigger_id = json1_data["trigger_id"]
    # user_name = json1_data["user_name"]
    # action = json1_data["action"]
    # if user_name == "akshitha":
    #     agent_id = "AgentEtisalat_VideoQuality"
    # else:
    #     agent_id = "Agent8Server_LiveVideoQuality"
    # print(agent_id)
    # if action == "generate_report":
    #     print("Generating Report")
    #     status = csv_to_pdf.convert_csv_to_pdf(trigger_id)
    #     print(status)
    #     data = {"trigger_id":trigger_id , "agent_id":agent_id , "action":action}
    #     result = Video_metrics_function.post_data_generate_vq_report(data)
    # else:
    #     print("Sending data to JC for deleting csv file")
    #     data = {"trigger_id": trigger_id, "agent_id": agent_id, "action": action}
    #     result = Video_metrics_function.post_data_generate_vq_report(data)
    # return result
    attributes = request.args.get('data')
    json1_data = json.loads(attributes)
    keys = json1_data.keys()
    for i in keys:
        print(json1_data[i])
    print(json1_data["url"])
    url = json1_data["url"]
    device_name = json1_data["device_name"]
    if url == "":
        case = "Device"
        case_type = device_name
    else:
        case = "url"
        case_type = url
    print(case)
    print(case_type)

    trigger_id = json1_data["trigger_id"]
    user_name = json1_data["user_name"]
    action = json1_data["action"]
    data = {"trigger_id": trigger_id, "video_details": case_type, "status": "Pending", "locked_by": user_name,
            "platform": "Media And Entertainment"}
    result = Video_metrics_function.post_vq_report_status_db(data)
    # print (f"status of sending data to db :{result}")

    if user_name == "akshitha":
        agent_id = "AgentEtisalat_VideoQuality"
    else:
        agent_id = "Agent8Server_LiveVideoQuality"
    print(agent_id)
    if action == "generate_report":
        print("Generating Report")
        status = csv_to_pdf.convert_csv_to_pdf(trigger_id, case, case_type)
        print(status)
        data = {"trigger_id": trigger_id, "agent_id": agent_id, "action": action}
        print(data)
        result = Video_metrics_function.post_data_generate_vq_report(data)

    else:
        print("Sending data to JC for deleting csv file")
        data = {"trigger_id": trigger_id, "agent_id": agent_id, "action": action}
        print(data)
        result = Video_metrics_function.post_data_generate_vq_report(data)
        print("the result is", result)
    return result

# generate_pdf_video_quality({})
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)