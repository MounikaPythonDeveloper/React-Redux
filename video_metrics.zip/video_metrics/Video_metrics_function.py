import cv2
import imagehash
from PIL import Image
import time
import numpy as np
from skimage.metrics import structural_similarity
from datetime import datetime
import os
import csv
import requests
import json
S = '/home/sysuser/PycharmProjects/video_quality_analysis/black_screen'
#S = 'black_screen'
jc5_ip = '3.111.103.153:5003'


# import time
output_directory = 'blurred_frames'
os.makedirs(output_directory, exist_ok=True)




def capture_frames_for_duration(video_path, duration):
    cap = cv2.VideoCapture(video_path)
    cap.set(cv2.CAP_PROP_FPS, 60)
    frames = []
    start_time = time.time()
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    fps = cap.get(cv2.CAP_PROP_FPS)
    codec = int(cap.get(cv2.CAP_PROP_FOURCC))  # Codec as four-character code

    # Calculate the expected time interval between frames
    expected_frame_interval = 1.0 / fps

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        # Check if the processing of frames is taking longer than the expected time between frames
        current_time = time.time()
        if current_time - start_time > duration:
            break
        frames.append(frame)

        # Ensure that we maintain the desired frame rate
        expected_next_frame_time = start_time + len(frames) * expected_frame_interval
        while time.time() < expected_next_frame_time:
            time.sleep(0.001)  # Adjust as needed to maintain accuracy

    cap.release()
    processed_frames = len(frames)
    total_frames = fps * duration
    frames_dropped = total_frames - processed_frames
    drop_percentage = (frames_dropped / total_frames) * 100 if total_frames > 0 else 0

    # Convert codec to four-character code string
    codec_str = "".join([chr((codec >> 8 * i) & 0xFF) for i in range(4)])

    return frames, width, height, fps, drop_percentage, frames_dropped, codec_str

def is_black_frame(frame, black_hash, threshold=4):
    pil_frame = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    frame_hash = imagehash.average_hash(pil_frame)

    return frame_hash - black_hash < threshold


def calculate_psnr(original_frame, processed_frame):
    original_frame = original_frame.astype(np.float64)
    processed_frame = processed_frame.astype(np.float64)

    mse = np.mean((original_frame - processed_frame) ** 2)
    if mse == 0:
        return float('inf')

    max_pixel_value = 255.0
    psnr = 20 * np.log10(max_pixel_value) - 10 * np.log10(mse)
    return psnr


def calculate_blocking_banding_counts(frame, block_threshold, banding_threshold):
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    diff_blocks = np.abs(np.diff(gray_frame, axis=0))
    blocking_pixels = np.sum(diff_blocks > block_threshold)

    diff_pixels = np.abs(np.diff(gray_frame, axis=1))
    banding_pixels = np.sum(diff_pixels > banding_threshold)

    return blocking_pixels, banding_pixels


def calculate_blocking_banding_rates_from_frame(frame, block_threshold_factor=0.0001, banding_threshold_factor=0.02):
    block_threshold = int(np.max(frame) * block_threshold_factor)
    banding_threshold = int(np.max(frame) * banding_threshold_factor)

    blocking_pixels, banding_pixels = calculate_blocking_banding_counts(frame, block_threshold, banding_threshold)

    total_pixels = frame.shape[0] * frame.shape[1]
    if total_pixels == 0:
        print("Error: The total number of pixels is zero.")
        return

    blocking_rate = blocking_pixels / total_pixels * 100
    banding_rate = banding_pixels / total_pixels * 100

    # print(f"Blocking Artifact Rate: {blocking_rate:.2f}%, Banding Artifact Rate: {banding_rate:.2f}%")
    return blocking_rate, banding_rate


def compute_blur(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    return laplacian_var


def detect_blur(frame):
    blur_score = compute_blur(frame)

    threshold = 100.0

    cv2.putText(frame, f'Blur: {blur_score:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    if blur_score < threshold:
        print("Blurry frame detected!")
        # Save the blurry frame to the output directory with a unique filename
        c = datetime.now()
        timestamp = c.strftime("%d%m_%H%M%S_%f")
        frame_name = f'frame_{timestamp}.jpg'
        frame_filename = os.path.join(output_directory, frame_name)
        cv2.imwrite(frame_filename, frame)
        res = "Blur Detected at" + frame_name + " : " + str(blur_score)
        return res


def calculate_ssim(frame1, frame2):
    # Calculate SSIM
    ssim_threshold = 0.8
    gray_frame1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    gray_frame2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    ssim_score = structural_similarity(gray_frame1, gray_frame2)

    # Classify based on the SSIM threshold
    # if ssim_score < ssim_threshold:
    #     print("Macroblocking Detected")
    # else:
    #     print("No Macroblocking")

    return ssim_score


video_url = 'https://www.youtube.com/watch?v=93nZzGeNEt8&ab_channel=WBFFFOX45Baltimore'


def get_download_speed(url):
    try:
        start_time = time.time()
        response = requests.get(url)
        end_time = time.time()

        if response.status_code == 200:
            download_speed = len(response.content) / (end_time - start_time) / 1024  # KB/s
            return download_speed
        else:
            print(f"Error: {response.status_code}")
            return None

    except Exception as e:
        print(f"Error: {e}")
        return None


def measure_connection_speed(video_url):
    speed = get_download_speed(video_url)

    if speed is not None:
        return round(speed, 2)
    else:
        return None


def measure_network_activity(video_url):
    start_time = time.time()
    response = requests.get(video_url, stream=True)
    end_time = time.time()

    if response.status_code == 200:
        data_chunk = len(response.content) / 1024  # Convert bytes to KB
        # timestamp = time.strftime('%H:%M:%S')  # Display only time

        # print(f"{timestamp} - Network activity: {data_chunk:.2f} KB")
        return f"{round(data_chunk, 2)}Kb"
    else:
        print(f"Error: {response.status_code}")
        return None


def measure_latency(video_url):
    start_request_time = time.time()
    response = requests.get(video_url)
    end_request_time = time.time()

    if response.status_code == 200:
        latency = (end_request_time - start_request_time) * 1000  # Convert to milliseconds

        return f"{round(latency, 2)} ms"
    else:
        print(f"Error: {response.status_code}")
        return None


# def video_metrics(port, duration, trigger_id, threshold=5):
#     #port="https://www.sample-videos.com/video321/mp4/720/big_buck_bunny_720p_50mb.mp4"
#     frames, width, height, fps, drop_percentage,frames_dropped,codec = capture_frames_for_duration(port, duration)
#     resolution = width + " X " + height
#     black_frames = []
#     psnr_value = []
#     blocking_rate = []
#     banding_rate = []
#     ssim_score = []
#     blur = []
#     bs_list = []
#     prev_frame = None
#     black_pil = Image.open('%s.jpg' % S)
#     black_hash = imagehash.average_hash(black_pil)
#     for frame in frames:
#         is_black = is_black_frame(frame, black_hash, threshold)
#         if is_black:
#             black_frames.append(frame)
#
#         if prev_frame is not None:
#             psnr_value.append(float(calculate_psnr(prev_frame, frame)))
#             ssim_score.append(float(calculate_ssim(prev_frame, frame)))
#         prev_frame = frame
#
#         blocking, banding = calculate_blocking_banding_rates_from_frame(frame)
#         if blocking and banding:
#             blocking_rate.append(float(blocking))
#             banding_rate.append(float(banding))
#
#         blur_score = detect_blur(frame)
#         if blur_score:
#             blur.append(blur_score)
#
#         bs = compute_blur(frame)
#         if bs:
#             bs_list.append(bs)
#
#         # bs = compute_blur(frame)
#         # x=blur_score.append(bs)
#         # print("*******************************************",x)
#
#     c = datetime.now()
#     timestamp = c.strftime("%d%m_%H%M%S")
#     connection_speed = f"{measure_connection_speed(video_url)}KB/s"
#     network_activity = measure_network_activity(video_url)
#     # latency = measure_latency(video_url)
#     avg_bs = sum(bs_list) / len(bs_list) if bs_list else 0
#     # print(avg_bs)
#     max_psnr = max(psnr_value)
#     min_psnr = min(psnr_value)
#     avg_ssim = sum(ssim_score) / len(ssim_score) if ssim_score else 0
#     #print(avg_ssim)
#
#
#     avg_psnr = sum(psnr_value) / len(psnr_value)
#     #print(max_psnr,min_psnr,"are the psnr values")
#     psnr_diff = max_psnr - min_psnr
#     if psnr_diff == 0:
#         psnr_diff = 0.001
#     norm_psnr = ((avg_psnr - min_psnr) / (psnr_diff)) * 100
#     # print(norm_psnr)
#     # print(max(bs_list))
#     if avg_bs >= 100:
#         norm_bs = 100
#     else:
#         norm_bs = avg_bs
#
#     avg_blocking_rate = sum(blocking_rate) / len(blocking_rate)
#     avg_banding_rate = sum(banding_rate) / len(banding_rate)
#
#     # Quality_Score = ((0.3572 * (100 - avg_blocking_rate)) + (0.2857 * (100 - avg_banding_rate)) + (0.119 * norm_bs) + (
#     #             0.0595 * norm_psnr) + (0.1786 * (100 - drop_percentage)))
#     # print(Quality_Score)
#     Quality_Score = ((0.25 * (100 - avg_blocking_rate)) + (0.20 * (100 - avg_banding_rate)) + (
#             0.30 * avg_ssim) + (0.10 * norm_bs) + (0.05 * norm_psnr) + (
#                                  0.10 * (100 - drop_percentage)))
#     if avg_ssim < 0.8:
#         macroblocking = "Macroblocking Detected"
#     else:
#         macroblocking = "No Macroblocking"
#
#
#     # print(drop_percentage)
#     result = {"Resolution": resolution, "FPS": fps, "black_frames": len(black_frames),
#               "Avg_PSNR_Value": round(sum(psnr_value) / len(psnr_value),2),
#               "Blocking_Rate": str(round(sum(blocking_rate) / len(blocking_rate),2)),
#               "Banding_Rate": str(round(sum(banding_rate) / len(banding_rate),2)),
#               "Blur Detected": blur, "time_stamp": timestamp, "connection_speed": connection_speed,
#               "network_activity": network_activity, "Quality_Score": round(Quality_Score, 2),
#               "Blur_Score": round(avg_bs,2),"Dropped_Frames":frames_dropped,"ssim_score":round(avg_ssim,2),"macro_blocking":macroblocking}
#     print(result)
#
#     if blur == []:
#         blur_status = "No Blur"
#     else:
#         blur_status = "Blur Detected"
#
#     file_path = f'/home/sysuser/Documents/Project_M/AgentEtisalat_VideoQuality/workspace/AgentEtisalat/csv_files/{trigger_id}.csv'
#     data_to_append = [
#         [timestamp,(round(Quality_Score, 2)),resolution, fps, len(black_frames) ,(round(sum(psnr_value) / len(psnr_value),2)),(str(round(sum(blocking_rate) / len(blocking_rate),2))),(str(round(sum(banding_rate) / len(banding_rate),2))),blur_status, connection_speed,network_activity,round(avg_bs,2),frames_dropped,(round(avg_ssim,2)),macroblocking]
#     ]
#     if not os.path.exists(file_path):
#         # If the file doesn't exist, write the column names
#         with open(file_path, 'w', newline='') as csv_file:
#             csv_writer = csv.writer(csv_file)
#             # Specify column names
#             column_names = ['Timestamp' ,'Quality Score','Resolution', 'FPS', 'black_frames','Average PSNR','Blocking Rate','Banding Rate','Blur Detection','Connection Speed','Data Used','Blur Score','Dropped Frames', 'SSIM Score', 'Macroblocking']
#             print(len(column_names))
#             csv_writer.writerow(column_names)
#             csv_writer = csv.writer(csv_file)
#
#             # Append the data to the CSV file
#             csv_writer.writerows(data_to_append)
#     else:
#         # If the file exists, open it in append mode
#         with open(file_path, 'a', newline='') as csv_file:
#             csv_writer = csv.writer(csv_file)
#
#             # Append the data to the CSV file
#             csv_writer.writerows(data_to_append)
#
#
#     print(f'Data appended to CSV file at: {file_path}')
#
#
#     return result

def video_metrics(port, duration, trigger_id, threshold=5):
    # port="https://www.sample-videos.com/video321/mp4/720/big_buck_bunny_720p_50mb.mp4"
    frames, width, height, fps, drop_percentage, frames_dropped, codec = capture_frames_for_duration(port, duration)
    bit_rate = (width * height * fps * 1 / 10) * 0.000125
    resolution = str(width) + " X " + str(height)
    black_frames = []
    psnr_value = []
    blocking_rate = []
    banding_rate = []
    ssim_score = []
    blur = []
    bs_list = []
    prev_frame = None
    black_pil = Image.open('%s.jpg' % S)
    black_hash = imagehash.average_hash(black_pil)
    for frame in frames:
        is_black = is_black_frame(frame, black_hash, threshold)
        if is_black:
            black_frames.append(frame)

        if prev_frame is not None:
            psnr_value.append(float(calculate_psnr(prev_frame, frame)))
            ssim_score.append(float(calculate_ssim(prev_frame, frame)))
        prev_frame = frame

        blocking, banding = calculate_blocking_banding_rates_from_frame(frame)
        if blocking and banding:
            blocking_rate.append(float(blocking))
            banding_rate.append(float(banding))

        blur_score = detect_blur(frame)
        if blur_score:
            blur.append(blur_score)

        bs = compute_blur(frame)
        if bs:
            bs_list.append(bs)

        # bs = compute_blur(frame)
        # x=blur_score.append(bs)
        # print("*******************************************",x)

    c = datetime.now()
    timestamp = c.strftime("%d%m_%H%M%S")
    connection_speed = f"{measure_connection_speed(video_url)}KB/s"
    network_activity = measure_network_activity(video_url)
    # latency = measure_latency(video_url)
    avg_bs = sum(bs_list) / len(bs_list) if bs_list else 0
    # print(avg_bs)
    max_psnr = max(psnr_value)
    min_psnr = min(psnr_value)
    avg_ssim = sum(ssim_score) / len(ssim_score) if ssim_score else 0
    # print(avg_ssim)

    avg_psnr = sum(psnr_value) / len(psnr_value)
    norm_psnr = ((avg_psnr - min_psnr) / (max_psnr - min_psnr)) * 100
    # print(norm_psnr)
    # print(max(bs_list))
    if avg_bs >= 100:
        norm_bs = 100
    else:
        norm_bs = avg_bs

    avg_blocking_rate = sum(blocking_rate) / len(blocking_rate)
    avg_banding_rate = sum(banding_rate) / len(banding_rate)

    # Quality_Score = ((0.3572 * (100 - avg_blocking_rate)) + (0.2857 * (100 - avg_banding_rate)) + (0.119 * norm_bs) + (
    #             0.0595 * norm_psnr) + (0.1786 * (100 - drop_percentage)))
    # print(Quality_Score)
    # Quality_Score = ((0.25 * (100 - avg_blocking_rate)) + (0.20 * (100 - avg_banding_rate)) + (
    #         0.30 * avg_ssim) + (0.10 * norm_bs) + (0.05 * norm_psnr) + (
    #                          0.10 * (100 - drop_percentage)))
    Quality_Score = ((0.2 * (100 - avg_blocking_rate)) + (0.2 * (100 - avg_banding_rate)) + (
            0.30 * avg_ssim) + (0.25 * norm_bs) + (0.05 * norm_psnr))
    if avg_ssim < 0.8:
        macroblocking = "Macroblocking Detected"
    else:
        macroblocking = "No Macroblocking"

    threshold_blur = 150
    blur_frames = sum(value > threshold_blur for value in bs_list)
    print(blur_frames)

    threshold_macroblocking = 0.8
    macroblocking_frames = sum(value < threshold_macroblocking for value in ssim_score)
    print(macroblocking_frames)

    # print(drop_percentage)
    result = {"Resolution": resolution, "FPS": fps, "black_frames": len(black_frames),
              "Avg_PSNR_Value": round(sum(psnr_value) / len(psnr_value), 2),
              "Blocking_Rate": str(round(sum(blocking_rate) / len(blocking_rate), 2)),
              "Banding_Rate": str(round(sum(banding_rate) / len(banding_rate), 2)),
              "Blur Detected": blur, "time_stamp": timestamp, "connection_speed": connection_speed,
              "network_activity": network_activity, "Quality_Score": round(Quality_Score, 2),
              "Blur_Score": round(avg_bs, 2), "Dropped_Frames": frames_dropped, "ssim_score": round(avg_ssim, 2),
              "macro_blocking": macroblocking}
    print(result)

    if blur == []:
        blur_status = "No Blur"
    else:
        blur_status = "Blur Detected"
    #file_path = f"/home/user/JC_5_Agent_8/Agent8Server_LiveVideoQuality/workspace/Agent8Server/csv_files/{trigger_id}.csv"
    file_path = f'/home/sysuser/Documents/Project_M/AgentEtisalat_VideoQuality/workspace/AgentEtisalat/csv_files/{trigger_id}.csv'
    data_to_append = [
        [timestamp, (round(Quality_Score, 2)), resolution, fps, len(black_frames),
         (round(sum(psnr_value) / len(psnr_value), 2)), (str(round(sum(blocking_rate) / len(blocking_rate), 2))),
         (str(round(sum(banding_rate) / len(banding_rate), 2))), blur_status, connection_speed, network_activity,
         round(avg_bs, 2), frames_dropped, (round(avg_ssim, 2)), macroblocking, bit_rate, codec, blur_frames, macroblocking_frames]]
    if not os.path.exists(file_path):
        # If the file doesn't exist, write the column names
        with open(file_path, 'w', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            # Specify column names
            column_names = ['Timestamp', 'Quality Score', 'Resolution', 'FPS', 'black_frames', 'Average PSNR',
                            'Blocking Rate', 'Banding Rate', 'Blur Detection', 'Connection Speed', 'Data Used',
                            'Blur Score', 'Dropped Frames', 'SSIM Score', 'Macroblocking', 'Bit Rate', 'Codec', 'Blur Frames', 'Macroblocking Frames']
            print(len(column_names))
            csv_writer.writerow(column_names)
            csv_writer = csv.writer(csv_file)

            # Append the data to the CSV file
            csv_writer.writerows(data_to_append)
    else:
        # If the file exists, open it in append mode
        with open(file_path, 'a', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)

            # Append the data to the CSV file
            csv_writer.writerows(data_to_append)
    print(f'Data appended to CSV file at: {file_path}')

    # print(f'Data appended to CSV file at: {file_path}')

    return result
def post_data_generate_vq_report(data):
    # http://3.111.103.153:5003/GenerateReport_Et?exc_cmd5={%22trigger_id%22:%2012345,%20%22agent_id%22:%20%22Agent8Server_LiveVideoQuality%22,%20%22action%22:%20%22generate_report%22}

    print("sending data to jc")
    print(data)
    url = "http://" + jc5_ip + "/GenerateReport_Et?exc_cmd5="
    data_1 = json.dumps(data)
    print(url + data_1)
    try:
        x = requests.post(url + data_1)
    except Exception as e:
        print(e)
        status = "Sending data to jc failed due to some technical issue"
    else:
        status = x.text
    return status


def post_vq_report_status_db(data):
    # 3.111.103.153:5000/insertdata_video_quality_dashboard?exc_cmd={"trigger_id": "12222", "video_details": "youtube", "status":"Pending", "locked_by":"mounika"}

    db_ip = "43.205.56.231:5000"
    print("sending data to jc")
    print(data)
    url = "http://" + db_ip + "/insertdata_video_quality_dashboard?exc_cmd="
    data_1 = json.dumps(data)
    print(url + data_1)
    try:
        x = requests.post(url + data_1)
    except Exception as e:
        print(e)
        status = "Sending status to DB failed due to some technical issue"
    else:
        status = x.text

    # print(status)
    return status



def capture_and_save_image(output_path):
    cap = cv2.VideoCapture(0)  # 0 for default camera, change if needed

    # Check if the camera is opened successfully
    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    # Capture frame-by-frame
    ret, frame = cap.read()

    # If the frame is read correctly, save it
    if ret:
        cv2.imwrite(output_path, frame)
        print(f"Image saved to {output_path}")

    # Release the camera
    cap.release()

# capture_and_save_image("/home/user/JC_5_Agent_8/black_screen.jpg")

# video_metrics("udp://239.200.1.1:5500",1, 123467)
