import matplotlib
import pandas as pd
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
import matplotlib.pyplot as plt
matplotlib.use('Agg')
import seaborn as sns
from PIL import Image
import re
from datetime import datetime

def convert_csv_to_pdf(trigger_id, case, case_type):
    # Read your CSV file into a DataFrame
    csv_file_path = f'/home/sysuser/Documents/Project_M/AgentEtisalat_VideoQuality/workspace/AgentEtisalat/csv_files/{trigger_id}.csv'  # Replace with the actual path to your CSV file
    df = pd.read_csv(csv_file_path, parse_dates=['Timestamp'])
    #df = pd.read_csv(csv_file_path, parse_dates=['Timestamp'], date_parser=lambda x: datetime.strptime(x, '%d%m_%H%M%S'))


    # Set up PDF
    pdf_path = f'/home/sysuser/Documents/Project_M/AgentEtisalat_VideoQuality/workspace/AgentEtisalat/pdf_files/{trigger_id}.pdf'
    logo_path = 'EvQUAL_Logo.png'  # replace with the actual path to your logo image

    # Create PDF with border
    c = canvas.Canvas(pdf_path, pagesize=letter)
    c.setStrokeColorRGB(0, 0, 0)

    # Add logo and heading to the first page with a transparent background
    logo_height = 35
    c.drawInlineImage(logo_path, letter[0] - 200, letter[1] - 50 - logo_height, width=160, height=logo_height)
    c.setFillColorRGB(1, 1, 0)
    c.roundRect(30, letter[1] - 120, letter[0] - 60, 20, 4, fill=True, stroke=False)

    # Add current date under the yellow color bar
    current_date = datetime.now().strftime("Date: %d-%m-%Y %H:%M")
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica", 10)
    c.drawString(35, letter[1] - 140, current_date)

    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(letter[0] / 2, letter[1] - 120, "VIDEO QUALITY ANALYSIS REPORT")

    # Draw a light blue box
    c.setFillColorRGB(0.8, 0.9, 1)
    box_x = 30
    box_y = letter[1] - 310
    box_width = letter[0] - 60
    box_height = 150
    c.rect(box_x, box_y, box_width, box_height, fill=True, stroke=False)

    # Draw a border for the first page
    c.rect(10, 10, letter[0] - 20, letter[1] - 20)

    # Extract numeric values from columns and calculate averages
    connection_speed_values = df['Connection Speed'].apply(lambda x: re.findall(r'\d+\.\d+', str(x)))
    numeric_values_connection_speed = [float(value[0]) for value in connection_speed_values if value]
    average_connection_speed = sum(numeric_values_connection_speed) / len(
        numeric_values_connection_speed) if numeric_values_connection_speed else 0

    data_used_values = df['Data Used'].apply(lambda x: re.findall(r'\d+\.\d+', str(x)))
    numeric_values_data_used = [float(value[0]) for value in data_used_values if value]
    average_data_used = sum(numeric_values_data_used) / len(numeric_values_data_used) if numeric_values_data_used else 0

    total_dropped_frames = df['Dropped Frames'].sum()
    total_blurred_frames = df['Blur Frames'].sum()
    total_macroblocking_frames = df['Macroblocking Frames'].sum()
    total_black_frames = df['black_frames'].sum()

    average_quality_score = df['Quality Score'].mean()
    average_blocking_rate = df['Blocking Rate'].mean()
    average_banding_rate = df['Banding Rate'].mean()
    average_blur_score = df['Blur Score'].mean()

    start_time = df.at[0, 'Timestamp']
    end_time = df.at[df.index[-1], 'Timestamp']

    format_str = '%d%m_%H%M%S'
    try:
        start_time = datetime.strptime(str(start_time), format_str)
        end_time = datetime.strptime(str(end_time), format_str)
    except ValueError as e:
        print(f"Error parsing date: {e}")
        # Handle the error, e.g., set default values or log the issue
        start_time = datetime.now()
        end_time = datetime.now()

    # start_time = datetime.strptime(start_time, format_str)
    # end_time = datetime.strptime(end_time, format_str)

    time_difference = end_time - start_time

    hours, remainder = divmod(time_difference.total_seconds(), 3600)
    minutes, seconds = divmod(remainder, 60)

    formatted_time = '{:02}:{:02}:{:02}'.format(int(hours), int(minutes), int(seconds))

    if average_quality_score < 40:
        quality = "Low Quality"
    elif average_quality_score < 65:
        quality = "Medium Quality"
    else:
        quality = "High Quality"

    parameters_left = {
        case: f'{case_type}',
        "Duration": f'{formatted_time}',
        "Visual Perception Score": f"{average_quality_score:.2f} ({quality})",
        "Average Bit Rate": f"{df.at[0, 'Bit Rate']} kbps",
        "Network Speed": f"{average_connection_speed:.2f} KB/s",
        "Data Used": f"{average_data_used:.2f} KB",
    }

    parameters_right = {
        "Blurred Frames": total_blurred_frames,
        "Total Black Frames": total_black_frames,
        "Total Dropped Frames": total_dropped_frames,
        # "Codec": df.at[0, 'Codec'],
        "Codec": "h264",
        "Macroblocking Frames": total_macroblocking_frames,
    }

    middle_x = box_x + box_width / 2
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica", 12)
    y_position_left = box_y + box_height - 20
    for key, value in parameters_left.items():
        c.setFont("Helvetica-Bold", 10)
        c.drawString(box_x + 10, y_position_left, f"{key}:")
        c.setFont("Helvetica", 10)
        c.drawString(box_x + 150, y_position_left, f"{value}")
        y_position_left -= 20

    y_position_right = y_position_left - 0
    for key, value in parameters_right.items():
        y_position_right += 20
        c.setFont("Helvetica-Bold", 10)
        c.drawString(middle_x + 10, y_position_right, f"{key}:")
        c.setFont("Helvetica", 10)
        c.drawString(middle_x + 150, y_position_right, f"{value}")

    # Create an area plot for Quality Score
    sns.set(style="whitegrid")
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y='Quality Score', data=df, color="skyblue", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1=df['Quality Score'], color="skyblue", alpha=0.3)
    plt.title('Visual Perception Score Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Visual Perception Score')

    image_stream_quality = BytesIO()
    plt.savefig(image_stream_quality, format='png', bbox_inches='tight')
    plt.close()

    image_stream_quality.seek(0)
    image_pil_quality = Image.open(image_stream_quality)
    image_pil_quality.save('output_plot_quality.png', format='PNG')

    graph_horizontal_position_quality = letter[0] - 30 - 500
    graph_vertical_position_quality = box_y - 210
    c.drawInlineImage('output_plot_quality.png', graph_horizontal_position_quality, graph_vertical_position_quality,
                      width=400, height=200)

    # Create an area plot for Data Used on the first page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y=numeric_values_data_used, data=df, color="lightcoral", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1=numeric_values_data_used, color="lightcoral", alpha=0.3)
    plt.title('Data Used Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Data Used (KB)')

    image_stream_data_used = BytesIO()
    plt.savefig(image_stream_data_used, format='png', bbox_inches='tight')
    plt.close()

    image_stream_data_used.seek(0)
    image_pil_data_used = Image.open(image_stream_data_used)
    image_pil_data_used.save('output_plot_data_used.png', format='PNG')

    graph_horizontal_position_data_used = graph_horizontal_position_quality
    graph_vertical_position_data_used = box_y - 410
    c.drawInlineImage('output_plot_data_used.png', graph_horizontal_position_data_used, graph_vertical_position_data_used,
                      width=400, height=200)

    # Save the first page
    c.showPage()

    # Create the second page with borders
    c.setStrokeColorRGB(0, 0, 0)
    c.rect(10, 10, letter[0] - 20, letter[1] - 20)

    # Create an area plot for Connection Speed on the second page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y=numeric_values_connection_speed, data=df, color="lightgreen", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1=numeric_values_connection_speed, color="lightgreen", alpha=0.3)
    plt.title('Connection Speed Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Connection Speed (KB/s)')

    image_stream_connection_speed = BytesIO()
    plt.savefig(image_stream_connection_speed, format='png', bbox_inches='tight')
    plt.close()

    image_stream_connection_speed.seek(0)
    image_pil_connection_speed = Image.open(image_stream_connection_speed)
    image_pil_connection_speed.save('output_plot_connection_speed.png', format='PNG')

    graph_horizontal_position_connection_speed = letter[0] - 30 - 500
    graph_vertical_position_connection_speed = letter[1] - 250
    c.drawInlineImage('output_plot_connection_speed.png', graph_horizontal_position_connection_speed,
                      graph_vertical_position_connection_speed, width=400, height=200)

    # Create an area plot for Banding Rate on the second page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y='Banding Rate', data=df, color="lightcoral", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1='Banding Rate', data=df, color="lightcoral", alpha=0.3)
    plt.title('Banding Rate Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Banding Rate')

    image_stream_banding_rate = BytesIO()
    plt.savefig(image_stream_banding_rate, format='png', bbox_inches='tight')
    plt.close()

    image_stream_banding_rate.seek(0)
    image_pil_banding_rate = Image.open(image_stream_banding_rate)
    image_pil_banding_rate.save('output_plot_banding_rate.png', format='PNG')

    graph_horizontal_position_banding_rate = graph_horizontal_position_connection_speed
    graph_vertical_position_banding_rate = graph_vertical_position_connection_speed - 210
    c.drawInlineImage('output_plot_banding_rate.png', graph_horizontal_position_banding_rate,
                      graph_vertical_position_banding_rate, width=400, height=200)

    # Create an area plot for Blocking Rate on the second page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y='Blocking Rate', data=df, color="lightgreen", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1='Blocking Rate', data=df, color="lightgreen", alpha=0.3)
    plt.title('Blocking Rate Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Blocking Rate')

    image_stream_blocking_rate = BytesIO()
    plt.savefig(image_stream_blocking_rate, format='png', bbox_inches='tight')
    plt.close()

    image_stream_blocking_rate.seek(0)
    image_pil_blocking_rate = Image.open(image_stream_blocking_rate)
    image_pil_blocking_rate.save('output_plot_blocking_rate.png', format='PNG')

    graph_horizontal_position_blocking_rate = graph_horizontal_position_banding_rate
    graph_vertical_position_blocking_rate = graph_vertical_position_banding_rate - 210
    c.drawInlineImage('output_plot_blocking_rate.png', graph_horizontal_position_blocking_rate,
                      graph_vertical_position_blocking_rate, width=400, height=200)

    # Save the second page
    c.showPage()

    # Create the third page with borders
    c.setStrokeColorRGB(0, 0, 0)
    c.rect(10, 10, letter[0] - 20, letter[1] - 20)

    # Create an area plot for Blur Score on the third page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y='Blur Score', data=df, color="skyblue", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1='Blur Score', data=df, color="skyblue", alpha=0.3)
    plt.title('Blur Score Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Blur Score')

    image_stream_blur_score = BytesIO()
    plt.savefig(image_stream_blur_score, format='png', bbox_inches='tight')
    plt.close()

    image_stream_blur_score.seek(0)
    image_pil_blur_score = Image.open(image_stream_blur_score)
    image_pil_blur_score.save('output_plot_blur_score.png', format='PNG')

    graph_horizontal_position_blur_score = graph_horizontal_position_banding_rate
    graph_vertical_position_blur_score = graph_vertical_position_banding_rate + 200
    c.drawInlineImage('output_plot_blur_score.png', graph_horizontal_position_blur_score,
                      graph_vertical_position_blur_score, width=400, height=200)

    # Create an area plot for Dropped Frames on the third page
    plt.figure(figsize=(8, 4))
    sns.lineplot(x='Timestamp', y='Dropped Frames', data=df, color="lightgreen", alpha=0.7)
    plt.fill_between(x=df['Timestamp'], y1='Dropped Frames', data=df, color="lightgreen", alpha=0.3)
    plt.title('Dropped Frames Over Time')

    plt.xlabel('Timestamp')
    plt.xticks(rotation='vertical', fontsize=7)
    plt.ylabel('Dropped Frames')

    image_stream_dropped_frames = BytesIO()
    plt.savefig(image_stream_dropped_frames, format='png', bbox_inches='tight')
    plt.close()

    image_stream_dropped_frames.seek(0)
    image_pil_dropped_frames = Image.open(image_stream_dropped_frames)
    image_pil_dropped_frames.save('output_plot_dropped_frames.png', format='PNG')

    graph_horizontal_position_dropped_frames = graph_horizontal_position_blur_score
    graph_vertical_position_dropped_frames = graph_vertical_position_blur_score - 210
    c.drawInlineImage('output_plot_dropped_frames.png', graph_horizontal_position_dropped_frames,
                      graph_vertical_position_dropped_frames, width=400, height=200)

    # Save the third page
    c.showPage()

    # Save the PDF file
    c.save()

    # Close image streams
    image_stream_quality.close()
    image_stream_data_used.close()
    image_stream_connection_speed.close()
    image_stream_banding_rate.close()
    image_stream_blocking_rate.close()
    image_stream_blur_score.close()
    image_stream_dropped_frames.close()

    print(f"PDF generated successfully: {pdf_path}")

# Example usage
# convert_csv_to_pdf('trigger_id', 'Case', 'Live Stream')
# convert_csv_to_pdf(847554, "url", "https://www.sample-videos.com/video321/mp4/720/big_buck_bunny_720p_50mb.mp4")
